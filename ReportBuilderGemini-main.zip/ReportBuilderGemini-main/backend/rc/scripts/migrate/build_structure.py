#!/usr/bin/env python3
"""
گام ۲ فاز ۰ — تبدیل references/schemas/*.md به kb/structure/*.yaml
                + استنتاج گراف FK از قرارداد نام‌گذاری

چرا استنتاج لازم است:
    خروجی فعلی FK ندارد. بدون گراف JOIN، بازیابی و تولید کوئری کار نمی‌کند.
    ولی دیتابیس قرارداد منظمی دارد:
        PK:  <TableName>ID        (۹۶٪ جدول‌ها)
        FK:  <TargetTable>Ref  →  <TargetTable>.<TargetTable>ID

سطوح اطمینان یال‌ها:
    high    تطبیق دقیق نام + مقصد یکتا + هم‌schema
    medium  تطبیق دقیق ولی بین‌schema، یا تطبیق پسوندی (PayerAccountRef → Account)
    low     چند مقصد ممکن (نام جدول در چند schema تکرار شده)
    —       حل‌نشده → به لیست «نیازمند تأیید» می‌رود

⚠️ هیچ یال استنتاجی «حقیقت» نیست. همه با source: inferred_from_naming علامت
   می‌خورند و باید با اسکریپت استخراج در SSMS تأیید شوند.

استفاده:
    python3 build_structure.py --src <schemas-dir> --out <kb-dir>
"""

from __future__ import annotations

import argparse
import collections
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("نیاز به PyYAML:  pip install pyyaml")


# ─────────────────────────── الگوها ───────────────────────────

TABLE_SPLIT = re.compile(r"^## ([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)", re.M)
COLUMN = re.compile(r"^- `([A-Za-z0-9_]+)` — (.+?) \[([^\]]*)\]\s*$", re.M)
ROWCOUNT = re.compile(r"\(~([\d,]+) ردیف\)")
CAMEL = re.compile(r"[A-Z][a-z0-9]*|[A-Z]+(?![a-z])")


# ─────────────────────────── پارس ───────────────────────────

def parse_schema_file(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8")
    parts = TABLE_SPLIT.split(text)
    out = []
    for i in range(1, len(parts), 3):
        schema, table, body = parts[i], parts[i + 1], parts[i + 2]

        columns, pk = [], []
        for ordinal, (name, dtype, flags) in enumerate(COLUMN.findall(body), 1):
            is_pk = "PK" in flags
            columns.append({
                "name": name,
                "type": dtype.strip(),
                "nullable": "NOT NULL" not in flags,
                "ordinal": ordinal,
                **({"is_pk": True} if is_pk else {}),
            })
            if is_pk:
                pk.append(name)

        rc = ROWCOUNT.search(body.split("\n", 1)[0])

        # fallback: schemaهای قدیمی (ACC, GNR, RPA, FMK) نشانگر [PK] ندارند.
        # اگر ستون اول <TableName>Id/ID باشد، آن را PK حدسی می‌گیریم.
        pk_inferred = False
        if not pk and columns:
            first = columns[0]["name"]
            if first.lower() == f"{table}id".lower():
                pk = [first]
                first_col = columns[0]
                first_col["is_pk"] = True
                pk_inferred = True

        out.append({
            "schema": schema,
            "name": table,
            "columns": columns,
            "primary_key": pk,
            **({"pk_source": "inferred_from_naming"} if pk_inferred else {}),
            # تعداد ردیف = داده‌ی instance، نه canonical → جدا نگه داشته می‌شود
            "_row_count": int(rc.group(1).replace(",", "")) if rc else None,
        })
    return out


# ─────────────────────────── استنتاج FK ───────────────────────────

class JoinGraphInferrer:
    def __init__(self, tables: list[dict]):
        self.pk_of = {
            (t["schema"], t["name"]): t["primary_key"][0]
            for t in tables if len(t["primary_key"]) == 1
        }
        self.by_name: dict[str, list[tuple[str, str, str]]] = collections.defaultdict(list)
        for (schema, name), pk in self.pk_of.items():
            self.by_name[name.lower()].append((schema, name, pk))
        self.unresolved = collections.Counter()

    def _lookup(self, base: str, schema: str, table: str):
        """برمی‌گرداند: (روش, کاندیداها)"""
        if base.lower() == "parent":
            pk = self.pk_of.get((schema, table))
            return ("self", [(schema, table, pk)]) if pk else (None, [])

        if hits := self.by_name.get(base.lower()):
            return "exact", hits

        # تطبیق پسوندی: PayerAccountRef → Account، BaseCurrencyRef → Currency
        words = CAMEL.findall(base)
        for i in range(1, len(words)):
            if hits := self.by_name.get("".join(words[i:]).lower()):
                return "suffix", hits

        return None, []

    @staticmethod
    def _generation(schema: str) -> str:
        """دیتابیس دو نسل دارد: schemaهای *3 مدرن، بقیه قدیمی."""
        return "modern" if schema.endswith("3") else "legacy"

    @classmethod
    def _pick(cls, candidates, schema):
        """
        اولویت: ۱) هم‌schema  ۲) هم‌نسل  ۳) اولین

        قانون هم‌نسلی روی ۷۴۹۲ FK واقعی اندازه‌گیری شد:
        بدون آن ۹۱.۵٪ — با آن ۹۶.۴٪.
        علت: جدول‌هایی مثل FiscalYear و BankAccount در هر دو نسل
        وجود دارند و بدون این قانون انتخاب تصادفی می‌شد.
        """
        if same := [c for c in candidates if c[0] == schema]:
            return same[0], len(same) > 1

        my_gen = cls._generation(schema)
        if same_gen := [c for c in candidates if cls._generation(c[0]) == my_gen]:
            return same_gen[0], len(same_gen) > 1

        return candidates[0], len(candidates) > 1

    def infer(self, tables: list[dict]) -> list[dict]:
        edges = []
        for t in tables:
            schema, name = t["schema"], t["name"]
            for col in t["columns"]:
                cname = col["name"]
                if not cname.endswith("Ref"):
                    continue

                method, candidates = self._lookup(cname[:-3], schema, name)
                if method is None:
                    self.unresolved[cname[:-3]] += 1
                    continue

                (tgt_schema, tgt_table, tgt_pk), ambiguous = self._pick(candidates, schema)

                # سطوح بر اساس اندازه‌گیری واقعی روی ۷۴۹۲ FK:
                #   هم‌schema دقیق  → ۹۸.۴٪
                #   هم‌نسل / پسوندی → ۹۳.۷٪
                #   مبهم بدون تکیه‌گاه → ۸.۸٪
                same_schema = tgt_schema == schema
                same_gen = self._generation(tgt_schema) == self._generation(schema)

                if method == "self" or (method == "exact" and same_schema):
                    confidence = "high"
                elif method == "exact" and same_gen and not ambiguous:
                    confidence = "high"
                elif ambiguous and not same_gen:
                    confidence = "low"
                else:
                    confidence = "medium"

                edge = {
                    "from": f"{schema}.{name}.{cname}",
                    "to": f"{tgt_schema}.{tgt_table}.{tgt_pk}",
                    "method": method,
                    "source": "inferred_from_naming",
                    "confidence": confidence,
                    "verified": False,
                }
                if ambiguous:
                    edge["alternatives"] = [
                        f"{s}.{t2}.{p}" for s, t2, p in candidates
                        if (s, t2) != (tgt_schema, tgt_table)
                    ][:4]
                edges.append(edge)
        return edges


# ─────────────────────────── نوشتن ───────────────────────────

def dump_yaml(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=200),
        encoding="utf-8",
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, type=Path, help="پوشه‌ی schemas/*.md ماسک‌شده")
    ap.add_argument("--out", required=True, type=Path, help="ریشه‌ی kb/")
    ap.add_argument("--instance", type=Path, help="پوشه‌ی instances/<customer>/ برای آمار ردیف")
    args = ap.parse_args()

    files = sorted(args.src.glob("*.md"))
    if not files:
        print(f"هیچ فایل .md در {args.src} نیست", file=sys.stderr)
        return 1

    all_tables = []
    for f in files:
        all_tables.extend(parse_schema_file(f))

    # ── ۱. ساختار canonical ──
    by_schema = collections.defaultdict(list)
    for t in all_tables:
        by_schema[t["schema"]].append(t)

    for schema, tabs in sorted(by_schema.items()):
        dump_yaml(args.out / "structure" / f"{schema}.yaml", {
            "schema": schema,
            "table_count": len(tabs),
            "note": "تولیدشده از خروجی SSMS — دستی ویرایش نکنید. معنا در kb/semantics/ است.",
            "tables": [
                {k: v for k, v in t.items() if not k.startswith("_") and k != "schema"}
                for t in sorted(tabs, key=lambda x: x["name"])
            ],
        })

    # ── ۲. گراف JOIN استنتاجی ──
    inferrer = JoinGraphInferrer(all_tables)
    edges = inferrer.infer(all_tables)

    conf = collections.Counter(e["confidence"] for e in edges)
    dump_yaml(args.out / "joins" / "inferred.yaml", {
        "note": (
            "یال‌های استنتاجی از قرارداد نام‌گذاری *Ref → <Table>.<Table>ID. "
            "هیچ‌کدام با دیتابیس تأیید نشده‌اند (verified: false). "
            "برای تأیید، scripts/extract/01-foreign-keys.sql را در SSMS اجرا کنید."
        ),
        "summary": {
            "total_edges": len(edges),
            "by_confidence": dict(conf),
            "unresolved_ref_columns": sum(inferrer.unresolved.values()),
        },
        "edges": edges,
    })

    # ── ۳. لیست حل‌نشده‌ها (اولویت تأیید دستی) ──
    dump_yaml(args.out / "joins" / "unresolved.yaml", {
        "note": (
            "ستون‌های *Ref که مقصدشان از روی نام قابل تشخیص نبود. "
            "بیشترشان ارجاع چندریختی‌اند (مقصد به یک ستون نوع بستگی دارد) "
            "و فقط با بررسی داده یا FK واقعی مشخص می‌شوند."
        ),
        "items": [
            {"base_name": name, "occurrences": count}
            for name, count in inferrer.unresolved.most_common()
        ],
    })

    # ── ۴. آمار ردیف → لایه‌ی instance (محرمانه) ──
    if args.instance:
        dump_yaml(args.instance / "table-stats.yaml", {
            "note": "داده‌ی این نصب — قابل اشتراک نیست. برای تشخیص ماژول‌های فعال.",
            "tables": {
                f"{t['schema']}.{t['name']}": t["_row_count"]
                for t in all_tables if t["_row_count"] is not None
            },
        })

    # ── گزارش ──
    ncols = sum(len(t["columns"]) for t in all_tables)
    with_pk = sum(1 for t in all_tables if t["primary_key"])
    print(f"✔ {len(by_schema)} schema  |  {len(all_tables)} جدول  |  {ncols} ستون")
    print(f"  PK شناسایی‌شده: {with_pk}  ({with_pk*100//len(all_tables)}%)")
    print(f"\n  یال JOIN استنتاجی: {len(edges)}")
    for level in ("high", "medium", "low"):
        n = conf.get(level, 0)
        print(f"    {level:8} {n:>5}  ({n*100//max(len(edges),1)}%)")
    print(f"  ستون *Ref حل‌نشده: {sum(inferrer.unresolved.values())}")
    print(f"\n  → {args.out}/structure/  |  {args.out}/joins/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
