#!/usr/bin/env python3
"""
فاز ۳ — ساخت لایه‌ی معنایی

ورودی:
    lookups.json              نگاشت قطعی enum از SYS3.Lookup
    enum-observed.yaml        توزیع واقعی مقادیر در این نصب
    entity-catalog.csv        نام فارسی موجودیت‌ها
    hcm3-table-titles.csv     عنوان جدول‌های HCM3
    lookup-values.csv         ⚠️ فقط برای مقایسه — OrdinalInType ≠ Code

خروجی:
    kb/enums/<SCHEMA>.yaml      معنای مقادیر با منشأ و اطمینان
    kb/semantics/<SCHEMA>.yaml  عنوان فارسی جدول‌ها
    kb/enums/_review.yaml       صف بازبینی دستی

منطق اطمینان (enum):
    proven_by_data   مقدار هم در lookup هست، هم در داده دیده شده
    stated_by_config مقدار در lookup هست ولی در این نصب دیده نشده
    unknown          مقدار در داده هست ولی lookup توضیحش نمی‌دهد ← پرچم قرمز
"""

from __future__ import annotations

import argparse
import collections
import csv
import json
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("نیاز به PyYAML:  pip install pyyaml")


def load_json_loose(path: Path):
    """خروجی SSMS: BOM، نام ستون خودکار، شکستن در چند خط."""
    text = path.read_text(encoding="utf-8-sig")
    starts = [i for i in (text.find("["), text.find("{")) if i != -1]
    ends = [i for i in (text.rfind("]"), text.rfind("}")) if i != -1]
    if not starts or not ends:
        return []
    text = "".join(l.strip() for l in text[min(starts):max(ends) + 1].splitlines())
    return json.loads(text)


def dump_yaml(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=200),
        encoding="utf-8",
    )


# ─────────────────────────── enum ───────────────────────────

def build_enums(lookups_path: Path, observed_path: Path, kb: Path) -> dict:
    rows = load_json_loose(lookups_path)

    # type -> {code: label}   — فقط نوع‌های نام‌دار؛ عددی‌ها پویا/کاربرتعریف‌اند
    lk: dict[str, dict[str, str]] = collections.defaultdict(dict)
    for r in rows:
        if r["kind"] == "enum_value" and not r.get("type", "").isdigit():
            lk[r["type"]][r.get("code")] = (r.get("value") or "").strip()

    type_title = {
        r["type"]: r["value"]
        for r in rows
        if r["kind"] == "enum_type" and not r.get("type", "").isdigit()
    }

    observed = {
        c["column"]: c["distribution"]
        for c in yaml.safe_load(observed_path.read_text(encoding="utf-8"))["columns"]
    }

    by_schema = collections.defaultdict(list)
    review: list[dict] = []
    stats = collections.Counter()

    def choose_type(table: str, column: str, seen: set[str]):
        """
        انتخاب نوع lookup میان کاندیداها.

        ⚠️ ترتیب ثابت «اول نام ستون» غلط بود:
           BDG3.BudgetEntity.State مقادیر 1,2,3 دارد.
             نوع عمومی State        → 0=غیر فعال, 1=فعال      (پوشش ۱ از ۳)
             نوع BudgetEntityState  → 1=موقت, 2=تایید, 3=صادر (پوشش ۳ از ۳)
           در ۳۷ ستون از ۴۰ ستونِ دارای هر دو نوع، معنا متفاوت بود.

        معیار: پوشش مقادیر واقعاً مشاهده‌شده. در تساوی، نوع اختصاصی‌تر برنده است.
        """
        candidates = [c for c in (table + column, column) if c in lk]
        if not candidates:
            return None, False
        if len(candidates) == 1:
            return candidates[0], False

        scored = [(len(seen & set(lk[c])), -i, c) for i, c in enumerate(candidates)]
        scored.sort(reverse=True)
        best = scored[0][2]
        # اگر معناها یکی نیستند و انتخاب بر پایه‌ی داده نبوده، پرچم بزن
        ambiguous = (
            lk[candidates[0]] != lk[candidates[1]]
            and scored[0][0] == scored[1][0]
        )
        return best, ambiguous

    for col_key, dist in sorted(observed.items()):
        schema, table, column = col_key.split(".", 2)

        nullable = "<NULL>" in dist
        seen = {v for v in dist if v != "<NULL>"}
        lookup_type, ambiguous = choose_type(table, column, seen)

        if lookup_type is None:
            stats["بدون تطابق"] += 1
            entry = {
                "table": table,
                "column": column,
                **({"nullable": True} if nullable else {}),
                "lookup_type": None,
                "values": [
                    {"value": v, "label_fa": None, "source": "unknown",
                     "confidence": "low", "observed_count": dist[v]}
                    for v in sorted(seen, key=lambda x: (len(x), x))
                ],
            }
            if seen:
                review.append({
                    "column": col_key,
                    "reason": "نوع lookup پیدا نشد",
                    "observed_values": sorted(seen, key=lambda x: (len(x), x)),
                })
        else:
            mapping = lk[lookup_type]
            values = []
            unexplained = []
            for code in sorted(set(mapping) | seen, key=lambda x: (len(x), x)):
                label = mapping.get(code)
                cnt = dist.get(code)
                if label is not None and cnt is not None:
                    src, conf = "proven_by_data", "high"
                    stats["اثبات‌شده"] += 1
                elif label is not None:
                    src, conf = "stated_by_config", "high"
                    stats["از پیکربندی"] += 1
                else:
                    src, conf = "unknown", "low"
                    unexplained.append(code)
                    stats["توضیح‌داده‌نشده"] += 1
                v = {"value": code, "label_fa": label, "source": src, "confidence": conf}
                if cnt is not None:
                    v["observed_count"] = cnt
                values.append(v)

            entry = {
                "table": table,
                "column": column,
                **({"nullable": True} if nullable else {}),
                "lookup_type": lookup_type,
                **({"type_title_fa": type_title[lookup_type]}
                   if lookup_type in type_title else {}),
                **({"ambiguous_type": True} if ambiguous else {}),
                "values": values,
            }
            if unexplained:
                review.append({
                    "column": col_key,
                    "reason": "مقادیری در داده هست که lookup توضیحشان نمی‌دهد",
                    "unexplained": unexplained,
                    "lookup_type": lookup_type,
                })
            if ambiguous:
                review.append({
                    "column": col_key,
                    "reason": "چند نوع lookup ممکن با معنای متفاوت — داده تفکیک نکرد",
                    "chosen": lookup_type,
                    "alternatives": [c for c in (table + column, column)
                                     if c in lk and c != lookup_type],
                })

        by_schema[schema].append(entry)

    for schema, items in by_schema.items():
        dump_yaml(kb / "enums" / f"{schema}.yaml", {
            "schema": schema,
            "source": "SYS3.Lookup + توزیع مشاهده‌شده",
            "note": (
                "⚠️ lookup-values.csv ستون OrdinalInType دارد که ترتیب نمایش است، "
                "نه مقدار ذخیره‌شده. مرجع این فایل SYS3.Lookup.Code است."
            ),
            "enums": items,
        })

    if review:
        dump_yaml(kb / "enums" / "_review.yaml", {
            "note": "نیازمند بررسی دستی. label_fa را پر کنید و source را به stated_by_user تغییر دهید.",
            "count": len(review),
            "items": review,
        })

    return stats


# ─────────────────────────── معنا (عنوان جدول‌ها) ───────────────────────────

RESOURCE_KEY = re.compile(r"^[A-Za-z][\w.]*[:,][\w.]*$")   # SystemGroup.ECM…:Reminder_EntityName


def build_semantics(glossary: Path, kb: Path) -> dict:
    titles: dict[tuple[str, str], tuple[str, str]] = {}   # (schema,table) -> (عنوان, منبع)
    stats = collections.Counter()

    # ۱. HCM3 — مستقیم و قابل اعتماد
    p = glossary / "hcm3-table-titles.csv"
    if p.exists():
        with p.open(encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                titles[(r["Schema"], r["Table"])] = (r["PersianTitle"].strip(), "glossary_hcm3")
                stats["hcm3"] += 1

    # ۲. کاتالوگ موجودیت‌ها
    p = glossary / "entity-catalog.csv"
    if p.exists():
        with p.open(encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                schema = (r.get("MappedSchema") or "").strip()
                table = (r.get("TableName") or "").strip()
                title = (r.get("PersianTitle") or "").strip()
                if not schema or not table or not title:
                    continue
                # IsTranslated=0 یعنی عنوان هنوز کلید منبع است، نه فارسی
                if r.get("IsTranslated") == "0" or RESOURCE_KEY.match(title):
                    stats["ترجمه‌نشده"] += 1
                    continue
                key = (schema, table)
                if key not in titles:            # HCM3 اولویت دارد
                    titles[key] = (title, "glossary_entity_catalog")
                    stats["entity_catalog"] += 1

    # ۳. نوشتن — فقط جدول‌هایی که در ساختار وجود دارند
    known = {}
    for f in (kb / "structure").glob("*.yaml"):
        d = yaml.safe_load(f.read_text(encoding="utf-8"))
        known[d["schema"]] = {t["name"] for t in d["tables"]}

    by_schema = collections.defaultdict(list)
    orphan = []
    for (schema, table), (title, source) in sorted(titles.items()):
        if schema in known and table in known[schema]:
            by_schema[schema].append({
                "name": table,
                "title_fa": title,
                "source": "stated_by_user",
                "confidence": "medium",
                "origin": source,
            })
        else:
            orphan.append(f"{schema}.{table}")

    for schema, items in by_schema.items():
        path = kb / "semantics" / f"{schema}.yaml"
        existing = {}
        if path.exists():                       # دانش دستی را پاک نکن
            doc = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            existing = {t["name"]: t for t in doc.get("tables", [])}
        merged = []
        for item in items:
            old = existing.pop(item["name"], None)
            if old and old.get("source") == "stated_by_user" and old.get("_manual"):
                merged.append(old)              # ویرایش دستی برنده است
            else:
                merged.append({**(old or {}), **item})
        merged.extend(existing.values())
        dump_yaml(path, {
            "schema": schema,
            "note": "description_fa و gotchas را دستی اضافه کنید؛ ingest بعدی پاکشان نمی‌کند.",
            "tables": sorted(merged, key=lambda x: x["name"]),
        })

    stats["نوشته‌شده"] = sum(len(v) for v in by_schema.values())
    stats["بی‌تطابق"] = len(orphan)
    if orphan:
        dump_yaml(kb / "semantics" / "_orphans.yaml", {
            "note": "عنوان فارسی دارند ولی جدولشان در ساختار نیست (احتمالاً ماژول نصب‌نشده یا نام قدیمی).",
            "items": orphan,
        })
    return stats


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb", required=True, type=Path)
    ap.add_argument("--lookups", type=Path)
    ap.add_argument("--observed", type=Path)
    ap.add_argument("--glossary", type=Path)
    args = ap.parse_args()

    if args.lookups and args.observed:
        s = build_enums(args.lookups, args.observed, args.kb)
        print("── enum ──")
        for k in ("اثبات‌شده", "از پیکربندی", "توضیح‌داده‌نشده", "بدون تطابق"):
            print(f"  {k:16} {s.get(k, 0):>5}")

    if args.glossary:
        s = build_semantics(args.glossary, args.kb)
        print("\n── عنوان جدول‌ها ──")
        print(f"  از hcm3-table-titles:  {s.get('hcm3', 0):>5}")
        print(f"  از entity-catalog:     {s.get('entity_catalog', 0):>5}")
        print(f"  ترجمه‌نشده (رد شد):    {s.get('ترجمه‌نشده', 0):>5}")
        print(f"  نوشته‌شده در KB:       {s.get('نوشته‌شده', 0):>5}")
        print(f"  بی‌تطابق:              {s.get('بی‌تطابق', 0):>5}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
