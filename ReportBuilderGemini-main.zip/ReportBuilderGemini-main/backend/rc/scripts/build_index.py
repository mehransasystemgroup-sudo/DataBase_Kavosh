#!/usr/bin/env python3
"""
گام ۶ — ساخت ایندکس جست‌وجو از kb/

ایندکس یک مصنوع مشتق است: همیشه باید با یک دستور از kb/ بازساخته شود.
هرگز در git نگذارید و هرگز مستقیم ویرایش نکنید.

استفاده:
    python3 build_index.py --kb kb/ --out index/kb.sqlite \
                           [--instance instances/default/]
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("نیاز به PyYAML:  pip install pyyaml")

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core.textnorm import build_search_text, normalize   # noqa: E402


SCHEMA = """
PRAGMA journal_mode = OFF;
PRAGMA synchronous  = OFF;

CREATE TABLE tables (
    full_name   TEXT PRIMARY KEY,
    schema      TEXT NOT NULL,
    name        TEXT NOT NULL,
    title_fa    TEXT,
    description_fa TEXT,
    kind        TEXT,
    n_cols      INTEGER NOT NULL DEFAULT 0,
    row_count   INTEGER,          -- از instance؛ NULL یعنی نامعلوم
    has_data    INTEGER NOT NULL DEFAULT 0,
    in_live_db  INTEGER           -- NULL = بررسی نشده، 0 = در دیتابیس نیست
);
CREATE INDEX ix_tables_schema ON tables(schema);
CREATE INDEX ix_tables_name   ON tables(name);

CREATE TABLE columns (
    table_ref   TEXT NOT NULL REFERENCES tables(full_name),
    name        TEXT NOT NULL,
    type        TEXT,
    nullable    INTEGER NOT NULL DEFAULT 1,
    is_pk       INTEGER NOT NULL DEFAULT 0,
    ordinal     INTEGER,
    PRIMARY KEY (table_ref, name)
);
CREATE INDEX ix_columns_name ON columns(name);

CREATE TABLE joins (
    from_table  TEXT NOT NULL,
    from_col    TEXT NOT NULL,
    to_table    TEXT NOT NULL,
    to_col      TEXT NOT NULL,
    confidence  TEXT NOT NULL,
    verified    INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (from_table, from_col, to_table, to_col)
);
CREATE INDEX ix_joins_from ON joins(from_table);
CREATE INDEX ix_joins_to   ON joins(to_table);

CREATE TABLE enums (
    table_ref   TEXT NOT NULL,
    column      TEXT NOT NULL,
    value       TEXT NOT NULL,
    label_fa    TEXT,
    confidence  TEXT,
    observed    INTEGER,
    PRIMARY KEY (table_ref, column, value)
);

CREATE TABLE indexes_ (
    table_ref   TEXT NOT NULL,
    name        TEXT NOT NULL,
    columns     TEXT,
    is_unique   INTEGER DEFAULT 0,
    is_pk       INTEGER DEFAULT 0,
    PRIMARY KEY (table_ref, name)
);

-- جست‌وجوی تمام‌متن روی نام انگلیسی + عنوان فارسی + توضیح
CREATE VIRTUAL TABLE fts USING fts5(
    full_name UNINDEXED,
    body,
    tokenize = 'unicode61 remove_diacritics 2'
);

CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT);
"""


def build(kb: Path, out: Path, instance: Path | None) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()

    db = sqlite3.connect(out)
    db.executescript(SCHEMA)

    # ── ساختار ──
    tables, columns = [], []
    for f in sorted((kb / "structure").glob("*.yaml")):
        doc = yaml.safe_load(f.read_text(encoding="utf-8"))
        schema = doc["schema"]
        for t in doc["tables"]:
            full = f"{schema}.{t['name']}"
            tables.append((full, schema, t["name"], None, None, None,
                           len(t["columns"]), None, 0, None))
            for c in t["columns"]:
                columns.append((full, c["name"], c.get("type"),
                                int(c.get("nullable", True)),
                                int(c.get("is_pk", False)), c.get("ordinal")))
    db.executemany("INSERT INTO tables VALUES (?,?,?,?,?,?,?,?,?,?)", tables)
    db.executemany("INSERT INTO columns VALUES (?,?,?,?,?,?)", columns)

    # ── معنا ──
    n_sem = 0
    for f in sorted((kb / "semantics").glob("[A-Z]*.yaml")):
        doc = yaml.safe_load(f.read_text(encoding="utf-8"))
        for t in doc.get("tables", []):
            db.execute(
                "UPDATE tables SET title_fa=?, description_fa=?, kind=? WHERE full_name=?",
                (t.get("title_fa"), t.get("description_fa"), t.get("kind"),
                 f"{doc['schema']}.{t['name']}"),
            )
            n_sem += 1

    # ── گراف JOIN ──
    n_joins = 0
    jf = kb / "joins" / "inferred.yaml"
    if jf.exists():
        doc = yaml.safe_load(jf.read_text(encoding="utf-8"))
        rows = []
        for e in doc.get("edges", []):
            fs, ft, fc = e["from"].split(".", 2)
            ts, tt, tc = e["to"].split(".", 2)
            rows.append((f"{fs}.{ft}", fc, f"{ts}.{tt}", tc,
                         e["confidence"], int(e.get("verified", False))))
        db.executemany("INSERT OR IGNORE INTO joins VALUES (?,?,?,?,?,?)", rows)
        n_joins = len(rows)

    # ── enum ──
    n_enum = 0
    for f in sorted((kb / "enums").glob("[A-Z]*.yaml")):
        doc = yaml.safe_load(f.read_text(encoding="utf-8"))
        rows = []
        for e in doc.get("enums", []):
            full = f"{doc['schema']}.{e['table']}"
            for v in e.get("values", []):
                rows.append((full, e["column"], str(v["value"]), v.get("label_fa"),
                             v.get("confidence"), v.get("observed_count")))
        db.executemany("INSERT OR IGNORE INTO enums VALUES (?,?,?,?,?,?)", rows)
        n_enum += len(rows)

    # ── ایندکس‌ها ──
    n_idx = 0
    for f in sorted((kb / "indexes").glob("*.yaml")):
        doc = yaml.safe_load(f.read_text(encoding="utf-8"))
        rows = [
            (f"{doc['schema']}.{i['table']}", i["name"],
             ",".join(i.get("columns", [])),
             int(i.get("unique", False)), int(i.get("is_pk", False)))
            for i in doc.get("indexes", [])
        ]
        db.executemany("INSERT OR IGNORE INTO indexes_ VALUES (?,?,?,?,?)", rows)
        n_idx += len(rows)

    # ── آمار نصب ──
    n_active = 0
    if instance:
        sf = instance / "table-stats.yaml"
        if sf.exists():
            stats = yaml.safe_load(sf.read_text(encoding="utf-8"))["tables"]
            db.executemany(
                "UPDATE tables SET row_count=?, has_data=? WHERE full_name=?",
                [(v, 1 if v else 0, k) for k, v in stats.items()],
            )
            n_active = sum(1 for v in stats.values() if v)
            # rowcounts از sys.tables می‌آید و همه‌ی جدول‌های موجود را دارد.
            # پس هرچه در آن نیست، در دیتابیس زنده وجود ندارد → مستندات کهنه.
            db.execute("UPDATE tables SET in_live_db = 0")
            db.executemany("UPDATE tables SET in_live_db = 1 WHERE full_name = ?",
                           [(k,) for k in stats])
            stale = db.execute(
                "SELECT COUNT(*) FROM tables WHERE in_live_db = 0").fetchone()[0]
            undocumented = sorted(
                {k.split(".")[0] for k in stats} -
                {r[0] for r in db.execute("SELECT DISTINCT schema FROM tables")})
            if stale:
                print(f"  ⚠️  {stale} جدول در KB هست ولی در دیتابیس زنده نیست (مستندات کهنه)")
            if undocumented:
                print(f"  ⚠️  schema بدون ساختار: {', '.join(undocumented)}")

    # ── FTS ──
    rows = db.execute(
        "SELECT full_name, schema, name, title_fa, description_fa FROM tables"
    ).fetchall()
    db.executemany(
        "INSERT INTO fts (full_name, body) VALUES (?, ?)",
        [(r[0], build_search_text(r[1], r[2], r[3], r[4])) for r in rows],
    )

    db.executemany("INSERT INTO meta VALUES (?,?)", [
        ("tables", str(len(tables))), ("columns", str(len(columns))),
        ("joins", str(n_joins)), ("enums", str(n_enum)),
        ("indexes", str(n_idx)), ("with_title_fa", str(n_sem)),
        ("active_tables", str(n_active)),
    ])
    db.commit()
    db.execute("VACUUM")
    db.close()

    size = out.stat().st_size / 1024 / 1024
    print(f"✔ {out}  ({size:.1f} MB)")
    print(f"  جدول {len(tables)}  ·  ستون {len(columns)}  ·  یال {n_joins}")
    print(f"  عنوان فارسی {n_sem}  ·  enum {n_enum}  ·  ایندکس {n_idx}")
    print(f"  جدول دارای داده در این نصب: {n_active}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--instance", type=Path)
    a = ap.parse_args()
    build(a.kb, a.out, a.instance)
    return 0


if __name__ == "__main__":
    sys.exit(main())
