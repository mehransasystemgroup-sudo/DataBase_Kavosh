#!/usr/bin/env python3
"""
ورود خروجی SSMS به KB و تطبیق با حدس‌ها.

خروجی مهم این اسکریپت، «کارت امتیاز» است:
    چند درصد از یال‌های استنتاجی درست بودند؟
    کدام‌ها اشتباه؟  کدام FK واقعی را اصلاً حدس نزده بودیم؟

این عدد تعیین می‌کند چقدر می‌شود به بقیه‌ی حدس‌ها اعتماد کرد
— در دیتابیس‌هایی که FK تعریف‌شده ندارند، این تنها معیار است.

استفاده:
    python3 ingest_metadata.py --kb kb/ --fk fk.json [--pk pk.json] \
                               [--indexes indexes.json] \
                               [--rowcounts rowcounts.json --instance instances/x/]
"""

from __future__ import annotations

import argparse
import collections
import json

import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("نیاز به PyYAML:  pip install pyyaml")


def load_json(path: Path):
    """
    خروجی SSMS تمیز نیست: BOM، نام ستون خودکار (JSON_F52E2B61-…)،
    «(N rows affected)»، و شکستن JSON در چند ردیف.

    به‌جای تطبیق با این فرمت‌ها (شکننده)، مرز واقعی JSON را پیدا می‌کنیم:
    از اولین [ یا { تا آخرین ] یا }.
    """
    text = path.read_text(encoding="utf-8-sig")

    starts = [i for i in (text.find("["), text.find("{")) if i != -1]
    ends = [i for i in (text.rfind("]"), text.rfind("}")) if i != -1]
    if not starts or not ends:
        return []

    text = text[min(starts): max(ends) + 1]
    # SSMS خروجی طولانی را در چند ردیف می‌شکند — بچسبان
    text = "".join(line.strip() for line in text.splitlines())

    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        sys.exit(
            f"✖ فایل {path.name} قابل خواندن نیست: {exc}\n"
            f"  احتمالاً خروجی بریده شده. در SSMS:\n"
            f"    Query ▸ Results To ▸ Results to File   (Ctrl+Shift+F)\n"
            f"  یا با sqlcmd اجرا کنید:  sqlcmd -S … -i 01-metadata.sql -o out.json -y 0"
        )


def dump_yaml(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=200),
        encoding="utf-8",
    )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb", required=True, type=Path)
    ap.add_argument("--fk", type=Path, help="خروجی بخش ۱")
    ap.add_argument("--pk", type=Path, help="خروجی بخش ۳")
    ap.add_argument("--indexes", type=Path, help="خروجی بخش ۲")
    ap.add_argument("--rowcounts", type=Path, help="خروجی ۴")
    ap.add_argument("--enums", type=Path, help="خروجی ۵ — توزیع مقادیر")
    ap.add_argument("--instance", type=Path, help="مقصد داده‌ی محرمانه")
    args = ap.parse_args()

    # ── FK واقعی ──
    if args.fk:
        rows = load_json(args.fk)
        real = {}
        for r in rows:
            src = f'{r["from_schema"]}.{r["from_table"]}.{r["from_column"]}'
            dst = f'{r["to_schema"]}.{r["to_table"]}.{r["to_column"]}'
            real[src] = dst

        inferred_doc = yaml.safe_load(
            (args.kb / "joins" / "inferred.yaml").read_text(encoding="utf-8")
        )
        edges = inferred_doc["edges"]

        # محافظ: اگر قبلاً تأیید شده، کارت امتیاز بی‌معناست
        # (همه‌چیز درست به‌نظر می‌رسد چون خودمان اصلاحش کرده‌ایم)
        already = sum(1 for e in edges if e.get("verified"))
        if already:
            print(
                f"⚠️  {already} یال از قبل تأیید شده‌اند.\n"
                f"   کارت امتیاز فقط روی گراف تازه‌ساخته معنا دارد.\n"
                f"   برای اندازه‌گیری صحیح: build_structure.py را دوباره اجرا کنید.\n"
            )

        correct = wrong = 0
        by_conf = collections.defaultdict(lambda: [0, 0])   # [درست, غلط]
        corrections = []

        for e in edges:
            truth = real.get(e["from"])
            if truth is None:
                continue                      # FK واقعی وجود ندارد → قابل قضاوت نیست
            conf = e["confidence"]
            if truth == e["to"]:
                e["verified"] = True
                e["source"] = "extracted"
                e["confidence"] = "high"
                correct += 1
                by_conf[conf][0] += 1
            else:
                corrections.append({"from": e["from"], "guessed": e["to"], "actual": truth})
                e["to"] = truth
                e["verified"] = True
                e["source"] = "extracted"
                e["confidence"] = "high"
                e.pop("alternatives", None)
                wrong += 1
                by_conf[conf][1] += 1

        # FKهایی که اصلاً حدس نزده بودیم
        known = {e["from"] for e in edges}
        missed = [
            {"from": s, "to": d, "method": "extracted",
             "source": "extracted", "confidence": "high", "verified": True}
            for s, d in real.items() if s not in known
        ]
        edges.extend(missed)

        judged = correct + wrong
        inferred_doc["summary"] = {
            "total_edges": len(edges),
            "verified": sum(1 for e in edges if e.get("verified")),
            "by_confidence": dict(collections.Counter(e["confidence"] for e in edges)),
        }
        inferred_doc["scorecard"] = {
            "judged": judged,
            "correct": correct,
            "wrong": wrong,
            "accuracy_pct": round(correct * 100 / judged, 1) if judged else None,
            "missed_real_fks": len(missed),
            "by_confidence": {
                k: {"correct": v[0], "wrong": v[1],
                    "accuracy_pct": round(v[0] * 100 / (v[0] + v[1]), 1) if v[0] + v[1] else None}
                for k, v in by_conf.items()
            },
        }
        dump_yaml(args.kb / "joins" / "inferred.yaml", inferred_doc)

        if corrections:
            dump_yaml(args.kb / "joins" / "corrections.yaml", {
                "note": "حدس‌هایی که غلط بودند — برای بهبود قوانین استنتاج بررسی شوند.",
                "items": corrections,
            })

        print(f"── تطبیق FK ──")
        print(f"  FK واقعی در دیتابیس: {len(real)}")
        print(f"  قابل قضاوت:          {judged}")
        if judged:
            print(f"    ✔ درست: {correct}   ✖ غلط: {wrong}   → دقت {correct*100/judged:.1f}%")
            for lvl in ("high", "medium", "low"):
                if lvl in by_conf:
                    c, w = by_conf[lvl]
                    print(f"      {lvl:8} {c*100/(c+w):5.1f}%   ({c}/{c+w})")
        print(f"  FK واقعی که حدس نزده بودیم: {len(missed)}")
        if not real:
            print("  ⚠️  هیچ FK تعریف‌شده‌ای در دیتابیس نیست — گراف کاملاً حدسی می‌ماند.")

    # ── PK واقعی ──
    if args.pk:
        rows = load_json(args.pk)
        # گروه‌بندی بر اساس schema — هر فایل فقط یک بار باز و ذخیره می‌شود
        by_schema = collections.defaultdict(dict)
        for r in rows:
            by_schema[r["schema"]][r["table"]] = r["pk_columns"].split(",")

        ok = mismatch = 0
        for schema, pk_map in by_schema.items():
            f = args.kb / "structure" / f"{schema}.yaml"
            if not f.exists():
                continue
            doc = yaml.safe_load(f.read_text(encoding="utf-8"))
            for t in doc["tables"]:
                actual = pk_map.get(t["name"])
                if actual is None:
                    continue
                if t["primary_key"] == actual:
                    ok += 1
                else:
                    t["primary_key"] = actual
                    t["pk_source"] = "extracted"
                    mismatch += 1
            dump_yaml(f, doc)
        print(f"\n── تطبیق PK ──\n  مطابق: {ok}   اصلاح‌شده: {mismatch}")

    # ── ایندکس‌ها ──
    if args.indexes:
        rows = load_json(args.indexes)
        by_schema = collections.defaultdict(list)
        for r in rows:
            by_schema[r["schema"]].append({
                "table": r["table"],
                "name": r["index_name"],
                "type": r["index_type"],
                "unique": bool(r["is_unique"]),
                "is_pk": bool(r["is_pk"]),
                "columns": (r.get("key_columns") or "").split(",") if r.get("key_columns") else [],
                **({"included": r["included"].split(",")} if r.get("included") else {}),
            })
        for schema, items in by_schema.items():
            dump_yaml(args.kb / "indexes" / f"{schema}.yaml",
                      {"schema": schema, "source": "extracted", "indexes": items})
        print(f"\n── ایندکس ──\n  {len(rows)} ایندکس در {len(by_schema)} schema")

    # ── تعداد ردیف (محرمانه) ──
    if args.rowcounts:
        if not args.instance:
            return ap.error("--rowcounts نیاز به --instance دارد (داده‌ی محرمانه)")
        rows = load_json(args.rowcounts)
        stats = {f'{r["schema"]}.{r["table"]}': r["row_count"] for r in rows}
        active = sorted({k.split(".")[0] for k, v in stats.items() if v > 0})
        dump_yaml(args.instance / "table-stats.yaml", {
            "note": "داده‌ی این نصب — در git نگذارید.",
            "active_schemas": active,
            "tables": stats,
        })
        empty = sum(1 for v in stats.values() if v == 0)
        print(f"\n── آمار نصب ──")
        print(f"  جدول: {len(stats)}   خالی: {empty}   schema فعال: {len(active)}")
        print(f"  فعال: {', '.join(active[:12])}{' …' if len(active) > 12 else ''}")

    # ── توزیع enum (محرمانه — آمار این نصب) ──
    if args.enums:
        if not args.instance:
            return ap.error("--enums نیاز به --instance دارد")
        rows = load_json(args.enums)

        obs = collections.defaultdict(dict)
        for r in rows:
            key = f'{r["schema"]}.{r["table"]}.{r["column"]}'
            # FOR JSON PATH کلیدهای NULL را حذف می‌کند → نبودِ value یعنی NULL
            obs[key]["<NULL>" if "value" not in r else str(r["value"])] = r["cnt"]

        dump_yaml(args.instance / "enum-observed.yaml", {
            "note": (
                "توزیع واقعی مقادیر در این نصب. تنها مدرک برای ادعای معنای enum. "
                "⛔ محرمانه — در git نگذارید."
            ),
            "columns": [
                {"column": k, "distinct": len(v), "distribution": v}
                for k, v in sorted(obs.items())
            ],
        })

        # اسکلت canonical برای پر کردن معنا در گام ۳
        skeleton = collections.defaultdict(list)
        for key, dist in sorted(obs.items()):
            schema, table, column = key.split(".", 2)
            skeleton[schema].append({
                "table": table,
                "column": column,
                **({"nullable": True} if "<NULL>" in dist else {}),
                "values": [
                    {"value": v, "label_fa": None,
                     "source": "unknown", "confidence": "low"}
                    for v in sorted(dist, key=lambda x: (len(x), x))
                    if v != "<NULL>"
                ],
            })
        for schema, items in skeleton.items():
            path = args.kb / "enums" / f"{schema}.yaml"
            if path.exists():
                continue          # دانش دستی را بازنویسی نکن
            dump_yaml(path, {
                "schema": schema,
                "note": "label_fa را از lookup-values.csv یا دانش خودتان پر کنید.",
                "enums": items,
            })

        nullable = sum(1 for v in obs.values() if "<NULL>" in v)
        single = sum(1 for v in obs.values() if len([x for x in v if x != "<NULL>"]) == 1)
        print(f"\n── توزیع enum ──")
        print(f"  ستون: {len(obs)}   مقدار متمایز: {sum(len(v) for v in obs.values())}")
        print(f"  ⚠️  تک‌مقداری: {single}  (یک نمونه اثبات نیست)")
        print(f"  ⚠️  دارای NULL: {nullable}  (فرض 0/1 خطرناک است)")

    return 0


if __name__ == "__main__":
    sys.exit(main())
