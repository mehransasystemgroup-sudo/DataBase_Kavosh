#!/usr/bin/env python3
"""
ورود ساختار کامل از دیتابیس — جایگزینی منبع حقیقت.

تا حالا ساختار از فایل‌های markdown می‌آمد که:
    • ۴۹ جدول کهنه داشت (schemaهای ACC، FMK، RPA، GNR، dbo)
    • دو schema را اصلاً نداشت (USR3 با ۴۱ جدول، CNV3 با ۱۲ جدول)

این اسکریپت kb/structure/ را از خروجی sys.* بازمی‌سازد.

⚠️ لایهٔ معنایی (kb/semantics، kb/enums) دست نمی‌خورد.
   فقط جدول‌هایی که دیگر وجود ندارند، گزارش می‌شوند تا خودتان تصمیم بگیرید.

استفاده:
    python3 ingest_columns.py --kb kb --columns columns.json [--prune]

    --prune  جدول‌های ناموجود را از kb/structure حذف می‌کند
             (بدون آن فقط گزارش می‌دهد)
"""

from __future__ import annotations

import argparse
import collections
import json
import sys
from datetime import date
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("نیاز به PyYAML:  pip install pyyaml")


def load_json_loose(path: Path):
    text = path.read_text(encoding="utf-8-sig")
    s = [i for i in (text.find("["), text.find("{")) if i != -1]
    e = [i for i in (text.rfind("]"), text.rfind("}")) if i != -1]
    if not s or not e:
        return []
    text = "".join(l.strip() for l in text[min(s):max(e) + 1].splitlines())
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        sys.exit(f"✖ {path.name} خوانده نشد: {exc}\n"
                 f"  احتمالاً بریده شده — از Results to File یا sqlcmd استفاده کنید.")


def dump_yaml(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=200),
        encoding="utf-8")


def render_type(r: dict) -> str:
    """int · nvarchar(50) · decimal(28,4) · nvarchar(max)"""
    t = r["type_name"]
    ln = r.get("max_length")
    if t in ("nvarchar", "varchar", "nchar", "char", "varbinary", "binary"):
        return f"{t}(max)" if ln == -1 else f"{t}({ln})"
    if t in ("decimal", "numeric"):
        return f"{t}({r.get('precision')},{r.get('scale')})"
    return t


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kb", required=True, type=Path)
    ap.add_argument("--columns", required=True, type=Path)
    ap.add_argument("--prune", action="store_true")
    a = ap.parse_args()

    rows = load_json_loose(a.columns)
    if not rows:
        sys.exit("✖ فایل خالی است.")

    # ── گروه‌بندی ──
    live: dict[str, dict[str, list]] = collections.defaultdict(
        lambda: collections.defaultdict(list))
    for r in rows:
        live[r["schema"]][r["table"]].append(r)

    # ── PK موجود را از KB فعلی نگه دار ──
    existing_pk: dict[str, list[str]] = {}
    struct_dir = a.kb / "structure"
    for f in struct_dir.glob("*.yaml"):
        doc = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        for t in doc.get("tables", []):
            existing_pk[f"{doc['schema']}.{t['name']}"] = t.get("primary_key", [])

    old_tables = set(existing_pk)
    new_tables = {f"{s}.{t}" for s, tabs in live.items() for t in tabs}

    added = sorted(new_tables - old_tables)
    removed = sorted(old_tables - new_tables)

    # ── نوشتن ──
    for schema, tables in sorted(live.items()):
        out = []
        for name, cols in sorted(tables.items()):
            full = f"{schema}.{name}"
            out.append({
                "name": name,
                "columns": [{
                    "name": c["column"],
                    "type": render_type(c),
                    "nullable": bool(c["is_nullable"]),
                    "ordinal": c["ordinal"],
                    **({"is_pk": True} if c["column"] in existing_pk.get(full, []) else {}),
                    **({"identity": True} if c.get("is_identity") else {}),
                    **({"computed": True} if c.get("is_computed") else {}),
                } for c in sorted(cols, key=lambda x: x["ordinal"])],
                "primary_key": existing_pk.get(full, []),
            })
        dump_yaml(struct_dir / f"{schema}.yaml", {
            "schema": schema,
            "table_count": len(out),
            "source": "extracted",
            "extracted_at": date.today().isoformat(),
            "note": "از sys.* استخراج شده — دستی ویرایش نکنید. معنا در kb/semantics/ است.",
            "tables": out,
        })

    # ── جدول‌های ناموجود ──
    stale_report = a.kb / "structure" / "_stale.yaml"
    if removed:
        by_schema = collections.Counter(t.split(".")[0] for t in removed)
        dump_yaml(stale_report, {
            "note": ("این جدول‌ها در KB بودند ولی در دیتابیس نیستند. "
                     "اگر معنایی برایشان ثبت شده، قبل از حذف بررسی کنید."),
            "checked_at": date.today().isoformat(),
            "by_schema": dict(by_schema),
            "tables": removed,
        })
        if a.prune:
            for f in struct_dir.glob("*.yaml"):
                if f.name.startswith("_"):
                    continue
                sch = f.stem
                if sch not in live:
                    f.unlink()

    # ── هشدار: معنای یتیم ──
    orphan_semantics = []
    sem_dir = a.kb / "semantics"
    if sem_dir.exists():
        for f in sem_dir.glob("[A-Z]*.yaml"):
            doc = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
            for t in doc.get("tables", []):
                full = f"{doc['schema']}.{t['name']}"
                if full not in new_tables and t.get("title_fa"):
                    orphan_semantics.append(full)

    # ── گزارش ──
    n_cols = len(rows)
    print(f"✔ {len(live)} schema · {len(new_tables)} جدول · {n_cols:,} ستون")
    if added:
        by = collections.Counter(t.split(".")[0] for t in added)
        print(f"\n  + {len(added)} جدول جدید: {dict(by.most_common(6))}")
    if removed:
        by = collections.Counter(t.split(".")[0] for t in removed)
        verb = "حذف شد" if a.prune else "گزارش شد (برای حذف --prune بزنید)"
        print(f"  − {len(removed)} جدول ناموجود {verb}: {dict(by.most_common(6))}")
        print(f"    جزئیات: {stale_report}")
    if orphan_semantics:
        print(f"\n  ⚠️  {len(orphan_semantics)} عنوان فارسی برای جدول‌های ناموجود مانده.")
        print(f"     نمونه: {'، '.join(orphan_semantics[:4])}")
    print("\n  → حالا PK را دوباره وارد کنید:")
    print("    python3 scripts/ingest/ingest_metadata.py --kb kb --pk pk.json")
    print("  → و ایندکس را بسازید:")
    print("    python3 scripts/build_index.py --kb kb --out index/kb.sqlite "
          "--instance instances/default")
    return 0


if __name__ == "__main__":
    sys.exit(main())
