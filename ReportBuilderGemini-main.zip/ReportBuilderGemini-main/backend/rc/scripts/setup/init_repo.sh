#!/usr/bin/env bash
# راه‌اندازی مخزن با محافظ PII — کار ۳.۵ هفتهٔ ۱
set -e
cd "$(dirname "$0")/../.."

[ -d .git ] || { git init -q; echo "✔ مخزن ساخته شد"; }

# محافظ: هیچ commitی با PII عبور نکند
mkdir -p .git/hooks
cat > .git/hooks/pre-commit <<'HOOK'
#!/bin/sh
echo "▸ اسکن PII..."
python3 scripts/redact/redact_schemas.py --src kb --check 2>/dev/null || true
for d in kb/schemas kb-redacted/schemas; do
  [ -d "$d" ] && { python3 scripts/redact/redact_schemas.py --src "$d" --check || {
    echo "✖ commit رد شد: داده‌ی محرمانه در $d"; exit 1; }; }
done
# فایل‌هایی که هرگز نباید commit شوند
if git diff --cached --name-only | grep -Eq '^(instances/|index/|\.redaction-salt)'; then
  echo "✖ commit رد شد: فایل محرمانه در stage است."
  git diff --cached --name-only | grep -E '^(instances/|index/|\.redaction-salt)'
  exit 1
fi
echo "✔ اسکن پاک"
HOOK
chmod +x .git/hooks/pre-commit
echo "✔ pre-commit hook نصب شد"

git add -A 2>/dev/null || true
echo
echo "برای اولین commit:"
echo "  git commit -m 'پایگاه دانش و هستهٔ مدل‌ناوابسته'"
