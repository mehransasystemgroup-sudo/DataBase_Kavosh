#!/usr/bin/env python3
"""
ماسک‌گذاری فایل‌های references/schemas/*.md

چرا regex و نه json.loads؟
    ۱۶۳ بلوک از ۴۱۲ بلوک JSON در فایل‌های واقعی بریده‌شده‌اند («...(بریده‌شده)»)
    و JSON معتبر نیستند. پارس ساختاری روی آن‌ها شکست می‌خورد.
    این اسکریپت روی جفت‌های "key": value در سطح متن کار می‌کند.

تضمین‌ها:
    • idempotent — اجرای دوباره روی خروجی، تغییری ایجاد نمی‌کند
    • pseudonym پایدار — همان مقدار همیشه همان برچسب (رابطه‌ها حفظ می‌شوند)
    • فقط بلوک‌های ```json دست‌کاری می‌شوند؛ ساختار سند و تعریف ستون‌ها دست‌نخورده

استفاده:
    python3 redact_schemas.py --src <dir> --out <dir> [--rules rules.yaml] [--check]

    --check   حالت اسکن: چیزی نمی‌نویسد، فقط می‌گوید چه چیزی PII است (برای pre-commit)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("نیاز به PyYAML:  pip install pyyaml")


# ─────────────────────────── الگوهای پایه ───────────────────────────

JSON_BLOCK = re.compile(r"(```json\n)(.*?)(\n```)", re.S)

# سرتیتر جدول:  ## HCM3.PayCalcItem  (~10,051 ردیف)
TABLE_HEADING = re.compile(r"^## ([A-Za-z0-9_]+\.[A-Za-z0-9_]+)", re.M)

# "Key": value  —  value یکی از: رشته / عدد / true / false / null
KV_PAIR = re.compile(
    r'"(?P<key>[A-Za-z_][A-Za-z_0-9]*)"'
    r'(?P<sep>\s*:\s*)'
    r'(?P<val>"(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?|true|false|null)'
)

PERSIAN = re.compile(r"[\u0600-\u06FF]")

# برچسب‌هایی که خودمان تولید می‌کنیم — برای idempotency باید شناسایی شوند
ALREADY_REDACTED = re.compile(r"^«[^»]*»$")


# ─────────────────────────── موتور ماسک ───────────────────────────

class Redactor:
    def __init__(self, rules: dict, salt: str):
        self.salt = salt
        self.drop_placeholder = rules["settings"]["drop_placeholder"]

        self.key_rules = [
            (re.compile(r["match"], re.I), r) for r in rules["key_rules"]
        ]
        self.content_rules = [
            (re.compile(r["pattern"]), r["replace"]) for r in rules["content_rules"]
        ]
        # قوانین جدول‌آگاه: [(الگوی جدول, [(الگوی کلید, قانون), ...]), ...]
        self.table_rules = [
            (
                re.compile(tr["table"], re.I),
                [(re.compile(k["match"], re.I), k) for k in tr["keys"]],
            )
            for tr in rules.get("table_scoped_rules", [])
        ]

        self.stats = Counter()
        self._pseudonym_cache: dict[tuple[str, str], str] = {}
        self._current_table: str = ""

    # ---------- کمکی‌ها ----------

    def _pseudonym(self, token: str, value: str) -> str:
        """جایگزین پایدار: «نام_a3f1». همان مقدار → همان برچسب."""
        cache_key = (token, value)
        if cache_key not in self._pseudonym_cache:
            digest = hashlib.sha256((self.salt + value).encode("utf-8")).hexdigest()[:4]
            self._pseudonym_cache[cache_key] = f"«{token}_{digest}»"
        return self._pseudonym_cache[cache_key]

    @staticmethod
    def _magnitude(num_text: str) -> str:
        """5000000.0000 → ~5e6   (اندازه حفظ، رقم دقیق حذف)"""
        try:
            n = float(num_text)
        except ValueError:
            return num_text
        if n == 0:
            return "0"
        sign = "-" if n < 0 else ""
        exp = len(str(int(abs(n)))) - 1
        lead = int(abs(n) / (10 ** exp)) if exp >= 0 else 0
        return f'"~{sign}{lead}e{exp}"' if exp >= 3 else num_text

    def _find_key_rule(self, key: str):
        # اولویت ۱ — قانون جدول‌آگاه (خاص‌تر است)
        if self._current_table:
            for table_pattern, key_rules in self.table_rules:
                if table_pattern.fullmatch(self._current_table):
                    for key_pattern, rule in key_rules:
                        if key_pattern.fullmatch(key):
                            return rule
        # اولویت ۲ — قانون سراسری
        for pattern, rule in self.key_rules:
            if pattern.fullmatch(key):
                return rule
        return None

    def _apply_content_rules(self, text: str) -> str:
        for pattern, replacement in self.content_rules:
            text, n = pattern.subn(replacement, text)
            if n:
                self.stats["content_hits"] += n
        return text

    # ---------- منطق اصلی ----------

    def _redact_pair(self, m: re.Match) -> str:
        key, sep, raw_val = m.group("key"), m.group("sep"), m.group("val")
        is_string = raw_val.startswith('"')
        inner = raw_val[1:-1] if is_string else raw_val

        # idempotency: اگر قبلاً ماسک شده، دست نزن
        if is_string and ALREADY_REDACTED.match(inner):
            return m.group(0)

        rule = self._find_key_rule(key)

        if rule:
            action = rule["action"]

            if action == "drop":
                if is_string and inner:
                    self.stats[f"drop:{key}"] += 1
                    return f'"{key}"{sep}"{self.drop_placeholder}"'
                return m.group(0)

            if action == "pseudonym":
                if is_string and inner:
                    self.stats[f"pseudonym:{key}"] += 1
                    return f'"{key}"{sep}"{self._pseudonym(rule["token"], inner)}"'
                return m.group(0)

            if action == "magnitude":
                if not is_string:
                    new = self._magnitude(raw_val)
                    if new != raw_val:
                        self.stats[f"magnitude:{key}"] += 1
                        return f'"{key}"{sep}{new}'
                return m.group(0)

            if action == "shorten":
                limit = rule.get("max_len", 40)
                if is_string and len(inner) > limit:
                    self.stats[f"shorten:{key}"] += 1
                    return f'"{key}"{sep}"{inner[:limit]}…"'
                return m.group(0)

        # لایه ۲ — روی مقادیر نگه‌داشته‌شده
        if is_string and inner:
            cleaned = self._apply_content_rules(inner)
            if cleaned != inner:
                return f'"{key}"{sep}"{cleaned}"'

        return m.group(0)

    def redact_text(self, text: str) -> str:
        """
        فقط داخل بلوک‌های ```json — بقیه‌ی سند دست‌نخورده می‌ماند.
        سند به بخش‌های «## SCHEMA.Table» تقسیم می‌شود تا هر بلوک،
        جدول متناظرش را بداند (لازم برای قوانین جدول‌آگاه).
        """
        def handle_block(bm: re.Match) -> str:
            open_fence, body, close_fence = bm.groups()
            body = KV_PAIR.sub(self._redact_pair, body)
            # جاروب نهایی روی کل بلوک.
            # ضروری است: ۱۶۳ بلوک بریده‌شده‌اند، پس آخرین جفت "key":"value
            # هرگز بسته نمی‌شود و KV_PAIR آن را نمی‌گیرد — ولی ممکن است
            # شماره‌حساب/کد ملی داشته باشد.
            body = self._apply_content_rules(body)
            return open_fence + body + close_fence

        out, pos = [], 0
        for heading in TABLE_HEADING.finditer(text):
            # بخش قبل از این سرتیتر، با جدولِ قبلی پردازش می‌شود
            out.append(JSON_BLOCK.sub(handle_block, text[pos:heading.start()]))
            self._current_table = heading.group(1)
            pos = heading.start()
        out.append(JSON_BLOCK.sub(handle_block, text[pos:]))
        self._current_table = ""
        return "".join(out)


# ─────────────────────────── حالت اسکن (pre-commit) ───────────────────────────

def scan_for_leaks(text: str, redactor: Redactor) -> list[str]:
    """چیزی که *بعد از* ماسک هنوز مشکوک است را برمی‌گرداند."""
    findings = []
    for block in JSON_BLOCK.findall(text):
        body = block[1]
        for m in KV_PAIR.finditer(body):
            key, val = m.group("key"), m.group("val")
            if not val.startswith('"'):
                continue
            inner = val[1:-1]
            if ALREADY_REDACTED.match(inner):
                continue
            for pattern, _ in redactor.content_rules:
                if pattern.search(inner):
                    findings.append(f"{key} = {inner[:60]}")
                    break
            rule = redactor._find_key_rule(key)
            if rule and rule["action"] in ("drop", "pseudonym") and inner:
                findings.append(f"{key} = {inner[:60]}  [کلید محافظت‌شده]")
    return findings


# ─────────────────────────── CLI ───────────────────────────

def main() -> int:
    ap = argparse.ArgumentParser(description="ماسک‌گذاری فایل‌های schema")
    ap.add_argument("--src", required=True, type=Path)
    ap.add_argument("--out", type=Path)
    ap.add_argument("--rules", type=Path,
                    default=Path(__file__).parent / "rules.yaml")
    ap.add_argument("--check", action="store_true",
                    help="فقط اسکن؛ چیزی نمی‌نویسد. کد خروج ۱ اگر نشتی پیدا شود.")
    args = ap.parse_args()

    if not args.check and not args.out:
        return ap.error("--out لازم است (مگر با --check)")

    rules = yaml.safe_load(args.rules.read_text(encoding="utf-8"))

    salt_path = Path(rules["settings"]["salt_file"])
    if salt_path.exists():
        salt = salt_path.read_text().strip()
    else:
        import secrets
        salt = secrets.token_hex(16)
        salt_path.write_text(salt)
        print(f"⚠️  نمک جدید ساخته شد: {salt_path}  (این فایل را در .gitignore بگذار)")

    redactor = Redactor(rules, salt)
    files = sorted(args.src.glob("*.md"))
    if not files:
        print(f"هیچ فایل .md در {args.src} نیست", file=sys.stderr)
        return 1

    # ── حالت اسکن ──
    if args.check:
        total = 0
        for f in files:
            leaks = scan_for_leaks(f.read_text(encoding="utf-8"), redactor)
            if leaks:
                print(f"\n❌ {f.name}  ({len(leaks)} مورد)")
                for leak in leaks[:5]:
                    print(f"     {leak}")
                if len(leaks) > 5:
                    print(f"     … و {len(leaks) - 5} مورد دیگر")
                total += len(leaks)
        if total:
            print(f"\n✖ مجموع {total} نشتی احتمالی پیدا شد.")
            return 1
        print("✔ هیچ نشتی پیدا نشد.")
        return 0

    # ── حالت ماسک ──
    args.out.mkdir(parents=True, exist_ok=True)
    for f in files:
        original = f.read_text(encoding="utf-8")
        (args.out / f.name).write_text(redactor.redact_text(original), encoding="utf-8")

    # ── گزارش ──
    print(f"✔ {len(files)} فایل پردازش شد → {args.out}\n")
    grouped: dict[str, Counter] = {}
    for key, count in redactor.stats.items():
        action = key.split(":")[0]
        grouped.setdefault(action, Counter())[key.partition(":")[2] or action] = count

    for action in sorted(grouped):
        total = sum(grouped[action].values())
        print(f"  {action:12} {total:>6}")
        for name, count in grouped[action].most_common(6):
            if name != action:
                print(f"      {name:32} {count:>5}")
    print(f"\n  برچسب یکتای تولیدشده: {len(redactor._pseudonym_cache)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
