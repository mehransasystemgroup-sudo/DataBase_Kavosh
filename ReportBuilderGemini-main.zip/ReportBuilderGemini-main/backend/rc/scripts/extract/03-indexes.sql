/* ═══════════════════════════════════════════════════════════
   ۳ از ۵ — ایندکس‌ها               →  ذخیره کنید به‌نام:  indexes.json
   برای تشخیص اینکه کدام JOIN/WHERE ارزان است. فقط sys.* — بدون داده.
   ═══════════════════════════════════════════════════════════ */
SET NOCOUNT ON;

SELECT
    [schema]    = SCHEMA_NAME(t.schema_id),
    [table]     = t.name,
    index_name  = i.name,
    index_type  = i.type_desc,
    is_unique   = CONVERT(bit, i.is_unique),
    is_pk       = CONVERT(bit, i.is_primary_key),
    key_columns = STUFF((
                      SELECT ',' + c2.name
                      FROM sys.index_columns ic2
                      JOIN sys.columns c2 ON c2.object_id = ic2.object_id
                                         AND c2.column_id = ic2.column_id
                      WHERE ic2.object_id = i.object_id AND ic2.index_id = i.index_id
                        AND ic2.is_included_column = 0
                      ORDER BY ic2.key_ordinal
                      FOR XML PATH('')), 1, 1, ''),
    included    = STUFF((
                      SELECT ',' + c3.name
                      FROM sys.index_columns ic3
                      JOIN sys.columns c3 ON c3.object_id = ic3.object_id
                                         AND c3.column_id = ic3.column_id
                      WHERE ic3.object_id = i.object_id AND ic3.index_id = i.index_id
                        AND ic3.is_included_column = 1
                      ORDER BY ic3.index_column_id
                      FOR XML PATH('')), 1, 1, '')
FROM sys.indexes AS i
JOIN sys.tables  AS t ON t.object_id = i.object_id
WHERE i.type > 0 AND t.is_ms_shipped = 0
ORDER BY [schema], [table], i.index_id
FOR JSON PATH;
