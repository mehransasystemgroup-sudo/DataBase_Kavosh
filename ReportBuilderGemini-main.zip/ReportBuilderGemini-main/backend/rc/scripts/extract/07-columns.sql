/* ═══════════════════════════════════════════════════════════════════
   ۶ — ساختار کامل ستون‌ها        →  ذخیره کنید به‌نام:  columns.json

   چرا این اسکریپت:
       ساختار فعلی KB از فایل‌های markdown آمده که ۴۹ جدول کهنه دارند
       و دو schema (USR3، CNV3) را اصلاً پوشش نمی‌دهند.

       این اسکریپت مستقیم از sys.* می‌خواند و منبع حقیقت می‌شود.
       بعد از ورود این فایل، markdownها دیگر لازم نیستند.

   ⚠️  فقط sys.* — هیچ داده‌ای از ردیف‌های جدول خوانده نمی‌شود.

   ⏱  چند ثانیه. حدود ۴۵ هزار ردیف — حتماً Results to File.
   ═══════════════════════════════════════════════════════════════════ */

SET NOCOUNT ON;

SELECT
    [schema]     = SCHEMA_NAME(t.schema_id),
    [table]      = t.name,
    [column]     = c.name,
    ordinal      = c.column_id,
    type_name    = ty.name,
    max_length   = CASE
                     WHEN ty.name IN ('nvarchar','nchar') AND c.max_length > 0
                       THEN c.max_length / 2
                     WHEN c.max_length = -1 THEN -1        -- MAX
                     ELSE c.max_length
                   END,
    [precision]  = c.precision,
    scale        = c.scale,
    is_nullable  = CONVERT(bit, c.is_nullable),
    is_identity  = CONVERT(bit, c.is_identity),
    is_computed  = CONVERT(bit, c.is_computed),
    default_def  = OBJECT_DEFINITION(c.default_object_id)
FROM sys.columns AS c
JOIN sys.tables  AS t  ON t.object_id     = c.object_id
JOIN sys.types   AS ty ON ty.user_type_id = c.user_type_id
WHERE t.is_ms_shipped = 0
  AND t.type = 'U'
ORDER BY [schema], [table], c.column_id
FOR JSON PATH;
