/* ═══════════════════════════════════════════════════════════
   ۱ از ۵ — کلیدهای خارجی            →  ذخیره کنید به‌نام:  fk.json
   مهم‌ترین اسکریپت. گراف JOIN فعلی حدسی است؛ این آن را نمره می‌دهد.
   فقط sys.* خوانده می‌شود — هیچ داده‌ای از جدول‌ها خوانده نمی‌شود.
   ═══════════════════════════════════════════════════════════ */
SET NOCOUNT ON;

SELECT
    fk_name      = fk.name,
    from_schema  = SCHEMA_NAME(tp.schema_id),
    from_table   = tp.name,
    from_column  = cp.name,
    to_schema    = SCHEMA_NAME(tr.schema_id),
    to_table     = tr.name,
    to_column    = cr.name,
    ordinal      = fkc.constraint_column_id,
    is_disabled  = CONVERT(bit, fk.is_disabled)
FROM sys.foreign_keys        AS fk
JOIN sys.foreign_key_columns AS fkc ON fkc.constraint_object_id = fk.object_id
JOIN sys.tables              AS tp  ON tp.object_id = fkc.parent_object_id
JOIN sys.columns             AS cp  ON cp.object_id = fkc.parent_object_id
                                   AND cp.column_id = fkc.parent_column_id
JOIN sys.tables              AS tr  ON tr.object_id = fkc.referenced_object_id
JOIN sys.columns             AS cr  ON cr.object_id = fkc.referenced_object_id
                                   AND cr.column_id = fkc.referenced_column_id
ORDER BY from_schema, from_table, fk.name, ordinal
FOR JSON PATH;
