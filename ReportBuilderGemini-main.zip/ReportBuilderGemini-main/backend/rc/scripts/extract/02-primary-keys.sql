/* ═══════════════════════════════════════════════════════════
   ۲ از ۵ — کلیدهای اصلی             →  ذخیره کنید به‌نام:  pk.json
   تأیید حدس «PK = <TableName>ID». فقط sys.* — بدون داده.
   ═══════════════════════════════════════════════════════════ */
SET NOCOUNT ON;

SELECT
    [schema]   = SCHEMA_NAME(t.schema_id),
    [table]    = t.name,
    pk_name    = kc.name,
    pk_columns = STUFF((
                     SELECT ',' + c.name
                     FROM sys.index_columns ic
                     JOIN sys.columns c ON c.object_id = ic.object_id
                                       AND c.column_id = ic.column_id
                     WHERE ic.object_id = i.object_id
                       AND ic.index_id  = i.index_id
                     ORDER BY ic.key_ordinal
                     FOR XML PATH('')), 1, 1, '')
FROM sys.key_constraints AS kc
JOIN sys.tables          AS t ON t.object_id = kc.parent_object_id
JOIN sys.indexes         AS i ON i.object_id = kc.parent_object_id
                             AND i.index_id  = kc.unique_index_id
WHERE kc.type = 'PK' AND t.is_ms_shipped = 0
ORDER BY [schema], [table]
FOR JSON PATH;
