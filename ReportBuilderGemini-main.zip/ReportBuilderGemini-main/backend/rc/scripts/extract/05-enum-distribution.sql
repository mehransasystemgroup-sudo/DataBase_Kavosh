/* ═══════════════════════════════════════════════════════════════════
   ۵ از ۵ — توزیع مقادیر enum        →  ذخیره کنید به‌نام:  enums.json

   چرا لازم است:
       lookup-values.csv شما برچسب فارسی دارد، ولی نمی‌گوید در عمل
       کدام مقادیر رخ می‌دهند. بدون این، «State = 3 یعنی تأییدشده»
       یک حدس است، نه دانش اثبات‌شده.

   ⚠️  تنها اسکریپتی که داده می‌خواند — ولی فقط شمارش:
       خروجی = (جدول، ستون، مقدار، تعداد).
       هیچ نامی، مبلغی، شرحی، یا محتوای ردیفی خارج نمی‌شود.

   ⏱  هر ستون جداگانه پردازش می‌شود؛ خطای یکی بقیه را متوقف نمی‌کند.
       با NOLOCK اجرا می‌شود و قفلی روی جدول‌ها نمی‌گذارد.
       اگر کند بود: @MaxRows را کم کنید (مثلاً 2000000).
   ═══════════════════════════════════════════════════════════════════ */

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @MaxRows     bigint = 20000000;  -- جدول بزرگ‌تر از این رد می‌شود
DECLARE @MaxDistinct int    = 60;        -- تنوع بیشتر → enum نیست
DECLARE @TopPerCol   int    = 60;        -- حداکثر مقدار گزارش‌شده در هر ستون

IF OBJECT_ID('tempdb..#result') IS NOT NULL DROP TABLE #result;
CREATE TABLE #result (
    [schema] sysname, [table] sysname, [column] sysname,
    value nvarchar(20), cnt bigint
);

IF OBJECT_ID('tempdb..#skipped') IS NOT NULL DROP TABLE #skipped;
CREATE TABLE #skipped (
    [schema] sysname, [table] sysname, [column] sysname, reason nvarchar(200)
);


/* ── ۱. ستون‌های کاندید ─────────────────────────────────────────── */

DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
SELECT SCHEMA_NAME(t.schema_id), t.name, c.name
FROM sys.columns c
JOIN sys.tables  t  ON t.object_id = c.object_id
JOIN sys.types   ty ON ty.user_type_id = c.user_type_id
CROSS APPLY (
    SELECT rows_est = SUM(CASE WHEN p.index_id IN (0,1) THEN p.rows ELSE 0 END)
    FROM sys.partitions p WHERE p.object_id = t.object_id
) rc
WHERE t.is_ms_shipped = 0
  AND t.type = 'U'
  AND ty.name IN ('int','smallint','tinyint','bit')
  AND rc.rows_est BETWEEN 1 AND @MaxRows
  AND (   c.name LIKE '%State'
       OR c.name LIKE '%Status'
       OR c.name LIKE '%Type'
       OR c.name LIKE '%Kind'
       OR c.name IN ('Mode','Level','Category','Direction','Nature') )
  AND c.name NOT LIKE '%Ref'
  AND c.name NOT LIKE '%[Ii]d'
ORDER BY SCHEMA_NAME(t.schema_id), t.name, c.name;


/* ── ۲. پردازش ستون‌به‌ستون ─────────────────────────────────────── */

DECLARE @s sysname, @t sysname, @c sysname, @sql nvarchar(max), @n int;

OPEN cur;
FETCH NEXT FROM cur INTO @s, @t, @c;

WHILE @@FETCH_STATUS = 0
BEGIN
    BEGIN TRY
        -- تنوع را بسنج؛ اگر زیاد بود، enum نیست
        SET @sql = N'SELECT @out = COUNT(*) FROM (SELECT DISTINCT TOP (@lim) '
                 + QUOTENAME(@c) + N' FROM ' + QUOTENAME(@s) + N'.' + QUOTENAME(@t)
                 + N' WITH (NOLOCK)) AS d;';
        EXEC sp_executesql @sql,
             N'@lim int, @out int OUTPUT',
             @lim = @MaxDistinct, @out = @n OUTPUT;

        IF @n >= @MaxDistinct
            INSERT #skipped VALUES (@s, @t, @c, N'تنوع بالا — enum نیست');
        ELSE
        BEGIN
            SET @sql = N'
                INSERT #result ([schema],[table],[column],value,cnt)
                SELECT TOP (@top) @ps, @pt, @pc,
                       CONVERT(nvarchar(20), ' + QUOTENAME(@c) + N'),
                       COUNT_BIG(*)
                FROM ' + QUOTENAME(@s) + N'.' + QUOTENAME(@t) + N' WITH (NOLOCK)
                GROUP BY ' + QUOTENAME(@c) + N'
                ORDER BY COUNT_BIG(*) DESC;';
            EXEC sp_executesql @sql,
                 N'@top int, @ps sysname, @pt sysname, @pc sysname',
                 @top = @TopPerCol, @ps = @s, @pt = @t, @pc = @c;
        END
    END TRY
    BEGIN CATCH
        INSERT #skipped VALUES (@s, @t, @c, LEFT(ERROR_MESSAGE(), 200));
    END CATCH

    FETCH NEXT FROM cur INTO @s, @t, @c;
END

CLOSE cur;
DEALLOCATE cur;


/* ── ۳. خروجی ──────────────────────────────────────────────────── */

SELECT [schema], [table], [column], value, cnt
FROM #result
ORDER BY [schema], [table], [column], cnt DESC
FOR JSON PATH;
