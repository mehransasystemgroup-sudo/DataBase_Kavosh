@echo off
chcp 65001 >nul
REM ═══════════════════════════════════════════════════════════
REM  اجرای همه‌ی اسکریپت‌های استخراج با sqlcmd
REM  مطمئن‌تر از SSMS — خروجی بریده نمی‌شود.
REM
REM  استفاده:
REM     run-all.bat  <SERVER>  <DATABASE>  [OUTDIR]
REM  مثال:
REM     run-all.bat  localhost  MyErpDb  C:\extract
REM ═══════════════════════════════════════════════════════════

if "%~2"=="" (
  echo استفاده:  run-all.bat ^<SERVER^> ^<DATABASE^> [OUTDIR]
  exit /b 1
)

set SERVER=%~1
set DB=%~2
set OUT=%~3
if "%OUT%"=="" set OUT=%CD%\extract-output
if not exist "%OUT%" mkdir "%OUT%"

echo.
echo سرور: %SERVER%   دیتابیس: %DB%
echo خروجی: %OUT%
echo.

call :run 01-foreign-keys.sql      fk.json         "کلیدهای خارجی"
call :run 02-primary-keys.sql      pk.json         "کلیدهای اصلی"
call :run 03-indexes.sql           indexes.json    "ایندکس‌ها"
call :run 04-row-counts.sql        rowcounts.json  "تعداد ردیف"
call :run 05-enum-distribution.sql enums.json      "توزیع enum (ممکن است طول بکشد)"
call :run 06-lookups.sql           lookups.json    "واژه‌نامه enum"

echo.
echo ══ تمام شد ══
dir /b "%OUT%"
exit /b 0

:run
echo [%~3] ...
sqlcmd -S %SERVER% -d %DB% -E -i "%~1" -o "%OUT%\%~2" -y 0 -Y 0 -h -1 -W -f 65001
if errorlevel 1 (echo    ✖ خطا) else (echo    ✔ %~2)
exit /b 0
