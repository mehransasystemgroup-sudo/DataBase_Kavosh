/* ═══════════════════════════════════════════════════════════════════
   ۶ — واژه‌نامه‌ی enum        →  ذخیره کنید به‌نام:  lookups.json

   چرا این اسکریپت لازم است:
       فایل lookup-values.csv شما ستون OrdinalInType دارد — که
       «ترتیب نمایش در لیست کشویی» است، نه مقداری که در دیتابیس
       ذخیره می‌شود.

       نمونه‌ی واقعی از داده‌ی خودتان:
           FIN3.AccountGroup.State  در دیتابیس همیشه ۱ است
           ولی CSV می‌گوید ordinal 1 = «غیر فعال»
       یعنی همه‌ی گروه‌های حساب غیرفعال‌اند؟ بعید است.

       جدول SYS3.Lookup ستون Code را دارد — مقدار واقعی ذخیره‌شده.
       این تنها منبع قابل اعتماد است.

   ⚠️  محرمانگی: این چهار جدول، جدول‌های پیکربندی‌اند.
       محتوایشان برچسب‌هایی مثل «فعال»، «تأییدشده»، «پیش‌نویس» است.
       هیچ داده‌ی شخصی، مالی، یا تراکنشی ندارند.

   ⏱  چند ثانیه. حدود ۱۸ هزار ردیف.
   ═══════════════════════════════════════════════════════════════════ */

SET NOCOUNT ON;

SELECT kind, [type], code, [value], extra
FROM (
    /* ── مقادیر enum: مهم‌ترین بخش ──
       type  = نام نوع (مثلاً VoucherState)
       code  = مقدار واقعی در ستون دیتابیس  ⭐
       value = برچسب فارسی
       extra = ترتیب نمایش (همان OrdinalInType در CSV شما)          */
    SELECT
        kind    = 'enum_value',
        [type]  = l.[Type],
        code    = CONVERT(nvarchar(50), l.Code),
        [value] = l.[Value],
        extra   = CONVERT(nvarchar(50), l.DisplayOrder)
    FROM SYS3.Lookup AS l WITH (NOLOCK)

    UNION ALL

    /* ── عنوان فارسی خودِ نوع enum ──
       مثلاً: type='VoucherState'  →  value='وضعیت سند'            */
    SELECT
        'enum_type',
        li.[Type],
        NULL,
        li.Title,
        NULL
    FROM SYS3.LookupInfo AS li WITH (NOLOCK)

    UNION ALL

    /* ── ترجمه‌ها (اگر چندزبانه است) ──
       code = LookupRef → به LookupID در بخش اول وصل می‌شود        */
    SELECT
        'translation',
        NULL,
        CONVERT(nvarchar(50), lt.LookupRef),
        lt.[Value],
        lt.Culture
    FROM SYS3.LookupTranslation AS lt WITH (NOLOCK)

    UNION ALL

    /* ── نام موجودیت‌ها ──
       احتمالاً منبع entity-catalog.csv شماست                      */
    SELECT
        'entity',
        NULL,
        CONVERT(nvarchar(50), el.Code),
        el.EntityName,
        NULL
    FROM SYS3.EntityLookup AS el WITH (NOLOCK)
) AS x
ORDER BY kind, [type], code
FOR JSON PATH;
