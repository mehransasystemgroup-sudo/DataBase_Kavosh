/* ═══════════════════════════════════════════════════════════
   ۴ از ۵ — تعداد ردیف              →  ذخیره کنید به‌نام:  rowcounts.json
   نشان می‌دهد کدام ماژول‌ها در این نصب فعال‌اند.
   ⚠️  محرمانه — به instances/ می‌رود، نه kb/. در git نگذارید.
   ═══════════════════════════════════════════════════════════ */
SET NOCOUNT ON;

SELECT
    [schema]  = SCHEMA_NAME(t.schema_id),
    [table]   = t.name,
    row_count = SUM(CASE WHEN p.index_id IN (0,1) THEN p.rows ELSE 0 END)
FROM sys.tables     AS t
JOIN sys.partitions AS p ON p.object_id = t.object_id
WHERE t.is_ms_shipped = 0
GROUP BY SCHEMA_NAME(t.schema_id), t.name
ORDER BY [schema], [table]
FOR JSON PATH;
