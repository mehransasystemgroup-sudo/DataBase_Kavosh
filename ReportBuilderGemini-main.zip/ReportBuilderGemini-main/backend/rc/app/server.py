"""
سرور اپ وب لوکال.

پوستهٔ نازک روی core/ — هیچ منطقی این‌جا نیست.
هر مسیر یک تابع هسته را صدا می‌زند.

چرا مهم است:
    اگر منطق در لایهٔ وب باشد، رفتار اپ و MCP از هم جدا می‌شود.
    شش ماه بعد دو سیستم متفاوت دارید که یکی‌شان باگ‌های دیگری را ندارد.

اجرا:
    pip install fastapi uvicorn cryptography lxml
    python3 -m app.server
    → http://127.0.0.1:8321
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.search import KnowledgeBase                       # noqa: E402
from core.plan import QueryPlan, PlanValidator, SqlAssembler  # noqa: E402
from core.validate import SqlValidator                      # noqa: E402
from core.writer import KnowledgeWriter                     # noqa: E402
from core.agent import ReportAgent                          # noqa: E402
from core.providers import from_preset, PRESETS, ProviderError  # noqa: E402
from core.catalog import ReportCatalog                      # noqa: E402
from core.rdl_layout import (ReportLayout, derive_layout,    # noqa: E402
                             validate_layout)
from core.rdl_build import RdlBuilder, ReportStyle          # noqa: E402
from core.rdl import RdlParser, RdlValidator, render_report  # noqa: E402
from core.rdl_profile import OrgProfile                      # noqa: E402
from core.bench import ModelBench, BenchCase, DEFAULT_CASES  # noqa: E402

from .config import (SecretStore, SettingsStore, SessionStore,  # noqa: E402
                     AppSettings, estimate_cost, APP_DIR)


# ═══════════════ راه‌اندازی ═══════════════

KB_ROOT = Path(os.environ.get("KB_ROOT", ROOT / "kb"))
INDEX = Path(os.environ.get("KB_INDEX", ROOT / "index" / "kb.sqlite"))
OUT_DIR = Path(os.environ.get("RC_OUT", APP_DIR / "reports"))
OUT_DIR.mkdir(parents=True, exist_ok=True)
UPLOADS_DIR = Path(os.environ.get("RC_UPLOADS", APP_DIR / "uploads"))
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

# ── متادیتای واقعی دیتابیس (ایندکس‌ها / کلید اصلی) از خروجی‌های کاربر ──
DB_META_DIR = ROOT / "db-meta"


def _load_db_meta() -> dict:
    """ایندکس‌ها و کلیدهای اصلیِ واقعی را بر اساس نام کامل جدول گروه‌بندی می‌کند."""
    idx: dict[str, list] = {}
    pk: dict[str, str] = {}
    idx_file = (DB_META_DIR / "indexes.clean.json"
                if (DB_META_DIR / "indexes.clean.json").exists()
                else DB_META_DIR / "indexes.json")
    try:
        data = json.loads(idx_file.read_text(encoding="utf-8"))
        for r in data:
            full = f"{r['schema']}.{r['table']}"
            idx.setdefault(full, []).append({
                "name": r.get("index_name", ""),
                "type": r.get("index_type", ""),
                "unique": bool(r.get("is_unique")),
                "is_pk": bool(r.get("is_pk")),
                "columns": [c.strip() for c in (r.get("key_columns") or "").split(",") if c.strip()],
            })
    except Exception:
        pass
    try:
        data = json.loads((DB_META_DIR / "primaryKeys.json").read_text(encoding="utf-8"))
        for r in data:
            pk[f"{r['schema']}.{r['table']}"] = r.get("pk_columns", "")
    except Exception:
        pass
    return {"indexes": idx, "pk": pk}


DB_META = _load_db_meta()

if not INDEX.exists():
    sys.exit(f"✖ ایندکس نیست: {INDEX}\n"
             f"  بسازیدش: python3 scripts/build_index.py --kb kb "
             f"--out index/kb.sqlite --instance instances/default")

kb = KnowledgeBase(INDEX)
sql_validator = SqlValidator(kb)
plan_validator = PlanValidator(kb)
writer = KnowledgeWriter(KB_ROOT)
catalog = ReportCatalog(KB_ROOT / "reports")
secrets = SecretStore()
settings_store = SettingsStore()
sessions = SessionStore()

app = FastAPI(title="گزارش‌ساز", docs_url="/api/docs")
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])


def _style() -> ReportStyle:
    f = KB_ROOT / "report-style.json"
    return ReportStyle.load(f) if f.exists() else ReportStyle()


def _profile() -> OrgProfile:
    return OrgProfile.load(KB_ROOT / "report-profile.json")


def _provider(s: AppSettings):
    preset = PRESETS.get(s.model_preset)
    if preset is None:
        raise ProviderError(f"پیش‌تنظیم «{s.model_preset}» نیست.")
    key = secrets.get(preset.provider)
    over = {}
    if s.model_override:
        over["model"] = s.model_override
    if s.base_url:
        over["base_url"] = s.base_url
    over["timeout"] = s.timeout
    return from_preset(s.model_preset, key, **over)


# ═══════════════ مدل‌های درخواست ═══════════════

class ChatIn(BaseModel):
    request: str
    session_id: str | None = None
    tables: list[str] | None = None


class RdlIn(BaseModel):
    plan: dict
    title_fa: str = ""
    layout: dict | None = None
    filename: str = "report.rdl"
    category: str = ""


class KnowledgeIn(BaseModel):
    kind: str                       # table | enum | join | lesson
    payload: dict


class SettingsIn(BaseModel):
    settings: dict | None = None
    api_keys: dict[str, str] | None = None


# ═══════════════ سلامت و آمار ═══════════════

@app.get("/api/health")
def health() -> dict:
    s = settings_store.load()
    return {
        "ok": True,
        "kb": kb.stats(),
        "catalog": catalog.stats(),
        "model": s.model_preset,
        "keys": secrets.which(),
        "budget": {"limit": s.daily_budget_usd, "spent": s.spent_today_usd,
                   "over": settings_store.over_budget()},
    }


# ═══════════════ کاوش دانش ═══════════════

@app.get("/api/search")
def search(q: str, limit: int = 12, all: bool = False) -> dict:
    hits = kb.search_tables(q, limit=limit, only_with_data=not all)
    return {"results": [{
        "full_name": h.full_name, "title_fa": h.title_fa,
        "row_count": h.row_count, "has_data": h.has_data,
        "in_live_db": getattr(h, "in_live_db", True),
        "why": getattr(h, "why", ""),
    } for h in hits]}


@app.get("/api/columns")
def search_columns(q: str, limit: int = 25) -> dict:
    return {"results": kb.search_columns(q, limit=limit)}


@app.get("/api/table/{full_name}")
def table(full_name: str) -> dict:
    t = kb.get_table(full_name)
    if not t:
        raise HTTPException(404, f"جدول «{full_name}» پیدا نشد.")
    idx = DB_META["indexes"].get(full_name, [])
    indexed_cols = sorted({c for i in idx for c in i["columns"]})
    return {
        "full_name": t.full_name, "title_fa": t.title_fa,
        "description_fa": t.description_fa,
        "row_count": t.row_count, "has_data": t.has_data,
        "primary_key": t.primary_key or (
            [c.strip() for c in DB_META["pk"].get(full_name, "").split(",") if c.strip()]),
        "warnings": t.warnings,
        "columns": t.columns,
        "enums": {c: v for c, v in (t.enums or {}).items()},
        "outgoing": [{"from_col": j.from_col, "to_table": j.to_table,
                      "to_col": j.to_col, "verified": j.verified}
                     for j in t.outgoing],
        "incoming": [{"from_table": j.from_table, "from_col": j.from_col,
                      "to_col": j.to_col, "verified": j.verified}
                     for j in t.incoming],
        "schema": t.full_name.split(".")[0],
        "table_name": t.full_name.split(".")[1] if "." in t.full_name else t.full_name,
        "indexes": idx,
        "indexed_columns": indexed_cols,
    }


@app.get("/api/joinpath")
def joinpath(src: str, dst: str) -> dict:
    steps = kb.find_join_path(src, dst)
    if not steps:
        return {"found": False, "steps": [], "warning": "مسیری پیدا نشد."}
    return {"found": True,
            "steps": [{"sql": s.sql(), "verified": getattr(s, "verified", True)}
                      for s in steps],
            "warning": kb.path_warning(steps) or ""}


# ═══════════════ گفتگو با streaming ═══════════════

def _sse(event: str, data: Any) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


@app.post("/api/chat")
async def chat(body: ChatIn):
    """
    اجرای حلقهٔ ایجنت با گزارش زندهٔ هر گام.

    کاربر می‌بیند سیستم چه جدولی پیدا کرد، مدل چه نقشه‌ای داد،
    و اعتبارسنج چه گرفت — نه فقط نتیجهٔ نهایی.
    """
    s = settings_store.load()
    if settings_store.over_budget():
        raise HTTPException(429,
            f"سقف هزینهٔ روزانه ({s.daily_budget_usd}$) پر شده. "
            f"در تنظیمات تغییرش دهید.")
    try:
        prov = _provider(s)
    except ProviderError as e:
        raise HTTPException(400, str(e))

    sid = body.session_id or sessions.new()
    sessions.add(sid, "user", body.request)

    async def stream():
        yield _sse("start", {"session_id": sid, "model": s.model_preset})
        loop = asyncio.get_event_loop()

        agent = ReportAgent(kb, prov, max_attempts=s.max_attempts,
                            context_tables=s.context_tables, catalog=catalog)

        tables = await loop.run_in_executor(
            None, agent._pick_tables, body.request, body.tables)
        yield _sse("tables", {"tables": tables})

        prior = catalog.context_for(body.request)
        if prior:
            yield _sse("prior", {"text": prior[:900]})

        # حلقهٔ اصلی در نخ جدا — مدل ممکن است کند باشد
        result = await loop.run_in_executor(
            None, lambda: agent.build(body.request, hints=body.tables))

        for t in result.transcript:
            yield _sse("attempt", {"n": t.get("attempt"),
                                   "raw": (t.get("raw") or "")[:600]})
            await asyncio.sleep(0)

        if result.check:
            yield _sse("validation", {"issues": [
                {"severity": i.severity, "field": i.field,
                 "message": i.message_fa, "options": i.options[:12]}
                for i in result.check.issues]})

        cost = estimate_cost(s.model_override or PRESETS[s.model_preset].model,
                             result.usage.get("in", 0), result.usage.get("out", 0))
        if cost:
            settings_store.add_cost(cost)

        payload = {
            "ok": result.ok,
            "attempts": result.attempts,
            "sql": result.sql,
            "plan": result.plan.to_dict() if result.plan else None,
            "usage": result.usage,
            "cost_usd": cost,
            "tables": result.context_tables,
        }
        if result.ok and result.plan:
            lay = derive_layout(result.plan, kb)
            validate_layout(lay, result.plan)
            payload["layout"] = lay.to_dict()

        sessions.add(sid, "assistant", result.sql or "—", payload)
        yield _sse("done", payload)

    return StreamingResponse(stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


# ═══════════════ اعتبارسنجی و تولید ═══════════════

@app.post("/api/validate-plan")
def validate_plan(body: dict) -> dict:
    plan, check = plan_validator.validate(QueryPlan.from_dict(body))
    return {
        "ok": check.ok,
        "sql": SqlAssembler.build(plan) if check.ok else "",
        "plan": plan.to_dict(),
        "issues": [{"severity": i.severity, "field": i.field,
                    "message": i.message_fa, "options": i.options[:20]}
                   for i in check.issues],
    }


@app.post("/api/validate-sql")
def validate_sql(body: dict) -> dict:
    sql = body.get("sql", "")
    res = sql_validator.validate(sql)
    sql_validator.check_fiscal_year(sql, res)
    return {"ok": res.ok, "findings": [
        {"severity": f.severity, "message": f.message, "hint": f.hint}
        for f in res.findings]}


@app.post("/api/rdl")
def build_rdl(body: RdlIn) -> dict:
    plan, check = plan_validator.validate(QueryPlan.from_dict(body.plan))
    if not check.ok:
        raise HTTPException(400, check.feedback_for_model())

    sql = SqlAssembler.build(plan)
    lay = ReportLayout.from_dict(body.layout) if body.layout \
        else derive_layout(plan, kb)
    lay_issues = validate_layout(lay, plan)
    if any(i.severity == "error" for i in lay_issues):
        raise HTTPException(400, "\n".join(
            i.message_fa for i in lay_issues if i.severity == "error"))

    xml = RdlBuilder(_style(), kb, _profile()).from_plan(
        plan, sql, layout=lay, title_fa=body.title_fa or plan.intent_fa)

    name = "".join(c for c in body.filename if c not in '\\/:*?"<>|') or "report.rdl"
    if not name.endswith(".rdl"):
        name += ".rdl"
    out = OUT_DIR / name
    out.write_text(xml, encoding="utf-8")

    doc = RdlParser(out).parse()
    issues = RdlValidator(kb, sql_validator).validate(doc)
    errors = [str(i) for i in issues if i.severity == "error"]

    entry = catalog.save(title_fa=body.title_fa or plan.intent_fa, plan=plan,
                         sql=sql, layout=lay, rdl_path=str(out),
                         category=body.category)

    return {
        "ok": not errors,
        "path": str(out), "filename": name, "size": len(xml),
        "layout": lay.kind, "slug": entry.slug,
        "errors": errors,
        "warnings": [str(i) for i in issues if i.severity == "warning"],
    }


@app.get("/api/download/{name}")
def download(name: str):
    p = OUT_DIR / Path(name).name
    if not p.exists():
        raise HTTPException(404, "فایل نیست.")
    ext = p.suffix.lower()
    media = {".rdl": "application/xml", ".sql": "text/plain",
             ".txt": "text/plain", ".xml": "application/xml"}.get(ext,
                                                                  "application/octet-stream")
    return FileResponse(p, filename=p.name, media_type=media)


# ═══════════════ آپلود منابع و استخراج دانش ═══════════════

_TABLE_REF = __import__("re").compile(
    r"\b([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\b")


def _extract_tables_from_sql(*sqls: str) -> list[dict]:
    """نام‌های SCHEMA.Table را از متن SQL می‌کشد و با KB تطبیق می‌دهد."""
    seen: dict[str, dict] = {}
    for sql in sqls:
        if not sql:
            continue
        for schema, table in _TABLE_REF.findall(sql):
            full = f"{schema}.{table}"
            if full in seen:
                continue
            t = kb.get_table(full)
            if t:
                seen[full] = {"full_name": full, "title_fa": t.title_fa,
                              "has_data": t.has_data, "in_kb": True}
    return list(seen.values())


def _safe_name(name: str) -> str:
    keep = "".join(c for c in (name or "") if c not in '\\/:*?"<>|')
    return keep.strip() or "upload"


@app.post("/api/upload")
async def upload_resource(file: UploadFile = File(...)) -> dict:
    """
    آپلود یک منبع (.rdl / .sql / .txt) و استخراج دانشِ قابل‌افزودن.

    خروجی شامل جدول‌های شناسایی‌شده است تا کاربر به‌صورت دستی
    تصمیم بگیرد کدام‌ها به حافظهٔ اپلیکیشن اضافه شوند.
    """
    raw = await file.read()
    if len(raw) > 8 * 1024 * 1024:
        raise HTTPException(400, "حجم فایل بیش از ۸ مگابایت است.")
    name = _safe_name(file.filename or "upload")
    ext = Path(name).suffix.lower()
    if ext not in (".rdl", ".sql", ".txt", ".xml"):
        raise HTTPException(400, "فقط فایل‌های .rdl / .sql / .txt پشتیبانی می‌شوند.")
    dest = UPLOADS_DIR / name
    if dest.exists():
        import uuid as _uuid
        dest = UPLOADS_DIR / f"{Path(name).stem}-{_uuid.uuid4().hex[:6]}{ext}"
    dest.write_bytes(raw)

    if ext in (".rdl", ".xml"):
        try:
            doc = RdlParser(dest).parse()
        except Exception as e:                              # noqa: BLE001
            raise HTTPException(400, f"خواندن RDL ناموفق بود: {e}")
        commands = [d.command for d in doc.datasets]
        tables = _extract_tables_from_sql(*commands)
        return {
            "ok": True, "type": "rdl", "filename": name, "path": str(dest),
            "learnable_profile": True,
            "datasets": [{"name": d.name, "command": (d.command or "")[:4000],
                          "fields": [f.name for f in d.fields][:60]}
                         for d in doc.datasets],
            "parameters": [p.name for p in doc.parameters],
            "subreports": doc.subreports,
            "tables_found": tables,
        }

    text = raw.decode("utf-8", "replace")
    tables = _extract_tables_from_sql(text)
    return {
        "ok": True, "type": "sql", "filename": name, "path": str(dest),
        "learnable_profile": False,
        "sql": text[:20000],
        "tables_found": tables,
    }


@app.post("/api/save-report")
def save_report(body: dict) -> dict:
    """
    ذخیرهٔ یک گزارش تولیدشده در کتابخانه (کاتالوگ) به‌همراه فایل .sql.

    این همان دکمهٔ «ثبت در حافظه» در پایان مکالمه است.
    """
    sql = (body.get("sql") or "").strip()
    if not sql:
        raise HTTPException(400, "SQL خالی است.")
    plan_dict = body.get("plan")
    title_fa = body.get("title_fa") or (plan_dict or {}).get("intent_fa") or "گزارش"
    request_fa = body.get("request_fa", "")
    model = body.get("model", "")
    category = body.get("category", "")

    # اگر فایل RDL آپلودشده باشد، در خروجی‌ها کپی و به گزارش پیوست می‌شود
    rdl_path = ""
    src = body.get("rdl_source_path")
    if src and Path(src).is_file():
        from core.catalog import _slugify as _sl
        rdl_name = f"{_sl(title_fa)}.rdl"
        dst = OUT_DIR / rdl_name
        dst.write_bytes(Path(src).read_bytes())
        rdl_path = str(dst)

    if plan_dict:
        plan, check = plan_validator.validate(QueryPlan.from_dict(plan_dict))
        entry = catalog.save(title_fa=title_fa, plan=plan, sql=sql,
                             request_fa=request_fa, model=model,
                             category=category, rdl_path=rdl_path)
        slug = entry.slug
    else:
        entry = catalog.save_raw(title_fa=title_fa, sql=sql, category=category,
                                 tables=body.get("tables") or [],
                                 rdl_path=rdl_path, request_fa=request_fa)
        slug = entry.slug

    # فایل .sql کنار خروجی‌ها
    sql_name = f"{slug}.sql"
    (OUT_DIR / sql_name).write_text(
        f"-- {title_fa}\n-- {datetime_now()}\n\n{sql}\n", encoding="utf-8")

    return {"ok": True, "slug": slug, "sql_file": sql_name,
            "in_catalog": True}


def datetime_now() -> str:
    from datetime import datetime
    return datetime.now().isoformat(timespec="seconds")


@app.get("/api/reports/{slug}/file/{fmt}")
def report_file(slug: str, fmt: str):
    """دانلود گزارش ذخیره‌شده در قالب sql / txt / rdl."""
    e = catalog.get(slug)
    if not e:
        raise HTTPException(404, "گزارش نیست.")
    if fmt in ("sql", "txt"):
        body = f"-- {e.title_fa}\n\n{e.sql}\n"
        from urllib.parse import quote
        fn = quote(f"{slug}.{fmt}")
        return Response(
            content=body, media_type="text/plain; charset=utf-8",
            headers={"Content-Disposition":
                     f"attachment; filename=report.{fmt}; filename*=UTF-8''{fn}"})
    if fmt == "rdl":
        if not e.rdl_path or not Path(e.rdl_path).is_file():
            raise HTTPException(404, "فایل RDL برای این گزارش ساخته نشده.")
        p = Path(e.rdl_path)
        return FileResponse(p, filename=p.name, media_type="application/xml")
    raise HTTPException(400, "قالب نامعتبر.")


@app.post("/api/check-rdl")
async def check_rdl(body: dict) -> dict:
    path = Path(body.get("path", ""))
    if not path.exists():
        raise HTTPException(404, f"فایل نیست: {path}")
    doc = RdlParser(path).parse()
    issues = RdlValidator(kb, sql_validator).validate(doc)
    return {"report": render_report(doc, issues),
            "errors": sum(1 for i in issues if i.severity == "error"),
            "warnings": sum(1 for i in issues if i.severity == "warning")}


# ═══════════════ کاتالوگ ═══════════════

BENCH_STATE = {"running": False, "results": None, "progress": ""}


@app.post("/api/bench")
async def run_bench(body: dict):
    """
    محک چند مدل روی یک یا چند درخواست — با گزارش زندهٔ پیشرفت.

    فقط مدل‌هایی که کلید دارند (یا محلی‌اند) اجرا می‌شوند.
    """
    if BENCH_STATE["running"]:
        raise HTTPException(429, "محک در جریان است.")

    presets = body.get("models") or []
    reqs = [r for r in (body.get("requests") or []) if r.strip()]
    cases = [BenchCase(r) for r in reqs] if reqs else DEFAULT_CASES

    pairs = []
    for name in presets:
        cfg = PRESETS.get(name)
        if not cfg:
            continue
        key = secrets.get(cfg.provider)
        local = "localhost" in (cfg.base_url or "")
        if key or local:
            pairs.append((name, key))
    if not pairs:
        raise HTTPException(400, "هیچ مدلی کلید ندارد.")

    async def stream():
        BENCH_STATE["running"] = True
        try:
            yield _sse("start", {"models": [p[0] for p in pairs],
                                 "cases": len(cases)})
            loop = asyncio.get_event_loop()
            bench = ModelBench(kb, catalog,
                               max_attempts=settings_store.load().max_attempts)
            queue: list = []

            def progress(done, total, case, model):
                queue.append({"done": done, "total": total,
                              "case": case[:60], "model": model})

            task = loop.run_in_executor(
                None, lambda: bench.run(pairs, cases,
                                        cost_fn=estimate_cost, on_progress=progress))
            sent = 0
            while not task.done():
                await asyncio.sleep(0.4)
                while sent < len(queue):
                    yield _sse("progress", queue[sent])
                    sent += 1
            results = await task
            while sent < len(queue):
                yield _sse("progress", queue[sent]); sent += 1

            total_cost = sum(r.cost_usd for br in results for r in br.runs)
            if total_cost:
                settings_store.add_cost(total_cost)

            payload = {
                "cases": [{"case": br.case,
                           "consensus": br.consensus()[1:],
                           "runs": [r.to_dict() for r in br.runs]}
                          for br in results],
                "scoreboard": ModelBench.scoreboard(results),
                "cost_usd": round(total_cost, 5),
            }
            BENCH_STATE["results"] = payload
            yield _sse("done", payload)
        finally:
            BENCH_STATE["running"] = False

    return StreamingResponse(stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@app.get("/api/bench/last")
def bench_last() -> dict:
    return {"running": BENCH_STATE["running"], "results": BENCH_STATE["results"]}


@app.get("/api/profile")
def get_profile() -> dict:
    """قرارداد سازمانی استخراج‌شده از RDLهای واقعی."""
    pf = _profile()
    st = _style()
    return {
        "learned": bool(pf.learned_from),
        "profile": {
            "data_source": f"{pf.data_source_name} → {pf.data_source_ref}",
            "system_parameters": [d["name"] for d in pf.system_parameters],
            "helper_datasets": [d["name"] for d in pf.helper_datasets],
            "number_format": pf.number_format,
            "border": f"{pf.border_style} · {pf.border_color}",
            "page": " × ".join(pf.page_size()),
            "margin": pf.margin,
            "learned_from": pf.learned_from,
            "learned_at": pf.learned_at,
        },
        "style": {"font": st.font_family, "size": st.font_size_body,
                  "direction": st.direction, "header_bg": st.header_bg},
    }


@app.post("/api/profile/learn")
def learn_profile(body: dict) -> dict:
    """یادگیری قالب و قرارداد از فایل‌های RDL روی این سیستم."""
    paths = [Path(p) for p in body.get("paths", []) if Path(p).exists()]
    if not paths:
        raise HTTPException(400, "هیچ فایل معتبری داده نشد.")
    st = ReportStyle.learn_from(*paths)
    st.save(KB_ROOT / "report-style.json")
    pf = OrgProfile.learn_from(*paths)
    pf.save(KB_ROOT / "report-profile.json")
    return {"ok": True, "files": len(paths), "summary": pf.summary_fa()}


@app.get("/api/reports")
def reports(q: str = "", category: str | None = None) -> dict:
    if q:
        return {"results": [{**e.__dict__, "score": sc}
                            for e, sc in catalog.find(q)],
                "categories": catalog.categories()}
    entries = catalog.all()
    if category is not None:
        entries = [e for e in entries if (e.category or "") == category]
    return {"results": [{"slug": e.slug, "title_fa": e.title_fa,
                         "category": e.category,
                         "tables": e.tables, "layout_kind": e.layout_kind,
                         "parameters": e.parameters, "lessons": e.lessons,
                         "rdl_path": e.rdl_path, "request_fa": e.request_fa,
                         "created_at": e.created_at, "used_count": e.used_count}
                        for e in entries],
            "categories": catalog.categories(),
            "stats": catalog.stats()}


@app.get("/api/categories")
def list_categories() -> dict:
    return {"categories": catalog.categories()}


@app.post("/api/reports/{slug}/category")
def set_report_category(slug: str, body: dict) -> dict:
    ok = catalog.set_category(slug, (body.get("category") or "").strip())
    if not ok:
        raise HTTPException(404, "گزارش نیست.")
    return {"ok": True, "categories": catalog.categories()}


@app.get("/api/reports/{slug}")
def report(slug: str) -> dict:
    e = catalog.get(slug)
    if not e:
        raise HTTPException(404, "گزارش نیست.")
    catalog.touch(slug)
    return e.__dict__


# ═══════════════ ثبت دانش ═══════════════

INDEX_STATE = {"building": False, "last": "", "log": ""}


@app.post("/api/index/rebuild")
async def rebuild_index() -> dict:
    """
    بازسازی ایندکس پس از ثبت دانش.

    بدون این، دانشی که ثبت می‌کنید در جست‌وجو ظاهر نمی‌شود —
    چون ایندکس یک مصنوع مشتق است، نه منبع حقیقت.
    """
    import subprocess
    from datetime import datetime as _dt

    if INDEX_STATE["building"]:
        return {"ok": False, "error": "بازسازی در جریان است."}
    INDEX_STATE["building"] = True

    def run():
        inst = ROOT / "instances" / settings_store.load().instance
        if not inst.exists():
            for cand in ("live", "dev-fixture"):
                if (ROOT / "instances" / cand).exists():
                    inst = ROOT / "instances" / cand
                    break
        cmd = [sys.executable, str(ROOT / "scripts" / "build_index.py"),
               "--kb", str(KB_ROOT), "--out", str(INDEX)]
        if inst.exists():
            cmd += ["--instance", str(inst)]
        return subprocess.run(cmd, capture_output=True, text=True, timeout=600)

    try:
        r = await asyncio.get_event_loop().run_in_executor(None, run)
        INDEX_STATE["log"] = (r.stdout or r.stderr)[-1200:]
        INDEX_STATE["last"] = _dt.now().isoformat(timespec="seconds")
        ok = r.returncode == 0
        if ok:
            kb.reload() if hasattr(kb, "reload") else None
        return {"ok": ok, "log": INDEX_STATE["log"], "at": INDEX_STATE["last"],
                "note": "برای اعمال کامل، سرور را دوباره اجرا کنید."}
    except Exception as e:
        return {"ok": False, "error": str(e)}
    finally:
        INDEX_STATE["building"] = False


@app.get("/api/index/state")
def index_state() -> dict:
    return {**INDEX_STATE, "path": str(INDEX)}


@app.post("/api/layout/preview")
def layout_preview(body: dict) -> dict:
    """
    پیش‌نمایش ساختار ردیف‌ها برای یک چیدمان.

    قبل از تولید فایل، کاربر می‌بیند گزارش چه شکلی می‌شود.
    """
    from core.rdl_layout import build_row_model
    plan, check = plan_validator.validate(QueryPlan.from_dict(body.get("plan", {})))
    if not check.ok:
        raise HTTPException(400, check.feedback_for_model())
    lay = ReportLayout.from_dict(body["layout"]) if body.get("layout") \
        else derive_layout(plan, kb)
    issues = validate_layout(lay, plan)
    rows = build_row_model(lay)
    labels = {"header": "سرستون", "group_header": "عنوان گروه",
              "detail": "جزئیات", "group_total": "جمع گروه",
              "grand_total": "جمع کل"}
    return {
        "kind": lay.kind,
        "layout": lay.to_dict(),
        "rows": [{"kind": r.kind, "label": labels.get(r.kind, r.kind),
                  "level": r.level, "group": r.group_name} for r in rows],
        "columns": [c.output_name() for c in plan.select],
        "issues": [{"severity": i.severity, "message": i.message_fa} for i in issues],
    }


@app.post("/api/knowledge")
def knowledge(body: KnowledgeIn) -> dict:
    p = body.payload
    try:
        if body.kind == "table":
            writer.record_table(**p)
        elif body.kind == "enum":
            writer.record_enum(**p)
        elif body.kind == "join":
            writer.record_join(**p)
        elif body.kind == "lesson":
            ok = catalog.add_lesson(p.get("slug", ""), p.get("lesson", ""))
            if not ok:
                raise HTTPException(404, "گزارش در کاتالوگ نیست.")
        else:
            raise HTTPException(400, f"نوع «{body.kind}» شناخته نشد.")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "note": "برای اعمال در جست‌وجو، ایندکس را بازسازی کنید."}


# ═══════════════ تنظیمات ═══════════════

@app.get("/api/settings")
def get_settings() -> dict:
    return {"settings": settings_store.load().to_public(),
            "keys": secrets.which(),
            "presets": {k: {"provider": v.provider, "model": v.model,
                            "base_url": v.base_url,
                            "local": "localhost" in (v.base_url or "")}
                        for k, v in PRESETS.items()}}


@app.post("/api/settings")
def set_settings(body: SettingsIn) -> dict:
    if body.settings:
        s = settings_store.load()
        for k, v in body.settings.items():
            if k in AppSettings.__dataclass_fields__ and k not in (
                    "spent_today_usd", "spent_date"):
                setattr(s, k, v)
        settings_store.save(s)
    if body.api_keys:
        for provider, key in body.api_keys.items():
            secrets.set(provider, key.strip())
    return {"ok": True, "settings": settings_store.load().to_public(),
            "keys": secrets.which()}


@app.post("/api/test-model")
def test_model() -> dict:
    """آزمایش اتصال — بدون مصرف زیاد."""
    s = settings_store.load()
    try:
        prov = _provider(s)
        out = prov.complete("پاسخ فقط یک کلمه.", [{"role": "user", "content": "سلام"}])
        return {"ok": True, "reply": out[:120],
                "usage": getattr(prov, "last_usage", {})}
    except ProviderError as e:
        return {"ok": False, "error": str(e)}


# ═══════════════ جلسه‌ها ═══════════════

@app.get("/api/sessions")
def list_sessions() -> dict:
    return {"sessions": sessions.list()}


@app.get("/api/sessions/{sid}")
def get_session(sid: str) -> dict:
    return {"turns": [{"role": t.role, "content": t.content,
                       "meta": t.meta, "at": t.at} for t in sessions.turns(sid)]}


@app.delete("/api/sessions/{sid}")
def del_session(sid: str) -> dict:
    sessions.delete(sid)
    return {"ok": True}


# ═══════════════ فایل‌های ایستا ═══════════════

STATIC = Path(__file__).parent / "static"
if STATIC.exists():
    app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/")
def index():
    f = STATIC / "index.html"
    if not f.exists():
        return {"error": "رابط پیدا نشد", "api": "/api/docs"}
    return FileResponse(f)


def main() -> None:
    import uvicorn
    port = int(os.environ.get("RC_PORT", 8321))
    print(f"\n  گزارش‌ساز  →  http://127.0.0.1:{port}")
    print(f"  دانش: {KB_ROOT}   ایندکس: {INDEX}")
    print(f"  خروجی: {OUT_DIR}\n")
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    main()
