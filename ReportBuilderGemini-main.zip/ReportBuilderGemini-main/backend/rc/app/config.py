"""
پیکربندی اپ — ذخیره‌سازی امن کلید API و جلسه‌ها.

اصول:
    • کلید API رمزنگاری‌شده روی دیسک، خارج از مخزن git
    • کلید رمزنگاری در فایل جدا با دسترسی محدود (۶۰۰)
    • هیچ کلیدی در پاسخ API برنمی‌گردد — فقط «تنظیم شده / نشده»
    • جلسه‌ها در SQLite محلی، بدون ارسال به بیرون
"""

from __future__ import annotations

import json
import os
import sqlite3
import stat
import uuid
from dataclasses import dataclass, asdict, field
from datetime import datetime
from pathlib import Path

try:
    from cryptography.fernet import Fernet, InvalidToken
    HAS_CRYPTO = True
except ImportError:                                   # pragma: no cover
    HAS_CRYPTO = False


APP_DIR = Path(os.environ.get("RC_HOME", Path.home() / ".report-copilot"))


# ═══════════════ رمزنگاری ═══════════════

class SecretStore:
    """
    ذخیرهٔ کلیدهای API با رمزنگاری متقارن.

    کلید رمزنگاری در فایل جداگانه است با دسترسی فقط برای مالک.
    اگر کسی فایل رمزشده را بردارد ولی کلید را نه، بی‌فایده است.
    """

    def __init__(self, root: Path | None = None):
        self.root = Path(root or APP_DIR)
        self.root.mkdir(parents=True, exist_ok=True)
        self.key_file = self.root / ".enckey"
        self.data_file = self.root / "secrets.enc"

    def _fernet(self) -> "Fernet":
        if not HAS_CRYPTO:
            raise RuntimeError("نیاز به cryptography:  pip install cryptography")
        if not self.key_file.exists():
            self.key_file.write_bytes(Fernet.generate_key())
            try:
                self.key_file.chmod(stat.S_IRUSR | stat.S_IWUSR)   # 600
            except OSError:
                pass                                   # ویندوز
        return Fernet(self.key_file.read_bytes())

    def load(self) -> dict[str, str]:
        if not self.data_file.exists():
            return {}
        try:
            raw = self._fernet().decrypt(self.data_file.read_bytes())
            return json.loads(raw.decode("utf-8"))
        except (InvalidToken, ValueError, json.JSONDecodeError):
            return {}

    def save(self, secrets: dict[str, str]) -> None:
        blob = self._fernet().encrypt(
            json.dumps(secrets, ensure_ascii=False).encode("utf-8"))
        self.data_file.write_bytes(blob)
        try:
            self.data_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass

    def get(self, provider: str) -> str:
        # متغیر محیطی اولویت دارد — برای CI و اجرای موقت
        env = {"anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY",
               "google": "GOOGLE_API_KEY", "deepseek": "DEEPSEEK_API_KEY",
               "emergent": "EMERGENT_LLM_KEY"}
        v = os.environ.get(env.get(provider, ""), "")
        return v or self.load().get(provider, "")

    def set(self, provider: str, key: str) -> None:
        s = self.load()
        if key:
            s[provider] = key
        else:
            s.pop(provider, None)
        self.save(s)

    def which(self) -> dict[str, bool]:
        """کدام ارائه‌دهنده کلید دارد — بدون افشای خود کلید."""
        stored = self.load()
        out = {}
        for p in ("anthropic", "openai", "google", "deepseek"):
            out[p] = bool(stored.get(p)) or bool(self.get(p))
        out["emergent"] = bool(os.environ.get("EMERGENT_LLM_KEY", ""))
        return out


# ═══════════════ تنظیمات ═══════════════

@dataclass
class AppSettings:
    model_preset: str = "emergent"
    model_override: str = ""            # نام مدل خاص
    base_url: str = ""                  # برای سرویس سازگار OpenAI
    max_attempts: int = 4
    context_tables: int = 6
    timeout: int = 180
    daily_budget_usd: float = 2.0
    spent_today_usd: float = 0.0
    spent_date: str = ""
    kb_root: str = ""
    index_path: str = ""
    instance: str = "live"

    def to_public(self) -> dict:
        """بدون هیچ اطلاعات حساس."""
        return asdict(self)


class SettingsStore:
    def __init__(self, root: Path | None = None):
        self.root = Path(root or APP_DIR)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "settings.json"

    def load(self) -> AppSettings:
        if not self.path.exists():
            return AppSettings()
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            return AppSettings(**{k: v for k, v in d.items()
                                  if k in AppSettings.__dataclass_fields__})
        except Exception:
            return AppSettings()

    def save(self, s: AppSettings) -> None:
        self.path.write_text(json.dumps(asdict(s), ensure_ascii=False, indent=2),
                             encoding="utf-8")

    def add_cost(self, usd: float) -> AppSettings:
        """
        ثبت هزینه و بازنشانی روزانه.

        بدون سقف صریح، هزینهٔ API نامرئی است تا صورتحساب بیاید.
        """
        s = self.load()
        today = datetime.now().strftime("%Y-%m-%d")
        if s.spent_date != today:
            s.spent_date, s.spent_today_usd = today, 0.0
        s.spent_today_usd = round(s.spent_today_usd + usd, 5)
        self.save(s)
        return s

    def over_budget(self) -> bool:
        s = self.load()
        today = datetime.now().strftime("%Y-%m-%d")
        if s.spent_date != today:
            return False
        return s.daily_budget_usd > 0 and s.spent_today_usd >= s.daily_budget_usd


# ═══════════════ هزینه ═══════════════

# دلار به ازای یک میلیون توکن — تقریبی، برای هشدار نه صورتحساب
PRICING = {
    "claude-sonnet": (3.0, 15.0),
    "claude-opus": (15.0, 75.0),
    "claude-haiku": (0.8, 4.0),
    "gpt-4o": (2.5, 10.0),
    "gpt-4o-mini": (0.15, 0.6),
    "deepseek": (0.27, 1.10),
    "gemini-2.0-flash": (0.10, 0.40),
    "gemini-1.5-pro": (1.25, 5.0),
}


def estimate_cost(model: str, tokens_in: int, tokens_out: int) -> float:
    m = (model or "").lower()
    rate = next((v for k, v in PRICING.items() if k in m), None)
    if rate is None:
        return 0.0                                     # مدل محلی یا ناشناخته
    return round(tokens_in / 1e6 * rate[0] + tokens_out / 1e6 * rate[1], 6)


# ═══════════════ جلسه ═══════════════

@dataclass
class Turn:
    role: str                            # user | assistant
    content: str
    meta: dict = field(default_factory=dict)
    at: str = ""


class SessionStore:
    """تاریخچهٔ گفتگو — محلی، بدون ارسال به بیرون."""

    def __init__(self, root: Path | None = None):
        self.root = Path(root or APP_DIR)
        self.root.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.root / "sessions.db", check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS sessions(
                id TEXT PRIMARY KEY, title TEXT, created_at TEXT, updated_at TEXT);
            CREATE TABLE IF NOT EXISTS turns(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT, role TEXT, content TEXT, meta TEXT, at TEXT);
            CREATE INDEX IF NOT EXISTS ix_turns ON turns(session_id, id);
        """)
        self.db.commit()

    def new(self, title: str = "") -> str:
        sid = uuid.uuid4().hex[:12]
        now = datetime.now().isoformat(timespec="seconds")
        self.db.execute("INSERT INTO sessions VALUES(?,?,?,?)",
                        (sid, title or "گفتگوی جدید", now, now))
        self.db.commit()
        return sid

    def add(self, sid: str, role: str, content: str, meta: dict | None = None) -> None:
        now = datetime.now().isoformat(timespec="seconds")
        self.db.execute(
            "INSERT INTO turns(session_id, role, content, meta, at) VALUES(?,?,?,?,?)",
            (sid, role, content, json.dumps(meta or {}, ensure_ascii=False), now))
        self.db.execute("UPDATE sessions SET updated_at=? WHERE id=?", (now, sid))
        # عنوان از اولین پیام کاربر
        if role == "user":
            row = self.db.execute(
                "SELECT title FROM sessions WHERE id=?", (sid,)).fetchone()
            if row and row["title"] == "گفتگوی جدید":
                self.db.execute("UPDATE sessions SET title=? WHERE id=?",
                                (content[:60], sid))
        self.db.commit()

    def turns(self, sid: str) -> list[Turn]:
        rows = self.db.execute(
            "SELECT role, content, meta, at FROM turns WHERE session_id=? ORDER BY id",
            (sid,)).fetchall()
        return [Turn(r["role"], r["content"], json.loads(r["meta"] or "{}"), r["at"])
                for r in rows]

    def list(self, limit: int = 40) -> list[dict]:
        rows = self.db.execute(
            "SELECT s.id, s.title, s.updated_at, COUNT(t.id) n "
            "FROM sessions s LEFT JOIN turns t ON t.session_id = s.id "
            "GROUP BY s.id ORDER BY s.updated_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def delete(self, sid: str) -> None:
        self.db.execute("DELETE FROM turns WHERE session_id=?", (sid,))
        self.db.execute("DELETE FROM sessions WHERE id=?", (sid,))
        self.db.commit()
