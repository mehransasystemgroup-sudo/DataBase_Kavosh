"""
جست‌وجو و پیمایش گراف روی ایندکس.

این ماژول هسته‌ی مشترک است: هم MCP و هم اپ مستقل از همین توابع
استفاده می‌کنند. اگر منطق این‌جا باشد، رفتار هر دو مسیر یکسان می‌ماند.
"""

from __future__ import annotations

import sqlite3
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

from .textnorm import normalize, stem_fa


@dataclass
class TableHit:
    full_name: str
    title_fa: str | None
    n_cols: int
    row_count: int | None
    has_data: bool
    score: float
    why: str = ""


@dataclass
class JoinStep:
    from_table: str
    from_col: str
    to_table: str
    to_col: str
    confidence: str
    verified: bool

    def sql(self) -> str:
        return (f"JOIN {self.to_table} ON {self.from_table}.{self.from_col} "
                f"= {self.to_table}.{self.to_col}")


@dataclass
class TableInfo:
    full_name: str
    title_fa: str | None
    description_fa: str | None
    kind: str | None
    row_count: int | None
    has_data: bool
    columns: list[dict] = field(default_factory=list)
    primary_key: list[str] = field(default_factory=list)
    outgoing: list[JoinStep] = field(default_factory=list)
    incoming: list[JoinStep] = field(default_factory=list)
    enums: dict[str, list[dict]] = field(default_factory=dict)
    indexes: list[dict] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class KnowledgeBase:
    def __init__(self, db_path: str | Path):
        # check_same_thread=False برای سرور چندنخی — KB فقط-خواندنی است
        # و SQLite در حالت پیش‌فرض serialized، امن است.
        self.db = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True,
                                  check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self._db_path = str(db_path)
        self._adj: dict[str, list[tuple]] | None = None

    def reload(self) -> None:
        """اتصال را به ایندکس تازه‌بازسازی‌شده بازمی‌کند — بدون نیاز به ری‌استارت سرور."""
        try:
            self.db.close()
        except Exception:
            pass
        self.db = sqlite3.connect(f"file:{self._db_path}?mode=ro", uri=True,
                                  check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self._adj = None

    # ─────────────────────── جست‌وجو ───────────────────────

    def search_tables(
        self,
        query: str,
        limit: int = 20,
        schema: str | None = None,
        only_with_data: bool = False,
    ) -> list[TableHit]:
        """
        جست‌وجوی معنایی/واژگانی روی نام انگلیسی و عنوان فارسی.

        امتیازدهی: BM25 به‌علاوه‌ی تقویت برای
          • تطابق دقیق نام جدول
          • جدول‌هایی که در این نصب داده دارند
        """
        q = normalize(query)
        if not q:
            return []

        # هر واژه اختیاری (OR) تا پرس‌وجوی چندکلمه‌ای نتیجه‌ی خالی ندهد.
        # برای هر واژه هم شکل کامل و هم ریشه را می‌فرستیم:
        # «حقوقی» ریشه‌اش «حقوق» است و عنوان «فیش حقوق نفت» را پیدا می‌کند.
        variants: list[str] = []
        for token in q.split():
            if len(token) <= 1:
                continue
            variants.append(f'"{token}"*')
            root = stem_fa(token)
            if root != token:
                variants.append(f'"{root}"*')
        if not variants:
            return []
        terms = " OR ".join(dict.fromkeys(variants))

        sql = """
            SELECT t.full_name, t.title_fa, t.n_cols, t.row_count, t.has_data,
                   t.in_live_db, bm25(fts) AS rank
            FROM fts
            JOIN tables t ON t.full_name = fts.full_name
            WHERE fts MATCH ?
        """
        params: list = [terms]
        if schema:
            sql += " AND t.schema = ?"
            params.append(schema)
        if only_with_data:
            sql += " AND t.has_data = 1"
        sql += " ORDER BY rank LIMIT ?"
        params.append(limit * 4)

        hits: dict[str, TableHit] = {}
        ql = q.lower()
        qcompact = ql.replace(" ", "")

        def add(r, base: float, why: list[str]) -> None:
            score = base
            name_l = r["full_name"].split(".")[1].lower()
            if name_l == qcompact:
                score += 40; why.append("نام دقیق")
            elif qcompact in name_l or name_l in qcompact:
                score += 6; why.append("نام نزدیک")
            if r["title_fa"] and normalize(r["title_fa"]) == ql:
                score += 35; why.append("عنوان فارسی دقیق")
            if r["has_data"]:
                score += 3; why.append("داده دارد")
            if r["in_live_db"] == 0:
                score -= 30; why.append("⚠️ در دیتابیس نیست")
            prev = hits.get(r["full_name"])
            if prev is None or score > prev.score:
                hits[r["full_name"]] = TableHit(
                    r["full_name"], r["title_fa"], r["n_cols"],
                    r["row_count"], bool(r["has_data"]), score, "، ".join(why))

        # ۱) تطابق دقیق نام — همیشه باید بیاید، فارغ از رتبه‌ی BM25
        exact_sql = ("SELECT full_name, title_fa, n_cols, row_count, has_data, in_live_db "
                     "FROM tables WHERE lower(name) = ?")
        exact_params: list = [qcompact]
        if schema:
            exact_sql += " AND schema = ?"; exact_params.append(schema)
        if only_with_data:
            exact_sql += " AND has_data = 1"
        for r in self.db.execute(exact_sql, exact_params):
            add(r, 10.0, [])

        # ۲) جست‌وجوی تمام‌متن
        for r in self.db.execute(sql, params):
            add(r, -r["rank"], [])

        return sorted(hits.values(), key=lambda h: -h.score)[:limit]

    def search_columns(self, query: str, limit: int = 30) -> list[dict]:
        """یافتن ستون بر اساس نام — برای وقتی نام جدول را نمی‌دانید."""
        like = f"%{query}%"
        rows = self.db.execute(
            """SELECT c.table_ref, c.name, c.type, t.title_fa, t.has_data
               FROM columns c JOIN tables t ON t.full_name = c.table_ref
               WHERE c.name LIKE ?
               ORDER BY t.has_data DESC, length(c.name) LIMIT ?""",
            (like, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    # ─────────────────────── جزئیات جدول ───────────────────────

    def get_table(self, full_name: str) -> TableInfo | None:
        r = self.db.execute(
            "SELECT * FROM tables WHERE full_name = ?", (full_name,)
        ).fetchone()
        if r is None:
            return None

        info = TableInfo(
            full_name=r["full_name"], title_fa=r["title_fa"],
            description_fa=r["description_fa"], kind=r["kind"],
            row_count=r["row_count"], has_data=bool(r["has_data"]),
        )

        for c in self.db.execute(
            "SELECT * FROM columns WHERE table_ref=? ORDER BY ordinal", (full_name,)
        ):
            info.columns.append({
                "name": c["name"], "type": c["type"],
                "nullable": bool(c["nullable"]), "is_pk": bool(c["is_pk"]),
            })
            if c["is_pk"]:
                info.primary_key.append(c["name"])

        for j in self.db.execute(
            "SELECT * FROM joins WHERE from_table=?", (full_name,)
        ):
            info.outgoing.append(JoinStep(
                j["from_table"], j["from_col"], j["to_table"], j["to_col"],
                j["confidence"], bool(j["verified"])))

        for j in self.db.execute(
            "SELECT * FROM joins WHERE to_table=? LIMIT 40", (full_name,)
        ):
            info.incoming.append(JoinStep(
                j["from_table"], j["from_col"], j["to_table"], j["to_col"],
                j["confidence"], bool(j["verified"])))

        for e in self.db.execute(
            "SELECT * FROM enums WHERE table_ref=? ORDER BY column, value", (full_name,)
        ):
            info.enums.setdefault(e["column"], []).append({
                "value": e["value"], "label_fa": e["label_fa"],
                "confidence": e["confidence"], "observed": e["observed"],
            })

        for i in self.db.execute(
            "SELECT * FROM indexes_ WHERE table_ref=?", (full_name,)
        ):
            info.indexes.append({
                "name": i["name"], "columns": i["columns"].split(",") if i["columns"] else [],
                "unique": bool(i["is_unique"]),
            })

        # ── هشدارها ──
        if not info.has_data:
            info.warnings.append(
                "این جدول در نصب فعلی داده ندارد — احتمالاً ماژولش خریداری نشده."
            )
        if any(c["name"] == "FiscalYearRef" for c in info.columns):
            info.warnings.append(
                "ستون FiscalYearRef دارد — فیلتر سال مالی الزامی است، "
                "وگرنه خروجی بی‌خطا ولی غلط می‌شود."
            )
        weak = [j for j in info.outgoing if not j.verified]
        if weak:
            info.warnings.append(
                f"{len(weak)} مسیر JOIN از این جدول تأییدنشده است (استنتاج از نام)."
            )
        return info

    # ─────────────────────── گراف ───────────────────────

    def _adjacency(self) -> dict[str, list[tuple]]:
        """گراف بدون‌جهت — برای JOIN، جهت اهمیتی ندارد."""
        if self._adj is None:
            adj: dict[str, list[tuple]] = {}
            for j in self.db.execute("SELECT * FROM joins"):
                a, b = j["from_table"], j["to_table"]
                adj.setdefault(a, []).append(
                    (b, j["from_col"], j["to_col"], j["confidence"], j["verified"], True))
                adj.setdefault(b, []).append(
                    (a, j["to_col"], j["from_col"], j["confidence"], j["verified"], False))
            self._adj = adj
        return self._adj

    def find_join_path(
        self, source: str, target: str, max_hops: int = 4,
        verified_only: bool = False,
    ) -> list[JoinStep] | None:
        """
        کوتاه‌ترین مسیر JOIN بین دو جدول (BFS).

        یال‌های تأییدشده اولویت دارند: در هر سطح اول آن‌ها بررسی می‌شوند،
        تا اگر دو مسیر هم‌طول باشند، مسیر قطعی برنده شود.
        """
        if source == target:
            return []
        adj = self._adjacency()
        if source not in adj:
            return None

        seen = {source}
        queue = deque([(source, [])])
        while queue:
            node, path = queue.popleft()
            if len(path) >= max_hops:
                continue
            neighbours = sorted(adj.get(node, []), key=lambda n: -n[4])
            for nxt, from_col, to_col, conf, verified, _fwd in neighbours:
                if verified_only and not verified:
                    continue
                if nxt in seen:
                    continue
                step = JoinStep(node, from_col, nxt, to_col, conf, bool(verified))
                if nxt == target:
                    return path + [step]
                seen.add(nxt)
                queue.append((nxt, path + [step]))
        return None

    @staticmethod
    def path_warning(path: list[JoinStep]) -> str | None:
        """
        مسیرِ موجود ≠ مسیرِ درست.

        BFS کوتاه‌ترین مسیر گراف را می‌دهد، ولی گراف معنا نمی‌فهمد.
        مثال واقعی: AttendanceData → FiscalYear مسیر چهارمرحله‌ای از
        ContractHeader پیدا می‌کند — از نظر گراف معتبر، از نظر تجاری بی‌معنا.
        """
        if not path:
            return None
        if len(path) > 2:
            return (f"این مسیر {len(path)} مرحله دارد و از "
                    f"{' → '.join(s.to_table for s in path[:-1])} عبور می‌کند. "
                    f"مسیرهای بلند معمولاً از نظر تجاری بی‌معنا هستند — "
                    f"احتمالاً این دو جدول مستقیماً مرتبط نیستند.")
        weak = [s for s in path if not s.verified]
        if weak:
            return f"{len(weak)} مرحله از این مسیر تأییدنشده است (استنتاج از نام)."
        return None

    def neighbours(self, table: str, limit: int = 25) -> list[dict]:
        """جدول‌های مجاور — برای بسط زمینه هنگام ساخت گزارش."""
        out = []
        for nxt, fc, tc, conf, ver, fwd in self._adjacency().get(table, [])[:limit]:
            out.append({
                "table": nxt, "via": f"{fc} → {tc}",
                "confidence": conf, "verified": bool(ver),
                "direction": "outgoing" if fwd else "incoming",
            })
        return out

    # ─────────────────────── اعتبارسنجی ───────────────────────

    def check_exists(self, table: str, column: str | None = None) -> tuple[bool, str]:
        r = self.db.execute(
            "SELECT full_name FROM tables WHERE full_name = ?", (table,)
        ).fetchone()
        if r is None:
            alt = self.db.execute(
                "SELECT full_name FROM tables WHERE name = ? LIMIT 3",
                (table.split(".")[-1],),
            ).fetchall()
            hint = f"  شاید منظورتان: {', '.join(a[0] for a in alt)}" if alt else ""
            return False, f"جدول «{table}» وجود ندارد.{hint}"

        if column is None:
            return True, ""

        c = self.db.execute(
            "SELECT name FROM columns WHERE table_ref=? AND name=?", (table, column)
        ).fetchone()
        if c is None:
            # تطابق فازی — LIKE برای غلط املایی («Numberr» → «Number») کار نمی‌کند
            import difflib
            all_cols = [r[0] for r in self.db.execute(
                "SELECT name FROM columns WHERE table_ref=?", (table,))]
            close = difflib.get_close_matches(column, all_cols, n=3, cutoff=0.6)
            if not close:
                low = column.lower()
                close = [c for c in all_cols if low in c.lower()][:3]
            hint = f"  شاید: {', '.join(close)}" if close else ""
            return False, f"ستون «{column}» در {table} نیست.{hint}"
        return True, ""

    def stats(self) -> dict:
        return {r["key"]: r["value"] for r in self.db.execute("SELECT * FROM meta")}
