"""
نقشهٔ کوئری — قلب معماری مدل‌ناوابسته.

مسئله:
    مدل‌های مختلف (Claude، Gemini، DeepSeek، مدل محلی) کیفیت یکسانی
    در نوشتن T-SQL ندارند. اگر اجازه دهیم SQL خام بنویسند، خروجی
    به کیفیت مدل وابسته می‌شود.

راه‌حل:
    مدل هرگز SQL نمی‌نویسد. فقط یک «نقشه» می‌سازد — انتخاب‌هایی از
    مجموعه‌ای که سیستم در اختیارش گذاشته:
        کدام جدول پایه؟ کدام JOIN؟ کدام ستون؟ چه فیلتری؟

    سپس:
        ۱. اعتبارسنج هر انتخاب را با KB می‌سنجد
        ۲. اگر غلط بود، خطای مشخص + گزینه‌های معتبر برمی‌گردد
        ۳. مونتاژگر از نقشهٔ تأییدشده، SQL قطعی می‌سازد

    نتیجه: مدل ضعیف هم نمی‌تواند SQL نامعتبر تولید کند،
    چون اصلاً SQL تولید نمی‌کند.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from typing import Any, Literal


# ═══════════════════════ ساختار نقشه ═══════════════════════

AGGREGATES = ("SUM", "COUNT", "COUNT_DISTINCT", "AVG", "MIN", "MAX")
OPERATORS = ("=", "<>", ">", ">=", "<", "<=", "LIKE", "IN", "BETWEEN",
             "IS NULL", "IS NOT NULL")
JOIN_KINDS = ("INNER", "LEFT")


@dataclass
class PlanColumn:
    table: str                      # FIN3.Voucher  (نام کامل یا نام مستعار)
    column: str
    aggregate: str | None = None    # SUM | COUNT | ...
    alias: str | None = None

    def output_name(self) -> str:
        if self.alias:
            return self.alias
        if self.aggregate:
            return f"{self.aggregate.title().replace('_', '')}{self.column}"
        return self.column


@dataclass
class PlanJoin:
    kind: str                       # INNER | LEFT
    from_table: str
    from_column: str
    to_table: str
    to_column: str


@dataclass
class PlanFilter:
    table: str
    column: str
    op: str
    value: Any = None               # مقدار ثابت
    parameter: str | None = None    # یا نام پارامتر: FiscalYear


@dataclass
class PlanOrder:
    expression: str                 # نام خروجی یا table.column
    direction: str = "ASC"          # ASC | DESC


@dataclass
class PlanParameter:
    name: str                       # FiscalYear  (بدون @)
    type: str                       # int | nvarchar | date
    title_fa: str
    required: bool = True
    default: Any = None


@dataclass
class QueryPlan:
    """نقشه‌ای که مدل تولید می‌کند — نه SQL."""
    intent_fa: str
    base_table: str
    select: list[PlanColumn] = field(default_factory=list)
    joins: list[PlanJoin] = field(default_factory=list)
    filters: list[PlanFilter] = field(default_factory=list)
    group_by: list[str] = field(default_factory=list)
    order_by: list[PlanOrder] = field(default_factory=list)
    parameters: list[PlanParameter] = field(default_factory=list)
    top: int | None = None
    notes: list[str] = field(default_factory=list)

    # ---------- تبدیل ----------

    @classmethod
    def from_dict(cls, d: dict) -> "QueryPlan":
        def build(cls_, items):
            out = []
            for it in items or []:
                if not isinstance(it, dict):
                    continue
                allowed = {f for f in cls_.__dataclass_fields__}
                out.append(cls_(**{k: v for k, v in it.items() if k in allowed}))
            return out

        return cls(
            intent_fa=d.get("intent_fa", ""),
            base_table=d.get("base_table", ""),
            select=build(PlanColumn, d.get("select")),
            joins=build(PlanJoin, d.get("joins")),
            filters=build(PlanFilter, d.get("filters")),
            group_by=list(d.get("group_by") or []),
            order_by=build(PlanOrder, d.get("order_by")),
            parameters=build(PlanParameter, d.get("parameters")),
            top=d.get("top"),
            notes=list(d.get("notes") or []),
        )

    def to_dict(self) -> dict:
        return asdict(self)


# ═══════════════════════ نتیجهٔ اعتبارسنجی ═══════════════════════

@dataclass
class PlanIssue:
    severity: Literal["error", "warning"]
    field: str                      # کجای نقشه
    message_fa: str
    options: list[str] = field(default_factory=list)   # گزینه‌های معتبر

    def for_model(self) -> str:
        """پیامی که به مدل برگردانده می‌شود — باید مشخص و قابل اقدام باشد."""
        s = f"[{self.severity}] {self.field}: {self.message_fa}"
        if self.options:
            shown = self.options[:25]
            s += f"\n    گزینه‌های معتبر: {', '.join(shown)}"
            if len(self.options) > 25:
                s += f"  (و {len(self.options) - 25} مورد دیگر)"
        return s


@dataclass
class PlanCheck:
    ok: bool
    issues: list[PlanIssue] = field(default_factory=list)

    @property
    def errors(self) -> list[PlanIssue]:
        return [i for i in self.issues if i.severity == "error"]

    def feedback_for_model(self) -> str:
        if not self.errors:
            return ""
        lines = ["نقشه‌ای که دادی این مشکلات را دارد. اصلاحش کن:"]
        lines += [i.for_model() for i in self.errors]
        return "\n".join(lines)


# ═══════════════════════ اعتبارسنج ═══════════════════════

IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class PlanValidator:
    """
    هر انتخاب مدل را با پایگاه دانش می‌سنجد.

    هیچ ادعایی از مدل پذیرفته نمی‌شود — نه نام جدول، نه ستون، نه مسیر JOIN.
    """

    def __init__(self, kb):
        self.kb = kb

    # ---------- کمکی ----------

    def _table_columns(self, full: str) -> list[str] | None:
        info = self.kb.get_table(full)
        return [c["name"] for c in info.columns] if info else None

    def _resolve_table(self, name: str) -> tuple[str | None, list[str]]:
        """نام را به full_name تبدیل می‌کند؛ اگر مبهم بود، کاندیداها را برمی‌گرداند."""
        if not name:
            return None, []
        ok, _ = self.kb.check_exists(name)
        if ok:
            return name, []
        rows = self.kb.db.execute(
            "SELECT full_name FROM tables WHERE name = ? "
            "  AND (in_live_db IS NULL OR in_live_db = 1) "   # جدول کهنه پیشنهاد نشود
            "ORDER BY has_data DESC LIMIT 6",
            (name.split(".")[-1],),
        ).fetchall()
        cands = [r[0] for r in rows]
        return (cands[0] if len(cands) == 1 else None), cands

    # ---------- اصلی ----------

    def validate(self, plan: QueryPlan) -> tuple[QueryPlan, PlanCheck]:
        issues: list[PlanIssue] = []

        # ── جدول پایه ──
        base, cands = self._resolve_table(plan.base_table)
        if base is None:
            issues.append(PlanIssue(
                "error", "base_table",
                f"جدول «{plan.base_table}» در کاتالوگ نیست یا مبهم است.",
                cands or self._suggest_tables(plan.base_table)))
            return plan, PlanCheck(False, issues)
        plan.base_table = base

        # ── JOINها ──
        known: dict[str, str] = {base: base}          # نام کوتاه/کامل → کامل
        known[base.split(".")[1]] = base

        valid_joins: list[PlanJoin] = []
        for i, j in enumerate(plan.joins):
            tag = f"joins[{i}]"

            if j.kind not in JOIN_KINDS:
                j.kind = "INNER"

            src = known.get(j.from_table) or self._resolve_table(j.from_table)[0]
            if src is None or src not in known.values():
                issues.append(PlanIssue(
                    "error", tag,
                    f"from_table «{j.from_table}» هنوز به کوئری اضافه نشده. "
                    f"ترتیب JOIN باید از جدول پایه شروع شود.",
                    sorted(set(known.values()))))
                continue

            dst, dcands = self._resolve_table(j.to_table)
            if dst is None:
                issues.append(PlanIssue(
                    "error", tag,
                    f"to_table «{j.to_table}» در کاتالوگ نیست.",
                    dcands or self._suggest_tables(j.to_table)))
                continue

            # ستون‌ها
            bad = False
            for side, tbl, col in (("from", src, j.from_column), ("to", dst, j.to_column)):
                ok, _ = self.kb.check_exists(tbl, col)
                if not ok:
                    issues.append(PlanIssue(
                        "error", tag,
                        f"ستون «{col}» در {tbl} نیست.",
                        self._table_columns(tbl) or []))
                    bad = True
            if bad:
                continue

            # آیا این مسیر در گراف هست؟
            edge = self.kb.db.execute(
                "SELECT confidence, verified FROM joins "
                "WHERE (from_table=? AND from_col=? AND to_table=? AND to_col=?) "
                "   OR (from_table=? AND from_col=? AND to_table=? AND to_col=?)",
                (src, j.from_column, dst, j.to_column,
                 dst, j.to_column, src, j.from_column),
            ).fetchone()

            if edge is None:
                issues.append(PlanIssue(
                    "warning", tag,
                    f"مسیر {src}.{j.from_column} → {dst}.{j.to_column} "
                    f"در گراف شناخته‌شده نیست. اگر مطمئنید ادامه دهید، "
                    f"وگرنه از find_join_path استفاده کنید."))
            elif not edge["verified"]:
                issues.append(PlanIssue(
                    "warning", tag,
                    f"مسیر {src} → {dst} استنتاجی است (تأییدنشده)."))

            j.from_table, j.to_table = src, dst
            known[dst] = dst
            known[dst.split(".")[1]] = dst
            valid_joins.append(j)

        plan.joins = valid_joins

        # ── ستون‌های خروجی ──
        if not plan.select:
            issues.append(PlanIssue("error", "select", "هیچ ستون خروجی مشخص نشده."))

        valid_select: list[PlanColumn] = []
        aliases: set[str] = set()
        for i, c in enumerate(plan.select):
            tag = f"select[{i}]"
            tbl = known.get(c.table)
            if tbl is None:
                issues.append(PlanIssue(
                    "error", tag,
                    f"جدول «{c.table}» در کوئری نیست. اول باید JOIN شود.",
                    sorted(set(known.values()))))
                continue
            ok, _ = self.kb.check_exists(tbl, c.column)
            if not ok:
                issues.append(PlanIssue(
                    "error", tag, f"ستون «{c.column}» در {tbl} نیست.",
                    self._table_columns(tbl) or []))
                continue
            if c.aggregate and c.aggregate.upper() not in AGGREGATES:
                issues.append(PlanIssue(
                    "error", tag, f"تابع تجمعی «{c.aggregate}» پشتیبانی نمی‌شود.",
                    list(AGGREGATES)))
                continue
            if c.aggregate:
                c.aggregate = c.aggregate.upper()
            if c.alias and not IDENT.match(c.alias):
                c.alias = None
            name = c.output_name()
            if name in aliases:
                c.alias = f"{name}_{i}"
            aliases.add(c.output_name())
            c.table = tbl
            valid_select.append(c)
        plan.select = valid_select

        # ── فیلترها ──
        valid_filters: list[PlanFilter] = []
        for i, f in enumerate(plan.filters):
            tag = f"filters[{i}]"
            tbl = known.get(f.table)
            if tbl is None:
                issues.append(PlanIssue(
                    "error", tag, f"جدول «{f.table}» در کوئری نیست.",
                    sorted(set(known.values()))))
                continue
            ok, _ = self.kb.check_exists(tbl, f.column)
            if not ok:
                issues.append(PlanIssue(
                    "error", tag, f"ستون «{f.column}» در {tbl} نیست.",
                    self._table_columns(tbl) or []))
                continue
            if f.op not in OPERATORS:
                issues.append(PlanIssue(
                    "error", tag, f"عملگر «{f.op}» مجاز نیست.", list(OPERATORS)))
                continue
            if f.parameter and not IDENT.match(f.parameter):
                issues.append(PlanIssue(
                    "error", tag, f"نام پارامتر «{f.parameter}» معتبر نیست."))
                continue
            # مقدار enum را بسنج
            if f.value is not None and f.op == "=":
                self._check_enum_value(tbl, f.column, f.value, tag, issues)
            f.table = tbl
            valid_filters.append(f)
        plan.filters = valid_filters

        # ── group by ──
        has_agg = any(c.aggregate for c in plan.select)
        plain = [c for c in plan.select if not c.aggregate]
        if has_agg and plain:
            needed = {f"{c.table}.{c.column}" for c in plain}
            given = set(plan.group_by)
            missing = needed - given
            if missing:
                plan.group_by = sorted(needed)      # اصلاح خودکار
                issues.append(PlanIssue(
                    "warning", "group_by",
                    f"GROUP BY خودکار تکمیل شد: {', '.join(sorted(missing))}"))

        # ── قانون سال مالی ──
        self._fiscal_year_rule(plan, issues)

        # ── پارامترها ──
        used = {f.parameter for f in plan.filters if f.parameter}
        declared = {p.name for p in plan.parameters}
        for name in used - declared:
            plan.parameters.append(PlanParameter(
                name=name, type="int", title_fa=name))
            issues.append(PlanIssue(
                "warning", "parameters", f"پارامتر «{name}» خودکار تعریف شد."))

        ok = not any(i.severity == "error" for i in issues)
        return plan, PlanCheck(ok, issues)

    # ---------- قوانین ----------

    def _fiscal_year_rule(self, plan: QueryPlan, issues: list[PlanIssue]) -> None:
        """
        نبود فیلتر سال مالی خطا تولید نمی‌کند، فقط عدد اشتباه می‌دهد.
        خطرناک‌ترین نوع باگ — پس error است، نه warning.
        """
        tables = {plan.base_table} | {j.to_table for j in plan.joins}
        filtered = {f.table for f in plan.filters if f.column == "FiscalYearRef"}
        for t in sorted(tables):
            cols = self._table_columns(t) or []
            if "FiscalYearRef" in cols and t not in filtered:
                issues.append(PlanIssue(
                    "error", "filters",
                    f"{t} ستون FiscalYearRef دارد ولی فیلتر نشده. "
                    f"بدون آن، داده‌ی همهٔ سال‌های مالی جمع می‌شود و "
                    f"خروجی بی‌خطا ولی غلط است. "
                    f"یک فیلتر با parameter=\"FiscalYear\" اضافه کن."))

    def _check_enum_value(self, table: str, column: str, value: Any,
                          tag: str, issues: list[PlanIssue]) -> None:
        rows = self.kb.db.execute(
            "SELECT value, label_fa FROM enums WHERE table_ref=? AND column=?",
            (table, column),
        ).fetchall()
        if not rows:
            return
        valid = {str(r["value"]) for r in rows}
        if str(value) not in valid:
            issues.append(PlanIssue(
                "error", tag,
                f"مقدار «{value}» برای {table}.{column} تعریف نشده.",
                [f"{r['value']}={r['label_fa'] or '؟'}" for r in rows]))

    def _suggest_tables(self, query: str) -> list[str]:
        try:
            return [h.full_name for h in self.kb.search_tables(query, limit=8)]
        except Exception:
            return []


# ═══════════════════════ مونتاژگر ═══════════════════════

class SqlAssembler:
    """
    از نقشهٔ تأییدشده، T-SQL قطعی می‌سازد.

    این‌جا هیچ تصمیمی گرفته نمی‌شود — فقط نگارش.
    خروجی همیشه معتبر است چون ورودی قبلاً اعتبارسنجی شده.
    """

    @staticmethod
    def _alias(full: str, used: dict[str, str]) -> str:
        if full in used:
            return used[full]
        bare = full.split(".")[1]
        base = "".join(ch for ch in bare if ch.isupper()).lower() or bare[:2].lower()
        alias, n = base, 1
        while alias in used.values():
            n += 1
            alias = f"{base}{n}"
        used[full] = alias
        return alias

    @classmethod
    def build(cls, plan: QueryPlan) -> str:
        used: dict[str, str] = {}
        a_base = cls._alias(plan.base_table, used)
        for j in plan.joins:
            cls._alias(j.to_table, used)

        def ref(table: str, column: str) -> str:
            return f"{used[table]}.[{column}]"

        # SELECT
        cols = []
        for c in plan.select:
            expr = ref(c.table, c.column)
            if c.aggregate == "COUNT_DISTINCT":
                expr = f"COUNT(DISTINCT {expr})"
            elif c.aggregate:
                expr = f"{c.aggregate}({expr})"
            cols.append(f"{expr} AS [{c.output_name()}]")

        top = f"TOP ({plan.top}) " if plan.top else ""
        lines = [f"SELECT {top}" + (",\n       ".join(cols) if cols else "*")]
        lines.append(f"FROM   {plan.base_table} AS {a_base}")

        for j in plan.joins:
            lines.append(
                f"{j.kind:6} JOIN {j.to_table} AS {used[j.to_table]}"
                f" ON {ref(j.from_table, j.from_column)}"
                f" = {ref(j.to_table, j.to_column)}"
            )

        # WHERE
        if plan.filters:
            conds = []
            for f in plan.filters:
                left = ref(f.table, f.column)
                if f.op in ("IS NULL", "IS NOT NULL"):
                    conds.append(f"{left} {f.op}")
                elif f.parameter:
                    conds.append(f"{left} {f.op} @{f.parameter}")
                elif isinstance(f.value, (list, tuple)):
                    if f.op == "BETWEEN" and len(f.value) == 2:
                        conds.append(f"{left} BETWEEN {cls._lit(f.value[0])} "
                                     f"AND {cls._lit(f.value[1])}")
                    else:
                        vals = ", ".join(cls._lit(v) for v in f.value)
                        conds.append(f"{left} IN ({vals})")
                else:
                    conds.append(f"{left} {f.op} {cls._lit(f.value)}")
            lines.append("WHERE  " + "\n  AND  ".join(conds))

        if plan.group_by:
            g = [ref(*x.rsplit(".", 1)) if x.count(".") == 2 else x
                 for x in plan.group_by]
            lines.append("GROUP BY " + ", ".join(g))

        if plan.order_by:
            o = [f"[{x.expression}] {x.direction}"
                 if not x.expression.count(".") else
                 f"{ref(*x.expression.rsplit('.', 1))} {x.direction}"
                 for x in plan.order_by]
            lines.append("ORDER BY " + ", ".join(o))

        sql = "\n".join(lines) + ";"

        if plan.parameters:
            head = "\n".join(
                f"-- @{p.name} ({p.type}) — {p.title_fa}" for p in plan.parameters)
            sql = head + "\n\n" + sql
        return sql

    @staticmethod
    def _lit(v: Any) -> str:
        if v is None:
            return "NULL"
        if isinstance(v, bool):
            return "1" if v else "0"
        if isinstance(v, (int, float)):
            return str(v)
        return "N'" + str(v).replace("'", "''") + "'"


# ═══════════════════════ طرح‌واره برای مدل ═══════════════════════

PLAN_JSON_SCHEMA = {
    "type": "object",
    "required": ["intent_fa", "base_table", "select"],
    "properties": {
        "intent_fa": {"type": "string"},
        "base_table": {"type": "string"},
        "select": {"type": "array", "items": {
            "type": "object", "required": ["table", "column"],
            "properties": {
                "table": {"type": "string"},
                "column": {"type": "string"},
                "aggregate": {"type": ["string", "null"], "enum": [*AGGREGATES, None]},
                "alias": {"type": ["string", "null"]},
            }}},
        "joins": {"type": "array", "items": {
            "type": "object",
            "required": ["kind", "from_table", "from_column", "to_table", "to_column"],
            "properties": {
                "kind": {"type": "string", "enum": list(JOIN_KINDS)},
                "from_table": {"type": "string"},
                "from_column": {"type": "string"},
                "to_table": {"type": "string"},
                "to_column": {"type": "string"},
            }}},
        "filters": {"type": "array", "items": {
            "type": "object", "required": ["table", "column", "op"],
            "properties": {
                "table": {"type": "string"},
                "column": {"type": "string"},
                "op": {"type": "string", "enum": list(OPERATORS)},
                "value": {},
                "parameter": {"type": ["string", "null"]},
            }}},
        "group_by": {"type": "array", "items": {"type": "string"}},
        "order_by": {"type": "array", "items": {
            "type": "object", "required": ["expression"],
            "properties": {
                "expression": {"type": "string"},
                "direction": {"type": "string", "enum": ["ASC", "DESC"]},
            }}},
        "parameters": {"type": "array", "items": {
            "type": "object", "required": ["name", "type", "title_fa"],
            "properties": {
                "name": {"type": "string"},
                "type": {"type": "string", "enum": ["int", "nvarchar", "date", "decimal"]},
                "title_fa": {"type": "string"},
                "required": {"type": "boolean"},
            }}},
        "top": {"type": ["integer", "null"]},
        "notes": {"type": "array", "items": {"type": "string"}},
    },
}


def extract_json(text: str) -> dict | None:
    """
    استخراج JSON از پاسخ مدل.

    مدل‌های ضعیف‌تر معمولاً JSON را داخل ```json می‌گذارند یا
    قبل و بعدش توضیح می‌نویسند. هر دو حالت مدیریت می‌شود.
    """
    if not text:
        return None
    fence = re.search(r"```(?:json)?\s*(.+?)```", text, re.S)
    if fence:
        text = fence.group(1)
    start = text.find("{")
    if start == -1:
        return None
    depth, in_str, esc = 0, False, False
    for i in range(start, len(text)):
        ch = text[i]
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i + 1])
                except json.JSONDecodeError:
                    return None
    return None
