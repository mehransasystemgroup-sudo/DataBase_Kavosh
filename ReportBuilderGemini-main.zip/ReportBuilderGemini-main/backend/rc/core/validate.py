"""
اعتبارسنجی T-SQL بدون اتصال به دیتابیس.

فلسفه: از ارزان به گران.
    ۱. پارس نحوی            — خطای نگارشی
    ۲. وجود در کاتالوگ      — ⭐ بیشترین ارزش؛ توهم مدل را همان‌جا می‌کشد
    ۳. قوانین تجاری         — FiscalYearRef، جدول خالی، JOIN حدسی

چیزی که این‌جا *نمی‌تواند* بررسی شود (نیاز به دیتابیس دارد):
    • درستی نوع داده در مقایسه‌ها
    • کارایی و طرح اجرا
    • اینکه آیا نتیجه از نظر تجاری درست است
"""

from __future__ import annotations

from dataclasses import dataclass, field

try:
    import sqlglot
    from sqlglot import exp
    HAS_SQLGLOT = True
except ImportError:                                    # pragma: no cover
    HAS_SQLGLOT = False


@dataclass
class Finding:
    severity: str        # error | warning | info
    message: str
    hint: str = ""

    def __str__(self) -> str:
        icon = {"error": "✖", "warning": "⚠", "info": "ℹ"}[self.severity]
        return f"{icon} {self.message}" + (f"\n   {self.hint}" if self.hint else "")


@dataclass
class ValidationResult:
    ok: bool
    findings: list[Finding] = field(default_factory=list)
    tables_used: list[str] = field(default_factory=list)
    output_columns: list[str] = field(default_factory=list)

    def render(self) -> str:
        head = "✔ اعتبارسنجی موفق" if self.ok else "✖ اعتبارسنجی ناموفق"
        lines = [head]
        if self.tables_used:
            lines.append(f"جدول‌های استفاده‌شده: {', '.join(self.tables_used)}")
        for f in self.findings:
            lines.append(str(f))
        return "\n".join(lines)


class SqlValidator:
    def __init__(self, kb):
        self.kb = kb

    # ─────────────── استخراج ───────────────

    @staticmethod
    def _qualify(table: exp.Table) -> str:
        db = table.text("db")
        name = table.name
        return f"{db}.{name}" if db else name

    def _resolve(self, raw: str) -> tuple[str | None, list[str]]:
        """نام جدول را به full_name کاتالوگ تبدیل می‌کند."""
        ok, _ = self.kb.check_exists(raw)
        if ok:
            return raw, []
        # بدون schema نوشته شده — کاندیداها را پیدا کن
        bare = raw.split(".")[-1]
        rows = self.kb.db.execute(
            "SELECT full_name, has_data FROM tables WHERE name = ? "
            "ORDER BY has_data DESC LIMIT 5", (bare,)
        ).fetchall()
        cands = [r["full_name"] for r in rows]
        return (cands[0] if len(cands) == 1 else None), cands

    # ─────────────── اعتبارسنجی ───────────────

    def validate(self, sql: str) -> ValidationResult:
        res = ValidationResult(ok=True)

        if not HAS_SQLGLOT:
            res.findings.append(Finding(
                "warning", "sqlglot نصب نیست — فقط بررسی سطحی انجام شد.",
                "pip install sqlglot"))
            return res

        # ── ۱. پارس ──
        try:
            trees = sqlglot.parse(sql, dialect="tsql")
        except Exception as exc:
            res.ok = False
            res.findings.append(Finding("error", f"خطای نحوی: {exc}"))
            return res

        alias_map: dict[str, str] = {}       # alias → full_name
        resolved: list[str] = []

        for tree in trees:
            if tree is None:
                continue

            # ── ۲. جدول‌ها ──
            for tbl in tree.find_all(exp.Table):
                raw = self._qualify(tbl)
                if not raw or raw in ("", None):
                    continue
                full, cands = self._resolve(raw)

                if full is None and not cands:
                    res.ok = False
                    res.findings.append(Finding(
                        "error", f"جدول «{raw}» در کاتالوگ نیست.",
                        self._nearest(raw)))
                    continue
                if full is None:
                    res.ok = False
                    res.findings.append(Finding(
                        "error", f"«{raw}» بدون schema نوشته شده و مبهم است.",
                        f"کاندیداها: {', '.join(cands)}"))
                    continue

                resolved.append(full)
                alias_map[(tbl.alias or tbl.name).lower()] = full
                alias_map[full.lower()] = full
                alias_map[full.split(".")[1].lower()] = full

            # ── ۳. ستون‌ها ──
            for col in tree.find_all(exp.Column):
                tbl_ref = col.table
                if not tbl_ref:
                    continue                     # بدون پیشوند — نمی‌شود قضاوت کرد
                owner = alias_map.get(tbl_ref.lower())
                if owner is None:
                    continue
                ok, msg = self.kb.check_exists(owner, col.name)
                if not ok:
                    res.ok = False
                    res.findings.append(Finding("error", msg))

            # ── ۴. ستون‌های خروجی ──
            if isinstance(tree, exp.Select):
                for e in tree.expressions:
                    if isinstance(e, exp.Star):
                        res.findings.append(Finding(
                            "warning", "SELECT * استفاده شده.",
                            "در RDL نام ستون‌ها باید ثابت باشد؛ "
                            "با * هر تغییر schema گزارش را می‌شکند."))
                    else:
                        res.output_columns.append(e.alias_or_name)

        res.tables_used = sorted(set(resolved))
        self._business_rules(res)
        return res

    def _nearest(self, raw: str) -> str:
        bare = raw.split(".")[-1]
        rows = self.kb.db.execute(
            "SELECT full_name FROM tables WHERE name LIKE ? "
            "ORDER BY has_data DESC, length(name) LIMIT 3", (f"%{bare}%",)
        ).fetchall()
        return f"شاید: {', '.join(r[0] for r in rows)}" if rows else ""

    # ─────────────── قوانین تجاری ───────────────

    def _business_rules(self, res: ValidationResult) -> None:
        for full in res.tables_used:
            info = self.kb.get_table(full)
            if info is None:
                continue

            if info.has_data is False and info.row_count == 0:
                res.findings.append(Finding(
                    "warning", f"{full} در این نصب هیچ داده‌ای ندارد.",
                    "احتمالاً ماژولش خریداری نشده — گزارش خالی برمی‌گردد."))

            r = self.kb.db.execute(
                "SELECT in_live_db FROM tables WHERE full_name=?", (full,)
            ).fetchone()
            if r and r["in_live_db"] == 0:
                res.ok = False
                res.findings.append(Finding(
                    "error", f"{full} در دیتابیس زنده وجود ندارد.",
                    "این جدول از مستندات قدیمی است."))

    def check_fiscal_year(self, sql: str, res: ValidationResult) -> None:
        """
        قانون طلایی: نبود فیلتر سال مالی خطا تولید نمی‌کند،
        فقط عدد اشتباه می‌دهد — خطرناک‌ترین نوع باگ.
        """
        lowered = sql.lower()
        for full in res.tables_used:
            info = self.kb.get_table(full)
            if info and any(c["name"] == "FiscalYearRef" for c in info.columns):
                if "fiscalyearref" not in lowered:
                    res.findings.append(Finding(
                        "error",
                        f"{full} ستون FiscalYearRef دارد ولی کوئری فیلترش نکرده.",
                        "بدون این فیلتر، خروجی بی‌خطا ولی غلط است — "
                        "داده‌ی همه‌ی سال‌های مالی جمع می‌شود."))
                    res.ok = False
                elif "@" not in lowered:
                    res.findings.append(Finding(
                        "warning",
                        "FiscalYearRef فیلتر شده ولی مقدارش ثابت است.",
                        "در RDL باید پارامتر باشد، نه عدد ثابت."))
