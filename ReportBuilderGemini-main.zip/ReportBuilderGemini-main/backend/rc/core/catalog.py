"""
کاتالوگ گزارش‌ها — حافظهٔ کاری سیستم.

هر گزارش موفق ذخیره می‌شود: نقشه، SQL، چیدمان، و درس‌های آموخته.
دفعهٔ بعد که درخواست مشابهی بیاید، به‌جای شروع از صفر،
گزارش قبلی به‌عنوان نقطهٔ شروع پیشنهاد می‌شود.

چرا مهم است:
    بعد از سی گزارش، سیستم الگوهای شما را می‌داند —
    کدام جدول‌ها معمولاً با هم می‌آیند، کدام فیلترها همیشه لازم‌اند،
    و چه چیزی قبلاً اشتباه از آب درآمده.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path

from .textnorm import normalize


@dataclass
class CatalogEntry:
    slug: str
    title_fa: str
    category: str = ""                 # فولدر/دستهٔ ماژول
    request_fa: str = ""              # درخواست اصلی کاربر
    intent_fa: str = ""
    tables: list[str] = field(default_factory=list)
    parameters: list[str] = field(default_factory=list)
    layout_kind: str = "table"
    sql: str = ""
    plan: dict = field(default_factory=dict)
    layout: dict = field(default_factory=dict)
    rdl_path: str = ""
    lessons: list[str] = field(default_factory=list)
    created_at: str = ""
    used_count: int = 0
    model: str = ""

    def summary(self) -> str:
        return (f"{self.title_fa}  ·  {len(self.tables)} جدول"
                f"  ·  {self.layout_kind}"
                + (f"  ·  {len(self.parameters)} پارامتر" if self.parameters else ""))


def _slugify(text: str) -> str:
    s = re.sub(r"[^\w\u0600-\u06FF\s-]", "", text).strip()
    s = re.sub(r"[\s_]+", "-", s)
    return (s[:60] or "report").strip("-")


class ReportCatalog:
    """
    ذخیره‌سازی روی فایل — یک JSON برای هر گزارش.

    در git می‌رود (بدون داده، فقط ساختار) تا با همکاران به اشتراک برود.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    # ---------- نوشتن ----------

    def save(self, *, title_fa: str, plan, sql: str,
             layout=None, request_fa: str = "", rdl_path: str = "",
             lessons: list[str] | None = None, model: str = "",
             category: str = "") -> CatalogEntry:
        tables = [plan.base_table] + [j.to_table for j in plan.joins]
        entry = CatalogEntry(
            slug=_slugify(title_fa or plan.intent_fa),
            title_fa=title_fa or plan.intent_fa,
            category=category,
            request_fa=request_fa,
            intent_fa=plan.intent_fa,
            tables=sorted(set(tables)),
            parameters=[p.name for p in plan.parameters],
            layout_kind=getattr(layout, "kind", "table"),
            sql=sql,
            plan=plan.to_dict(),
            layout=layout.to_dict() if layout else {},
            rdl_path=str(rdl_path),
            lessons=lessons or [],
            created_at=datetime.now().isoformat(timespec="seconds"),
            model=model,
        )

        path = self.root / f"{entry.slug}.json"
        if path.exists():                       # نگه‌داشتن شمارندهٔ استفاده و دسته
            try:
                old = json.loads(path.read_text(encoding="utf-8"))
                entry.used_count = old.get("used_count", 0)
                if not entry.category:
                    entry.category = old.get("category", "")
            except Exception:
                pass
            n = 2
            while path.exists() and json.loads(
                    path.read_text(encoding="utf-8")).get("title_fa") != entry.title_fa:
                path = self.root / f"{entry.slug}-{n}.json"
                n += 1
            entry.slug = path.stem

        path.write_text(json.dumps(asdict(entry), ensure_ascii=False, indent=2),
                        encoding="utf-8")
        return entry

    def save_raw(self, *, title_fa: str, sql: str = "", category: str = "",
                 tables: list[str] | None = None, rdl_path: str = "",
                 request_fa: str = "", layout_kind: str = "table") -> CatalogEntry:
        """ذخیرهٔ گزارش بدون «نقشه» — برای منابع آپلودشده (SQL/RDL خام)."""
        entry = CatalogEntry(
            slug=_slugify(title_fa),
            title_fa=title_fa,
            category=category,
            request_fa=request_fa,
            intent_fa=title_fa,
            tables=sorted(set(tables or [])),
            parameters=[],
            layout_kind=layout_kind,
            sql=sql,
            plan={},
            layout={},
            rdl_path=str(rdl_path),
            lessons=[],
            created_at=datetime.now().isoformat(timespec="seconds"),
        )
        path = self.root / f"{entry.slug}.json"
        if path.exists():
            try:
                old = json.loads(path.read_text(encoding="utf-8"))
                entry.used_count = old.get("used_count", 0)
                if not entry.category:
                    entry.category = old.get("category", "")
                if not entry.rdl_path:
                    entry.rdl_path = old.get("rdl_path", "")
            except Exception:
                pass
        path.write_text(json.dumps(asdict(entry), ensure_ascii=False, indent=2),
                        encoding="utf-8")
        return entry

    def set_category(self, slug: str, category: str) -> bool:
        p = self.root / f"{slug}.json"
        if not p.exists():
            return False
        d = json.loads(p.read_text(encoding="utf-8"))
        d["category"] = category
        p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
        return True

    def categories(self) -> list[dict]:
        from collections import Counter
        c = Counter((e.category or "") for e in self.all())
        return [{"name": k, "count": v} for k, v in
                sorted(c.items(), key=lambda kv: (kv[0] == "", kv[0]))]

    def add_lesson(self, slug: str, lesson: str) -> bool:
        p = self.root / f"{slug}.json"
        if not p.exists():
            return False
        d = json.loads(p.read_text(encoding="utf-8"))
        if lesson not in d.setdefault("lessons", []):
            d["lessons"].append(lesson)
        p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
        return True

    # ---------- خواندن ----------

    def all(self) -> list[CatalogEntry]:
        out = []
        for f in sorted(self.root.glob("*.json")):
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
                out.append(CatalogEntry(**{
                    k: v for k, v in d.items()
                    if k in CatalogEntry.__dataclass_fields__}))
            except Exception:
                continue
        return out

    def get(self, slug: str) -> CatalogEntry | None:
        return next((e for e in self.all() if e.slug == slug), None)

    def find(self, query: str, limit: int = 6) -> list[tuple[CatalogEntry, float]]:
        """
        جست‌وجوی گزارش مشابه.

        امتیاز بر اساس اشتراک واژه در عنوان و درخواست، به‌علاوهٔ نام جدول.
        نرمال‌سازی فارسی اعمال می‌شود تا «كاركرد» و «کارکرد» یکی باشند.
        """
        q = set(normalize(query).split())
        if not q:
            return []
        scored = []
        for e in self.all():
            text = normalize(f"{e.title_fa} {e.request_fa} {e.intent_fa}")
            words = set(text.split())
            hit = len(q & words)
            if not hit:
                # شاید نام جدول باشد
                if any(t.lower() in query.lower() for t in e.tables):
                    hit = 1
                else:
                    continue
            score = hit / len(q) + 0.05 * e.used_count
            scored.append((e, round(score, 3)))
        scored.sort(key=lambda x: -x[1])
        return scored[:limit]

    def touch(self, slug: str) -> None:
        """ثبت استفادهٔ دوباره — گزارش‌های پرکاربرد بالاتر می‌آیند."""
        p = self.root / f"{slug}.json"
        if not p.exists():
            return
        d = json.loads(p.read_text(encoding="utf-8"))
        d["used_count"] = d.get("used_count", 0) + 1
        p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---------- زمینه برای مدل ----------

    def context_for(self, request: str, limit: int = 2) -> str:
        """
        گزارش‌های مشابه قبلی را به‌صورت زمینه برمی‌گرداند.

        این به مدل کمک می‌کند الگوی شما را تکرار کند، نه اینکه
        هر بار از نو تصمیم بگیرد.
        """
        hits = self.find(request, limit=limit)
        if not hits:
            return ""
        out = ["## گزارش‌های مشابه قبلی", ""]
        for e, score in hits:
            out.append(f"### {e.title_fa}  (شباهت {score})")
            if e.request_fa:
                out.append(f"درخواست: {e.request_fa}")
            out.append(f"جدول‌ها: {'، '.join(e.tables)}")
            if e.parameters:
                out.append(f"پارامترها: {'، '.join(e.parameters)}")
            out.append(f"چیدمان: {e.layout_kind}")
            for l in e.lessons:
                out.append(f"⚠ درس: {l}")
            out.append("")
        return "\n".join(out)

    def stats(self) -> dict:
        entries = self.all()
        from collections import Counter
        tables = Counter(t for e in entries for t in e.tables)
        return {
            "count": len(entries),
            "layouts": dict(Counter(e.layout_kind for e in entries)),
            "top_tables": tables.most_common(6),
            "with_lessons": sum(1 for e in entries if e.lessons),
        }
