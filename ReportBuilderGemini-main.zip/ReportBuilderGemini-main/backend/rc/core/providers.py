"""
لایهٔ ارائه‌دهندهٔ مدل — مستقل از فروشنده.

طراحی عمداً کم‌عمق است: هر ارائه‌دهنده فقط باید یک کار بکند —
متن بگیرد، متن بدهد. استخراج JSON، اعتبارسنجی، و تلاش دوباره
همه در لایهٔ بالاتر انجام می‌شوند.

چرا این‌طور:
    اگر منطق در provider باشد، هر مدل جدید یعنی بازنویسی آن منطق.
    با این طراحی، افزودن یک مدل جدید ۱۵ خط کد است.

پشتیبانی:
    anthropic   Claude
    openai      GPT — و هر سرویس سازگار با OpenAI:
                DeepSeek · Ollama · LM Studio · OpenRouter · Together · Groq
    google      Gemini
"""

from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field


class ProviderError(RuntimeError):
    pass


@dataclass
class ModelConfig:
    provider: str                       # anthropic | openai | google
    model: str
    api_key: str = ""
    base_url: str = ""                  # برای سرویس‌های سازگار OpenAI
    temperature: float = 0.0            # صفر = تکرارپذیر
    max_tokens: int = 4096
    timeout: int = 180                  # مدل‌های کند مشکلی نیستند
    extra_headers: dict = field(default_factory=dict)


def _post(url: str, payload: dict, headers: dict, timeout: int) -> dict:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:400]
        raise ProviderError(f"HTTP {e.code} — {detail}") from None
    except urllib.error.URLError as e:
        raise ProviderError(f"اتصال برقرار نشد: {e.reason}") from None


# ═══════════════════════ ارائه‌دهنده‌ها ═══════════════════════

class Provider:
    name = "base"

    def __init__(self, cfg: ModelConfig):
        self.cfg = cfg

    def complete(self, system: str, messages: list[dict],
                 want_json: bool = False) -> str:
        raise NotImplementedError

    # هر ارائه‌دهنده مصرف توکن را این‌جا می‌گذارد
    last_usage: dict = {}


class AnthropicProvider(Provider):
    name = "anthropic"
    DEFAULT_URL = "https://api.anthropic.com/v1/messages"

    def complete(self, system, messages, want_json=False) -> str:
        payload = {
            "model": self.cfg.model,
            "max_tokens": self.cfg.max_tokens,
            "temperature": self.cfg.temperature,
            "system": system,
            "messages": messages,
        }
        data = _post(self.cfg.base_url or self.DEFAULT_URL, payload, {
            "x-api-key": self.cfg.api_key,
            "anthropic-version": "2023-06-01",
            **self.cfg.extra_headers,
        }, self.cfg.timeout)

        u = data.get("usage", {})
        self.last_usage = {"in": u.get("input_tokens", 0),
                           "out": u.get("output_tokens", 0)}
        return "".join(b.get("text", "") for b in data.get("content", [])
                       if b.get("type") == "text")


class OpenAIProvider(Provider):
    """
    سازگار با OpenAI — یعنی این‌ها هم:
        OpenAI      https://api.openai.com/v1
        DeepSeek    https://api.deepseek.com/v1
        Ollama      http://localhost:11434/v1
        LM Studio   http://localhost:1234/v1
        OpenRouter  https://openrouter.ai/api/v1
        Groq        https://api.groq.com/openai/v1
    """
    name = "openai"
    DEFAULT_URL = "https://api.openai.com/v1"

    def complete(self, system, messages, want_json=False) -> str:
        base = (self.cfg.base_url or self.DEFAULT_URL).rstrip("/")
        payload = {
            "model": self.cfg.model,
            "temperature": self.cfg.temperature,
            "max_tokens": self.cfg.max_tokens,
            "messages": [{"role": "system", "content": system}, *messages],
        }
        if want_json:
            # همهٔ سرویس‌ها پشتیبانی نمی‌کنند؛ اگر رد شد بدون آن دوباره تلاش کن
            payload["response_format"] = {"type": "json_object"}

        headers = {**self.cfg.extra_headers}
        if self.cfg.api_key:
            headers["Authorization"] = f"Bearer {self.cfg.api_key}"

        try:
            data = _post(f"{base}/chat/completions", payload, headers, self.cfg.timeout)
        except ProviderError as e:
            if want_json and "response_format" in str(e):
                payload.pop("response_format")
                data = _post(f"{base}/chat/completions", payload, headers,
                             self.cfg.timeout)
            else:
                raise

        u = data.get("usage", {})
        self.last_usage = {"in": u.get("prompt_tokens", 0),
                           "out": u.get("completion_tokens", 0)}
        choices = data.get("choices") or []
        return choices[0]["message"]["content"] if choices else ""


class GoogleProvider(Provider):
    name = "google"
    DEFAULT_URL = "https://generativelanguage.googleapis.com/v1beta"

    def complete(self, system, messages, want_json=False) -> str:
        base = (self.cfg.base_url or self.DEFAULT_URL).rstrip("/")
        url = f"{base}/models/{self.cfg.model}:generateContent?key={self.cfg.api_key}"

        contents = [{
            "role": "user" if m["role"] == "user" else "model",
            "parts": [{"text": m["content"]}],
        } for m in messages]

        gen = {"temperature": self.cfg.temperature,
               "maxOutputTokens": self.cfg.max_tokens}
        if want_json:
            gen["responseMimeType"] = "application/json"

        data = _post(url, {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": contents,
            "generationConfig": gen,
        }, self.cfg.extra_headers, self.cfg.timeout)

        u = data.get("usageMetadata", {})
        self.last_usage = {"in": u.get("promptTokenCount", 0),
                           "out": u.get("candidatesTokenCount", 0)}
        cands = data.get("candidates") or []
        if not cands:
            return ""
        return "".join(p.get("text", "")
                       for p in cands[0].get("content", {}).get("parts", []))


class EmergentProvider(Provider):
    """
    ارائه‌دهندهٔ کلید یونیورسال Emergent — بدون تنظیم، از طریق کتابخانهٔ
    emergentintegrations به Claude / GPT / Gemini دسترسی می‌دهد.

    نام مدلِ مقصد در cfg.model و بک‌اند (anthropic|openai|gemini) در
    cfg.base_url نگه‌داری می‌شود.
    """
    name = "emergent"

    def complete(self, system, messages, want_json=False) -> str:
        import asyncio
        import uuid as _uuid
        from emergentintegrations.llm.chat import LlmChat, UserMessage

        backend = (self.cfg.base_url or "anthropic").strip()
        text = "\n\n".join(f"[{m['role']}]\n{m['content']}" for m in messages)

        async def _run() -> str:
            chat = LlmChat(api_key=self.cfg.api_key,
                           session_id=_uuid.uuid4().hex,
                           system_message=system).with_model(backend, self.cfg.model)
            return await chat.send_message(UserMessage(text=text))

        try:
            out = asyncio.run(_run())
        except Exception as e:                             # noqa: BLE001
            raise ProviderError(f"Emergent: {e}") from None
        self.last_usage = {"in": 0, "out": 0}
        return out if isinstance(out, str) else str(out)


_REGISTRY = {
    "anthropic": AnthropicProvider,
    "openai": OpenAIProvider,
    "google": GoogleProvider,
    "emergent": EmergentProvider,
}

# پیش‌تنظیم سرویس‌های رایج — کاربر فقط کلید می‌دهد
PRESETS = {
    "emergent":        ModelConfig("emergent", "claude-sonnet-4-6", base_url="anthropic"),
    "emergent-gpt":    ModelConfig("emergent", "gpt-5.4", base_url="openai"),
    "emergent-gemini": ModelConfig("emergent", "gemini-3.1-pro-preview", base_url="gemini"),
    "claude":     ModelConfig("anthropic", "claude-sonnet-4-6"),
    "gpt":        ModelConfig("openai", "gpt-4o"),
    "deepseek":   ModelConfig("openai", "deepseek-chat",
                              base_url="https://api.deepseek.com/v1"),
    "gemini":     ModelConfig("google", "gemini-2.0-flash"),
    "ollama":     ModelConfig("openai", "qwen2.5-coder:14b",
                              base_url="http://localhost:11434/v1",
                              api_key="ollama"),
    "lmstudio":   ModelConfig("openai", "local-model",
                              base_url="http://localhost:1234/v1",
                              api_key="lm-studio"),
    "openrouter": ModelConfig("openai", "anthropic/claude-sonnet-4.5",
                              base_url="https://openrouter.ai/api/v1"),
}


def make_provider(cfg: ModelConfig) -> Provider:
    if cfg.provider not in _REGISTRY:
        raise ProviderError(
            f"ارائه‌دهندهٔ «{cfg.provider}» شناخته نشد. "
            f"موجود: {', '.join(_REGISTRY)}")
    if cfg.provider == "emergent" and not cfg.api_key:
        cfg.api_key = os.environ.get("EMERGENT_LLM_KEY", "")
        if not cfg.api_key:
            raise ProviderError("کلید یونیورسال Emergent تنظیم نشده است.")
    if not cfg.api_key and cfg.provider not in ("openai", "emergent"):
        env = {"anthropic": "ANTHROPIC_API_KEY", "google": "GOOGLE_API_KEY"}
        cfg.api_key = os.environ.get(env.get(cfg.provider, ""), "")
        if not cfg.api_key:
            raise ProviderError(f"کلید API برای {cfg.provider} تنظیم نشده.")
    return _REGISTRY[cfg.provider](cfg)


def from_preset(name: str, api_key: str = "", **over) -> Provider:
    if name not in PRESETS:
        raise ProviderError(f"پیش‌تنظیم «{name}» نیست. موجود: {', '.join(PRESETS)}")
    base = PRESETS[name]
    cfg = ModelConfig(**{**base.__dict__, "api_key": api_key or base.api_key, **over})
    return make_provider(cfg)


# ═══════════════════════ تلاش دوباره ═══════════════════════

def with_retry(fn, attempts: int = 3, wait: float = 2.0):
    """
    مدل‌های رایگان/محلی گاهی موقتاً خطا می‌دهند.
    کندی مشکلی نیست — پس صبورانه تلاش می‌کنیم.
    """
    last: Exception | None = None
    for i in range(attempts):
        try:
            return fn()
        except ProviderError as e:
            last = e
            msg = str(e).lower()
            if any(k in msg for k in ("401", "403", "invalid_api_key", "unauthorized")):
                raise                                  # خطای کلید — تکرار بی‌فایده
            if i < attempts - 1:
                time.sleep(wait * (2 ** i))
    raise last or ProviderError("تلاش‌ها ناموفق بود")
