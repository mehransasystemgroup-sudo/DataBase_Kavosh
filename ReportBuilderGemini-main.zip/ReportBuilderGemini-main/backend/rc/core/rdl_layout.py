"""
چیدمان گزارش — لایه‌ای بین نقشهٔ کوئری و فایل RDL.

مسئله:
    یک کوئری، چند شکل نمایش دارد. همان داده می‌تواند جدول ساده باشد،
    جدول گروه‌بندی‌شده با جمع هر گروه، یا ماتریس (پیوت).

    در RDL، سلسله‌مراتب گروه‌ها و ردیف‌های بدنه باید دقیقاً با هم بخوانند.
    اگر بدنه ۴ ردیف داشته باشد و سلسله‌مراتب ۳ عضو، فایل باز نمی‌شود.
    این شایع‌ترین باگ RDLهای دست‌ساز است.

راه‌حل:
    یک «مدل ردیف» واحد که هم بدنه و هم سلسله‌مراتب از آن ساخته می‌شوند.
    ناهماهنگی از نظر ساختاری ممکن نیست.
"""

from __future__ import annotations

import re

from dataclasses import dataclass, field
from typing import Literal

from .plan import QueryPlan


# ─────────────── مشخصات چیدمان ───────────────

@dataclass
class LayoutGroup:
    """یک سطح گروه‌بندی."""
    field_name: str                     # نام ستون خروجی
    header_fa: str = ""
    show_header_row: bool = True        # ردیف عنوان گروه
    show_total_row: bool = True         # ردیف جمع گروه
    page_break: bool = False            # هر گروه در صفحهٔ جدید


@dataclass
class LayoutValue:
    """یک مقدار در سلول ماتریس."""
    field_name: str
    aggregate: str = "SUM"              # SUM | COUNT | AVG | MIN | MAX
    header_fa: str = ""
    format: str = "#,##0"


@dataclass
class DynamicColumnSet:
    """
    ستون‌های پویا — تعداد ستون‌های نمایش‌داده‌شده زمان اجرا با یک پارامتر
    عددی تعیین می‌شود (الگوی «تقویم حضور»: SalaryListItems + AttendanceColumnsCount).

    اصل SSRS: کوئری همیشه حداکثر تعداد ستون ممکن را برمی‌گرداند (مثلاً
    Day1..Day31)؛ ستون‌های بیش از مقدار پارامتر با Visibility مخفی می‌شوند،
    نه حذف — چون TablixColumns، TablixColumnHierarchy، و TablixCell هر
    ردیف باید همیشه دقیقاً هم‌تعداد بمانند.
    """
    field_prefix: str                      # "Day" → Day1..Day31
    max_columns: int                       # حداکثر تعداد ممکن (مثلاً 31)
    count_parameter: str                   # نام پارامتر int بدون @ (AttendanceColumnsCount)
    header_prefix: str = ""                # عنوان ستون = header_prefix + شماره (اگر خالی، فقط شماره)
    header_field_prefix: str = ""          # اختیاری: عنوان از دیتاست (مثلاً DayName1..DayName31)
    column_width: str = "0.8cm"
    value_format: str = ""                 # اگر خالی، از پروفایل سازمانی خوانده می‌شود
    leading_fields: list[str] = field(default_factory=list)   # ستون‌های ثابت قبل از ستون‌های پویا
    trailing_fields: list[str] = field(default_factory=list)  # ستون‌های ثابت بعد از ستون‌های پویا

    def field_name(self, i: int) -> str:
        return f"{self.field_prefix}{i}"

    def header_field_name(self, i: int) -> str:
        return f"{self.header_field_prefix}{i}" if self.header_field_prefix else ""


@dataclass
class PageBand:
    """سرصفحه یا پاصفحه."""
    enabled: bool = False
    height: str = "1.2cm"
    left: str = ""                      # عبارت یا متن
    center: str = ""
    right: str = ""
    show_line: bool = True


@dataclass
class ReportLayout:
    kind: Literal["table", "grouped", "matrix", "dynamic_columns"] = "table"

    row_groups: list[LayoutGroup] = field(default_factory=list)
    column_group: LayoutGroup | None = None      # فقط ماتریس
    values: list[LayoutValue] = field(default_factory=list)   # فقط ماتریس
    dynamic_columns: DynamicColumnSet | None = None            # فقط dynamic_columns

    detail_fields: list[str] = field(default_factory=list)
    show_details: bool = True
    grand_total: bool = True

    page_header: PageBand = field(default_factory=PageBand)
    page_footer: PageBand = field(default_factory=PageBand)

    def to_dict(self) -> dict:
        from dataclasses import asdict
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ReportLayout":
        def band(x):
            return PageBand(**{k: v for k, v in (x or {}).items()
                               if k in PageBand.__dataclass_fields__})
        def grp(x):
            return LayoutGroup(**{k: v for k, v in (x or {}).items()
                                  if k in LayoutGroup.__dataclass_fields__})
        def dyncols(x):
            if not x:
                return None
            return DynamicColumnSet(**{k: v for k, v in x.items()
                                       if k in DynamicColumnSet.__dataclass_fields__})
        return cls(
            kind=d.get("kind", "table"),
            row_groups=[grp(g) for g in d.get("row_groups") or []],
            column_group=grp(d["column_group"]) if d.get("column_group") else None,
            values=[LayoutValue(**{k: v for k, v in (x or {}).items()
                                   if k in LayoutValue.__dataclass_fields__})
                    for x in d.get("values") or []],
            dynamic_columns=dyncols(d.get("dynamic_columns")),
            detail_fields=list(d.get("detail_fields") or []),
            show_details=d.get("show_details", True),
            grand_total=d.get("grand_total", True),
            page_header=band(d.get("page_header")),
            page_footer=band(d.get("page_footer")),
        )


# ─────────────── تشخیص ستون‌های پویا ───────────────

_DYNCOL_RE = re.compile(r"^([A-Za-z\u0600-\u06FF_]+?)(\d+)$")


def detect_dynamic_columns(plan: QueryPlan) -> DynamicColumnSet | None:
    """
    تشخیص خودکار الگوی «ستون‌های پویا» از روی خروجی نقشه — بدون این‌که
    مدل زبانی لازم باشد چیزی دربارهٔ RDL یا Visibility بداند.

    شرط: چند ستون هم‌پیشوند با شمارهٔ متوالی از ۱ در select
    (مثل Day1..Day31) + یک پارامتر int که نامش/عنوانش به «تعداد» اشاره دارد.
    """
    groups: dict[str, list[int]] = {}
    for c in plan.select:
        m = _DYNCOL_RE.match(c.output_name())
        if m:
            groups.setdefault(m.group(1), []).append(int(m.group(2)))

    candidates = {p: sorted(nums) for p, nums in groups.items() if len(nums) >= 3}
    if not candidates:
        return None

    prefix, nums = max(candidates.items(), key=lambda kv: len(kv[1]))
    if nums != list(range(1, len(nums) + 1)):
        return None   # باید دقیقاً ۱..N پیوسته باشد

    count_param = next(
        (p.name for p in plan.parameters
         if p.type in ("int", "integer")
         and ("count" in p.name.lower() or "تعداد" in (p.title_fa or ""))),
        None)
    if not count_param:
        return None

    dyn_names = {f"{prefix}{n}" for n in nums}
    leading = [c.output_name() for c in plan.select if c.output_name() not in dyn_names]

    return DynamicColumnSet(
        field_prefix=prefix, max_columns=len(nums), count_parameter=count_param,
        leading_fields=leading)


# ─────────────── استنتاج خودکار ───────────────

def derive_layout(plan: QueryPlan, kb=None) -> ReportLayout:
    """
    حدس چیدمان مناسب از روی نقشه.

    منطق ساده و قابل پیش‌بینی:
        الگوی ستون‌های پویا     →  dynamic_columns (تشخیص خودکار)
        بدون تجمیع            →  جدول ساده
        تجمیع + ۱ ستون ساده   →  جدول گروه‌بندی‌شده
        تجمیع + ۲+ ستون ساده  →  گروه‌بندی چندسطحی

    مدل می‌تواند این را بازنویسی کند — این فقط پیش‌فرض معقول است.
    """
    dc = detect_dynamic_columns(plan)
    if dc:
        lay = ReportLayout(kind="dynamic_columns", dynamic_columns=dc, grand_total=False)
        lay.page_header = PageBand(
            enabled=True, right=plan.intent_fa or "گزارش",
            left="=Format(Now(), \"yyyy/MM/dd\")")
        lay.page_footer = PageBand(
            enabled=True,
            right="=\"صفحه \" & Globals!PageNumber & \" از \" & Globals!TotalPages",
            left="=User!UserID", height="0.9cm")
        return lay

    plain = [c for c in plan.select if not c.aggregate]
    aggs = [c for c in plan.select if c.aggregate]

    lay = ReportLayout()
    lay.page_header = PageBand(
        enabled=True,
        right=plan.intent_fa or "گزارش",
        left="=Format(Now(), \"yyyy/MM/dd\")",
        center="")
    lay.page_footer = PageBand(
        enabled=True,
        right="=\"صفحه \" & Globals!PageNumber & \" از \" & Globals!TotalPages",
        left="=User!UserID",
        height="0.9cm")

    if not aggs:
        lay.kind = "table"
        lay.detail_fields = [c.output_name() for c in plan.select]
        lay.grand_total = False
        return lay

    if not plain:
        lay.kind = "table"
        lay.detail_fields = [c.output_name() for c in plan.select]
        lay.grand_total = False
        return lay

    lay.kind = "grouped"
    # آخرین ستون ساده جزئیات می‌ماند، بقیه گروه می‌شوند
    groups = plain[:-1] if len(plain) > 1 else plain
    details = plain[-1:] if len(plain) > 1 else []

    for c in groups:
        title = c.output_name()
        lay.row_groups.append(LayoutGroup(
            field_name=c.output_name(), header_fa=title,
            show_header_row=True, show_total_row=len(groups) == 1))

    lay.detail_fields = [c.output_name() for c in details] + \
                        [c.output_name() for c in aggs]
    lay.show_details = bool(details) or len(groups) == 0
    return lay


# ─────────────── اعتبارسنجی ───────────────

@dataclass
class LayoutIssue:
    severity: str
    message_fa: str
    options: list[str] = field(default_factory=list)

    def for_model(self) -> str:
        s = f"[{self.severity}] {self.message_fa}"
        if self.options:
            s += f"\n    گزینه‌های معتبر: {', '.join(self.options[:20])}"
        return s


def validate_layout(lay: ReportLayout, plan: QueryPlan) -> list[LayoutIssue]:
    """
    هر ارجاع چیدمان باید به یک ستون خروجی نقشه اشاره کند.

    بدون این بررسی، RDL تولید می‌شود ولی در Report Builder
    خطای «Field not found» می‌دهد.
    """
    out: list[LayoutIssue] = []
    available = [c.output_name() for c in plan.select]
    avail = set(available)

    def check(name: str, where: str) -> bool:
        if name not in avail:
            out.append(LayoutIssue(
                "error", f"{where}: ستون «{name}» در خروجی کوئری نیست.", available))
            return False
        return True

    for i, g in enumerate(lay.row_groups):
        check(g.field_name, f"row_groups[{i}]")
    if lay.column_group:
        check(lay.column_group.field_name, "column_group")
    for i, v in enumerate(lay.values):
        check(v.field_name, f"values[{i}]")
    for i, f in enumerate(lay.detail_fields):
        check(f, f"detail_fields[{i}]")

    # ── سازگاری شکل ──
    if lay.kind == "matrix":
        if not lay.column_group:
            out.append(LayoutIssue("error", "ماتریس بدون column_group ممکن نیست."))
        if not lay.row_groups:
            out.append(LayoutIssue("error", "ماتریس حداقل یک row_group لازم دارد."))
        if not lay.values:
            out.append(LayoutIssue("error", "ماتریس حداقل یک مقدار (values) لازم دارد."))
    elif lay.kind == "grouped":
        if not lay.row_groups:
            out.append(LayoutIssue(
                "error", "چیدمان grouped بدون row_groups ممکن نیست.",
                ["kind را table بگذارید یا row_groups اضافه کنید"]))
    elif lay.kind == "table":
        if lay.row_groups:
            out.append(LayoutIssue(
                "warning", "چیدمان table گروه دارد — به grouped تبدیل شد."))
            lay.kind = "grouped"
        if not lay.detail_fields:
            out.append(LayoutIssue("error", "جدول ساده بدون detail_fields ممکن نیست."))
    elif lay.kind == "dynamic_columns":
        dc = lay.dynamic_columns
        if not dc:
            out.append(LayoutIssue(
                "error", "چیدمان dynamic_columns بدون تعریف dynamic_columns ممکن نیست."))
        else:
            param_names = {p.name for p in plan.parameters}
            if dc.count_parameter not in param_names:
                out.append(LayoutIssue(
                    "error",
                    f"پارامتر شمارندهٔ ستون «{dc.count_parameter}» در نقشه تعریف نشده.",
                    sorted(param_names)))
            fixed_missing = [f for f in dc.leading_fields + dc.trailing_fields
                              if f not in avail]
            if fixed_missing:
                out.append(LayoutIssue(
                    "error",
                    f"ستون(های) ثابت {', '.join(fixed_missing)} در خروجی کوئری نیستند.",
                    available))
            overlap_lt = set(dc.leading_fields) & set(dc.trailing_fields)
            if overlap_lt:
                out.append(LayoutIssue(
                    "error",
                    f"ستون(های) {', '.join(sorted(overlap_lt))} هم در leading_fields "
                    f"هم در trailing_fields هستند — هر ستون فقط یک‌بار مجاز است."))
            dyn_names = [dc.field_name(i) for i in range(1, dc.max_columns + 1)]
            overlap_dyn = (set(dc.leading_fields) | set(dc.trailing_fields)) & set(dyn_names)
            if overlap_dyn:
                out.append(LayoutIssue(
                    "error",
                    f"ستون(های) {', '.join(sorted(overlap_dyn))} هم در leading/trailing_fields "
                    f"هم جزو الگوی ستون پویا ({dc.field_prefix}N) هستند."))
            dyn_missing = [f for f in dyn_names if f not in avail]
            if dyn_missing:
                shown = ', '.join(dyn_missing[:10]) + (" ..." if len(dyn_missing) > 10 else "")
                out.append(LayoutIssue(
                    "error",
                    f"همهٔ ستون‌های پویای {dc.field_prefix}1..{dc.field_prefix}{dc.max_columns} "
                    f"باید در خروجی کوئری باشند؛ این‌ها یافت نشدند: {shown}",
                    available))

    # ── هم‌پوشانی ──
    grouped = {g.field_name for g in lay.row_groups}
    overlap = grouped & set(lay.detail_fields)
    if overlap:
        lay.detail_fields = [f for f in lay.detail_fields if f not in overlap]
        out.append(LayoutIssue(
            "warning",
            f"ستون‌های {', '.join(sorted(overlap))} هم گروه بودند هم جزئیات — "
            f"از جزئیات حذف شدند."))

    return out


# ─────────────── مدل ردیف ───────────────

RowKind = Literal["header", "group_header", "detail", "group_total", "grand_total"]


@dataclass
class BodyRow:
    kind: RowKind
    level: int = 0                      # عمق گروه (۰ = بیرونی‌ترین)
    group_name: str = ""


def build_row_model(lay: ReportLayout) -> list[BodyRow]:
    """
    ترتیب ردیف‌های بدنه — مبنای ساخت هم بدنه و هم سلسله‌مراتب.

    چون هر دو از این فهرست ساخته می‌شوند، ناهماهنگی ممکن نیست.

    خروجی نمونه برای دو سطح گروه:
        header
        group_header(0)   ← گروه بیرونی
        group_header(1)   ← گروه داخلی
        detail
        group_total(1)
        group_total(0)
        grand_total
    """
    rows: list[BodyRow] = [BodyRow("header")]

    for i, g in enumerate(lay.row_groups):
        if g.show_header_row:
            rows.append(BodyRow("group_header", i, g.field_name))

    if lay.show_details or not lay.row_groups:
        rows.append(BodyRow("detail"))

    for i in range(len(lay.row_groups) - 1, -1, -1):
        if lay.row_groups[i].show_total_row:
            rows.append(BodyRow("group_total", i, lay.row_groups[i].field_name))

    if lay.grand_total:
        rows.append(BodyRow("grand_total"))

    return rows
