"""برآورد هزینه — مشترک بین CLI و اپ."""

PRICING = {
    "claude-sonnet": (3.0, 15.0), "claude-opus": (15.0, 75.0),
    "claude-haiku": (0.8, 4.0), "gpt-4o": (2.5, 10.0),
    "gpt-4o-mini": (0.15, 0.6), "deepseek": (0.27, 1.10),
    "gemini-2.0-flash": (0.10, 0.40), "gemini-1.5-pro": (1.25, 5.0),
}


def estimate_cost_safe(model: str, tin: int, tout: int) -> float:
    """دلار تقریبی. مدل ناشناخته یا محلی → صفر."""
    m = (model or "").lower()
    rate = next((v for k, v in PRICING.items() if k in m), None)
    return 0.0 if rate is None else round(tin / 1e6 * rate[0] + tout / 1e6 * rate[1], 6)
