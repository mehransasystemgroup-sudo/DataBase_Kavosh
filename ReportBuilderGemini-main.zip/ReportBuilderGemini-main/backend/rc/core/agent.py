"""
حلقهٔ ایجنت — تضمین کیفیت مستقل از مدل.

جریان:
    ۱. جست‌وجو: جدول‌های مرتبط پیدا می‌شوند                 [کد]
    ۲. زمینه‌سازی: ساختار دقیق آن‌ها به مدل داده می‌شود      [کد]
    ۳. نقشه: مدل انتخاب‌هایش را به‌صورت JSON می‌دهد          [مدل]
    ۴. اعتبارسنجی: هر انتخاب با KB سنجیده می‌شود            [کد]
    ۵. اگر خطا: بازخورد مشخص + گزینه‌های معتبر → دور بعد    [کد]
    ۶. مونتاژ: SQL قطعی ساخته می‌شود                        [کد]

مدل فقط در گام ۳ دخالت دارد. بقیه قطعی است.

چرا این برای مدل ضعیف کار می‌کند:
    • مدل هرگز SQL نمی‌نویسد — پس نمی‌تواند نحو را خراب کند
    • هر نام جدول/ستون از فهرستی که دادیم انتخاب می‌شود
    • خطاها با گزینه‌های معتبر برمی‌گردند — خوداصلاحی ممکن است
    • قوانین تجاری (سال مالی) توسط کد اعمال می‌شود، نه یادآوری به مدل
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from .plan import (QueryPlan, PlanValidator, PlanCheck, SqlAssembler,
                   extract_json, AGGREGATES, OPERATORS)
from .providers import Provider, with_retry


SYSTEM = """تو یک تحلیل‌گر دیتابیس هستی که برای یک سیستم ERP فارسی گزارش طراحی می‌کند.

وظیفهٔ تو: تبدیل درخواست کاربر به یک «نقشهٔ کوئری» در قالب JSON.

⚠️ تو SQL نمی‌نویسی. فقط نقشه می‌دهی. سیستم از نقشه SQL می‌سازد.

قوانین سخت:
۱. فقط از جدول‌ها و ستون‌هایی استفاده کن که در «ساختار موجود» آمده‌اند.
   هیچ نام دیگری ننویس — حتی اگر منطقی به‌نظر برسد.
۲. هر جدولی که در select یا filter استفاده می‌شود، باید یا base_table باشد
   یا از طریق joins به کوئری اضافه شده باشد.
۳. ترتیب joins مهم است: from_table باید قبلاً به کوئری اضافه شده باشد.
۴. اگر جدولی ستون FiscalYearRef دارد، حتماً فیلترش کن با parameter (نه مقدار ثابت).
۵. برای مقادیر enum فقط از کدهای فهرست‌شده استفاده کن.
۶. فقط JSON بده. هیچ توضیحی قبل یا بعدش ننویس.

قالب JSON:
{
  "intent_fa": "توضیح یک‌خطی گزارش",
  "base_table": "SCHEMA.Table",
  "select": [
    {"table": "SCHEMA.Table", "column": "ColumnName",
     "aggregate": null, "alias": "OutputName"}
  ],
  "joins": [
    {"kind": "INNER", "from_table": "SCHEMA.A", "from_column": "BRef",
     "to_table": "SCHEMA.B", "to_column": "BID"}
  ],
  "filters": [
    {"table": "SCHEMA.Table", "column": "State", "op": "=", "value": 2},
    {"table": "SCHEMA.Table", "column": "FiscalYearRef", "op": "=",
     "parameter": "FiscalYear"}
  ],
  "group_by": ["SCHEMA.Table.Column"],
  "order_by": [{"expression": "OutputName", "direction": "DESC"}],
  "parameters": [
    {"name": "FiscalYear", "type": "int", "title_fa": "سال مالی", "required": true}
  ],
  "top": null,
  "notes": ["نکتهٔ مهم برای کاربر"]
}

aggregate یکی از: """ + ", ".join(AGGREGATES) + """ یا null
op یکی از: """ + ", ".join(OPERATORS)


@dataclass
class AgentResult:
    ok: bool
    plan: QueryPlan | None = None
    sql: str = ""
    check: PlanCheck | None = None
    attempts: int = 0
    context_tables: list[str] = field(default_factory=list)
    usage: dict = field(default_factory=dict)
    transcript: list[dict] = field(default_factory=list)

    def report_fa(self) -> str:
        lines = []
        if self.ok:
            lines.append(f"✔ نقشه در تلاش {self.attempts} معتبر شد.")
        else:
            lines.append(f"✖ بعد از {self.attempts} تلاش، نقشهٔ معتبر ساخته نشد.")
        if self.context_tables:
            lines.append(f"جدول‌های بررسی‌شده: {'، '.join(self.context_tables)}")
        if self.check:
            for i in self.check.issues:
                mark = "✖" if i.severity == "error" else "⚠"
                lines.append(f"  {mark} {i.message_fa}")
        if self.plan and self.plan.notes:
            lines += [f"  ℹ {n}" for n in self.plan.notes]
        return "\n".join(lines)


class ReportAgent:
    def __init__(self, kb, provider: Provider, max_attempts: int = 4,
                 context_tables: int = 6, catalog=None, only_with_data: bool = False):
        self.kb = kb
        self.catalog = catalog
        self.provider = provider
        self.validator = PlanValidator(kb)
        self.max_attempts = max_attempts
        self.context_tables = context_tables
        self.only_with_data = only_with_data

    # ─────────────── زمینه‌سازی ───────────────

    def _pick_tables(self, request: str, hints: list[str] | None) -> list[str]:
        """
        جدول‌های مرتبط را پیدا می‌کند و همسایگانشان را هم اضافه می‌کند.

        بدون این گام، مدل باید نام جدول را حدس بزند — و همان‌جا شکست می‌خورد.
        """
        picked: list[str] = []
        for h in (hints or []):
            if self.kb.get_table(h):
                picked.append(h)

        for hit in self.kb.search_tables(request, limit=self.context_tables,
                                         only_with_data=self.only_with_data):
            if hit.full_name not in picked:
                picked.append(hit.full_name)

        # همسایه‌های تأییدشدهٔ جدول اول — معمولاً جدول‌های join لازم
        if picked:
            for n in self.kb.neighbours(picked[0], limit=30):
                if n["verified"] and n["table"] not in picked:
                    picked.append(n["table"])
                if len(picked) >= self.context_tables + 6:
                    break
        return picked[: self.context_tables + 6]

    def _describe(self, tables: list[str]) -> str:
        """ساختار دقیق جدول‌ها — این تنها منبع مجاز مدل است."""
        out = ["## ساختار موجود", ""]
        for full in tables:
            t = self.kb.get_table(full)
            if not t:
                continue
            head = f"### {full}"
            if t.title_fa:
                head += f" — {t.title_fa}"
            out.append(head)
            if t.description_fa:
                out.append(t.description_fa)
            rows = f"{t.row_count:,}" if t.row_count else "خالی"
            out.append(f"ردیف: {rows} · کلید: {', '.join(t.primary_key) or '—'}")

            out.append("ستون‌ها: " + ", ".join(c["name"] for c in t.columns))

            if t.enums:
                for col, vals in t.enums.items():
                    known = [f"{v['value']}={v['label_fa']}"
                             for v in vals if v.get("label_fa")]
                    if known:
                        out.append(f"مقادیر {col}: " + " · ".join(known[:14]))

            if t.outgoing:
                links = [f"{j.from_col}→{j.to_table}.{j.to_col}"
                         + ("" if j.verified else " (حدسی)")
                         for j in t.outgoing[:14]]
                out.append("اتصال‌ها: " + " · ".join(links))

            for w in t.warnings:
                out.append(f"⚠ {w}")
            out.append("")
        return "\n".join(out)

    # ─────────────── حلقه ───────────────

    def build(self, request: str, hints: list[str] | None = None) -> AgentResult:
        tables = self._pick_tables(request, hints)
        if not tables:
            return AgentResult(
                ok=False, attempts=0,
                check=PlanCheck(False, []),
                transcript=[{"error": "هیچ جدول مرتبطی پیدا نشد."}])

        context = self._describe(tables)
        # گزارش‌های مشابه قبلی — کمک می‌کند مدل الگوی کاربر را تکرار کند
        prior = self.catalog.context_for(request) if self.catalog else ""
        messages = [{"role": "user",
                     "content": (f"{prior}\n{context}" if prior else context)
                                + f"\n\n## درخواست کاربر\n{request}\n\n"
                                  f"نقشهٔ JSON را بده."}]

        total = {"in": 0, "out": 0}
        result = AgentResult(ok=False, context_tables=tables)

        for attempt in range(1, self.max_attempts + 1):
            result.attempts = attempt

            raw = with_retry(lambda: self.provider.complete(
                SYSTEM, messages, want_json=True))
            u = getattr(self.provider, "last_usage", {}) or {}
            total["in"] += u.get("in", 0)
            total["out"] += u.get("out", 0)
            result.transcript.append({"attempt": attempt, "raw": raw[:2000]})

            data = extract_json(raw)
            if data is None:
                messages += [
                    {"role": "assistant", "content": raw[:1500]},
                    {"role": "user", "content":
                        "پاسخ JSON معتبر نبود. فقط یک شیء JSON بده، "
                        "بدون هیچ متن اضافه‌ای."},
                ]
                continue

            plan, check = self.validator.validate(QueryPlan.from_dict(data))
            result.plan, result.check = plan, check

            if check.ok:
                result.ok = True
                result.sql = SqlAssembler.build(plan)
                break

            # بازخورد مشخص — با گزینه‌های معتبر
            messages += [
                {"role": "assistant",
                 "content": json.dumps(data, ensure_ascii=False)[:1500]},
                {"role": "user", "content": check.feedback_for_model()},
            ]

        result.usage = total
        return result
