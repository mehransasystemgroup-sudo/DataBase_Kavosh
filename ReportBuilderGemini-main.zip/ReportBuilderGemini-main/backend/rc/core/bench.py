"""
محک چندمدلی — کدام مدل برای کار شما کافی است؟

مسئله:
    شما گفتید حاضرید برای دقت، زمان بیشتری صبر کنید. ولی «دقت»
    باید اندازه‌گیری شود، نه حدس زده.

    این ماژول همان درخواست را به چند مدل می‌دهد و می‌سنجد:
        • آیا نقشهٔ معتبر ساخت؟
        • در چند تلاش؟
        • چقدر طول کشید و چقدر خرج شد؟
        • آیا SQL تولیدی با بقیه یکسان است؟

معیار آخر مهم‌ترین است:
    اگر دو مدل به SQL یکسان برسند، تفاوتشان فقط زمان و هزینه است.
    اگر متفاوت برسند، یکی اشتباه می‌کند — و باید فهمید کدام.
"""

from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass, field, asdict
from typing import Callable

from .agent import ReportAgent
from .providers import from_preset, PRESETS, ProviderError


def normalize_sql(sql: str) -> str:
    """
    نرمال‌سازی برای مقایسه — نام مستعار و فاصله نادیده گرفته می‌شوند.

    دو کوئری که فقط در نام مستعار جدول فرق دارند، از نظر معنایی یکی‌اند.
    """
    if not sql:
        return ""
    s = re.sub(r"--[^\n]*", " ", sql)
    s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S)
    s = re.sub(r"\[|\]", "", s)
    s = re.sub(r"\bAS\s+\w+", "", s, flags=re.I)      # نام مستعار ستون
    s = re.sub(r"\b\w+\.", "", s)                      # پیشوند جدول
    s = re.sub(r"\s+", " ", s)
    return s.strip().lower()


def sql_signature(sql: str) -> str:
    return hashlib.sha1(normalize_sql(sql).encode()).hexdigest()[:10]


@dataclass
class ModelRun:
    model: str
    ok: bool = False
    attempts: int = 0
    seconds: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    sql: str = ""
    signature: str = ""
    tables: list[str] = field(default_factory=list)
    error: str = ""
    issues: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["sql"] = self.sql[:2000]
        return d


@dataclass
class BenchCase:
    """یک درخواست آزمون."""
    request: str
    expect_tables: list[str] = field(default_factory=list)
    note: str = ""


@dataclass
class BenchResult:
    case: str
    runs: list[ModelRun] = field(default_factory=list)

    def consensus(self) -> tuple[str, int, int]:
        """
        امضای پرتکرار و تعداد موافق.

        اگر همهٔ مدل‌های موفق به یک امضا برسند، اطمینان بالاست.
        """
        sigs = [r.signature for r in self.runs if r.ok and r.signature]
        if not sigs:
            return "", 0, 0
        best = max(set(sigs), key=sigs.count)
        return best, sigs.count(best), len(sigs)

    def summary_fa(self) -> str:
        sig, agree, total = self.consensus()
        lines = [f"◆ {self.case}"]
        for r in sorted(self.runs, key=lambda x: (not x.ok, x.seconds)):
            mark = "✔" if r.ok else "✖"
            same = ""
            if r.ok and sig:
                same = " ≡" if r.signature == sig else " ≠ متفاوت"
            cost = f" · {r.cost_usd:.4f}$" if r.cost_usd else ""
            detail = (f"{r.attempts} تلاش · {r.seconds:.1f}s · "
                      f"{r.tokens_in + r.tokens_out:,} توکن{cost}{same}"
                      if r.ok else r.error[:52])
            lines.append(f"   {mark} {r.model:<12} {detail}")
        if total > 1:
            pct = round(agree / total * 100)
            verdict = ("همهٔ مدل‌ها به یک نتیجه رسیدند"
                       if agree == total else
                       f"{agree} از {total} مدل هم‌نظرند ({pct}٪)")
            lines.append(f"   └ {verdict}")
        return "\n".join(lines)


# ─────────────── مجموعهٔ پیش‌فرض ───────────────

DEFAULT_CASES = [
    BenchCase("گزارش اسناد حسابداری تأییدشدهٔ سال جاری",
              note="ساده — یک جدول، یک فیلتر enum، فیلتر سال مالی"),
    BenchCase("فهرست اسناد حسابداری با تعداد اقلام هر سند",
              note="متوسط — یک JOIN و یک تجمیع"),
    BenchCase("گزارش کارکنان به تفکیک واحد سازمانی",
              note="نیازمند یافتن جدول درست در HCM3"),
]


class ModelBench:
    def __init__(self, kb, catalog=None, max_attempts: int = 4):
        self.kb = kb
        self.catalog = catalog
        self.max_attempts = max_attempts

    def run_one(self, preset: str, api_key: str, case: BenchCase,
                cost_fn: Callable[[str, int, int], float] | None = None,
                **over) -> ModelRun:
        run = ModelRun(model=preset)
        try:
            prov = from_preset(preset, api_key, **over)
        except ProviderError as e:
            run.error = str(e)
            return run

        t0 = time.time()
        try:
            agent = ReportAgent(self.kb, prov, max_attempts=self.max_attempts,
                                catalog=self.catalog)
            res = agent.build(case.request)
            run.seconds = round(time.time() - t0, 2)
            run.ok = res.ok
            run.attempts = res.attempts
            run.tokens_in = res.usage.get("in", 0)
            run.tokens_out = res.usage.get("out", 0)
            run.sql = res.sql
            run.signature = sql_signature(res.sql) if res.sql else ""
            run.tables = res.plan and sorted(
                {res.plan.base_table} | {j.to_table for j in res.plan.joins}) or []
            if res.check:
                run.issues = [i.message_fa for i in res.check.issues][:5]
            if not res.ok:
                run.error = "نقشهٔ معتبر ساخته نشد"
            if cost_fn:
                model = over.get("model") or PRESETS[preset].model
                run.cost_usd = cost_fn(model, run.tokens_in, run.tokens_out)
        except Exception as e:
            run.seconds = round(time.time() - t0, 2)
            run.error = str(e)[:120]
        return run

    def run(self, models: list[tuple[str, str]], cases: list[BenchCase] | None = None,
            cost_fn=None, on_progress: Callable | None = None) -> list[BenchResult]:
        """
        اجرای همهٔ مدل‌ها روی همهٔ موردها.

        models: [(نام پیش‌تنظیم، کلید), ...]
        """
        cases = cases or DEFAULT_CASES
        out: list[BenchResult] = []
        total = len(cases) * len(models)
        done = 0
        for case in cases:
            br = BenchResult(case=case.request)
            for preset, key in models:
                if on_progress:
                    on_progress(done, total, case.request, preset)
                br.runs.append(self.run_one(preset, key, case, cost_fn))
                done += 1
            out.append(br)
        if on_progress:
            on_progress(total, total, "", "")
        return out

    @staticmethod
    def scoreboard(results: list[BenchResult]) -> list[dict]:
        """
        جمع‌بندی برای هر مدل — این جدولی است که تصمیم می‌گیرید.
        """
        agg: dict[str, dict] = {}
        for br in results:
            sig, _, _ = br.consensus()
            for r in br.runs:
                a = agg.setdefault(r.model, {
                    "model": r.model, "cases": 0, "ok": 0, "attempts": 0,
                    "seconds": 0.0, "tokens": 0, "cost": 0.0, "agree": 0})
                a["cases"] += 1
                a["seconds"] += r.seconds
                a["tokens"] += r.tokens_in + r.tokens_out
                a["cost"] += r.cost_usd
                if r.ok:
                    a["ok"] += 1
                    a["attempts"] += r.attempts
                    if sig and r.signature == sig:
                        a["agree"] += 1
        rows = []
        for a in agg.values():
            ok = a["ok"] or 1
            rows.append({
                "model": a["model"],
                "success": f"{a['ok']}/{a['cases']}",
                "success_pct": round(a["ok"] / a["cases"] * 100),
                "avg_attempts": round(a["attempts"] / ok, 1),
                "avg_seconds": round(a["seconds"] / a["cases"], 1),
                "tokens": a["tokens"],
                "cost_usd": round(a["cost"], 4),
                "agreement": f"{a['agree']}/{a['ok']}" if a["ok"] else "—",
            })
        rows.sort(key=lambda r: (-r["success_pct"], r["avg_seconds"]))
        return rows

    @staticmethod
    def render_fa(results: list[BenchResult]) -> str:
        lines = [br.summary_fa() for br in results]
        lines.append("")
        lines.append(f"{'مدل':<14}{'موفق':<9}{'تلاش':<7}{'زمان':<8}"
                     f"{'توکن':<11}{'هزینه':<10}{'هم‌نظری'}")
        lines.append("─" * 66)
        for r in ModelBench.scoreboard(results):
            lines.append(
                f"{r['model']:<14}{r['success']:<9}{r['avg_attempts']:<7}"
                f"{str(r['avg_seconds'])+'s':<8}{r['tokens']:<11,}"
                f"{(str(r['cost_usd'])+'$') if r['cost_usd'] else '—':<10}"
                f"{r['agreement']}")
        return "\n".join(lines)
