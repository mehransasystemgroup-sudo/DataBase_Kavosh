"""
تحلیل و اعتبارسنجی فایل RDL.

سه کار:
    ۱. پارس — خواندن ساختار یک RDL موجود
    ۲. اعتبارسنجی — یافتن خطاهایی که در Report Builder ظاهر می‌شوند
    ۳. استخراج قالب — یاد گرفتن قراردادهای شما از RDLهای واقعی‌تان

چرا استخراج قالب مهم است:
    اگر قالب را حدس بزنیم، خروجی در Report Builder شما باز نمی‌شود یا
    فونت فارسی و راست‌به‌چپ‌اش خراب می‌شود. بهتر است سیستم از
    فایل‌های واقعی شما یاد بگیرد: کدام فونت، چه اندازه‌ای،
    چه حاشیه‌ای، پارامترها چطور تعریف می‌شوند.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

try:
    from lxml import etree
    HAS_LXML = True
except ImportError:                                     # pragma: no cover
    HAS_LXML = False


# ─────────────── فضای نام ───────────────

RDL_2016 = "http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition"
RDL_2010 = "http://schemas.microsoft.com/sqlserver/reporting/2010/01/reportdefinition"
RDL_2008 = "http://schemas.microsoft.com/sqlserver/reporting/2008/01/reportdefinition"
RD_NS = "http://schemas.microsoft.com/SQLServer/reporting/reportdesigner"

KNOWN_RDL = {RDL_2016: "2016", RDL_2010: "2010", RDL_2008: "2008"}

PERSIAN_FONTS = {
    "b nazanin", "b titr", "b zar", "b lotus", "b mitra", "b yekan",
    "iranian sans", "iransans", "vazir", "vazirmatn", "sahel", "shabnam",
    "yekan", "tahoma", "iranyekan", "nazanin", "titr", "mitra", "lotus", "zar",
}


# ─────────────── ساختارها ───────────────

@dataclass
class RdlField:
    name: str
    data_field: str | None = None       # نام ستون در خروجی کوئری
    type_name: str | None = None


@dataclass
class RdlDataSet:
    name: str
    fields: list[RdlField] = field(default_factory=list)
    command: str = ""
    data_source: str = ""
    parameters: list[str] = field(default_factory=list)   # پارامترهای ارجاع‌شده

    def field_names(self) -> set[str]:
        return {f.name for f in self.fields}


@dataclass
class RdlParameter:
    name: str
    data_type: str = ""
    prompt: str = ""
    nullable: bool = False
    multi_value: bool = False
    has_default: bool = False


@dataclass
class RdlTablix:
    name: str
    dataset: str = ""
    used_fields: set[str] = field(default_factory=set)
    row_groups: list[str] = field(default_factory=list)
    column_groups: list[str] = field(default_factory=list)
    repeat_header: bool = False
    fixed_header: bool = False
    is_matrix: bool = False


@dataclass
class RdlDoc:
    path: str
    version: str = ""
    namespace: str = ""
    datasets: list[RdlDataSet] = field(default_factory=list)
    parameters: list[RdlParameter] = field(default_factory=list)
    tablixes: list[RdlTablix] = field(default_factory=list)
    fonts: dict[str, int] = field(default_factory=dict)
    directions: dict[str, int] = field(default_factory=dict)
    page: dict = field(default_factory=dict)
    subreports: list[str] = field(default_factory=list)
    textbox_count: int = 0

    def dataset(self, name: str) -> RdlDataSet | None:
        return next((d for d in self.datasets if d.name == name), None)


@dataclass
class RdlIssue:
    severity: str          # error | warning | info
    where: str
    message_fa: str
    hint: str = ""

    def __str__(self) -> str:
        icon = {"error": "✖", "warning": "⚠", "info": "ℹ"}[self.severity]
        s = f"{icon} [{self.where}] {self.message_fa}"
        return s + (f"\n     {self.hint}" if self.hint else "")


# ─────────────── پارسر ───────────────

FIELD_REF = re.compile(r"Fields!([A-Za-z_][A-Za-z0-9_]*)\.")
PARAM_REF = re.compile(r"Parameters!([A-Za-z_][A-Za-z0-9_]*)\.")
SQL_PARAM = re.compile(r"@([A-Za-z_][A-Za-z0-9_]*)")


class RdlParser:
    def __init__(self, path: str | Path):
        if not HAS_LXML:
            raise RuntimeError("نیاز به lxml:  pip install lxml")
        self.path = Path(path)
        self.tree = etree.parse(str(self.path))
        self.root = self.tree.getroot()
        self.ns = etree.QName(self.root).namespace

    # کمکی: یافتن با نام محلی، مستقل از فضای نام
    def _find(self, el, name: str):
        return el.findall(f".//{{{self.ns}}}{name}")

    def _child(self, el, name: str):
        return el.find(f"{{{self.ns}}}{name}")

    def _text(self, el, name: str, default: str = "") -> str:
        c = self._child(el, name)
        return (c.text or default) if c is not None else default

    def parse(self) -> RdlDoc:
        doc = RdlDoc(
            path=str(self.path),
            namespace=self.ns,
            version=KNOWN_RDL.get(self.ns, "ناشناخته"),
        )

        # ── DataSetها ──
        for ds in self._find(self.root, "DataSet"):
            d = RdlDataSet(name=ds.get("Name", ""))
            fields_el = self._child(ds, "Fields")
            if fields_el is not None:
                for f in fields_el:
                    if etree.QName(f).localname != "Field":
                        continue
                    d.fields.append(RdlField(
                        name=f.get("Name", ""),
                        data_field=self._text(f, "DataField") or None,
                        type_name=f.get(f"{{{RD_NS}}}TypeName"),
                    ))
            q = self._child(ds, "Query")
            if q is not None:
                d.command = self._text(q, "CommandText")
                d.data_source = self._text(q, "DataSourceName")
                qp = self._child(q, "QueryParameters")
                if qp is not None:
                    for p in qp:
                        nm = p.get("Name", "")
                        d.parameters.append(nm.lstrip("@"))
            doc.datasets.append(d)

        # ── پارامترها ──
        for p in self._find(self.root, "ReportParameter"):
            doc.parameters.append(RdlParameter(
                name=p.get("Name", ""),
                data_type=self._text(p, "DataType"),
                prompt=self._text(p, "Prompt"),
                nullable=self._text(p, "Nullable").lower() == "true",
                multi_value=self._text(p, "MultiValue").lower() == "true",
                has_default=self._child(p, "DefaultValue") is not None,
            ))

        # ── Tablixها ──
        for t in self._find(self.root, "Tablix"):
            tb = RdlTablix(name=t.get("Name", ""))
            tb.dataset = self._text(t, "DataSetName")

            raw = etree.tostring(t, encoding="unicode")
            tb.used_fields = set(FIELD_REF.findall(raw))

            rg = self._child(t, "TablixRowHierarchy")
            if rg is not None:
                for m in self._find(rg, "Group"):
                    nm = m.get("Name", "")
                    if nm:
                        tb.row_groups.append(nm)
            cg = self._child(t, "TablixColumnHierarchy")
            if cg is not None:
                for m in self._find(cg, "Group"):
                    nm = m.get("Name", "")
                    if nm:
                        tb.column_groups.append(nm)

            tb.is_matrix = len(tb.column_groups) > 0
            tb.repeat_header = "<RepeatOnNewPage>true</RepeatOnNewPage>" in raw
            tb.fixed_header = "<FixedData>true</FixedData>" in raw
            doc.tablixes.append(tb)

        # ── سبک: فونت و جهت ──
        for fn in self._find(self.root, "FontFamily"):
            if fn.text:
                doc.fonts[fn.text.strip()] = doc.fonts.get(fn.text.strip(), 0) + 1
        for dr in self._find(self.root, "Direction"):
            if dr.text:
                doc.directions[dr.text.strip()] = doc.directions.get(dr.text.strip(), 0) + 1

        # ── صفحه ──
        pg = self._child(self.root, "Page")
        if pg is not None:
            for k in ("PageWidth", "PageHeight", "LeftMargin", "RightMargin",
                      "TopMargin", "BottomMargin"):
                v = self._text(pg, k)
                if v:
                    doc.page[k] = v

        doc.subreports = [s.get("Name", "") for s in self._find(self.root, "Subreport")]
        doc.textbox_count = len(self._find(self.root, "Textbox"))
        return doc


# ─────────────── اعتبارسنج ───────────────

class RdlValidator:
    """
    خطاهایی که در Report Builder ظاهر می‌شوند — قبل از باز کردن فایل.

    kb اختیاری است: اگر داده شود، جدول‌ها و ستون‌های کوئری هم بررسی می‌شوند.
    """

    def __init__(self, kb=None, sql_validator=None):
        self.kb = kb
        self.sql_validator = sql_validator

    def validate(self, doc: RdlDoc) -> list[RdlIssue]:
        out: list[RdlIssue] = []
        self._check_version(doc, out)
        self._check_datasets(doc, out)
        self._check_tablix_fields(doc, out)
        self._check_parameters(doc, out)
        self._check_rtl(doc, out)
        self._check_pagination(doc, out)
        if self.sql_validator:
            self._check_sql(doc, out)
        return out

    # ---------- نسخه ----------

    def _check_version(self, doc, out) -> None:
        if doc.namespace not in KNOWN_RDL:
            out.append(RdlIssue(
                "error", "Report",
                f"فضای نام ناشناخته: {doc.namespace}",
                "Report Builder 2016 معمولاً فضای نام 2016 یا 2010 را می‌پذیرد."))
        elif doc.version == "2008":
            out.append(RdlIssue(
                "warning", "Report",
                "فضای نام نسخهٔ ۲۰۰۸ است.",
                "در Report Builder 2016 باز می‌شود ولی برخی قابلیت‌ها در دسترس نیست."))

    # ---------- DataSet ----------

    def _check_datasets(self, doc, out) -> None:
        if not doc.datasets:
            out.append(RdlIssue("error", "DataSets", "هیچ DataSet ای تعریف نشده."))
            return

        for d in doc.datasets:
            if not d.fields:
                out.append(RdlIssue(
                    "error", f"DataSet:{d.name}",
                    "هیچ Field ای تعریف نشده.",
                    "بدون Field، Tablix نمی‌تواند به داده اشاره کند."))

            # نام تکراری
            seen, dup = set(), set()
            for f in d.fields:
                if f.name in seen:
                    dup.add(f.name)
                seen.add(f.name)
            if dup:
                out.append(RdlIssue(
                    "error", f"DataSet:{d.name}",
                    f"نام Field تکراری: {', '.join(sorted(dup))}"))

            if not d.command.strip():
                out.append(RdlIssue(
                    "warning", f"DataSet:{d.name}", "CommandText خالی است."))
                continue

            # ستون‌های خروجی کوئری در برابر Fieldها
            declared = {f.data_field or f.name for f in d.fields}
            aliases = self._query_output_aliases(d.command)
            if aliases:
                missing = declared - aliases
                extra = aliases - declared
                if missing:
                    out.append(RdlIssue(
                        "error", f"DataSet:{d.name}",
                        f"این Fieldها در خروجی کوئری نیستند: "
                        f"{', '.join(sorted(missing)[:8])}",
                        "در Report Builder خطای «Field not found» می‌دهد."))
                if extra:
                    out.append(RdlIssue(
                        "info", f"DataSet:{d.name}",
                        f"کوئری این ستون‌ها را برمی‌گرداند ولی Field ندارند: "
                        f"{', '.join(sorted(extra)[:8])}"))

    @staticmethod
    def _query_output_aliases(sql: str) -> set[str]:
        """
        استخراج نام ستون‌های خروجی از SELECT.

        محافظه‌کارانه: اگر مطمئن نبود، مجموعهٔ خالی برمی‌گرداند تا
        هشدار کاذب ندهد. SELECT * هم مجموعهٔ خالی می‌دهد.
        """
        s = re.sub(r"--[^\n]*", " ", sql)
        s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S)

        m = re.search(r"\bSELECT\b(.*?)\bFROM\b", s, re.S | re.I)
        if not m:
            return set()
        body = m.group(1)
        if "*" in body:
            return set()

        # تقسیم روی کاماهای سطح صفر
        parts, depth, cur = [], 0, []
        for ch in body:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                parts.append("".join(cur))
                cur = []
            else:
                cur.append(ch)
        parts.append("".join(cur))

        names = set()
        for p in parts:
            p = p.strip().rstrip(";")
            if not p:
                continue
            a = re.search(r"\bAS\s+\[?([A-Za-z_][A-Za-z0-9_]*)\]?\s*$", p, re.I)
            if a:
                names.add(a.group(1))
                continue
            b = re.search(r"\[([^\]]+)\]\s*$", p)
            if b and "(" not in p:
                names.add(b.group(1))
                continue
            c = re.search(r"\.([A-Za-z_][A-Za-z0-9_]*)\s*$", p)
            if c and "(" not in p:
                names.add(c.group(1))
                continue
            d = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*)", p)
            if d:
                names.add(d.group(1))
        return names

    # ---------- Tablix ----------

    def _check_tablix_fields(self, doc, out) -> None:
        """
        شایع‌ترین و سخت‌یاب‌ترین باگ:
        Tablix به Field ای اشاره می‌کند که در DataSet نیست.
        """
        for t in doc.tablixes:
            if not t.dataset:
                out.append(RdlIssue(
                    "error", f"Tablix:{t.name}", "DataSetName تعیین نشده."))
                continue
            ds = doc.dataset(t.dataset)
            if ds is None:
                out.append(RdlIssue(
                    "error", f"Tablix:{t.name}",
                    f"DataSet «{t.dataset}» وجود ندارد.",
                    f"موجود: {', '.join(d.name for d in doc.datasets)}"))
                continue
            missing = t.used_fields - ds.field_names()
            if missing:
                out.append(RdlIssue(
                    "error", f"Tablix:{t.name}",
                    f"به Fieldهای ناموجود اشاره می‌کند: {', '.join(sorted(missing))}",
                    f"Fieldهای موجود در {ds.name}: "
                    f"{', '.join(sorted(ds.field_names())[:12])}"))

    # ---------- پارامتر ----------

    def _check_parameters(self, doc, out) -> None:
        declared = {p.name for p in doc.parameters}

        used_in_sql: set[str] = set()
        for d in doc.datasets:
            used_in_sql |= set(d.parameters)
            used_in_sql |= set(SQL_PARAM.findall(d.command))

        raw = Path(doc.path).read_text(encoding="utf-8", errors="replace")
        used_in_body = set(PARAM_REF.findall(raw))

        for name in sorted((used_in_sql | used_in_body) - declared):
            out.append(RdlIssue(
                "error", "Parameters",
                f"پارامتر «{name}» استفاده شده ولی ReportParameter ندارد.",
                "Report Builder موقع باز کردن خطا می‌دهد."))

        for name in sorted(declared - used_in_sql - used_in_body):
            out.append(RdlIssue(
                "info", "Parameters",
                f"پارامتر «{name}» تعریف شده ولی جایی استفاده نشده."))

        for p in doc.parameters:
            if not p.prompt:
                out.append(RdlIssue(
                    "warning", f"Parameter:{p.name}",
                    "Prompt ندارد — کاربر برچسب فارسی نمی‌بیند."))
            if not p.has_default and not p.nullable:
                out.append(RdlIssue(
                    "info", f"Parameter:{p.name}",
                    "مقدار پیش‌فرض ندارد — گزارش تا ورود مقدار اجرا نمی‌شود."))

    # ---------- راست‌به‌چپ ----------

    def _check_rtl(self, doc, out) -> None:
        rtl = doc.directions.get("RTL", 0)
        ltr = doc.directions.get("LTR", 0)

        if rtl == 0 and doc.textbox_count > 0:
            out.append(RdlIssue(
                "warning", "Style",
                "هیچ Direction=RTL در گزارش نیست.",
                "برای گزارش فارسی، Direction باید RTL باشد وگرنه "
                "ترتیب ستون‌ها و متن برعکس می‌شود."))
        elif ltr > rtl and rtl > 0:
            out.append(RdlIssue(
                "warning", "Style",
                f"{ltr} عنصر LTR در برابر {rtl} عنصر RTL — احتمالاً ناهماهنگ است."))

        if doc.fonts:
            non_fa = {f: n for f, n in doc.fonts.items()
                      if f.strip().lower() not in PERSIAN_FONTS}
            if non_fa:
                out.append(RdlIssue(
                    "warning", "Style",
                    f"فونت غیرفارسی: {', '.join(list(non_fa)[:5])}",
                    "در خروجی PDF ممکن است حروف فارسی جدا یا مربع شوند."))

    # ---------- صفحه‌بندی ----------

    def _check_pagination(self, doc, out) -> None:
        for t in doc.tablixes:
            if not t.repeat_header and t.row_groups:
                # فقط برای جدول‌های گروه‌بندی‌شده مهم است؛ گزارش‌های تک‌صفحه‌ای
                # (فیش، رسید) عمداً از آن استفاده نمی‌کنند.
                out.append(RdlIssue(
                    "info", f"Tablix:{t.name}",
                    "سرستون در صفحهٔ بعد تکرار نمی‌شود.",
                    "اگر گزارش چندصفحه‌ای است، RepeatOnNewPage=true بگذارید."))
            if t.is_matrix and not t.column_groups:
                out.append(RdlIssue(
                    "info", f"Tablix:{t.name}", "ساختار Matrix ناقص به‌نظر می‌رسد."))

    # ---------- SQL ----------

    def _check_sql(self, doc, out) -> None:
        for d in doc.datasets:
            if not d.command.strip():
                continue
            res = self.sql_validator.validate(d.command)
            self.sql_validator.check_fiscal_year(d.command, res)
            for f in res.findings:
                out.append(RdlIssue(
                    f.severity, f"DataSet:{d.name}", f.message, f.hint))


# ─────────────── گزارش ───────────────

def render_report(doc: RdlDoc, issues: list[RdlIssue]) -> str:
    errs = [i for i in issues if i.severity == "error"]
    warns = [i for i in issues if i.severity == "warning"]
    infos = [i for i in issues if i.severity == "info"]

    lines = [
        f"# {Path(doc.path).name}",
        f"نسخهٔ RDL: {doc.version}   ·   {doc.textbox_count} کادر متن",
        "",
        f"DataSet: {len(doc.datasets)}   Tablix: {len(doc.tablixes)}   "
        f"پارامتر: {len(doc.parameters)}"
        + (f"   Subreport: {len(doc.subreports)}" if doc.subreports else ""),
    ]

    for d in doc.datasets:
        lines.append(f"  • {d.name}: {len(d.fields)} فیلد"
                     + (f" · پارامتر {', '.join(d.parameters)}" if d.parameters else ""))
    for t in doc.tablixes:
        kind = "Matrix" if t.is_matrix else "Tablix"
        lines.append(f"  • {kind} {t.name} → {t.dataset} "
                     f"({len(t.used_fields)} فیلد استفاده‌شده"
                     + (f", {len(t.row_groups)} گروه" if t.row_groups else "") + ")")

    if doc.fonts:
        top = sorted(doc.fonts.items(), key=lambda x: -x[1])[:4]
        lines.append("فونت‌ها: " + " · ".join(f"{f} ({n})" for f, n in top))
    if doc.directions:
        lines.append("جهت: " + " · ".join(f"{k}={v}" for k, v in doc.directions.items()))

    lines.append("")
    if not issues:
        lines.append("✔ هیچ مشکلی پیدا نشد.")
    else:
        lines.append(f"✖ {len(errs)} خطا   ⚠ {len(warns)} هشدار   ℹ {len(infos)} نکته")
        lines.append("")
        for group in (errs, warns, infos):
            for i in group:
                lines.append(str(i))
    return "\n".join(lines)
