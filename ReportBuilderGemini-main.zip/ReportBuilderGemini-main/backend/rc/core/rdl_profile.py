"""
پروفایل سازمانی — استخراج قرارداد از RDLهای واقعی.

تفاوت با ReportStyle:
    ReportStyle فقط ظاهر است — فونت، رنگ، حاشیه.
    Profile قراردادهای ساختاری را هم می‌گیرد:
        • پارامترهای سیستمی که ERP به هر گزارش می‌فرستد
        • مسیر واقعی DataSource
        • قالب عدد و حاشیه‌ای که در سازمان استفاده می‌شود
        • DataSetهای کمکی استاندارد

چرا لازم بود:
    تحلیل چهار گزارش واقعی نشان داد هفت پارامتر سیستمی در همهٔ آن‌ها
    تکرار شده‌اند. گزارشی که این‌ها را نداشته باشد، در محیط ERP
    قابل اجرا نیست — حتی اگر XMLاش کاملاً معتبر باشد.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field, asdict
from pathlib import Path

from .rdl import RdlParser, PERSIAN_FONTS


# پارامترهایی که ERP خودش پر می‌کند — نباید از کاربر پرسیده شوند
SYSTEM_PARAM_HINT = re.compile(r"^Sys_", re.I)


@dataclass
class SystemParameter:
    name: str
    data_type: str = "String"
    prompt: str = ""
    seen_in: int = 0

    def is_system(self) -> bool:
        return bool(SYSTEM_PARAM_HINT.match(self.name))


@dataclass
class HelperDataSet:
    """DataSet کمکی که در چند گزارش تکرار شده — قرارداد سازمان."""
    name: str
    command: str
    parameters: list[str] = field(default_factory=list)
    seen_in: int = 0


@dataclass
class OrgProfile:
    """
    قرارداد سازمانی استخراج‌شده از گزارش‌های واقعی.

    در kb/report-profile.json ذخیره می‌شود و در تولید هر RDL اعمال می‌گردد.
    """
    # منبع داده
    data_source_name: str = "ReportDataSource"
    data_source_ref: str = "/DataSources/SgDataSource"

    # پارامترهای سیستمی — به هر گزارش اضافه می‌شوند
    system_parameters: list[dict] = field(default_factory=list)

    # DataSetهای کمکی استاندارد
    helper_datasets: list[dict] = field(default_factory=list)

    # قالب‌ها
    number_format: str = "#,0;(#,0)"
    integer_format: str = "n0"
    border_style: str = "Solid"
    border_color: str = "LightGrey"

    # اندازهٔ صفحه بر اساس کاربرد
    page_sizes: dict = field(default_factory=lambda: {
        "landscape_a4": {"w": "29.7cm", "h": "21cm"},
        "portrait_a4": {"w": "21cm", "h": "29.7cm"},
        "landscape_a5": {"w": "21cm", "h": "14.8cm"},
    })
    default_page: str = "landscape_a4"

    # حاشیه
    margin: str = "0.2cm"

    # آمار
    learned_from: list[str] = field(default_factory=list)
    learned_at: str = ""

    # ---------- استخراج ----------

    @classmethod
    def learn_from(cls, *paths: str | Path) -> "OrgProfile":
        from datetime import datetime

        p = cls()
        params: dict[str, SystemParameter] = {}
        datasets: dict[str, HelperDataSet] = {}
        ds_names, ds_refs = Counter(), Counter()
        formats, border_c, border_s = Counter(), Counter(), Counter()
        margins, pages = Counter(), Counter()
        n_files = 0

        for path in paths:
            try:
                parser = RdlParser(path)
            except Exception:
                continue
            n_files += 1
            p.learned_from.append(Path(path).name)
            root, ns = parser.root, parser.ns

            # منبع داده
            for ds in root.iter(f"{{{ns}}}DataSource"):
                if ds.get("Name"):
                    ds_names[ds.get("Name")] += 1
                ref = ds.find(f"{{{ns}}}DataSourceReference")
                if ref is not None and ref.text:
                    ds_refs[ref.text.strip()] += 1

            # پارامترها
            for rp in root.iter(f"{{{ns}}}ReportParameter"):
                name = rp.get("Name", "")
                if not name:
                    continue
                dt = rp.find(f"{{{ns}}}DataType")
                pr = rp.find(f"{{{ns}}}Prompt")
                if name not in params:
                    params[name] = SystemParameter(
                        name=name,
                        data_type=(dt.text or "String").strip() if dt is not None else "String",
                        prompt=(pr.text or "").strip() if pr is not None else "")
                params[name].seen_in += 1

            # DataSetهای کمکی
            for ds in root.iter(f"{{{ns}}}DataSet"):
                nm = ds.get("Name", "")
                q = ds.find(f"{{{ns}}}Query")
                if not nm or q is None:
                    continue
                ct = q.find(f"{{{ns}}}CommandText")
                cmd = (ct.text or "").strip() if ct is not None else ""
                # فقط کوئری‌های کوتاه و تکرارشونده قرارداد محسوب می‌شوند
                if not cmd or len(cmd) > 300:
                    continue
                qps = [x.get("Name", "").lstrip("@")
                       for x in q.iter(f"{{{ns}}}QueryParameter")]
                key = nm
                if key not in datasets:
                    datasets[key] = HelperDataSet(nm, cmd, qps)
                datasets[key].seen_in += 1

            # قالب و حاشیه
            for e in root.iter(f"{{{ns}}}Format"):
                if e.text and e.text.strip():
                    formats[e.text.strip()] += 1
            for b in root.iter(f"{{{ns}}}Border"):
                s = b.find(f"{{{ns}}}Style")
                c = b.find(f"{{{ns}}}Color")
                if s is not None and s.text and s.text.strip() != "None":
                    border_s[s.text.strip()] += 1
                if c is not None and c.text:
                    border_c[c.text.strip()] += 1

            # صفحه و حاشیه
            pg = root.find(f".//{{{ns}}}Page")
            if pg is not None:
                w = pg.find(f"{{{ns}}}PageWidth")
                h = pg.find(f"{{{ns}}}PageHeight")
                if w is not None and h is not None and w.text and h.text:
                    pages[(w.text.strip(), h.text.strip())] += 1
                for k in ("LeftMargin", "RightMargin", "TopMargin", "BottomMargin"):
                    m = pg.find(f"{{{ns}}}{k}")
                    if m is not None and m.text:
                        margins[m.text.strip()] += 1

        # ── تصمیم‌گیری ──
        if ds_names:
            p.data_source_name = ds_names.most_common(1)[0][0]
        if ds_refs:
            p.data_source_ref = ds_refs.most_common(1)[0][0]

        # پارامتر سیستمی: یا با Sys_ شروع شود، یا در همهٔ فایل‌ها باشد
        threshold = max(2, n_files)
        p.system_parameters = [
            asdict(sp) for sp in sorted(params.values(), key=lambda x: -x.seen_in)
            if sp.is_system() or sp.seen_in >= threshold
        ]

        # DataSet کمکی: در بیش از یک گزارش تکرار شده
        p.helper_datasets = [
            asdict(d) for d in sorted(datasets.values(), key=lambda x: -x.seen_in)
            if d.seen_in >= 2
        ]

        if formats:
            # پرتکرارترین قالب با کاما = قالب عدد
            with_comma = [(f, n) for f, n in formats.items() if "," in f or "#" in f]
            if with_comma:
                p.number_format = max(with_comma, key=lambda x: x[1])[0]
            plain = [(f, n) for f, n in formats.items() if f.lower().startswith("n")]
            if plain:
                p.integer_format = max(plain, key=lambda x: x[1])[0]

        if border_s:
            p.border_style = border_s.most_common(1)[0][0]
        if border_c:
            p.border_color = border_c.most_common(1)[0][0]
        if margins:
            p.margin = margins.most_common(1)[0][0]

        if pages:
            (w, h), _ = pages.most_common(1)[0]
            for key, size in p.page_sizes.items():
                if size["w"] == w and size["h"] == h:
                    p.default_page = key
                    break
            else:
                p.page_sizes["custom"] = {"w": w, "h": h}
                p.default_page = "custom"

        p.learned_at = datetime.now().isoformat(timespec="seconds")
        return p

    # ---------- استفاده ----------

    def system_param_names(self) -> list[str]:
        return [d["name"] for d in self.system_parameters]

    def report_params_xml(self, ns_prefix: str = "") -> str:
        """XML پارامترهای سیستمی — برای درج در هر گزارش تولیدی."""
        out = []
        for d in self.system_parameters:
            hidden = "<Hidden>true</Hidden>" if d["name"].startswith("Sys_") else ""
            out.append(
                f'    <ReportParameter Name="{d["name"]}">\n'
                f'      <DataType>{d["data_type"]}</DataType>\n'
                f'      <Prompt>{d["prompt"] or d["name"]}</Prompt>\n'
                f'      <Nullable>true</Nullable>\n'
                f'      {hidden}\n'
                f'      <AllowBlank>true</AllowBlank>\n'
                f'    </ReportParameter>')
        return "\n".join(out)

    def page_size(self, key: str = "") -> tuple[str, str]:
        s = self.page_sizes.get(key or self.default_page,
                                self.page_sizes["landscape_a4"])
        return s["w"], s["h"]

    def summary_fa(self) -> str:
        lines = [
            f"منبع داده     {self.data_source_name} → {self.data_source_ref}",
            f"پارامتر سیستمی {len(self.system_parameters)} مورد",
        ]
        if self.system_parameters:
            names = [d["name"] for d in self.system_parameters[:8]]
            lines.append(f"              {'، '.join(names)}")
        if self.helper_datasets:
            lines.append(f"DataSet کمکی   {len(self.helper_datasets)} مورد: "
                         + "، ".join(d["name"] for d in self.helper_datasets))
        w, h = self.page_size()
        lines += [
            f"قالب عدد      {self.number_format}   صحیح: {self.integer_format}",
            f"حاشیه سلول    {self.border_style} · {self.border_color}",
            f"صفحه          {w} × {h}  ({self.default_page})  حاشیه {self.margin}",
            f"از فایل‌های    {'، '.join(self.learned_from)}",
        ]
        return "\n".join(lines)

    # ---------- ذخیره ----------

    def save(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "OrgProfile":
        p = Path(path)
        if not p.exists():
            return cls()
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            return cls(**{k: v for k, v in d.items()
                          if k in cls.__dataclass_fields__})
        except Exception:
            return cls()
