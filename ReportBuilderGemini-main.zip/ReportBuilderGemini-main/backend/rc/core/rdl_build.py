"""
تولید فایل RDL — سه شکل: جدول ساده، گروه‌بندی چندسطحی، ماتریس.

اصل طراحی:
    بدنه و سلسله‌مراتب هر دو از یک «مدل ردیف» ساخته می‌شوند.
    در RDL این دو باید دقیقاً بخوانند — اگر بدنه ۵ ردیف داشته باشد
    و سلسله‌مراتب ۴ عضو، فایل در Report Builder باز نمی‌شود.

    با ساختن هر دو از یک منبع، این خطا از نظر ساختاری ممکن نیست.

مدل هرگز XML تولید نمی‌کند — RDL فرمت حساسی است و یک تگ اشتباه
فایل را غیرقابل باز می‌کند.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from xml.sax.saxutils import escape

from .plan import QueryPlan
from .rdl import RDL_2016, RD_NS, RdlParser, PERSIAN_FONTS
from .rdl_layout import (ReportLayout, PageBand, BodyRow, DynamicColumnSet,
                          build_row_model, derive_layout)
from .rdl_profile import OrgProfile


# ═══════════════════ سبک ═══════════════════

@dataclass
class ReportStyle:
    """قراردادهای ظاهری — با learn_from از RDLهای واقعی استخراج می‌شود."""

    font_family: str = "B Nazanin"
    font_size_body: str = "8pt"
    font_size_header: str = "10pt"
    font_size_title: str = "14pt"
    font_size_page: str = "8pt"

    header_bg: str = "#e5e9e5"
    group_bg: str = "#F2F2F2"
    total_bg: str = "#D9D9D9"
    border_color: str = "LightGrey"

    direction: str = "RTL"
    text_align_default: str = "Center"

    page_width: str = "29.7cm"
    page_height: str = "21cm"
    margin_left: str = "0.2cm"
    margin_right: str = "0.2cm"
    margin_top: str = "0.2cm"
    margin_bottom: str = "0.2cm"

    row_height: str = "0.7cm"
    header_height: str = "0.8cm"
    default_col_width: str = "3cm"

    language: str = "fa-IR"
    data_source: str = "ReportDataSource"

    # ---------- یادگیری از فایل واقعی ----------

    @classmethod
    def learn_from(cls, *rdl_paths: str | Path) -> "ReportStyle":
        """رأی‌گیری از فایل‌های واقعی: پرتکرارترین برنده است."""
        from collections import Counter

        fonts, sizes, dirs = Counter(), Counter(), Counter()
        pages, aligns, colors, sources = Counter(), Counter(), Counter(), Counter()

        for p in rdl_paths:
            try:
                parser = RdlParser(p)
            except Exception:
                continue
            root, ns = parser.root, parser.ns
            for tag, bucket in (("FontFamily", fonts), ("FontSize", sizes),
                                ("Direction", dirs), ("TextAlign", aligns),
                                ("DataSourceName", sources)):
                for el in root.iter(f"{{{ns}}}{tag}"):
                    if el.text and el.text.strip():
                        bucket[el.text.strip()] += 1
            for el in root.iter(f"{{{ns}}}BackgroundColor"):
                if el.text and el.text.strip().startswith("#"):
                    colors[el.text.strip()] += 1
            pg = root.find(f"{{{ns}}}Page")
            if pg is not None:
                for k in ("PageWidth", "PageHeight", "LeftMargin", "RightMargin",
                          "TopMargin", "BottomMargin"):
                    c = pg.find(f"{{{ns}}}{k}")
                    if c is not None and c.text:
                        pages[(k, c.text.strip())] += 1

        s = cls()

        fa = [(f, n) for f, n in fonts.items() if f.lower() in PERSIAN_FONTS]
        if fa:
            s.font_family = max(fa, key=lambda x: x[1])[0]
        elif fonts:
            s.font_family = fonts.most_common(1)[0][0]

        if sizes:
            def pt(x):
                try:
                    return float(str(x).replace("pt", ""))
                except ValueError:
                    return 0.0
            s.font_size_body = sizes.most_common(1)[0][0]
            ordered = sorted(sizes, key=pt)
            if len(ordered) > 1:
                i = ordered.index(s.font_size_body)
                s.font_size_header = ordered[min(len(ordered) - 1, i + 1)]
                s.font_size_title = ordered[-1]
                s.font_size_page = ordered[0]

        if dirs:
            s.direction = dirs.most_common(1)[0][0]
        if aligns:
            s.text_align_default = aligns.most_common(1)[0][0]
        if sources:
            s.data_source = sources.most_common(1)[0][0]

        # رنگ‌ها: روشن‌ترین سرستون، تیره‌تر جمع
        if colors:
            def lum(h):
                h = h.lstrip("#")
                if len(h) != 6:
                    return 999
                try:
                    return int(h[0:2], 16) * .3 + int(h[2:4], 16) * .6 + int(h[4:6], 16) * .1
                except ValueError:
                    return 999
            picked = [c for c, _ in colors.most_common(8) if lum(c) < 250]
            if picked:
                s.header_bg = picked[0]
                if len(picked) > 1:
                    s.group_bg = picked[1]
                if len(picked) > 2:
                    s.total_bg = picked[2]

        best: dict[str, str] = {}
        for (k, v), n in pages.items():
            if k not in best or n > pages[(k, best[k])]:
                best[k] = v
        for k, attr in (("PageWidth", "page_width"), ("PageHeight", "page_height"),
                        ("LeftMargin", "margin_left"), ("RightMargin", "margin_right"),
                        ("TopMargin", "margin_top"), ("BottomMargin", "margin_bottom")):
            if k in best:
                setattr(s, attr, best[k])
        return s

    def save(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "ReportStyle":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


# ═══════════════════ نگاشت نوع ═══════════════════

_SQL_TO_RDL = {
    "int": "System.Int32", "bigint": "System.Int64", "smallint": "System.Int16",
    "tinyint": "System.Byte", "bit": "System.Boolean",
    "decimal": "System.Decimal", "numeric": "System.Decimal",
    "money": "System.Decimal", "float": "System.Double", "real": "System.Single",
    "datetime": "System.DateTime", "date": "System.DateTime",
    "uniqueidentifier": "System.Guid",
}
_PARAM_TO_RDL = {"int": "Integer", "decimal": "Float",
                 "date": "DateTime", "nvarchar": "String"}
_NUMERIC = {"int", "bigint", "smallint", "tinyint",
            "decimal", "numeric", "money", "float", "real"}


def _rdl_type(t: str | None) -> str:
    return _SQL_TO_RDL.get((t or "").split("(")[0].strip().lower(), "System.String")


def _is_num(t: str | None) -> bool:
    return (t or "").split("(")[0].strip().lower() in _NUMERIC


@dataclass
class RdlColumn:
    field_name: str
    header_fa: str
    sql_type: str | None = None
    width: str = "3cm"
    aggregate: str | None = None

    @property
    def is_numeric(self) -> bool:
        return _is_num(self.sql_type)


# ═══════════════════ مولد ═══════════════════

class RdlBuilder:
    def __init__(self, style: ReportStyle | None = None, kb=None,
                 profile: OrgProfile | None = None):
        self.st = style or ReportStyle()
        self.kb = kb
        # قرارداد سازمانی — از RDLهای واقعی استخراج شده
        self.pf = profile or OrgProfile()
        self._n = 0

    # ---------- کمکی ----------

    @staticmethod
    def _esc(t) -> str:
        return escape(str(t or ""))

    def _uid(self, prefix: str) -> str:
        self._n += 1
        return f"{prefix}{self._n}"

    def _tb(self, value: str, *, bold=False, bg="", size="",
            align="", fmt="", grow=True) -> str:
        st = self.st
        return f"""<Textbox Name="{self._uid('tb')}">
  <CanGrow>{'true' if grow else 'false'}</CanGrow>
  <KeepTogether>true</KeepTogether>
  <Paragraphs><Paragraph><TextRuns><TextRun>
    <Value>{value}</Value>
    <Style>
      <FontFamily>{st.font_family}</FontFamily>
      <FontSize>{size or st.font_size_body}</FontSize>
      {'<FontWeight>Bold</FontWeight>' if bold else ''}
      {f'<Format>{fmt}</Format>' if fmt else ''}
    </Style>
  </TextRun></TextRuns>
  <Style><TextAlign>{align or st.text_align_default}</TextAlign></Style>
  </Paragraph></Paragraphs>
  <Style>
    {f'<BackgroundColor>{bg}</BackgroundColor>' if bg else ''}
    <Border><Color>{st.border_color}</Color><Style>Solid</Style><Width>0.5pt</Width></Border>
    <PaddingLeft>2pt</PaddingLeft><PaddingRight>2pt</PaddingRight>
    <PaddingTop>2pt</PaddingTop><PaddingBottom>2pt</PaddingBottom>
    <Direction>{st.direction}</Direction>
    <VerticalAlign>Middle</VerticalAlign>
  </Style>
</Textbox>"""

    @staticmethod
    def _cell(inner: str) -> str:
        return f"            <TablixCell><CellContents>\n{inner}\n            </CellContents></TablixCell>"

    @staticmethod
    def _cm(v) -> float:
        try:
            return float(str(v).replace("cm", ""))
        except ValueError:
            return 3.0

    @property
    def _content_width(self) -> float:
        return (self._cm(self.st.page_width)
                - self._cm(self.st.margin_left) - self._cm(self.st.margin_right))

    # ---------- ستون‌ها از نقشه ----------

    def _columns(self, plan: QueryPlan) -> dict[str, RdlColumn]:
        out: dict[str, RdlColumn] = {}
        for c in plan.select:
            name = c.output_name()
            sql_type = None
            if self.kb:
                info = self.kb.get_table(c.table)
                if info:
                    col = next((x for x in info.columns if x["name"] == c.column), None)
                    if col:
                        sql_type = col["type"]
            if c.aggregate:
                sql_type = "decimal" if c.aggregate in ("SUM", "AVG") else "bigint"
            out[name] = RdlColumn(name, name, sql_type,
                                  self.st.default_col_width, c.aggregate)
        return out

    # ═══════ نقطهٔ ورود ═══════

    def from_plan(self, plan: QueryPlan, sql: str, *,
                  layout: ReportLayout | None = None,
                  title_fa: str = "") -> str:
        lay = layout or derive_layout(plan, self.kb)
        cols = self._columns(plan)
        params = [(p.name, p.type, p.title_fa) for p in plan.parameters]

        if lay.kind == "matrix":
            tablix = self._matrix(lay, cols)
        elif lay.kind == "dynamic_columns":
            tablix = self._dynamic_table(lay, cols)
        else:
            tablix = self._table(lay, cols)

        return self._document(
            tablix=tablix, cols=cols, sql=sql, params=params,
            title_fa=title_fa or plan.intent_fa, lay=lay)

    # ═══════ جدول ساده و گروه‌بندی‌شده ═══════

    def _table(self, lay: ReportLayout, cols: dict[str, RdlColumn]) -> str:
        st = self.st
        rows = build_row_model(lay)

        order = [g.field_name for g in lay.row_groups] + list(lay.detail_fields)
        order = [f for f in order if f in cols]
        if not order:
            order = list(cols)

        tcols = "\n".join(
            f"                <TablixColumn><Width>{cols[f].width}</Width></TablixColumn>"
            for f in order)

        body = []
        for r in rows:
            cells = [self._cell(self._row_cell(r, f, i, order, lay, cols))
                     for i, f in enumerate(order)]
            h = st.header_height if r.kind == "header" else st.row_height
            body.append(f"""        <TablixRow>
          <Height>{h}</Height>
          <TablixCells>
{chr(10).join(cells)}
          </TablixCells>
        </TablixRow>""")

        width = min(sum(self._cm(cols[f].width) for f in order), self._content_width)

        return f"""          <Tablix Name="MainTablix">
            <TablixBody>
              <TablixColumns>
{tcols}
              </TablixColumns>
              <TablixRows>
{chr(10).join(body)}
              </TablixRows>
            </TablixBody>
            <TablixColumnHierarchy>
              <TablixMembers>
{chr(10).join('                <TablixMember />' for _ in order)}
              </TablixMembers>
            </TablixColumnHierarchy>
{self._row_hierarchy(lay)}
            <DataSetName>DataSet1</DataSetName>
            <Top>1.3cm</Top>
            <Left>0cm</Left>
            <Height>{st.header_height}</Height>
            <Width>{width:.2f}cm</Width>
            <Style>
              <Direction>{st.direction}</Direction>
              <Border><Style>None</Style></Border>
            </Style>
          </Tablix>"""

    def _row_cell(self, r: BodyRow, fname: str, idx: int, order: list[str],
                  lay: ReportLayout, cols: dict[str, RdlColumn]) -> str:
        """محتوای یک سلول بر اساس نوع ردیف."""
        st = self.st
        c = cols[fname]
        num = c.is_numeric
        align = "Center" if num else ""
        fmt = self.pf.number_format if num else ""

        if r.kind == "header":
            return self._tb(self._esc(c.header_fa), bold=True, bg=st.header_bg,
                            size=st.font_size_header, align="Center")

        if r.kind == "group_header":
            g = lay.row_groups[r.level]
            if fname == g.field_name:
                return self._tb(f"=Fields!{fname}.Value", bold=True, bg=st.group_bg)
            return self._tb("", bg=st.group_bg)

        if r.kind == "detail":
            return self._tb(f"=Fields!{fname}.Value", align=align, fmt=fmt)

        if r.kind == "group_total":
            g = lay.row_groups[r.level]
            if num:
                return self._tb(f"=Sum(Fields!{fname}.Value)", bold=True,
                                bg=st.total_bg, align="Center", fmt=fmt)
            label_at = min(r.level + 1, len(order) - 1)
            if idx == label_at:
                return self._tb(f"جمع {self._esc(g.header_fa or g.field_name)}",
                                bold=True, bg=st.total_bg)
            return self._tb("", bg=st.total_bg)

        # grand_total
        if num:
            return self._tb(f"=Sum(Fields!{fname}.Value)", bold=True,
                            bg=st.total_bg, align="Center", fmt=fmt)
        return self._tb("جمع کل" if idx == 0 else "", bold=idx == 0, bg=st.total_bg)

    def _row_hierarchy(self, lay: ReportLayout) -> str:
        """
        سلسله‌مراتب سطری — هم‌ترتیب دقیق با ردیف‌های بدنه.

        برای دو سطح گروه:
            TablixMember                  ← سرستون
            TablixMember Group=G0
              TablixMember                ← عنوان G0
              TablixMember Group=G1
                TablixMember              ← عنوان G1
                TablixMember Group=Details
                TablixMember              ← جمع G1
              TablixMember                ← جمع G0
            TablixMember                  ← جمع کل
        """
        ind = "                "

        def nest(level: int) -> str:
            if level >= len(lay.row_groups):
                if lay.show_details or not lay.row_groups:
                    return (f'{ind}<TablixMember>\n'
                            f'{ind}  <Group Name="DetailsGroup" />\n'
                            f'{ind}  <TablixMembers><TablixMember /></TablixMembers>\n'
                            f'{ind}</TablixMember>')
                return ""

            g = lay.row_groups[level]
            parts = []
            if g.show_header_row:
                parts.append(f'{ind}  <TablixMember>'
                             f'<KeepWithGroup>After</KeepWithGroup></TablixMember>')
            inner = nest(level + 1)
            if inner:
                parts.append(inner)
            if g.show_total_row:
                parts.append(f'{ind}  <TablixMember>'
                             f'<KeepWithGroup>Before</KeepWithGroup></TablixMember>')

            grp = (f'<GroupExpressions><GroupExpression>'
                   f'=Fields!{g.field_name}.Value'
                   f'</GroupExpression></GroupExpressions>')
            if g.page_break:
                grp += '<PageBreak><BreakLocation>Between</BreakLocation></PageBreak>'

            return (f'{ind}<TablixMember>\n'
                    f'{ind}  <Group Name="Group_{g.field_name}">{grp}</Group>\n'
                    f'{ind}  <SortExpressions><SortExpression>'
                    f'<Value>=Fields!{g.field_name}.Value</Value>'
                    f'</SortExpression></SortExpressions>\n'
                    f'{ind}  <TablixMembers>\n{chr(10).join(parts)}\n'
                    f'{ind}  </TablixMembers>\n'
                    f'{ind}</TablixMember>')

        members = [f'{ind}<TablixMember>\n'
                   f'{ind}  <KeepWithGroup>After</KeepWithGroup>\n'
                   f'{ind}  <RepeatOnNewPage>true</RepeatOnNewPage>\n'
                   f'{ind}  <FixedData>true</FixedData>\n'
                   f'{ind}</TablixMember>']
        inner = nest(0)
        if inner:
            members.append(inner)
        if lay.grand_total:
            members.append(f'{ind}<TablixMember>'
                           f'<KeepWithGroup>Before</KeepWithGroup></TablixMember>')

        return (f"            <TablixRowHierarchy>\n"
                f"              <TablixMembers>\n{chr(10).join(members)}\n"
                f"              </TablixMembers>\n"
                f"            </TablixRowHierarchy>")

    # ═══════ ستون‌های پویا (الگوی AttendanceColumnsCount) ═══════

    def _dyn_cell(self, r: BodyRow, fname: str, dc: DynamicColumnSet,
                  cols: dict[str, RdlColumn], is_first: bool) -> str:
        """
        محتوای یک سلول در جدول ستون‌پویا.

        ستون‌های ثابت (leading/trailing) از cols می‌آیند؛ ستون‌های پویا
        (Day1..DayN) در cols نیستند — همیشه با Fields! و قالب مشترک
        ساخته می‌شوند.
        """
        st = self.st
        dynamic = fname not in cols

        if r.kind == "header":
            if dynamic:
                n = fname[len(dc.field_prefix):]
                if dc.header_field_prefix:
                    return self._tb(f"=Fields!{dc.header_field_name(n)}.Value",
                                    bold=True, bg=st.header_bg, size=st.font_size_header)
                return self._tb(self._esc(f"{dc.header_prefix}{n}"), bold=True,
                                bg=st.header_bg, size=st.font_size_header)
            return self._tb(self._esc(cols[fname].header_fa), bold=True,
                            bg=st.header_bg, size=st.font_size_header)

        if r.kind == "grand_total":
            fmt = dc.value_format or self.pf.number_format
            if dynamic:
                return self._tb(f"=Sum(Fields!{fname}.Value)", bold=True,
                                bg=st.total_bg, align="Center", fmt=fmt)
            c = cols[fname]
            if c.is_numeric:
                return self._tb(f"=Sum(Fields!{fname}.Value)", bold=True,
                                bg=st.total_bg, align="Center", fmt=self.pf.number_format)
            return self._tb("جمع کل" if is_first else "", bold=is_first, bg=st.total_bg)

        # detail
        if dynamic:
            fmt = dc.value_format or self.pf.number_format
            return self._tb(f"=Fields!{fname}.Value", align="Center", fmt=fmt)
        c = cols[fname]
        num = c.is_numeric
        return self._tb(f"=Fields!{fname}.Value",
                        align="Center" if num else "",
                        fmt=self.pf.number_format if num else "")

    def _dynamic_table(self, lay: ReportLayout, cols: dict[str, RdlColumn]) -> str:
        """
        جدول با تعداد ستون متغیر — ستون‌های اضافی با Visibility مخفی
        می‌شوند، نه حذف؛ چون TablixColumns/Hierarchy/Cell باید همیشه
        هم‌تعداد بمانند (بند طلایی RDL).
        """
        st = self.st
        dc = lay.dynamic_columns
        leading = [f for f in dc.leading_fields if f in cols]
        trailing = [f for f in dc.trailing_fields if f in cols]
        dyn_names = [dc.field_name(i) for i in range(1, dc.max_columns + 1)]
        order = leading + dyn_names + trailing

        widths = ([cols[f].width for f in leading]
                  + [dc.column_width] * dc.max_columns
                  + [cols[f].width for f in trailing])
        tcols = "\n".join(
            f"                <TablixColumn><Width>{w}</Width></TablixColumn>"
            for w in widths)

        rows = build_row_model(lay)
        body = []
        for r in rows:
            cells = [self._cell(self._dyn_cell(r, f, dc, cols, i == 0))
                     for i, f in enumerate(order)]
            h = st.header_height if r.kind == "header" else st.row_height
            body.append(f"""        <TablixRow>
          <Height>{h}</Height>
          <TablixCells>
{chr(10).join(cells)}
          </TablixCells>
        </TablixRow>""")

        members = []
        for f in order:
            if f in dyn_names:
                n = f[len(dc.field_prefix):]
                hidden = self._esc(
                    f"=IIF(Parameters!{dc.count_parameter}.Value >= {n}, false, true)")
                members.append(
                    f'                <TablixMember>\n'
                    f'                  <Visibility><Hidden>{hidden}</Hidden></Visibility>\n'
                    f'                </TablixMember>')
            else:
                members.append("                <TablixMember />")

        width = min(sum(self._cm(w) for w in widths), self._content_width)

        return f"""          <Tablix Name="DynamicColumnsTablix">
            <TablixBody>
              <TablixColumns>
{tcols}
              </TablixColumns>
              <TablixRows>
{chr(10).join(body)}
              </TablixRows>
            </TablixBody>
            <TablixColumnHierarchy>
              <TablixMembers>
{chr(10).join(members)}
              </TablixMembers>
            </TablixColumnHierarchy>
{self._row_hierarchy(lay)}
            <DataSetName>DataSet1</DataSetName>
            <Top>1.3cm</Top>
            <Left>0cm</Left>
            <Height>{st.header_height}</Height>
            <Width>{width:.2f}cm</Width>
            <Style>
              <Direction>{st.direction}</Direction>
              <Border><Style>None</Style></Border>
            </Style>
          </Tablix>"""

    # ═══════ ماتریس ═══════

    def _matrix(self, lay: ReportLayout, cols: dict[str, RdlColumn]) -> str:
        """
        ماتریس (پیوت). ساختار بدنه ثابت ۲ ستون است — RDL خودش تکرار می‌کند:
            [گوشه]      [عنوان ستون]
            [عنوان سطر] [مقدار]
        """
        st = self.st
        rg = lay.row_groups[0]
        cg = lay.column_group
        val = lay.values[0]
        vc = cols.get(val.field_name)
        fmt = val.format or (self.pf.number_format if vc and vc.is_numeric else "")
        agg = val.aggregate or "SUM"

        rows = [
            (st.header_height, [
                self._tb(self._esc(rg.header_fa or rg.field_name), bold=True,
                         bg=st.header_bg, size=st.font_size_header, align="Center"),
                self._tb(f"=Fields!{cg.field_name}.Value", bold=True,
                         bg=st.header_bg, size=st.font_size_header, align="Center")]),
            (st.row_height, [
                self._tb(f"=Fields!{rg.field_name}.Value", bold=True, bg=st.group_bg),
                self._tb(f"={agg}(Fields!{val.field_name}.Value)",
                         align="Center", fmt=fmt)]),
        ]
        if lay.grand_total:
            rows.append((st.row_height, [
                self._tb("جمع کل", bold=True, bg=st.total_bg),
                self._tb(f"={agg}(Fields!{val.field_name}.Value)", bold=True,
                         bg=st.total_bg, align="Center", fmt=fmt)]))

        body = "\n".join(f"""        <TablixRow>
          <Height>{h}</Height>
          <TablixCells>
{chr(10).join(self._cell(c) for c in cells)}
          </TablixCells>
        </TablixRow>""" for h, cells in rows)

        ind = "                "
        total = (f'{ind}<TablixMember>'
                 f'<KeepWithGroup>Before</KeepWithGroup></TablixMember>'
                 if lay.grand_total else '')

        return f"""          <Tablix Name="MainMatrix">
            <TablixBody>
              <TablixColumns>
                <TablixColumn><Width>{st.default_col_width}</Width></TablixColumn>
                <TablixColumn><Width>{st.default_col_width}</Width></TablixColumn>
              </TablixColumns>
              <TablixRows>
{body}
              </TablixRows>
            </TablixBody>
            <TablixColumnHierarchy>
              <TablixMembers>
                <TablixMember />
                <TablixMember>
                  <Group Name="ColGroup"><GroupExpressions><GroupExpression>=Fields!{cg.field_name}.Value</GroupExpression></GroupExpressions></Group>
                  <SortExpressions><SortExpression><Value>=Fields!{cg.field_name}.Value</Value></SortExpression></SortExpressions>
                  <TablixMembers><TablixMember /></TablixMembers>
                </TablixMember>
              </TablixMembers>
            </TablixColumnHierarchy>
            <TablixRowHierarchy>
              <TablixMembers>
{ind}<TablixMember>
{ind}  <KeepWithGroup>After</KeepWithGroup>
{ind}  <RepeatOnNewPage>true</RepeatOnNewPage>
{ind}</TablixMember>
{ind}<TablixMember>
{ind}  <Group Name="RowGroup"><GroupExpressions><GroupExpression>=Fields!{rg.field_name}.Value</GroupExpression></GroupExpressions></Group>
{ind}  <SortExpressions><SortExpression><Value>=Fields!{rg.field_name}.Value</Value></SortExpression></SortExpressions>
{ind}  <TablixMembers><TablixMember /></TablixMembers>
{ind}</TablixMember>
{total}
              </TablixMembers>
            </TablixRowHierarchy>
            <DataSetName>DataSet1</DataSetName>
            <Top>1.3cm</Top>
            <Left>0cm</Left>
            <Height>{st.header_height}</Height>
            <Width>{self._cm(st.default_col_width) * 2:.2f}cm</Width>
            <Style>
              <Direction>{st.direction}</Direction>
              <Border><Style>None</Style></Border>
            </Style>
          </Tablix>"""

    # ═══════ سرصفحه و پاصفحه ═══════

    def _band(self, band: PageBand, tag: str) -> str:
        if not band.enabled:
            return ""
        st = self.st
        w = self._content_width
        third = w / 3
        items = []

        # در RTL اولین ناحیه سمت راست است
        for i, txt in enumerate((band.right, band.center, band.left)):
            if not txt:
                continue
            align = ("Right", "Center", "Left")[i]
            # عبارت هم باید escape شود — & در XML باید &amp; باشد
            value = self._esc(txt)
            items.append(f"""          <Textbox Name="{self._uid('pb')}">
            <CanGrow>false</CanGrow>
            <Paragraphs><Paragraph><TextRuns><TextRun>
              <Value>{value}</Value>
              <Style>
                <FontFamily>{st.font_family}</FontFamily>
                <FontSize>{st.font_size_page}</FontSize>
              </Style>
            </TextRun></TextRuns>
            <Style><TextAlign>{align}</TextAlign></Style>
            </Paragraph></Paragraphs>
            <Top>0.1cm</Top>
            <Left>{i * third:.2f}cm</Left>
            <Height>0.6cm</Height>
            <Width>{third:.2f}cm</Width>
            <Style><Direction>{st.direction}</Direction></Style>
          </Textbox>""")

        if not items:
            return ""

        if band.show_line:
            items.append(f"""          <Line Name="{self._uid('ln')}">
            <Top>{'0.85cm' if tag == 'PageHeader' else '0cm'}</Top>
            <Left>0cm</Left><Height>0cm</Height><Width>{w:.2f}cm</Width>
            <Style><Border><Color>{st.border_color}</Color><Style>Solid</Style></Border></Style>
          </Line>""")

        return f"""      <{tag}>
        <Height>{band.height}</Height>
        <PrintOnFirstPage>true</PrintOnFirstPage>
        <PrintOnLastPage>true</PrintOnLastPage>
        <ReportItems>
{chr(10).join(items)}
        </ReportItems>
        <Style />
      </{tag}>"""

    # ═══════ سند کامل ═══════

    def _document(self, *, tablix: str, cols: dict[str, RdlColumn], sql: str,
                  params: list[tuple[str, str, str]], title_fa: str,
                  lay: ReportLayout) -> str:
        st = self.st

        fields = "\n".join(
            f'      <Field Name="{c.field_name}">'
            f'<DataField>{c.field_name}</DataField>'
            f'<rd:TypeName>{_rdl_type(c.sql_type)}</rd:TypeName></Field>'
            for c in cols.values())

        qparams = rparams = ""
        sys_only = self.pf.report_params_xml()
        if not params and sys_only:
            rparams = f"  <ReportParameters>\n{sys_only}\n  </ReportParameters>"
        if params:
            qparams = ("        <QueryParameters>\n" + "\n".join(
                f'          <QueryParameter Name="@{n}">'
                f'<Value>=Parameters!{n}.Value</Value></QueryParameter>'
                for n, _, _ in params) + "\n        </QueryParameters>")
            sys_xml = self.pf.report_params_xml()
            rparams = ("  <ReportParameters>\n" + "\n".join(
                f"""    <ReportParameter Name="{n}">
      <DataType>{_PARAM_TO_RDL.get(t, 'String')}</DataType>
      <Prompt>{self._esc(title)}</Prompt>
      <Nullable>false</Nullable>
    </ReportParameter>""" for n, t, title in params)
                + ("\n" + sys_xml if sys_xml else "") + "\n  </ReportParameters>")

        title_block = ""
        if title_fa:
            title_block = f"""          <Textbox Name="ReportTitle">
            <CanGrow>true</CanGrow>
            <Paragraphs><Paragraph><TextRuns><TextRun>
              <Value>{self._esc(title_fa)}</Value>
              <Style>
                <FontFamily>{st.font_family}</FontFamily>
                <FontSize>{st.font_size_title}</FontSize>
                <FontWeight>Bold</FontWeight>
              </Style>
            </TextRun></TextRuns>
            <Style><TextAlign>Center</TextAlign></Style>
            </Paragraph></Paragraphs>
            <Top>0cm</Top><Left>0cm</Left>
            <Height>1cm</Height><Width>{self._content_width:.2f}cm</Width>
            <Style><Direction>{st.direction}</Direction></Style>
          </Textbox>"""

        return f"""<?xml version="1.0" encoding="utf-8"?>
<Report xmlns="{RDL_2016}"
        xmlns:rd="{RD_NS}">
  <AutoRefresh>0</AutoRefresh>
  <Language>{st.language}</Language>
  <ConsumeContainerWhitespace>true</ConsumeContainerWhitespace>

  <DataSources>
    <DataSource Name="{self.pf.data_source_name}">
      <DataSourceReference>{self.pf.data_source_ref}</DataSourceReference>
      <rd:SecurityType>None</rd:SecurityType>
    </DataSource>
  </DataSources>

  <DataSets>
    <DataSet Name="DataSet1">
      <Query>
        <DataSourceName>{self.pf.data_source_name}</DataSourceName>
{qparams}
        <CommandText>{self._esc(sql)}</CommandText>
        <rd:UseGenericDesigner>true</rd:UseGenericDesigner>
      </Query>
      <Fields>
{fields}
      </Fields>
    </DataSet>
  </DataSets>

{rparams}

  <ReportSections>
    <ReportSection>
      <Body>
        <ReportItems>
{title_block}
{tablix}
        </ReportItems>
        <Height>8cm</Height>
        <Style />
      </Body>
{self._band(lay.page_header, 'PageHeader')}
{self._band(lay.page_footer, 'PageFooter')}
      <Page>
        <PageHeight>{st.page_height}</PageHeight>
        <PageWidth>{st.page_width}</PageWidth>
        <LeftMargin>{st.margin_left}</LeftMargin>
        <RightMargin>{st.margin_right}</RightMargin>
        <TopMargin>{st.margin_top}</TopMargin>
        <BottomMargin>{st.margin_bottom}</BottomMargin>
        <ColumnSpacing>0.13cm</ColumnSpacing>
        <Style />
      </Page>
    </ReportSection>
  </ReportSections>

  <rd:ReportUnitType>Cm</rd:ReportUnitType>
</Report>
"""
