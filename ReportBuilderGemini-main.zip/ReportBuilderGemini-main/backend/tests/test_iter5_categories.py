"""Iteration 5 backend tests: report folders/categories."""
import os
import time
import requests

BASE = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE:
    from pathlib import Path
    for line in Path("/app/frontend/.env").read_text().splitlines():
        if line.startswith("REACT_APP_BACKEND_URL="):
            BASE = line.split("=", 1)[1].strip()
BASE = BASE.rstrip("/")

STAMP = str(int(time.time()))
CAT_A = f"TEST_iter5_folder_A_{STAMP}"
CAT_B = f"TEST_iter5_folder_B_{STAMP}"


def _plan():
    return {
        "intent_fa": f"TEST_iter5_report_{STAMP}",
        "base_table": "FIN3.Voucher",
        "joins": [],
        "columns": [{"table": "FIN3.Voucher", "column": "ID", "alias": "id"}],
        "filters": [],
        "parameters": [],
        "order_by": [],
        "limit": None,
    }


def _save(title, category):
    r = requests.post(f"{BASE}/api/save-report", json={
        "sql": "SELECT 1 AS x",
        "plan": _plan(),
        "title_fa": title,
        "category": category,
        "request_fa": title,
    }, timeout=30)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["ok"] and d["in_catalog"] is True
    return d["slug"]


def _save_raw(title, category):
    r = requests.post(f"{BASE}/api/save-report", json={
        "sql": "SELECT * FROM FIN3.Voucher",
        "title_fa": title,
        "category": category,
        "tables": ["FIN3.Voucher"],
    }, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()["slug"]


class TestCategoriesFolders:
    def test_categories_endpoint(self):
        r = requests.get(f"{BASE}/api/categories", timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert isinstance(d.get("categories"), list)

    def test_save_with_category_creates_folder(self):
        slug = _save(f"TEST_iter5_A_{STAMP}", CAT_A)
        # verify categories list includes the folder with count>=1
        r = requests.get(f"{BASE}/api/categories", timeout=10)
        names = {c["name"]: c["count"] for c in r.json()["categories"]}
        assert CAT_A in names and names[CAT_A] >= 1
        # verify report record has category
        r = requests.get(f"{BASE}/api/reports/{slug}", timeout=10)
        assert r.status_code == 200
        assert r.json().get("category") == CAT_A

    def test_reports_filter_by_category(self):
        _save(f"TEST_iter5_B1_{STAMP}", CAT_B)
        _save(f"TEST_iter5_B2_{STAMP}", CAT_B)
        r = requests.get(f"{BASE}/api/reports", params={"category": CAT_B}, timeout=10)
        assert r.status_code == 200
        results = r.json()["results"]
        assert len(results) >= 2
        for e in results:
            assert e["category"] == CAT_B

    def test_reports_returns_category_and_request_fa(self):
        title = f"TEST_iter5_fields_{STAMP}"
        _save(title, CAT_A)
        r = requests.get(f"{BASE}/api/reports", timeout=10)
        results = r.json()["results"]
        entry = next((x for x in results if x["title_fa"] == title), None)
        assert entry is not None
        assert "category" in entry and entry["category"] == CAT_A
        assert "request_fa" in entry and entry["request_fa"] == title

    def test_set_category_endpoint_reassigns(self):
        slug = _save(f"TEST_iter5_reassign_{STAMP}", CAT_A)
        r = requests.post(f"{BASE}/api/reports/{slug}/category",
                          json={"category": CAT_B}, timeout=10)
        assert r.status_code == 200
        assert r.json()["ok"] is True
        # verify persisted
        r = requests.get(f"{BASE}/api/reports/{slug}", timeout=10)
        assert r.json()["category"] == CAT_B

    def test_set_category_clear(self):
        slug = _save(f"TEST_iter5_clear_{STAMP}", CAT_A)
        r = requests.post(f"{BASE}/api/reports/{slug}/category",
                          json={"category": ""}, timeout=10)
        assert r.status_code == 200
        r = requests.get(f"{BASE}/api/reports/{slug}", timeout=10)
        assert r.json()["category"] == ""

    def test_set_category_404_on_missing(self):
        r = requests.post(f"{BASE}/api/reports/does-not-exist-xyz/category",
                          json={"category": "x"}, timeout=10)
        assert r.status_code == 404

    def test_save_raw_without_plan_creates_catalog_entry(self):
        slug = _save_raw(f"TEST_iter5_raw_{STAMP}", CAT_A)
        r = requests.get(f"{BASE}/api/reports/{slug}", timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d["category"] == CAT_A
        assert d["title_fa"] == f"TEST_iter5_raw_{STAMP}"
        # sql file downloadable
        r = requests.get(f"{BASE}/api/reports/{slug}/file/sql", timeout=10)
        assert r.status_code == 200
        assert r.text.startswith("-- ")

    def test_reports_search_q(self):
        title = f"TEST_iter5_searchable_{STAMP}"
        _save(title, CAT_A)
        r = requests.get(f"{BASE}/api/reports", params={"q": f"TEST_iter5_searchable_{STAMP}"}, timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert any(res["title_fa"] == title for res in d["results"])
