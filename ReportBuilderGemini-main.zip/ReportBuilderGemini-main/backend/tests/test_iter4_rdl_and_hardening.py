"""Iteration 4 focused tests:
1. FIX verification: GET /api/reports/{slug}/file/rdl returns 404 (not 500) when
   the report has no rdl_path built; and returns 200 XML after /api/rdl builds one.
2. Regression: upload filename collision suffixing (same name twice -> both 200).
3. Regression: core endpoints (health, save-report, /file/sql, /file/txt,
   /download/*.sql media-type, upload with .sql tables_found, chat SSE, rdl build,
   knowledge add, index rebuild, bench SSE).
"""
from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip()
                break
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def s():
    return requests.Session()


# -------------------------------------------------- SSE helper
def _read_sse_done(response, max_seconds: float = 120.0):
    start = time.time()
    ev = None
    buf = []
    events_seen = []
    for raw in response.iter_lines(decode_unicode=True):
        if time.time() - start > max_seconds:
            raise TimeoutError("SSE exceeded budget")
        if raw == "":
            if ev is not None and buf:
                events_seen.append(ev)
                if ev == "done":
                    return events_seen, json.loads("".join(buf))
            ev = None
            buf = []
            continue
        if raw.startswith("event:"):
            ev = raw[6:].strip()
        elif raw.startswith("data:"):
            buf.append(raw[5:].strip())
    return events_seen, None


# =============================================================
# 1. RDL 404 fix (primary target of this iteration)
# =============================================================
class TestRdlFileFix:
    def test_rdl_missing_returns_404_with_persian_detail(self, s):
        # Save a report WITHOUT triggering /api/rdl -> rdl_path should be empty
        body = {
            "sql": "SELECT 1 AS X",
            "plan": {"intent_fa": "TEST_iter4_no_rdl"},
            "title_fa": f"TEST_iter4_no_rdl_{uuid.uuid4().hex[:6]}",
        }
        r = s.post(f"{API}/save-report", json=body, timeout=15)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["ok"] is True
        assert d.get("in_catalog") is True, f"needs to be in catalog to test /file/rdl: {d}"
        slug = d["slug"]

        r3 = s.get(f"{API}/reports/{slug}/file/rdl", timeout=15)
        assert r3.status_code == 404, (
            f"BUG NOT FIXED: expected 404 for missing RDL, got {r3.status_code}: {r3.text[:300]}"
        )
        detail = r3.json().get("detail", "")
        assert "RDL" in detail
        assert "ساخته نشده" in detail, f"expected Persian 'ساخته نشده' in detail: {detail!r}"

    def test_rdl_present_returns_200_xml(self, s):
        # 1) Run chat to obtain plan + layout
        r0 = s.post(
            f"{API}/chat",
            json={"request": "لیست اسناد حسابداری با شماره و تاریخ"},
            stream=True,
            timeout=120,
        )
        assert r0.status_code == 200
        _, done = _read_sse_done(r0, max_seconds=120)
        assert done and done.get("ok") is True, f"chat did not emit ok done: {done}"

        # 2) save-report with plan -> catalog entry
        title = f"TEST_iter4_with_rdl_{uuid.uuid4().hex[:6]}"
        r_save = s.post(
            f"{API}/save-report",
            json={"sql": done["sql"], "plan": done["plan"], "title_fa": title},
            timeout=20,
        )
        assert r_save.status_code == 200, r_save.text
        slug = r_save.json()["slug"]

        # 3) Build RDL for the SAME slug so the catalog record gets rdl_path set.
        #    The /api/rdl endpoint updates the same slug because catalog.add_entry
        #    is keyed on slug from plan.intent_fa.
        rdl_body = {
            "plan": done["plan"],
            "layout": done["layout"],
            "title_fa": title,
            "filename": f"TEST_iter4_{uuid.uuid4().hex[:8]}.rdl",
        }
        r_rdl = s.post(f"{API}/rdl", json=rdl_body, timeout=60)
        assert r_rdl.status_code == 200, r_rdl.text
        assert r_rdl.json().get("size", 0) > 0

        # 4) Now /file/rdl on the same slug must be 200 XML.
        #    (Only meaningful if save-report and /api/rdl share the same slug.)
        r3 = s.get(f"{API}/reports/{slug}/file/rdl", timeout=15)
        if r3.status_code == 404:
            # /api/rdl may have assigned a different slug from plan.intent_fa
            # -> look up via /api/reports catalog for a slug with an rdl_path,
            #    using our TEST_ title.
            catalog = s.get(f"{API}/reports", timeout=15).json().get("results", [])
            matches = [c for c in catalog if c.get("title_fa") == title and c.get("rdl_path")]
            assert matches, (
                f"no catalog entry with rdl_path for title {title!r}; "
                f"first /file/rdl returned 404 on slug {slug}"
            )
            slug2 = matches[0]["slug"]
            r3 = s.get(f"{API}/reports/{slug2}/file/rdl", timeout=15)

        assert r3.status_code == 200, f"/file/rdl expected 200 got {r3.status_code}: {r3.text[:300]}"
        assert "xml" in r3.headers.get("content-type", "").lower()
        body = r3.content.lstrip()
        assert body.startswith(b"<?xml") or b"<Report" in body


# =============================================================
# 2. Upload filename collision hardening
# =============================================================
class TestUploadCollision:
    def test_same_filename_twice_no_error(self, s):
        name = f"TEST_iter4_collision_{uuid.uuid4().hex[:6]}.sql"
        payload_a = b"-- iter4 A\nSELECT * FROM FIN3.Voucher\n"
        payload_b = b"-- iter4 B\nSELECT * FROM GNR3.FiscalYear\n"

        r1 = s.post(
            f"{API}/upload",
            files={"file": (name, payload_a, "text/plain")},
            timeout=30,
        )
        assert r1.status_code == 200, r1.text
        d1 = r1.json()
        assert d1["ok"] is True and d1["type"] == "sql"
        path1 = d1["path"]

        r2 = s.post(
            f"{API}/upload",
            files={"file": (name, payload_b, "text/plain")},
            timeout=30,
        )
        assert r2.status_code == 200, (
            f"collision second upload failed: {r2.status_code} {r2.text[:300]}"
        )
        d2 = r2.json()
        assert d2["ok"] is True and d2["type"] == "sql"
        path2 = d2["path"]

        # Server must have written to different files (collision suffix)
        assert path1 != path2, f"collision handling did not create a distinct file: {path1}"
        # Both files must exist on disk
        assert Path(path1).is_file(), f"first upload file missing: {path1}"
        assert Path(path2).is_file(), f"second upload file missing: {path2}"

    def test_upload_sql_tables_found_kb_match(self, s):
        content = b"-- iter4 kb\nSELECT v.Number FROM FIN3.Voucher v\n"
        r = s.post(
            f"{API}/upload",
            files={"file": (f"TEST_iter4_kb_{uuid.uuid4().hex[:6]}.sql",
                            content, "text/plain")},
            timeout=30,
        )
        assert r.status_code == 200, r.text
        d = r.json()
        names = {t["full_name"] for t in d.get("tables_found", [])}
        assert "FIN3.Voucher" in names, f"KB match missing FIN3.Voucher: {names}"


# =============================================================
# 3. Regression: save/download endpoints
# =============================================================
class TestSaveDownloadRegression:
    def test_save_report_sql_txt(self, s):
        title = f"TEST_iter4_saved_{uuid.uuid4().hex[:6]}"
        body = {
            "sql": "SELECT 1 AS X",
            "plan": {"intent_fa": title},
            "title_fa": title,
        }
        r = s.post(f"{API}/save-report", json=body, timeout=15)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["ok"] is True
        assert d.get("in_catalog") is True
        slug = d["slug"]

        for fmt in ("sql", "txt"):
            rf = s.get(f"{API}/reports/{slug}/file/{fmt}", timeout=15)
            assert rf.status_code == 200, f"/file/{fmt} failed: {rf.status_code} {rf.text[:200]}"
            assert "text/plain" in rf.headers.get("content-type", ""), rf.headers
            assert rf.text.startswith("-- "), f"{fmt} should start with '-- ' got: {rf.text[:80]!r}"

    def test_download_sql_text_plain(self, s):
        title = f"TEST_iter4_dl_{uuid.uuid4().hex[:6]}"
        r = s.post(
            f"{API}/save-report",
            json={"sql": "SELECT 42", "plan": {"intent_fa": title}, "title_fa": title},
            timeout=15,
        )
        slug = r.json()["slug"]
        # /api/download/{name}.sql
        rd = s.get(f"{API}/download/{slug}.sql", timeout=15)
        assert rd.status_code == 200
        assert "text/plain" in rd.headers.get("content-type", "")


# =============================================================
# 4. Core endpoints smoke
# =============================================================
class TestCoreRegression:
    def test_health(self, s):
        r = s.get(f"{API}/health", timeout=15)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["ok"] is True
        assert d["keys"]["emergent"] is True

    def test_knowledge_table_add(self, s):
        # POST /api/knowledge with an existing KB table
        payload = {
            "kind": "table",
            "payload": {
                "full_name": "FIN3.Voucher",
                "title_fa": "TEST_iter4_سند",
            },
        }
        r = s.post(f"{API}/knowledge", json=payload, timeout=20)
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True

    def test_index_rebuild(self, s):
        r = s.post(f"{API}/index/rebuild", timeout=60)
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True

    def test_bench_emergent_sse(self, s):
        body = {"models": ["emergent"], "requests": ["لیست اسناد حسابداری"]}
        r = s.post(f"{API}/bench", json=body, stream=True, timeout=180)
        assert r.status_code == 200, r.text[:400]
        events, done = _read_sse_done(r, max_seconds=180)
        assert "start" in events, events
        assert done is not None, f"bench never emitted done: {events}"
        assert "scoreboard" in done
        assert isinstance(done.get("cases", []), list) and len(done["cases"]) >= 1
