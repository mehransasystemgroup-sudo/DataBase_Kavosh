"""Iteration 6: Verify real DB exports integration
- 420 active tables
- Real row counts, PKs, indexes on well-known tables
- Search ranking with real data
- Rebuild keeps instance=live (active_tables stays 420)
"""
from __future__ import annotations
import os, time, requests, pytest

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip()
                break
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def s():
    return requests.Session()


def test_health_active_tables_420(s):
    r = s.get(f"{API}/health", timeout=15)
    assert r.status_code == 200
    data = r.json()
    active = int(data["kb"]["active_tables"])
    assert active == 420, f"expected 420 active tables, got {active}"


def test_fin3_voucheritem_real_data(s):
    r = s.get(f"{API}/table/FIN3.VoucherItem", timeout=15)
    assert r.status_code == 200
    d = r.json()
    assert d["row_count"] == 26367
    assert d["has_data"] is True
    assert d["primary_key"] == ["VoucherItemID"]
    assert len(d.get("indexes", [])) >= 1
    # each index has columns list
    for idx in d["indexes"]:
        assert isinstance(idx.get("columns"), list) and len(idx["columns"]) >= 1
    assert len(d.get("indexed_columns", [])) >= 1


def test_acc_voucheritem_has_rows_but_indexes_may_be_empty(s):
    r = s.get(f"{API}/table/ACC.VoucherItem", timeout=15)
    assert r.status_code == 200
    d = r.json()
    assert d["row_count"] == 19176
    assert d["has_data"] is True
    # ACC.VoucherItem has no recovered indexes; graceful empty is expected
    assert isinstance(d.get("indexes", []), list)


def test_bdg3_zero_row_table(s):
    r = s.get(f"{API}/table/BDG3.AdjustmentFactor", timeout=15)
    assert r.status_code == 200
    d = r.json()
    assert d["row_count"] == 0
    assert d["has_data"] is False


def test_search_ranks_real_data(s):
    r = s.get(f"{API}/search", params={"q": "سند"}, timeout=15)
    assert r.status_code == 200
    body = r.json()
    items = body.get("results") or body.get("items") or body
    names = [it.get("full_name") for it in items]
    assert "FIN3.VoucherItem" in names
    # every returned item must have has_data True (no all=true)
    for it in items:
        assert it.get("has_data") is True, f"{it.get('full_name')} has_data={it.get('has_data')}"


def test_rebuild_index_keeps_live(s):
    r = s.post(f"{API}/index/rebuild", timeout=60)
    assert r.status_code == 200
    # small settle
    time.sleep(1)
    h = s.get(f"{API}/health", timeout=15).json()
    active = int(h["kb"]["active_tables"])
    assert active == 420, f"after rebuild expected 420 active tables, got {active}"
