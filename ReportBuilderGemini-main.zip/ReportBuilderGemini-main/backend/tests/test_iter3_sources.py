"""Iteration 3 tests: upload flow, save-report, report file downloads."""
from __future__ import annotations

import os
from pathlib import Path

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip()
                break
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"

SAMPLE_SQL = """
-- TEST_ upload
SELECT v.Number, v.Date FROM FIN3.Voucher v
JOIN GNR3.FiscalYear fy ON fy.ID = v.FiscalYearID
WHERE fy.Year = 1402
"""

RDL_PATH = "/app/backend/rc_data/reports/report.rdl"


@pytest.fixture(scope="module")
def s():
    return requests.Session()


class TestUpload:
    def test_upload_sql(self, s):
        files = {"file": ("TEST_upload.sql", SAMPLE_SQL.encode("utf-8"), "text/plain")}
        r = s.post(f"{API}/upload", files=files, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["ok"] is True
        assert data["type"] == "sql"
        names = {t["full_name"] for t in data.get("tables_found", [])}
        # FIN3.Voucher must be matched to KB
        assert "FIN3.Voucher" in names
        # GNR3.FiscalYear if present in KB
        # (allow presence not to be strictly required)

    def test_upload_rdl(self, s):
        if not Path(RDL_PATH).exists():
            pytest.skip("no sample RDL available")
        with open(RDL_PATH, "rb") as f:
            data = f.read()
        files = {"file": ("TEST_report.rdl", data, "application/xml")}
        r = s.post(f"{API}/upload", files=files, timeout=60)
        assert r.status_code == 200, r.text[:500]
        d = r.json()
        assert d["ok"] is True
        assert d["type"] == "rdl"
        assert d.get("learnable_profile") is True
        assert isinstance(d.get("datasets"), list) and len(d["datasets"]) >= 1
        assert "command" in d["datasets"][0]

    def test_upload_rejects_bad_ext(self, s):
        files = {"file": ("bad.exe", b"x", "application/octet-stream")}
        r = s.post(f"{API}/upload", files=files, timeout=15)
        assert r.status_code == 400


class TestSaveReport:
    def test_save_report_minimal(self, s):
        # Without plan -> in_catalog False but slug + file generated
        body = {"sql": "SELECT 1 AS X", "title_fa": "TEST_گزارش_ساده"}
        r = s.post(f"{API}/save-report", json=body, timeout=15)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["ok"] is True
        assert "slug" in d and d["slug"]
        assert d["sql_file"].endswith(".sql")

    def test_save_report_with_plan_creates_catalog(self, s):
        # Get a plan via chat
        r0 = s.post(f"{API}/chat",
                    json={"request": "لیست اسناد حسابداری"},
                    stream=True, timeout=120)
        assert r0.status_code == 200
        import json, time
        done = None
        start = time.time()
        ev = None; buf = []
        for raw in r0.iter_lines(decode_unicode=True):
            if time.time() - start > 120:
                break
            if raw == "":
                if ev == "done" and buf:
                    done = json.loads("".join(buf))
                    break
                ev = None; buf = []
                continue
            if raw.startswith("event:"): ev = raw[6:].strip()
            elif raw.startswith("data:"): buf.append(raw[5:].strip())
        assert done, "chat did not produce done"

        body = {"sql": done["sql"], "plan": done["plan"],
                "title_fa": "TEST_گزارش_کاتالوگ"}
        r = s.post(f"{API}/save-report", json=body, timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["ok"] is True
        assert d["in_catalog"] is True
        slug = d["slug"]

        # File downloads
        for fmt in ("sql", "txt"):
            r2 = s.get(f"{API}/reports/{slug}/file/{fmt}", timeout=15)
            assert r2.status_code == 200, r2.text[:200]
            text = r2.text
            assert text.startswith("-- ")
            assert len(text) > 5
            assert "text/plain" in r2.headers.get("content-type", "")

        # rdl not built yet -> should be 404 (iter4 fix verified)
        r3 = s.get(f"{API}/reports/{slug}/file/rdl", timeout=15)
        assert r3.status_code == 404, f"expected 404 for missing RDL, got {r3.status_code}: {r3.text[:200]}"
        detail = r3.json().get("detail", "")
        assert "RDL" in detail, f"expected Persian RDL error detail, got: {detail}"
        # Persian message uses this exact phrasing
        assert "ساخته نشده" in detail, f"expected 'ساخته نشده' in detail, got: {detail}"


class TestDownloadMediaType:
    def test_sql_download_text_plain(self, s):
        # Save first
        r = s.post(f"{API}/save-report",
                   json={"sql": "SELECT 2", "title_fa": "TEST_dl"}, timeout=15)
        slug = r.json()["slug"]
        fname = f"{slug}.sql"
        # File was written to OUT_DIR -> /api/download/{name}
        r2 = s.get(f"{API}/download/{fname}", timeout=15)
        assert r2.status_code == 200
        assert "text/plain" in r2.headers.get("content-type", "")
