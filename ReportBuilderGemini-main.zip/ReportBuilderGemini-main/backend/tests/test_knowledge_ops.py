"""Extended tests for iteration 2: knowledge write, index rebuild, session
delete, catalog lessons — all newly emphasized flows.
"""
from __future__ import annotations

import os
import time
import uuid

import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip()
                break
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def s():
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    return session


# ─────────────────────────── knowledge writes ───────────────────────────
class TestKnowledgeWrites:
    TARGET = "FIN3.Voucher"

    def test_teach_table_meta(self, s):
        title = f"سند حسابداری TEST_{uuid.uuid4().hex[:6]}"
        r = s.post(f"{API}/knowledge", json={
            "kind": "table",
            "payload": {
                "full_name": self.TARGET,
                "title_fa": title,
                "description_fa": "تست خودکار",
                "gotcha": "TEST_گاچا",
            }
        }, timeout=30)
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True
        # remember title for later verification
        TestKnowledgeWrites._title = title

    def test_teach_enum(self, s):
        r = s.post(f"{API}/knowledge", json={
            "kind": "enum",
            "payload": {
                "full_name": self.TARGET,
                "column": "State",
                "value": "9",
                "label_fa": "TEST_وضعیت",
            }
        }, timeout=30)
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True

    def test_teach_join(self, s):
        r = s.post(f"{API}/knowledge", json={
            "kind": "join",
            "payload": {
                "from_table": self.TARGET,
                "from_col": "AccountRef",
                "to_table": "FIN3.Account",
                "to_col": "AccountID",
            }
        }, timeout=30)
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True

    def test_teach_invalid_kind(self, s):
        r = s.post(f"{API}/knowledge", json={
            "kind": "bogus",
            "payload": {}
        }, timeout=15)
        assert r.status_code == 400


# ─────────────────────────── index rebuild ───────────────────────────
class TestIndexRebuild:
    def test_rebuild_and_applied(self, s):
        # ensure a fresh taught title exists (independent of other workers)
        title = f"سند حسابداری TEST_{uuid.uuid4().hex[:6]}"
        s.post(f"{API}/knowledge", json={
            "kind": "table",
            "payload": {
                "full_name": "FIN3.Voucher",
                "title_fa": title,
                "description_fa": "تست ری‌بیلد",
            }
        }, timeout=30)
        r = s.post(f"{API}/index/rebuild", timeout=600)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data.get("ok") is True, f"rebuild returned: {data}"
        # give a moment for reload
        time.sleep(0.5)
        r2 = s.get(f"{API}/search", params={"q": title.split()[-1], "all": "true"}, timeout=30)
        assert r2.status_code == 200
        results = r2.json().get("results", [])
        matched = next((row for row in results if row.get("full_name") == "FIN3.Voucher"), None)
        # Not fatal if the search token doesn't hit — but detail must reflect
        det = s.get(f"{API}/table/FIN3.Voucher", timeout=15).json()
        assert title in (det.get("title_fa") or ""), \
            f"expected title '{title}' in table detail, got '{det.get('title_fa')}'"


# ─────────────────────────── sessions delete ───────────────────────────
class TestSessionDelete:
    def test_delete_session(self, s):
        # need a session — trigger a quick chat if none exist
        lst = s.get(f"{API}/sessions", timeout=15).json().get("sessions", [])
        if not lst:
            # create one
            r = s.post(f"{API}/chat", json={"request": "TEST_delete سند"}, stream=True, timeout=60)
            # consume stream briefly
            for _ in r.iter_lines(decode_unicode=True):
                pass
            lst = s.get(f"{API}/sessions", timeout=15).json().get("sessions", [])
        assert lst, "still no sessions after creating one"
        sid = lst[0]["id"]
        d = s.delete(f"{API}/sessions/{sid}", timeout=15)
        assert d.status_code in (200, 204), d.text
        # verify removal
        lst2 = s.get(f"{API}/sessions", timeout=15).json().get("sessions", [])
        assert not any(x["id"] == sid for x in lst2)


# ─────────────────────────── catalog lessons ───────────────────────────
class TestCatalogLesson:
    def test_add_lesson_when_report_exists(self, s):
        reports = s.get(f"{API}/reports", timeout=15).json().get("results", [])
        if not reports:
            pytest.skip("no reports yet in catalog")
        slug = reports[0].get("slug")
        assert slug
        lesson = f"TEST_lesson_{uuid.uuid4().hex[:6]}"
        r = s.post(f"{API}/knowledge", json={
            "kind": "lesson",
            "payload": {"slug": slug, "lesson": lesson}
        }, timeout=30)
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True
        # confirm lesson appears
        r2 = s.get(f"{API}/reports/{slug}", timeout=15)
        assert r2.status_code == 200
        lessons = r2.json().get("lessons") or []
        # Some backends may return list of strings or list of objects
        found = any(lesson in (l if isinstance(l, str) else str(l)) for l in lessons)
        assert found, f"lesson '{lesson}' not persisted; lessons={lessons}"

    def test_add_lesson_bad_slug(self, s):
        r = s.post(f"{API}/knowledge", json={
            "kind": "lesson",
            "payload": {"slug": "TEST_does_not_exist_zzz", "lesson": "x"}
        }, timeout=15)
        assert r.status_code == 404
