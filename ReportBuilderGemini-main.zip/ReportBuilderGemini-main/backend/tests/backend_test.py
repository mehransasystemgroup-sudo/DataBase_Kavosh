"""End-to-end backend tests for the Persian Report Copilot API.

Covers:
- Health / KB stats
- Knowledge search + table detail
- Settings & test-model (Emergent LLM key)
- Sessions listing
- Reports catalog
- Chat SSE flow (core AI feature)
- RDL build + download
- Bench SSE flow
"""
from __future__ import annotations

import json
import os
import time
import uuid

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
if not BASE_URL:
    # Read from frontend/.env directly since backend tests still target public URL
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip()
                break
BASE_URL = BASE_URL.rstrip("/")
API = f"{BASE_URL}/api"


# ---------------------------------------------------------------- fixtures
@pytest.fixture(scope="module")
def s():
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    return session


# ---------------------------------------------------------------- health
class TestHealth:
    def test_health(self, s):
        r = s.get(f"{API}/health", timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["ok"] is True
        # kb.tables ~ 3428
        tables = int(data["kb"]["tables"])
        assert tables >= 3000, f"expected ~3428 tables, got {tables}"
        assert data["model"] == "emergent"
        assert data["keys"]["emergent"] is True


# ---------------------------------------------------------------- knowledge base
class TestKnowledge:
    def test_search_all(self, s):
        r = s.get(f"{API}/search", params={"q": "سند", "all": "true"}, timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data.get("results"), list)
        assert len(data["results"]) > 0, "expected some results for سند"
        first = data["results"][0]
        assert "full_name" in first
        assert "title_fa" in first

    def test_table_voucher(self, s):
        r = s.get(f"{API}/table/FIN3.Voucher", timeout=15)
        assert r.status_code == 200, r.text
        t = r.json()
        assert t["full_name"] == "FIN3.Voucher"
        assert isinstance(t.get("columns"), list) and len(t["columns"]) > 0
        assert "primary_key" in t
        assert "enums" in t
        assert isinstance(t.get("outgoing"), list)


# ---------------------------------------------------------------- test-model
class TestModel:
    def test_test_model(self, s):
        r = s.post(f"{API}/test-model", timeout=60)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data.get("ok") is True, f"test-model returned: {data}"
        assert isinstance(data.get("reply"), str) and len(data["reply"]) > 0


# ---------------------------------------------------------------- settings
class TestSettings:
    def test_get_settings(self, s):
        r = s.get(f"{API}/settings", timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "settings" in data
        assert "keys" in data
        assert "presets" in data
        assert data["keys"]["emergent"] is True
        # presets includes emergent variants
        assert "emergent" in data["presets"]

    def test_update_settings_persists(self, s):
        # capture current
        original = s.get(f"{API}/settings", timeout=15).json()["settings"]
        new_preset = original.get("model_preset", "emergent")
        new_budget = 5.5
        r = s.post(
            f"{API}/settings",
            json={"settings": {"model_preset": new_preset,
                               "daily_budget_usd": new_budget}},
            timeout=15,
        )
        assert r.status_code == 200, r.text
        assert r.json()["ok"] is True
        # verify persistence
        after = s.get(f"{API}/settings", timeout=15).json()["settings"]
        assert float(after["daily_budget_usd"]) == new_budget
        assert after["model_preset"] == new_preset


# ---------------------------------------------------------------- reports catalog
class TestReports:
    def test_reports_catalog(self, s):
        r = s.get(f"{API}/reports", timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert "results" in data
        assert "stats" in data


# ---------------------------------------------------------------- SSE helper
def _read_sse(response, max_seconds: float = 90.0):
    """Yields (event, data-dict) from an SSE stream."""
    start = time.time()
    event = None
    data_lines = []
    for raw in response.iter_lines(decode_unicode=True):
        if time.time() - start > max_seconds:
            raise TimeoutError("SSE read exceeded budget")
        if raw is None:
            continue
        line = raw
        if line == "":
            if event is not None and data_lines:
                try:
                    payload = json.loads("".join(data_lines))
                except Exception:
                    payload = {"_raw": "".join(data_lines)}
                yield event, payload
            event = None
            data_lines = []
            continue
        if line.startswith("event:"):
            event = line[6:].strip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].strip())


# ---------------------------------------------------------------- chat SSE (core) + RDL
class TestChatAndRDL:
    """Chat SSE core flow + subsequent RDL build using the returned plan/layout.

    Kept in one class so pytest-xdist loadscope keeps them on the same worker
    and state is shared naturally.
    """
    _done: dict = {}

    def test_01_chat_stream_full_flow(self, s):
        payload = {"request": "لیست اسناد حسابداری با شماره و تاریخ"}
        r = s.post(f"{API}/chat", json=payload, stream=True, timeout=120)
        assert r.status_code == 200, r.text[:400]

        events_seen = []
        done_payload = None
        for event, data in _read_sse(r, max_seconds=120):
            events_seen.append(event)
            if event == "done":
                done_payload = data
                break

        assert "start" in events_seen, f"missing start; events={events_seen}"
        assert "tables" in events_seen, f"missing tables; events={events_seen}"
        assert any(e in events_seen for e in ("attempt", "validation")), events_seen
        assert done_payload is not None, "chat did not emit done event"

        assert done_payload.get("ok") is True, f"chat done not ok: {done_payload}"
        sql = done_payload.get("sql") or ""
        assert isinstance(sql, str) and len(sql.strip()) > 0
        assert "SELECT" in sql.upper()
        assert done_payload.get("plan") is not None
        assert done_payload.get("layout") is not None

        TestChatAndRDL._done = done_payload

    def test_02_build_and_download_rdl(self, s):
        done = TestChatAndRDL._done
        if not done:
            pytest.skip("chat test did not produce plan/layout")

        rdl_body = {
            "plan": done["plan"],
            "layout": done["layout"],
            "title_fa": done["plan"].get("intent_fa") or "TEST_گزارش",
            "filename": f"TEST_{uuid.uuid4().hex[:8]}.rdl",
        }
        r = s.post(f"{API}/rdl", json=rdl_body, timeout=60)
        assert r.status_code == 200, r.text
        rdata = r.json()
        assert "ok" in rdata
        fname = rdata.get("filename", "")
        assert fname.endswith(".rdl")
        assert rdata.get("size", 0) > 0

        # download
        dr = s.get(f"{API}/download/{fname}", timeout=30)
        assert dr.status_code == 200
        body = dr.content
        assert len(body) > 0
        # RDL is XML
        assert body.lstrip().startswith(b"<?xml") or b"<Report" in body


# ---------------------------------------------------------------- sessions
class TestSessions:
    def test_list_sessions(self, s):
        r = s.get(f"{API}/sessions", timeout=15)
        assert r.status_code == 200
        data = r.json()
        assert "sessions" in data
        # after chat test, we expect at least 1
        assert isinstance(data["sessions"], list)

    def test_session_turns(self, s):
        lst = s.get(f"{API}/sessions", timeout=15).json()["sessions"]
        if not lst:
            pytest.skip("no sessions to inspect")
        sid = lst[0]["id"]
        r = s.get(f"{API}/sessions/{sid}", timeout=15)
        assert r.status_code == 200
        data = r.json()
        assert "turns" in data
        assert isinstance(data["turns"], list)


# ---------------------------------------------------------------- bench SSE
class TestBenchSSE:
    def test_bench_emergent(self, s):
        body = {"models": ["emergent"],
                "requests": ["لیست اسناد حسابداری"]}
        r = s.post(f"{API}/bench", json=body, stream=True, timeout=180)
        assert r.status_code == 200, r.text[:400]
        events = []
        done_payload = None
        for event, data in _read_sse(r, max_seconds=180):
            events.append(event)
            if event == "done":
                done_payload = data
                break

        assert "start" in events, events
        assert done_payload is not None, f"bench never emitted done: {events}"
        assert "scoreboard" in done_payload
        assert "cases" in done_payload
        assert isinstance(done_payload["cases"], list) and len(done_payload["cases"]) >= 1
        first = done_payload["cases"][0]
        assert "runs" in first
        assert isinstance(first["runs"], list) and len(first["runs"]) >= 1
