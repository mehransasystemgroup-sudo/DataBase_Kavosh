"""
نقطهٔ ورود بک‌اند روی پلتفرم Emergent.

منطق واقعی در بستهٔ `rc` (موتور Report Copilot) است. این فایل فقط
محیط را آماده می‌کند و اپلیکیشن FastAPI را از آن‌جا می‌آورد.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent
load_dotenv(BACKEND_DIR / ".env")

# مسیرهای موتور
RC_ROOT = BACKEND_DIR / "rc"
os.environ.setdefault("RC_HOME", str(BACKEND_DIR / "rc_data"))
os.environ.setdefault("KB_ROOT", str(RC_ROOT / "kb"))
os.environ.setdefault("KB_INDEX", str(RC_ROOT / "index" / "kb.sqlite"))

for p in (str(BACKEND_DIR), str(RC_ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

Path(os.environ["RC_HOME"]).mkdir(parents=True, exist_ok=True)

from rc.app.server import app  # noqa: E402,F401
