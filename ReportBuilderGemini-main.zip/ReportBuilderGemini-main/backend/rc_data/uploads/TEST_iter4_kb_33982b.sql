-- iter4 kb
SELECT v.Number FROM FIN3.Voucher v
