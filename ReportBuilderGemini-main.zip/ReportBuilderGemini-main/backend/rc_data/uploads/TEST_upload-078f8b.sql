
-- TEST_ upload
SELECT v.Number, v.Date FROM FIN3.Voucher v
JOIN GNR3.FiscalYear fy ON fy.ID = v.FiscalYearID
WHERE fy.Year = 1402
