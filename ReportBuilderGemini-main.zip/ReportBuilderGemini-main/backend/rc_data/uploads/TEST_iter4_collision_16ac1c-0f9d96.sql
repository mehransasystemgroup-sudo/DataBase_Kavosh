-- iter4 B
SELECT * FROM GNR3.FiscalYear
