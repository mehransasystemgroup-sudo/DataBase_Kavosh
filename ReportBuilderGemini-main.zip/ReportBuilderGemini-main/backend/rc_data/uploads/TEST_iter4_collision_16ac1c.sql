-- iter4 A
SELECT * FROM FIN3.Voucher
