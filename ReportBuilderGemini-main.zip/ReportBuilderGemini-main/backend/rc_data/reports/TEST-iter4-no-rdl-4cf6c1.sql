-- TEST_iter4_no_rdl_4cf6c1
-- 2026-08-09T08:44:46

SELECT 1 AS X
