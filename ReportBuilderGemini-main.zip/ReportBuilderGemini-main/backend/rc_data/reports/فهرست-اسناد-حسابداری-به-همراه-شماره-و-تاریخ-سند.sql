-- فهرست اسناد حسابداری به همراه شماره و تاریخ سند
-- 2026-08-08T20:58:12

-- @FiscalYear (int) — سال مالی

SELECT v.[VoucherID] AS [VoucherID],
       v.[Number] AS [Number],
       v.[DailyNumber] AS [DailyNumber],
       v.[Date] AS [Date],
       v.[Description] AS [Description],
       v.[State] AS [State]
FROM   FIN3.Voucher AS v
WHERE  v.[FiscalYearRef] = @FiscalYear
ORDER BY [شماره_سند] ASC;
