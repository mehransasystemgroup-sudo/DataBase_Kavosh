-- TEST_iter4_with_rdl_334687
-- 2026-08-08T21:41:12

-- @FiscalYear (int) — سال مالی

SELECT v.[Number] AS [Number],
       v.[Date] AS [Date],
       v.[Description] AS [Description]
FROM   FIN3.Voucher AS v
WHERE  v.[FiscalYearRef] = @FiscalYear
ORDER BY [شماره_سند] ASC;
