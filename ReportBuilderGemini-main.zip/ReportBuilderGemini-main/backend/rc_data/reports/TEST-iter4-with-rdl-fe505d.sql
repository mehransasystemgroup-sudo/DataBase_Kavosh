-- TEST_iter4_with_rdl_fe505d
-- 2026-08-08T21:44:44

-- @FiscalYear (int) — سال مالی

SELECT v.[VoucherID] AS [VoucherID],
       v.[Number] AS [Number],
       v.[Date] AS [Date],
       v.[Description] AS [Description]
FROM   FIN3.Voucher AS v
WHERE  v.[FiscalYearRef] = @FiscalYear
ORDER BY [شماره_سند] ASC;
