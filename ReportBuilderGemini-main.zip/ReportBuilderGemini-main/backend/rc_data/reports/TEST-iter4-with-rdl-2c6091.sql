-- TEST_iter4_with_rdl_2c6091
-- 2026-08-09T08:44:58

SELECT v.[VoucherID] AS [VoucherID],
       v.[Number] AS [Number],
       v.[VoucherDate] AS [VoucherDate],
       v.[Description] AS [Description],
       v.[IssueYearMonth] AS [IssueYearMonth],
       vs.[Title] AS [Title]
FROM   HCM3.Voucher AS v
INNER  JOIN HCM3.VoucherSpecification AS vs ON v.[VoucherSpecificationRef] = vs.[VoucherSpecificationID]
ORDER BY [تاریخ_سند] DESC, [شماره_سند] DESC;
