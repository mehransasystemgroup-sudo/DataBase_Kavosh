-- TEST_گزارش_کاتالوگ
-- 2026-08-09T08:45:17

-- @FiscalYear (int) — سال مالی

SELECT v.[Number] AS [Number],
       v.[Date] AS [Date],
       v.[Description] AS [Description],
       v.[State] AS [State],
       v.[ReferenceNumber] AS [ReferenceNumber],
       v.[DailyNumber] AS [DailyNumber],
       v.[IsTemporary] AS [IsTemporary],
       b.[Title] AS [Title]
FROM   FIN3.Voucher AS v
LEFT   JOIN GNR3.Branch AS b ON v.[BranchRef] = b.[BranchID]
WHERE  v.[FiscalYearRef] = @FiscalYear
ORDER BY [شماره_سند] ASC;
