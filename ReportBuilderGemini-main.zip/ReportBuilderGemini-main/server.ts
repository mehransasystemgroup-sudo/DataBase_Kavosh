import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { kb } from "./server/kb.js";
import { SqlAssembler, PlanValidator } from "./server/plan.js";
import { SqlSafetyAnalyzer } from "./server/sqlSafety.js";
import { RdlBuilder } from "./server/rdl.js";
import { catalog } from "./server/catalog.js";
import { settingsStore } from "./server/settings.js";
import { sessionStore } from "./server/sessions.js";
import { profileStore } from "./server/profile.js";
import { userProfileStore } from "./server/userProfiles.js";
import { LLMService } from "./server/llmService.js";
import { runAgentStream } from "./server/agent.js";
import { runBenchmark, getLastBenchmark } from "./server/bench.js";
import {
  CHATBOT_ROLES,
  executeMultiTurnChat,
  executeImageGenerationOrEditing,
  RoleKey,
} from "./server/geminiService.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // Temp download directory
  const downloadsDir = path.join(process.cwd(), "downloads");
  if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
  }

  // ──────────────────────── API ROUTES ────────────────────────

  // 1. Health
  app.get("/api/health", (req, res) => {
    const raw = settingsStore.getRawSettings();
    const stats = kb.getStats();
    res.json({
      status: "ok",
      model: raw.preset || raw.model || "emergent-gemini",
      budget: {
        spent: raw.spent_today,
        limit: raw.daily_budget,
        over: raw.spent_today >= raw.daily_budget,
      },
      kb: {
        tables: stats.tables,
        joins: stats.joins,
        schemas: stats.schemas,
      },
    });
  });

  // 2. Search tables
  app.get("/api/search", (req, res) => {
    const q = String(req.query.q || "");
    const schema = req.query.schema ? String(req.query.schema) : undefined;
    const limit = Number(req.query.limit) || 20;
    const fieldType = req.query.fieldType ? String(req.query.fieldType) : undefined;
    const minRows = req.query.minRows !== undefined && req.query.minRows !== "" ? Number(req.query.minRows) : undefined;
    const maxRows = req.query.maxRows !== undefined && req.query.maxRows !== "" ? Number(req.query.maxRows) : undefined;
    const dataStatus = (req.query.dataStatus ? String(req.query.dataStatus) : undefined) as "all" | "with_data" | "no_data" | undefined;
    const sortBy = req.query.sortBy ? (String(req.query.sortBy) as any) : undefined;
    const sortOrder = req.query.sortOrder ? (String(req.query.sortOrder) as any) : undefined;
    const onlyWithData = req.query.all !== "true" && req.query.all !== "1";

    const results = kb.searchTables({
      query: q,
      limit,
      schema,
      onlyWithData,
      fieldType,
      minRows,
      maxRows,
      dataStatus,
      sortBy,
      sortOrder,
    });
    res.json({ results });
  });

  // 3. Search columns
  app.get("/api/columns", (req, res) => {
    const q = String(req.query.q || "");
    const limit = Number(req.query.limit) || 30;
    const results = kb.searchColumns(q, limit);
    res.json({ results });
  });

  // 4. Table details
  app.get("/api/table/:name", (req, res) => {
    const name = decodeURIComponent(req.params.name);
    const tbl = kb.getTable(name);
    if (!tbl) {
      res.status(404).json({ detail: `جدول «${name}» یافت نشد.` });
      return;
    }
    const neighbors = kb.getSchemaNeighbors(tbl.schema, tbl.full_name, 24);
    res.json({ ...tbl, schema_neighbors: neighbors });
  });

  // 5. Join path finder
  app.get("/api/joinpath", (req, res) => {
    const source = String(req.query.source || req.query.src || "");
    const target = String(req.query.target || req.query.dst || "");
    const verifiedOnly = req.query.verified === "true";
    const pathResult = kb.findJoinPath(source, target, 4, verifiedOnly);
    if (pathResult === null) {
      res.json({ found: false, steps: [], path: null, warning: "هیچ مسیری بین این دو جدول یافت نشد." });
      return;
    }
    const warning = kb.pathWarning(pathResult);
    const steps = pathResult.map((s) => ({
      ...s,
      sql: `LEFT JOIN [${s.to_table}] ON [${s.from_table}].[${s.from_col}] = [${s.to_table}].[${s.to_col}]`,
    }));
    res.json({ found: true, steps, path: pathResult, warning });
  });

  // 5.1 Schema List
  app.get("/api/schemas", (req, res) => {
    const schemas = kb.getSchemaList();
    res.json({ schemas });
  });

  // 5.2 Schema Relationship Graph
  app.get("/api/schema/:schema/graph", (req, res) => {
    const schema = decodeURIComponent(req.params.schema || "");
    if (!schema) {
      res.status(400).json({ detail: "اسکیما مشخص نشده است." });
      return;
    }
    const includeExternal = req.query.includeExternal !== "false";
    const onlyWithData = req.query.onlyWithData === "true";
    const maxNodes = Number(req.query.maxNodes) || 60;
    const searchQuery = String(req.query.q || "");

    const graph = kb.getSchemaGraph(schema, {
      includeExternal,
      onlyWithData,
      maxNodes,
      searchQuery,
    });
    res.json(graph);
  });

  // 6. Chat endpoint (SSE Stream)
  app.post("/api/chat", async (req, res) => {
    const { request, session_id } = req.body;
    if (!request) {
      res.status(400).json({ detail: "درخواست نمی‌تواند خالی باشد." });
      return;
    }

    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();

    const sendEvent = (event: string, data: any) => {
      res.write(`event: ${event}\n`);
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    try {
      await runAgentStream(request, session_id, sendEvent);
    } catch (err: any) {
      sendEvent("error", { message: err?.message || "خطا در پردازش درخواست" });
    } finally {
      res.end();
    }
  });

  // 7. Validate Plan & Pre-flight Safety Check
  app.post("/api/validate-plan", (req, res) => {
    const plan = req.body.plan || req.body;
    if (!plan || typeof plan !== "object" || !plan.base_table) {
      res.status(400).json({ ok: false, detail: "نقشه ارسال نشده است یا فاقد جدول پایه است." });
      return;
    }
    const validation = PlanValidator.validate(plan, kb);
    let generatedSql = "";
    if (validation.plan) {
      try {
        generatedSql = SqlAssembler.build(validation.plan);
      } catch (err: any) {
        validation.issues.push({
          severity: "error",
          path: "sql",
          message: "خطا در مونتاژ SQL: " + (err?.message || String(err)),
        });
        validation.ok = false;
      }
    }

    // Run Safety & Slow Query Analysis
    const safety = SqlSafetyAnalyzer.analyze(generatedSql, validation.plan, kb);

    res.json({
      ...validation,
      sql: generatedSql,
      safety,
    });
  });

  // 8. Validate SQL & Pre-flight Safety Check
  app.post("/api/validate-sql", (req, res) => {
    const sql = req.body.sql || "";
    const plan = req.body.plan || null;
    const safety = SqlSafetyAnalyzer.analyze(sql, plan, kb);
    res.json({ ok: Boolean(sql) && safety.is_safe, issues: safety.issues, safety });
  });

  app.post("/api/check-sql-safety", (req, res) => {
    const { sql, plan } = req.body;
    const safety = SqlSafetyAnalyzer.analyze(sql || "", plan || null, kb);
    res.json(safety);
  });

  // 9. Build RDL
  app.post("/api/rdl", (req, res) => {
    const { plan, sql, layout, title } = req.body;
    if (!plan) {
      res.status(400).json({ detail: "نقشه الزامی است." });
      return;
    }
    const finalSql = sql || SqlAssembler.build(plan);
    const rdlXml = RdlBuilder.buildRdl(plan, finalSql, layout, { reportTitle: title });
    const filename = `report-${Date.now()}.rdl`;
    const filePath = path.join(downloadsDir, filename);
    fs.writeFileSync(filePath, rdlXml, "utf-8");

    const validation = RdlBuilder.validateRdl(rdlXml);

    res.json({
      ok: validation.ok,
      filename,
      size: Buffer.byteLength(rdlXml, "utf-8"),
      xml: rdlXml,
      warnings: validation.issues,
      fieldsCount: plan.select?.length || 0,
      parametersCount: plan.parameters?.length || 0,
    });
  });

  // 10. Download file
  app.get("/api/download/:name", (req, res) => {
    const filename = path.basename(req.params.name);
    const filePath = path.join(downloadsDir, filename);
    if (!fs.existsSync(filePath)) {
      res.status(404).send("File not found");
      return;
    }
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Content-Type", "application/octet-stream");
    fs.createReadStream(filePath).pipe(res);
  });

  // 11. Upload file
  app.post("/api/upload", (req, res) => {
    const { filename, content } = req.body;
    const name = filename || `upload-${Date.now()}`;
    const filePath = path.join(downloadsDir, name);
    if (content) {
      fs.writeFileSync(filePath, content, "utf-8");
    }
    res.json({
      success: true,
      path: filePath,
      filename: name,
      size: content ? Buffer.byteLength(content, "utf-8") : 0,
    });
  });

  // 12. Save report to catalog
  app.post("/api/save-report", (req, res) => {
    const saved = catalog.saveReport(req.body);
    res.json(saved);
  });

  // 13. Reports list
  app.get("/api/reports", (req, res) => {
    const category = req.query.category ? String(req.query.category) : undefined;
    const q = req.query.q ? String(req.query.q) : undefined;
    const results = catalog.getAll(category, q);
    res.json({ results, count: results.length });
  });

  // 14. Single report
  app.get("/api/reports/:slug", (req, res) => {
    const rep = catalog.getBySlug(req.params.slug);
    if (!rep) {
      res.status(404).json({ detail: "گزارش یافت نشد." });
      return;
    }
    res.json(rep);
  });

  // 15. Download report as format
  app.get("/api/reports/:slug/file/:fmt", (req, res) => {
    const slug = req.params.slug;
    const fmt = req.params.fmt as "sql" | "txt" | "rdl";
    const file = catalog.generateFile(slug, fmt);
    if (!file) {
      res.status(404).send("Report or format not found");
      return;
    }
    res.setHeader("Content-Disposition", `attachment; filename="${encodeURIComponent(file.filename)}"`);
    res.setHeader("Content-Type", file.contentType);
    res.send(file.content);
  });

  // 16. Categories
  app.get("/api/categories", (req, res) => {
    res.json({ categories: catalog.getCategories() });
  });

  // 17. Set report category
  app.post("/api/reports/:slug/category", (req, res) => {
    const ok = catalog.setCategory(req.params.slug, req.body.category || "");
    if (!ok) {
      res.status(404).json({ detail: "گزارش یافت نشد." });
      return;
    }
    res.json({ success: true });
  });

  // 18. Check RDL
  app.post("/api/check-rdl", (req, res) => {
    const { xml } = req.body;
    const validation = RdlBuilder.validateRdl(xml || "");
    res.json(validation);
  });

  // 19. Profile
  app.get("/api/profile", (req, res) => {
    res.json(profileStore.get());
  });

  // 20. Learn profile
  app.post("/api/profile/learn", (req, res) => {
    const paths = req.body.paths || [];
    const result = profileStore.learn(paths);
    res.json(result);
  });

  // 21. Rebuild index
  app.post("/api/index/rebuild", (req, res) => {
    kb.reload();
    catalog.loadAll();
    const stats = kb.getStats();
    res.json({
      success: true,
      message: "ایندکس پایگاه دانش و کاتالوگ با موفقیت بازسازی شد.",
      tables: stats.tables,
      joins: stats.joins,
    });
  });

  // 22. Index state
  app.get("/api/index/state", (req, res) => {
    const stats = kb.getStats();
    res.json({
      status: "ready",
      tables_count: stats.tables,
      joins_count: stats.joins,
      last_updated: new Date().toISOString(),
    });
  });

  // 23. Layout preview
  app.post("/api/layout/preview", (req, res) => {
    const { plan, layout } = req.body;
    res.json({
      columns: plan?.select?.map((s: any) => s.alias || s.column) || [],
      layout: layout || { kind: "table" },
    });
  });

  // 24. Knowledge writer
  app.post("/api/knowledge", (req, res) => {
    const { kind, payload } = req.body;
    if (kind === "lesson" && payload?.slug && payload?.lesson) {
      catalog.addLesson(payload.slug, payload.lesson);
    } else {
      kb.addKnowledge(kind, payload);
    }
    res.json({ success: true });
  });

  // 25. Settings
  app.get("/api/settings", (req, res) => {
    const s = settingsStore.getSettings();
    const profiles = userProfileStore.getAll();
    const def = userProfileStore.getDefault();
    res.json({
      ...s,
      profiles,
      active_profile_id: def?.id || "",
    });
  });

  app.post("/api/settings", (req, res) => {
    const updated = settingsStore.update(req.body);
    if (req.body.active_profile_id) {
      userProfileStore.setDefault(req.body.active_profile_id);
    }
    const profiles = userProfileStore.getAll();
    const def = userProfileStore.getDefault();
    res.json({
      ...updated,
      profiles,
      active_profile_id: def?.id || "",
    });
  });

  // 26. Test Model Connection (Gemini, Claude, GPT, DeepSeek, Local)
  app.post("/api/test-model", async (req, res) => {
    try {
      const result = await LLMService.testConnection();
      res.json(result);
    } catch (err: any) {
      res.json({
        ok: false,
        success: false,
        provider: "Unknown",
        model: "Unknown",
        reply: "",
        latency_ms: 0,
        mode: "heuristic",
        error: err?.message || String(err),
      });
    }
  });

  // 26.1 User Personal Profiles (Favorite Columns & Custom Layouts / Matrix Models)
  app.get("/api/user-profiles", (req, res) => {
    const profiles = userProfileStore.getAll();
    const def = userProfileStore.getDefault();
    res.json({
      profiles,
      active_id: def?.id || "",
      default_profile: def,
    });
  });

  app.post("/api/user-profiles", (req, res) => {
    const profile = userProfileStore.save(req.body);
    res.json({
      success: true,
      profile,
      profiles: userProfileStore.getAll(),
      active_id: userProfileStore.getDefault()?.id || "",
    });
  });

  app.delete("/api/user-profiles/:id", (req, res) => {
    const ok = userProfileStore.delete(req.params.id);
    res.json({
      success: ok,
      profiles: userProfileStore.getAll(),
      active_id: userProfileStore.getDefault()?.id || "",
    });
  });

  app.post("/api/user-profiles/:id/set-default", (req, res) => {
    const ok = userProfileStore.setDefault(req.params.id);
    res.json({
      success: ok,
      profiles: userProfileStore.getAll(),
      active_id: req.params.id,
    });
  });

  // 26.2 Comprehensive Settings & System Diagnostics
  app.post("/api/settings/diagnostics", async (req, res) => {
    const start = Date.now();
    const kbStats = kb.getStats();
    const catalogStats = catalog.stats();
    const modelTest = await LLMService.testConnection();
    const profiles = userProfileStore.getAll();
    const defProfile = userProfileStore.getDefault();
    const activePreset = settingsStore.getRawSettings().model_preset;

    res.json({
      ok: true,
      timestamp: new Date().toISOString(),
      duration_ms: Date.now() - start,
      diagnostics: {
        database_kb: {
          title: "پایگاه دانش اسکیما و ارتباطات (Knowledge Base)",
          status: kbStats.tables > 0 ? "healthy" : "warning",
          tables_count: kbStats.tables,
          joins_count: kbStats.joins,
          message: `${kbStats.tables} جدول پایگاه‌داده و ${kbStats.joins} مسیر اتصال آماده تحلیل و کوئری‌سازی است.`,
        },
        model_connection: {
          title: "اتصال مدل هوش مصنوعی (AI Model Connection)",
          status: modelTest.ok ? "healthy" : "warning",
          provider: modelTest.provider,
          model: modelTest.model,
          active_preset: activePreset,
          latency_ms: modelTest.latency_ms,
          message: modelTest.reply || modelTest.error,
        },
        catalog_and_rdl: {
          title: "موتور کاتالوگ و اعتبارسنجی RDL",
          status: "healthy",
          reports_count: catalogStats.total || 0,
          categories_count: catalog.getCategories().length,
          message: `موتور گزارش‌ساز فعال و آماده خروجی استاندارد RDL سازمانی است.`,
        },
        user_profiles: {
          title: "پروفایل‌های شخصی کاربر و مدل‌های ماتریسی",
          status: profiles.length > 0 ? "healthy" : "warning",
          profiles_count: profiles.length,
          active_default: defProfile?.name || "بدون پیش‌فرض",
          message: `تعداد ${profiles.length} پروفایل شخصی با ستون‌های مورد علاقه و تنظیمات ماتریسی لود شده است.`,
        },
      },
    });
  });

  // 27. Benchmarking (SSE Stream)
  app.post("/api/bench", async (req, res) => {
    const { requests, models } = req.body || {};

    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();

    const sendEvent = (event: string, data: any) => {
      res.write(`event: ${event}\n`);
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    try {
      await runBenchmark(requests, models, sendEvent);
    } catch (err: any) {
      sendEvent("error", { message: err?.message || "خطا در اجرای بنچمارک" });
    } finally {
      res.end();
    }
  });

  app.get("/api/bench/last", (req, res) => {
    res.json(getLastBenchmark() || { results: null });
  });

  // 28. Sessions
  app.get("/api/sessions", (req, res) => {
    res.json({ sessions: sessionStore.list() });
  });

  app.get("/api/sessions/:sid", (req, res) => {
    const s = sessionStore.get(req.params.sid);
    if (!s) {
      res.status(404).json({ detail: "جلسه یافت نشد." });
      return;
    }
    res.json(s);
  });

  app.delete("/api/sessions/:sid", (req, res) => {
    sessionStore.delete(req.params.sid);
    res.json({ success: true });
  });

  // 29. Gemini Chatbot Roles
  app.get("/api/gemini/roles", (req, res) => {
    res.json({ roles: Object.values(CHATBOT_ROLES) });
  });

  // 30. Gemini Multi-Turn Chatbot
  app.post("/api/gemini/chat", async (req, res) => {
    const { messages, model, roleKey, customInstruction, stream } = req.body;
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ detail: "تاریخچه پیام‌ها الزامی است." });
      return;
    }

    if (stream) {
      res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.flushHeaders?.();

      const sendEvent = (event: string, data: any) => {
        res.write(`event: ${event}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
      };

      try {
        const result = await executeMultiTurnChat({
          messages,
          model,
          roleKey: roleKey as RoleKey,
          customInstruction,
          onChunk: (chunk) => {
            sendEvent("chunk", { text: chunk });
          },
        });
        sendEvent("done", { fullText: result.text, model: result.model });
      } catch (err: any) {
        sendEvent("error", { message: err?.message || "خطا در پردازش چت" });
      } finally {
        res.end();
      }
    } else {
      try {
        const result = await executeMultiTurnChat({
          messages,
          model,
          roleKey: roleKey as RoleKey,
          customInstruction,
        });
        res.json({ success: true, text: result.text, model: result.model });
      } catch (err: any) {
        res.status(500).json({ detail: err?.message || "خطا در برقراری ارتباط با چت هوشمند جِمینای" });
      }
    }
  });

  // 31. Gemini Image Generation & Editing (gemini-3.1-flash-image-preview)
  app.post("/api/gemini/image", async (req, res) => {
    const { action, prompt, image, mimeType, aspectRatio } = req.body;
    if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
      res.status(400).json({ detail: "متن توصیفی (پرامپت) برای تصویر الزامی است." });
      return;
    }

    if (action === "edit" && !image) {
      res.status(400).json({ detail: "برای ویرایش تصویر، ارسال تصویر اولیه الزامی است." });
      return;
    }

    try {
      const result = await executeImageGenerationOrEditing({
        action: action === "edit" ? "edit" : "create",
        prompt: prompt.trim(),
        image,
        mimeType,
        aspectRatio,
      });
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ detail: err?.message || "خطا در پردازش تصویر" });
    }
  });

  // 32. List cached generated images
  app.get("/api/gemini/images", (req, res) => {
    try {
      if (!fs.existsSync(downloadsDir)) {
        res.json({ images: [] });
        return;
      }
      const files = fs.readdirSync(downloadsDir);
      const imgFiles = files
        .filter((f) => f.startsWith("img-") && (f.endsWith(".png") || f.endsWith(".jpg")))
        .sort((a, b) => {
          const statA = fs.statSync(path.join(downloadsDir, a));
          const statB = fs.statSync(path.join(downloadsDir, b));
          return statB.mtimeMs - statA.mtimeMs;
        })
        .slice(0, 30)
        .map((f) => {
          const stat = fs.statSync(path.join(downloadsDir, f));
          return {
            filename: f,
            url: `/api/download/${f}`,
            size: stat.size,
            createdAt: stat.mtime.toISOString(),
          };
        });
      res.json({ images: imgFiles });
    } catch {
      res.json({ images: [] });
    }
  });

  // ──────────────────────── FRONTEND SERVING ────────────────────────

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Report Builder Assistant server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
