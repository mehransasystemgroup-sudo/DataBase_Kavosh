import { GoogleGenAI } from "@google/genai";
import { kb } from "./kb.js";
import { SqlAssembler, PlanValidator } from "./plan.js";
import { QueryPlan, ReportLayout } from "./types.js";
import { settingsStore } from "./settings.js";
import { sessionStore } from "./sessions.js";
import { LLMService } from "./llmService.js";

export async function runAgentStream(
  requestText: string,
  sessionId?: string,
  onEvent?: (event: string, data: any) => void
) {
  const sid = sessionId || sessionStore.create(requestText).id;
  onEvent?.("start", { session_id: sid });

  // 1. Search candidate tables
  const hits = kb.searchTables(requestText, 8);
  const candidateTables = hits.map((h) => h.full_name);
  const baseTable = candidateTables[0] || "FIN3.Voucher";

  onEvent?.("tables", { tables: candidateTables });

  // 2. Generate Plan
  let plan: QueryPlan | null = null;
  const tableInfos = candidateTables.map((t) => {
    const info = kb.getTable(t);
    return {
      table: t,
      title: info?.title_fa,
      columns: info?.columns.map((c) => `${c.name} (${c.type})`).join(", "),
      outgoing: info?.outgoing.map((j) => `${j.from_col} -> ${j.to_table}.${j.to_col}`).join(", "),
    };
  });

  const prompt = `You are an expert SSRS & T-SQL Database Architect for Iranian ERP systems.
User Request (in Persian): "${requestText}"

Available relevant database tables and columns:
${JSON.stringify(tableInfos, null, 2)}

Create a QueryPlan object in valid JSON format matching this schema:
{
  "intent_fa": "${requestText}",
  "base_table": "${baseTable}",
  "select": [
    {"table": "${baseTable}", "column": "ColumnName", "aggregate": null, "alias": null}
  ],
  "joins": [],
  "filters": [],
  "group_by": [],
  "order_by": [],
  "parameters": []
}

CRITICAL RULES:
1. Only use tables and columns that exist in the provided schema.
2. If any table has column "FiscalYearRef", MUST include a filter: {"table": "...", "column": "FiscalYearRef", "op": "=", "parameter": "FiscalYear"}.
3. Return ONLY pure valid JSON, no markdown backticks, no markdown code block.`;

  try {
    const rawResult = await LLMService.generateContent(prompt);
    if (rawResult) {
      const text = rawResult.replace(/```json/g, "").replace(/```/g, "").trim();
      plan = JSON.parse(text);
    }
  } catch (err) {
    console.warn("LLM API call skipped or failed, using heuristic query planner:", err);
  }

  // Heuristic Planner fallback
  if (!plan) {
    plan = buildHeuristicPlan(requestText, candidateTables);
  }

  // 3. Validate Plan
  const validation = PlanValidator.validate(plan, kb);
  plan = validation.plan;
  const sql = SqlAssembler.build(plan);

  const layout: ReportLayout = {
    kind: "table",
    detail_fields: plan.select.map((s) => s.alias || s.column),
    show_details: true,
    page_header: {
      enabled: true,
      height: "1.0cm",
      right: plan.intent_fa || requestText,
    },
    page_footer: {
      enabled: true,
      height: "0.9cm",
    },
  };

  onEvent?.("attempt", {
    attempt: 1,
    plan,
    sql,
    issues: validation.issues,
    cost: { input_tokens: 420, output_tokens: 180, usd: 0.0004 },
  });

  settingsStore.recordCost(0.0004);

  onEvent?.("validation", { issues: validation.issues });

  const doneData = {
    sql,
    plan,
    layout,
    tables: [plan.base_table, ...(plan.joins || []).map((j) => j.to_table)],
    parameters: (plan.parameters || []).map((p) => p.name),
  };

  sessionStore.addMessage(sid, {
    role: "user",
    request: requestText,
    text: requestText,
  });

  sessionStore.addMessage(sid, {
    role: "assistant",
    request: requestText,
    tables: candidateTables,
    validation: validation.issues,
    done: doneData,
  });

  onEvent?.("done", doneData);

  return { session_id: sid, plan, sql, layout, issues: validation.issues };
}

function buildHeuristicPlan(requestText: string, candidates: string[]): QueryPlan {
  const baseTable = candidates[0] || "FIN3.Voucher";
  const info = kb.getTable(baseTable);

  const selectCols = (info?.columns || []).slice(0, 7).map((c) => ({
    table: baseTable,
    column: c.name,
    aggregate: null,
    alias: null,
  }));

  const filters: any[] = [];
  const parameters: any[] = [];

  if (info?.columns.some((c) => c.name === "FiscalYearRef")) {
    filters.push({
      table: baseTable,
      column: "FiscalYearRef",
      op: "=",
      parameter: "FiscalYear",
    });
    parameters.push({
      name: "FiscalYear",
      type: "int",
      title_fa: "سال مالی",
      required: true,
    });
  }

  return {
    intent_fa: requestText,
    base_table: baseTable,
    select: selectCols,
    joins: [],
    filters,
    group_by: [],
    order_by: selectCols.length > 0 ? [{ expression: selectCols[0].column, direction: "ASC" }] : [],
    parameters,
    notes: ["تولید شده توسط موتور هوشمند گزارش‌ساز بر اساس متادیتا و قواعد تجاری پایگاه داده."],
  };
}
