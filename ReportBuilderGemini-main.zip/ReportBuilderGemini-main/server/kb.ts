import fs from "fs";
import path from "path";
import yaml from "js-yaml";
import { TableInfo, TableHit, TableSearchParams, JoinStep, EnumEntry, TableIndex, TableColumn } from "./types.js";

function matchColumnType(columns: TableColumn[], fieldType: string): { matched: boolean; cols: Array<{ name: string; type: string }> } {
  if (!fieldType || !fieldType.trim()) return { matched: true, cols: [] };
  const target = fieldType.trim().toLowerCase();
  const matchedCols: Array<{ name: string; type: string }> = [];

  for (const col of columns || []) {
    const cType = (col.type || "").toLowerCase();
    let isMatch = false;

    if (target === "int" || target === "integer" || target === "numeric_int") {
      isMatch = /\b(int|bigint|smallint|tinyint)\b/i.test(cType);
    } else if (target === "decimal" || target === "numeric" || target === "money" || target === "float" || target === "numeric_dec") {
      isMatch = /\b(decimal|numeric|money|smallmoney|float|real)\b/i.test(cType);
    } else if (target === "varchar" || target === "text" || target === "string" || target === "nvarchar") {
      isMatch = /\b(varchar|nvarchar|text|ntext|char|nchar|string)\b/i.test(cType);
    } else if (target === "datetime" || target === "date" || target === "time") {
      isMatch = /\b(datetime|date|time|smalldatetime|datetime2|datetimeoffset|timestamp)\b/i.test(cType);
    } else if (target === "bit" || target === "boolean" || target === "bool") {
      isMatch = /\b(bit|bool|boolean)\b/i.test(cType);
    } else if (target === "guid" || target === "uuid" || target === "uniqueidentifier") {
      isMatch = /\b(uniqueidentifier|guid|uuid)\b/i.test(cType);
    } else if (target === "binary" || target === "image" || target === "varbinary") {
      isMatch = /\b(binary|varbinary|image)\b/i.test(cType);
    } else {
      isMatch = cType.includes(target);
    }

    if (isMatch) {
      matchedCols.push({ name: col.name, type: col.type });
    }
  }

  return {
    matched: matchedCols.length > 0,
    cols: matchedCols.slice(0, 5),
  };
}

function normalizePersian(text: string): string {
  if (!text) return "";
  return text
    .replace(/[\u200B-\u200D\uFEFF]/g, " ") // Zero width spaces
    .replace(/[ي]/g, "ی")
    .replace(/[ك]/g, "ک")
    .replace(/[ة]/g, "ه")
    .replace(/[أإآ]/g, "ا")
    .replace(/[ؤ]/g, "و")
    .replace(/[ئ]/g, "ی")
    .replace(/[\u064B-\u065F]/g, "") // Tashkeel
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function stemFa(token: string): string {
  const t = normalizePersian(token);
  const suffixes = ["های", "ها", "ان", "ات", "ی", "ین", "گان", "ندگان", "مند"];
  for (const s of suffixes) {
    if (t.length > s.length + 2 && t.endsWith(s)) {
      return t.slice(0, -s.length);
    }
  }
  return t;
}

function safeParseJson<T>(rawText: string, fallback: T): T {
  if (!rawText) return fallback;
  try {
    let text = rawText.charCodeAt(0) === 0xfeff ? rawText.slice(1) : rawText;
    // Strip illegal raw control characters that break JSON standard inside strings
    text = text.replace(/[\u0000-\u0009\u000B-\u000C\u000E-\u001F]/g, "");
    return JSON.parse(text) as T;
  } catch {
    return fallback;
  }
}

export class KnowledgeBase {
  private tables: Map<string, TableInfo> = new Map();
  private joins: JoinStep[] = [];
  private adjacency: Map<string, Array<{ to: string; fromCol: string; toCol: string; conf: string; verified: boolean; fwd: boolean }>> = new Map();
  private kbPath: string;
  private dbMetaPath: string;
  private instancesPath: string;

  constructor() {
    const cwd = process.cwd();
    this.kbPath = path.join(cwd, "backend", "rc", "kb");
    this.dbMetaPath = path.join(cwd, "backend", "rc", "db-meta");
    this.instancesPath = path.join(cwd, "backend", "rc", "instances");
    this.loadAll();
  }

  public reload() {
    this.tables.clear();
    this.joins = [];
    this.adjacency.clear();
    this.loadAll();
  }

  private loadAll() {
    const tableStats: Record<string, number> = {};
    const fixtureStats = path.join(this.instancesPath, "dev-fixture", "table-stats.yaml");
    if (fs.existsSync(fixtureStats)) {
      try {
        const statsDoc: any = yaml.load(fs.readFileSync(fixtureStats, "utf-8"));
        if (statsDoc?.tables) {
          for (const [k, v] of Object.entries(statsDoc.tables)) {
            tableStats[k] = Number(v) || 0;
          }
        }
      } catch (e) {
        console.error("Error loading table-stats.yaml", e);
      }
    }

    // 1. Structure files
    const structDir = path.join(this.kbPath, "structure");
    if (fs.existsSync(structDir)) {
      const files = fs.readdirSync(structDir).filter((f) => f.endsWith(".yaml") || f.endsWith(".yml"));
      for (const file of files) {
        try {
          const doc: any = yaml.load(fs.readFileSync(path.join(structDir, file), "utf-8"));
          const schema = doc.schema || file.replace(/\.ya?ml$/, "");
          if (Array.isArray(doc.tables)) {
            for (const t of doc.tables) {
              const fullName = `${schema}.${t.name}`;
              const cols: TableColumn[] = (t.columns || []).map((c: any) => ({
                name: c.name,
                type: c.type || "nvarchar(max)",
                nullable: c.nullable !== false,
                is_pk: Boolean(c.is_pk),
                ordinal: c.ordinal,
              }));
              const pk = cols.filter((c) => c.is_pk).map((c) => c.name);
              const rowCount = tableStats[fullName] ?? (t.row_count ?? null);
              const hasData = rowCount !== null ? rowCount > 0 : false;

              const tableInfo: TableInfo = {
                full_name: fullName,
                schema,
                name: t.name,
                title_fa: t.title_fa || "",
                description_fa: t.description_fa || "",
                kind: t.kind || "table",
                row_count: rowCount,
                has_data: hasData,
                in_live_db: 1,
                n_cols: cols.length,
                columns: cols,
                primary_key: pk,
                outgoing: [],
                incoming: [],
                enums: {},
                indexes: [],
                warnings: [],
              };
              this.tables.set(fullName, tableInfo);
            }
          }
        } catch (err) {
          console.error(`Failed parsing structure ${file}:`, err);
        }
      }
    }

    // 2. Semantics files (titles, descriptions, Persian names)
    const semDir = path.join(this.kbPath, "semantics");
    if (fs.existsSync(semDir)) {
      const files = fs.readdirSync(semDir).filter((f) => f.endsWith(".yaml") || f.endsWith(".yml"));
      for (const file of files) {
        try {
          const doc: any = yaml.load(fs.readFileSync(path.join(semDir, file), "utf-8"));
          const schema = doc.schema || file.replace(/\.ya?ml$/, "");
          if (Array.isArray(doc.tables)) {
            for (const t of doc.tables) {
              const fullName = `${schema}.${t.name}`;
              const existing = this.tables.get(fullName);
              if (existing) {
                if (t.title_fa) existing.title_fa = t.title_fa;
                if (t.description_fa) existing.description_fa = t.description_fa;
                if (t.kind) existing.kind = t.kind;
              }
            }
          }
        } catch (err) {
          console.error(`Failed parsing semantics ${file}:`, err);
        }
      }
    }

    // 3. Enums
    const enumDir = path.join(this.kbPath, "enums");
    if (fs.existsSync(enumDir)) {
      const files = fs.readdirSync(enumDir).filter((f) => f.endsWith(".yaml") || f.endsWith(".yml"));
      for (const file of files) {
        try {
          const doc: any = yaml.load(fs.readFileSync(path.join(enumDir, file), "utf-8"));
          if (Array.isArray(doc.enums || doc)) {
            const list = Array.isArray(doc.enums) ? doc.enums : doc;
            for (const e of list) {
              const tableRef = e.table_ref || `${doc.schema}.${e.table}`;
              const tbl = this.tables.get(tableRef);
              if (tbl) {
                const col = e.column || e.col;
                if (!tbl.enums[col]) tbl.enums[col] = [];
                tbl.enums[col].push({
                  value: String(e.value),
                  label_fa: e.label_fa || e.title_fa,
                  confidence: e.confidence || "high",
                  observed: e.observed,
                });
              }
            }
          }
        } catch (err) {
          console.error(`Failed parsing enums ${file}:`, err);
        }
      }
    }

    // 4. Indexes
    const idxDir = path.join(this.kbPath, "indexes");
    if (fs.existsSync(idxDir)) {
      const files = fs.readdirSync(idxDir).filter((f) => f.endsWith(".yaml") || f.endsWith(".yml"));
      for (const file of files) {
        try {
          const doc: any = yaml.load(fs.readFileSync(path.join(idxDir, file), "utf-8"));
          if (Array.isArray(doc.indexes)) {
            for (const idx of doc.indexes) {
              const tableRef = idx.table_ref || `${doc.schema}.${idx.table}`;
              const tbl = this.tables.get(tableRef);
              if (tbl) {
                tbl.indexes.push({
                  name: idx.name,
                  columns: Array.isArray(idx.columns) ? idx.columns : (idx.columns || "").split(","),
                  unique: Boolean(idx.unique || idx.is_unique),
                  is_pk: Boolean(idx.is_pk),
                });
              }
            }
          }
        } catch (err) {
          console.error(`Failed parsing indexes ${file}:`, err);
        }
      }
    }

    // 5. Joins - user-verified, corrections, and structure inference
    const userVerifiedFile = path.join(this.kbPath, "joins", "user-verified.yaml");
    if (fs.existsSync(userVerifiedFile)) {
      try {
        const doc: any = yaml.load(fs.readFileSync(userVerifiedFile, "utf-8"));
        if (Array.isArray(doc?.edges)) {
          for (const e of doc.edges) {
            const [fromTbl, fromCol] = [e.from.split(".").slice(0, 2).join("."), e.from.split(".")[2]];
            const [toTbl, toCol] = [e.to.split(".").slice(0, 2).join("."), e.to.split(".")[2]];
            if (fromTbl && fromCol && toTbl && toCol) {
              this.joins.push({
                from_table: fromTbl,
                from_col: fromCol,
                to_table: toTbl,
                to_col: toCol,
                confidence: e.confidence || "high",
                verified: true,
              });
            }
          }
        }
      } catch (err) {
        console.error("Error reading user-verified.yaml", err);
      }
    }

    // Load Primary Keys map from db-meta/primaryKeys.json
    const pkFile = path.join(this.dbMetaPath, "primaryKeys.json");
    const pkMap = new Map<string, string>(); // schema.table -> pk_column
    if (fs.existsSync(pkFile)) {
      try {
        const raw = fs.readFileSync(pkFile, "utf-8");
        const pks = safeParseJson<any[]>(raw, []);
        if (Array.isArray(pks)) {
          for (const item of pks) {
            if (item.schema && item.table && item.pk_columns) {
              const fullKey = `${item.schema}.${item.table}`;
              pkMap.set(fullKey, item.pk_columns);
              const tbl = this.tables.get(fullKey);
              if (tbl && !tbl.primary_key.includes(item.pk_columns)) {
                tbl.primary_key.push(item.pk_columns);
              }
            }
          }
        }
      } catch (err) {
        console.warn("Could not parse primaryKeys.json:", err);
      }
    }

    // Load clean indexes and real DB metadata if available
    const cleanIdxFile = path.join(this.dbMetaPath, "indexes.clean.json");
    if (fs.existsSync(cleanIdxFile)) {
      try {
        const raw = fs.readFileSync(cleanIdxFile, "utf-8");
        const cleanIndexes = safeParseJson<any[]>(raw, []);
        if (Array.isArray(cleanIndexes)) {
          for (const ix of cleanIndexes) {
            if (ix.schema && ix.table) {
              const fullName = `${ix.schema}.${ix.table}`;
              const tbl = this.tables.get(fullName);
              if (tbl) {
                const cols = (ix.key_columns || "").split(",").map((c: string) => c.trim()).filter(Boolean);
                if (ix.is_pk) {
                  for (const pkCol of cols) {
                    if (!tbl.primary_key.includes(pkCol)) {
                      tbl.primary_key.push(pkCol);
                    }
                  }
                  if (!pkMap.has(fullName) && cols.length > 0) {
                    pkMap.set(fullName, cols.join(","));
                  }
                }
                tbl.indexes.push({
                  name: ix.index_name || "",
                  type: ix.index_type || "",
                  columns: cols,
                  unique: Boolean(ix.is_unique),
                  is_pk: Boolean(ix.is_pk),
                });
              }
            }
          }
        }
      } catch (err) {
        console.warn("Could not parse indexes.clean.json:", err);
      }
    }

    // Auto-infer foreign keys based on naming conventions:
    // e.g. Column `PartyRef` -> `GNR3.Party.PartyID`, `AccountRef` -> `FIN3.Account.AccountID`
    for (const [tblName, tbl] of this.tables.entries()) {
      for (const col of tbl.columns) {
        if (col.name.endsWith("Ref")) {
          const targetEntity = col.name.slice(0, -3); // e.g. "Account", "Voucher", "Party"
          
          // Check same schema first
          const sameSchemaTarget = `${tbl.schema}.${targetEntity}`;
          const targetTbl = this.tables.get(sameSchemaTarget) ||
            Array.from(this.tables.values()).find((t) => t.name.toLowerCase() === targetEntity.toLowerCase());

          if (targetTbl) {
            const targetPk = pkMap.get(targetTbl.full_name) ||
              targetTbl.primary_key[0] ||
              targetTbl.columns.find((c) => c.name.toLowerCase() === `${targetEntity.toLowerCase()}id`)?.name ||
              `${targetEntity}ID`;

            const exists = this.joins.some(
              (j) => j.from_table === tblName && j.from_col === col.name && j.to_table === targetTbl.full_name
            );

            if (!exists) {
              this.joins.push({
                from_table: tblName,
                from_col: col.name,
                to_table: targetTbl.full_name,
                to_col: targetPk,
                confidence: "inferred",
                verified: false,
              });
            }
          }
        }
      }
    }

    // Also check lookups from db-meta (only include items that define foreign table joins)
    const lookupsFile = path.join(this.dbMetaPath, "lookups.json");
    if (fs.existsSync(lookupsFile)) {
      try {
        const raw = fs.readFileSync(lookupsFile, "utf-8");
        const lookups = safeParseJson<any[]>(raw, []);
        if (Array.isArray(lookups)) {
          for (const j of lookups) {
            if (j.from_table && j.from_col && j.to_table && j.to_col) {
              this.joins.push({
                from_table: j.from_table,
                from_col: j.from_col,
                to_table: j.to_table,
                to_col: j.to_col,
                confidence: j.confidence || "high",
                verified: j.verified ?? true,
              });
            }
          }
        }
      } catch (err) {
        console.warn("Could not parse lookups.json:", err);
      }
    }

    // Populate table joins and build adjacency
    for (const j of this.joins) {
      const fromTbl = this.tables.get(j.from_table);
      if (fromTbl && !fromTbl.outgoing.some((x) => x.from_col === j.from_col && x.to_table === j.to_table && x.to_col === j.to_col)) {
        fromTbl.outgoing.push(j);
      }
      const toTbl = this.tables.get(j.to_table);
      if (toTbl && !toTbl.incoming.some((x) => x.from_table === j.from_table && x.from_col === j.from_col && x.to_col === j.to_col)) {
        toTbl.incoming.push(j);
      }

      // Adjacency graph
      if (!this.adjacency.has(j.from_table)) this.adjacency.set(j.from_table, []);
      if (!this.adjacency.has(j.to_table)) this.adjacency.set(j.to_table, []);

      this.adjacency.get(j.from_table)!.push({
        to: j.to_table,
        fromCol: j.from_col,
        toCol: j.to_col,
        conf: j.confidence,
        verified: j.verified,
        fwd: true,
      });

      this.adjacency.get(j.to_table)!.push({
        to: j.from_table,
        fromCol: j.to_col,
        toCol: j.from_col,
        conf: j.confidence,
        verified: j.verified,
        fwd: false,
      });
    }

    // Set warnings for tables
    for (const tbl of this.tables.values()) {
      tbl.warnings = [];
      if (!tbl.has_data) {
        tbl.warnings.push("این جدول در نصب فعلی داده ندارد — احتمالاً ماژولش خریداری نشده.");
      }
      if (tbl.columns.some((c) => c.name === "FiscalYearRef")) {
        tbl.warnings.push("ستون FiscalYearRef دارد — فیلتر سال مالی الزامی است، وگرنه خروجی بی‌خطا ولی غلط می‌شود.");
      }
      const weak = tbl.outgoing.filter((j) => !j.verified);
      if (weak.length > 0) {
        tbl.warnings.push(`${weak.length} مسیر JOIN از این جدول تأییدنشده است (استنتاج از نام).`);
      }
    }
  }

  public getStats() {
    return {
      tables: this.tables.size,
      joins: this.joins.length,
      schemas: Array.from(new Set(Array.from(this.tables.values()).map((t) => t.schema))).sort(),
    };
  }

  public getSchemaList(): Array<{ schema: string; tableCount: number; tablesWithDataCount: number; relationshipsCount: number }> {
    const counts = new Map<string, { tableCount: number; tablesWithDataCount: number; relationshipsCount: number }>();
    for (const t of this.tables.values()) {
      const entry = counts.get(t.schema) || { tableCount: 0, tablesWithDataCount: 0, relationshipsCount: 0 };
      entry.tableCount++;
      if (t.has_data) entry.tablesWithDataCount++;
      entry.relationshipsCount += (t.outgoing?.length || 0);
      counts.set(t.schema, entry);
    }
    return Array.from(counts.entries())
      .map(([schema, data]) => ({
        schema,
        ...data,
      }))
      .sort((a, b) => b.tableCount - a.tableCount);
  }

  public getSchemaGraph(
    schema: string,
    options: {
      includeExternal?: boolean;
      onlyWithData?: boolean;
      maxNodes?: number;
      searchQuery?: string;
    } = {}
  ) {
    const { includeExternal = true, onlyWithData = false, maxNodes = 60, searchQuery = "" } = options;
    const schemaNorm = schema.trim().toUpperCase();

    // 1. Find primary candidate tables for this schema
    let primaryTables = Array.from(this.tables.values()).filter((t) => t.schema.toUpperCase() === schemaNorm);

    if (onlyWithData) {
      primaryTables = primaryTables.filter((t) => t.has_data);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      primaryTables = primaryTables.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.full_name.toLowerCase().includes(q) ||
          (t.title_fa && t.title_fa.toLowerCase().includes(q))
      );
    }

    // Sort by importance: has_data, degree, row count
    primaryTables.sort((a, b) => {
      const degA = (a.outgoing?.length || 0) + (a.incoming?.length || 0);
      const degB = (b.outgoing?.length || 0) + (b.incoming?.length || 0);
      if (a.has_data !== b.has_data) return a.has_data ? -1 : 1;
      if (degA !== degB) return degB - degA;
      return (b.row_count || 0) - (a.row_count || 0);
    });

    const totalInSchema = Array.from(this.tables.values()).filter((t) => t.schema.toUpperCase() === schemaNorm).length;
    const selectedPrimary = primaryTables.slice(0, maxNodes);
    const selectedSet = new Set(selectedPrimary.map((t) => t.full_name));

    const links: Array<{
      id: string;
      source: string;
      target: string;
      from_col: string;
      to_col: string;
      confidence: string;
      verified: boolean;
      isCrossSchema: boolean;
    }> = [];

    const linkKeySet = new Set<string>();
    const externalSet = new Set<string>();

    for (const tbl of selectedPrimary) {
      for (const j of tbl.outgoing || []) {
        const isTargetInSchema = j.to_table.toUpperCase().startsWith(schemaNorm + ".");
        if (selectedSet.has(j.to_table) || (includeExternal && this.tables.has(j.to_table))) {
          if (!selectedSet.has(j.to_table)) {
            externalSet.add(j.to_table);
          }
          const key = `${tbl.full_name}:${j.from_col}->${j.to_table}:${j.to_col}`;
          if (!linkKeySet.has(key)) {
            linkKeySet.add(key);
            links.push({
              id: key,
              source: tbl.full_name,
              target: j.to_table,
              from_col: j.from_col,
              to_col: j.to_col,
              confidence: j.confidence || "inferred",
              verified: Boolean(j.verified),
              isCrossSchema: !isTargetInSchema,
            });
          }
        }
      }

      for (const j of tbl.incoming || []) {
        const isSourceInSchema = j.from_table.toUpperCase().startsWith(schemaNorm + ".");
        if (selectedSet.has(j.from_table) || (includeExternal && this.tables.has(j.from_table))) {
          if (!selectedSet.has(j.from_table)) {
            externalSet.add(j.from_table);
          }
          const key = `${j.from_table}:${j.from_col}->${tbl.full_name}:${j.to_col}`;
          if (!linkKeySet.has(key)) {
            linkKeySet.add(key);
            links.push({
              id: key,
              source: j.from_table,
              target: tbl.full_name,
              from_col: j.from_col,
              to_col: j.to_col,
              confidence: j.confidence || "inferred",
              verified: Boolean(j.verified),
              isCrossSchema: !isSourceInSchema,
            });
          }
        }
      }
    }

    const nodes: Array<any> = [];

    for (const t of selectedPrimary) {
      const connCount = links.filter((l) => l.source === t.full_name || l.target === t.full_name).length;
      nodes.push({
        id: t.full_name,
        name: t.name,
        schema: t.schema,
        full_name: t.full_name,
        title_fa: t.title_fa || "",
        description_fa: t.description_fa || "",
        has_data: t.has_data,
        row_count: t.row_count,
        n_cols: t.n_cols || t.columns.length,
        primary_key: t.primary_key || [],
        degree: connCount,
        isCore: true,
        columns: t.columns.slice(0, 10).map((c) => ({ name: c.name, type: c.type, is_pk: c.is_pk })),
      });
    }

    const externalArray = Array.from(externalSet).slice(0, 20);
    for (const extName of externalArray) {
      const t = this.tables.get(extName);
      if (t) {
        const connCount = links.filter((l) => l.source === t.full_name || l.target === t.full_name).length;
        nodes.push({
          id: t.full_name,
          name: t.name,
          schema: t.schema,
          full_name: t.full_name,
          title_fa: t.title_fa || "",
          description_fa: t.description_fa || "",
          has_data: t.has_data,
          row_count: t.row_count,
          n_cols: t.n_cols || t.columns.length,
          primary_key: t.primary_key || [],
          degree: connCount,
          isCore: false,
          columns: t.columns.slice(0, 6).map((c) => ({ name: c.name, type: c.type, is_pk: c.is_pk })),
        });
      }
    }

    const nodeIds = new Set(nodes.map((n) => n.id));
    const validLinks = links.filter((l) => nodeIds.has(l.source) && nodeIds.has(l.target));

    return {
      schema: schemaNorm,
      totalInSchema,
      nodes,
      links: validLinks,
      stats: {
        totalSchemaTables: totalInSchema,
        nodesCount: nodes.length,
        primaryNodesCount: selectedPrimary.length,
        externalNodesCount: nodes.length - selectedPrimary.length,
        linksCount: validLinks.length,
        crossSchemaLinksCount: validLinks.filter((l) => l.isCrossSchema).length,
      },
    };
  }

  public searchTables(
    queryOrParams: string | TableSearchParams,
    limitParam = 20,
    schemaParam?: string,
    onlyWithDataParam = false
  ): TableHit[] {
    const params: TableSearchParams =
      typeof queryOrParams === "string"
        ? {
            query: queryOrParams,
            limit: limitParam,
            schema: schemaParam,
            onlyWithData: onlyWithDataParam,
          }
        : { ...queryOrParams };

    const query = params.query || "";
    const limit = Math.min(Math.max(Number(params.limit) || 20, 1), 200);
    const schema = params.schema && params.schema !== "ALL" ? params.schema.trim() : undefined;
    const fieldType = params.fieldType?.trim();
    const minRows =
      params.minRows !== undefined && params.minRows !== null && String(params.minRows) !== ""
        ? Number(params.minRows)
        : undefined;
    const maxRows =
      params.maxRows !== undefined && params.maxRows !== null && String(params.maxRows) !== ""
        ? Number(params.maxRows)
        : undefined;
    const dataStatus = params.dataStatus || (params.onlyWithData ? "with_data" : "all");
    const sortBy = params.sortBy || "score";
    const sortOrder = params.sortOrder || (sortBy === "name" ? "asc" : "desc");

    const qNorm = normalizePersian(query);
    const tokens = qNorm ? qNorm.split(" ").filter((w) => w.length > 1) : [];
    const stems = tokens.map(stemFa);
    const qCompact = qNorm ? qNorm.replace(/\s+/g, "") : "";

    const hits: Map<string, TableHit> = new Map();

    for (const tbl of this.tables.values()) {
      // 1. Filter by schema
      if (schema && tbl.schema !== schema) continue;

      // 2. Filter by presence / absence of data
      if (dataStatus === "with_data") {
        if (!tbl.has_data || (tbl.row_count ?? 0) <= 0) continue;
      } else if (dataStatus === "no_data") {
        if (tbl.has_data && (tbl.row_count ?? 0) > 0) continue;
      } else if (params.onlyWithData && !tbl.has_data) {
        continue;
      }

      // 3. Filter by row count range
      const rCount = tbl.row_count ?? 0;
      if (minRows !== undefined && !isNaN(minRows) && rCount < minRows) continue;
      if (maxRows !== undefined && !isNaN(maxRows) && rCount > maxRows) continue;

      // 4. Filter by column data type
      let typeMatchCols: Array<{ name: string; type: string }> = [];
      if (fieldType) {
        const typeCheck = matchColumnType(tbl.columns, fieldType);
        if (!typeCheck.matched) continue;
        typeMatchCols = typeCheck.cols;
      }

      // 5. Compute relevance and score
      let score = 0;
      const whys: string[] = [];

      if (fieldType && typeMatchCols.length > 0) {
        score += 20;
        whys.push(`فیلد نوع ${fieldType} (${typeMatchCols.map((c) => c.name).slice(0, 3).join(", ")})`);
      }

      if (minRows !== undefined || maxRows !== undefined) {
        whys.push(`${Number(rCount).toLocaleString("fa")} ردیف`);
      }

      if (qNorm) {
        const tblNameLower = tbl.name.toLowerCase();
        const titleNorm = normalizePersian(tbl.title_fa || "");
        const descNorm = normalizePersian(tbl.description_fa || "");

        if (tblNameLower === qCompact || tbl.full_name.toLowerCase() === qCompact) {
          score += 50;
          whys.push("نام دقیق");
        } else if (tblNameLower.includes(qCompact) || qCompact.includes(tblNameLower)) {
          score += 20;
          whys.push("نام نزدیک");
        }

        if (titleNorm === qNorm) {
          score += 45;
          whys.push("عنوان فارسی دقیق");
        } else if (titleNorm.includes(qNorm)) {
          score += 25;
          whys.push("عنوان شامل عبارت");
        }

        for (let i = 0; i < tokens.length; i++) {
          const tok = tokens[i];
          const stm = stems[i];
          if (titleNorm.includes(tok) || titleNorm.includes(stm)) {
            score += 15;
            whys.push(`تطابق کلمه «${tok}» در عنوان`);
          } else if (descNorm.includes(tok) || descNorm.includes(stm)) {
            score += 8;
            whys.push(`تطابق در توضیحات`);
          } else if (tblNameLower.includes(tok)) {
            score += 10;
            whys.push(`تطابق کلمه در نام لاتین`);
          }
        }

        // Check column names
        for (const col of tbl.columns || []) {
          const cLower = col.name.toLowerCase();
          if (tokens.some((tok) => cLower.includes(tok))) {
            score += 4;
            whys.push(`ستون مرتبط (${col.name})`);
            break;
          }
        }
      } else {
        // No text query: base score from data and rows
        score = 10;
        if (tbl.has_data) {
          score += 5;
          if (tbl.row_count) {
            score += Math.min(Math.round(Math.log10(tbl.row_count + 1) * 3), 20);
          }
        }
        if (!whys.length) {
          whys.push(tbl.has_data ? "دارای داده" : "پیش‌فرض");
        }
      }

      if (score > 0 || !qNorm) {
        if (tbl.has_data && qNorm) {
          score += 5;
          whys.push("داده دارد");
        }
        hits.set(tbl.full_name, {
          full_name: tbl.full_name,
          title_fa: tbl.title_fa,
          n_cols: tbl.n_cols,
          row_count: tbl.row_count,
          has_data: tbl.has_data,
          score,
          why: Array.from(new Set(whys)).join("، "),
          matched_columns: typeMatchCols.length > 0 ? typeMatchCols : undefined,
        });
      }
    }

    const hitList = Array.from(hits.values());

    // Sort results
    hitList.sort((a, b) => {
      if (sortBy === "row_count") {
        const rA = a.row_count ?? 0;
        const rB = b.row_count ?? 0;
        return sortOrder === "asc" ? rA - rB : rB - rA;
      }
      if (sortBy === "n_cols") {
        return sortOrder === "asc" ? a.n_cols - b.n_cols : b.n_cols - a.n_cols;
      }
      if (sortBy === "name") {
        return sortOrder === "asc"
          ? a.full_name.localeCompare(b.full_name)
          : b.full_name.localeCompare(a.full_name);
      }
      // default: score desc, then row_count desc
      if (b.score !== a.score) return b.score - a.score;
      return (b.row_count ?? 0) - (a.row_count ?? 0);
    });

    return hitList.slice(0, limit);
  }

  public searchColumns(query: string, limit = 30): Array<{ table_ref: string; name: string; type: string; title_fa?: string; has_data: boolean }> {
    const qLower = query.toLowerCase().trim();
    const results: Array<{ table_ref: string; name: string; type: string; title_fa?: string; has_data: boolean; len: number }> = [];

    for (const tbl of this.tables.values()) {
      for (const col of tbl.columns) {
        if (col.name.toLowerCase().includes(qLower)) {
          results.push({
            table_ref: tbl.full_name,
            name: col.name,
            type: col.type,
            title_fa: tbl.title_fa,
            has_data: tbl.has_data,
            len: col.name.length,
          });
        }
      }
    }

    return results
      .sort((a, b) => (b.has_data === a.has_data ? a.len - b.len : b.has_data ? 1 : -1))
      .slice(0, limit)
      .map(({ len, ...rest }) => rest);
  }

  public getTable(fullName: string): TableInfo | null {
    return this.tables.get(fullName) || null;
  }

  public getSchemaNeighbors(schema: string, currentTable?: string, limit = 24): Array<{ full_name: string; title_fa?: string; row_count: number; has_data: boolean; n_cols: number }> {
    const sNorm = schema.toUpperCase();
    return Array.from(this.tables.values())
      .filter((t) => t.schema.toUpperCase() === sNorm && (!currentTable || t.full_name !== currentTable))
      .sort((a, b) => (b.has_data === a.has_data ? b.row_count - a.row_count : b.has_data ? 1 : -1))
      .slice(0, limit)
      .map((t) => ({
        full_name: t.full_name,
        title_fa: t.title_fa,
        row_count: t.row_count,
        has_data: t.has_data,
        n_cols: t.n_cols || t.columns.length,
      }));
  }

  public findJoinPath(source: string, target: string, maxHops = 4, verifiedOnly = false): JoinStep[] | null {
    if (source === target) return [];
    if (!this.adjacency.has(source) || !this.adjacency.has(target)) return null;

    const visited = new Set<string>([source]);
    const queue: Array<{ node: string; path: JoinStep[] }> = [{ node: source, path: [] }];

    while (queue.length > 0) {
      const current = queue.shift()!;
      if (current.path.length >= maxHops) continue;

      const neighbours = [...(this.adjacency.get(current.node) || [])].sort((a, b) => (b.verified ? 1 : 0) - (a.verified ? 1 : 0));

      for (const n of neighbours) {
        if (verifiedOnly && !n.verified) continue;
        if (visited.has(n.to)) continue;

        const step: JoinStep = {
          from_table: current.node,
          from_col: n.fromCol,
          to_table: n.to,
          to_col: n.toCol,
          confidence: n.conf,
          verified: n.verified,
        };

        if (n.to === target) {
          return [...current.path, step];
        }

        visited.add(n.to);
        queue.push({ node: n.to, path: [...current.path, step] });
      }
    }

    return null;
  }

  public pathWarning(path: JoinStep[]): string | null {
    if (!path || path.length === 0) return null;
    if (path.length > 2) {
      const intermediate = path.slice(0, -1).map((s) => s.to_table).join(" → ");
      return `این مسیر ${path.length} مرحله دارد و از ${intermediate} عبور می‌کند. مسیرهای بلند معمولاً از نظر تجاری بی‌معنا هستند.`;
    }
    const weak = path.filter((s) => !s.verified);
    if (weak.length > 0) {
      return `${weak.length} مرحله از این مسیر تأییدنشده است (استنتاج از نام).`;
    }
    return null;
  }

  public checkExists(table: string, column?: string): { ok: boolean; message: string } {
    const tbl = this.tables.get(table);
    if (!tbl) {
      const tableName = table.split(".").pop();
      const suggestions = Array.from(this.tables.values())
        .filter((t) => t.name.toLowerCase() === tableName?.toLowerCase())
        .map((t) => t.full_name)
        .slice(0, 3);
      const hint = suggestions.length > 0 ? ` شاید منظورتان: ${suggestions.join("، ")}` : "";
      return { ok: false, message: `جدول «${table}» وجود ندارد.${hint}` };
    }

    if (!column) return { ok: true, message: "" };

    const col = tbl.columns.find((c) => c.name.toLowerCase() === column.toLowerCase());
    if (!col) {
      const close = tbl.columns
        .filter((c) => c.name.toLowerCase().includes(column.toLowerCase()) || column.toLowerCase().includes(c.name.toLowerCase()))
        .map((c) => c.name)
        .slice(0, 3);
      const hint = close.length > 0 ? ` شاید منظورتان: ${close.join("، ")}` : "";
      return { ok: false, message: `ستون «${column}» در ${table} نیست.${hint}` };
    }

    return { ok: true, message: "" };
  }

  public addKnowledge(kind: string, payload: any) {
    if (kind === "table" && payload.full_name) {
      const [schema, name] = payload.full_name.split(".");
      const tbl: TableInfo = {
        full_name: payload.full_name,
        schema: schema || "dbo",
        name: name || payload.full_name,
        title_fa: payload.title_fa || "",
        description_fa: payload.description_fa || "",
        kind: payload.kind || "table",
        row_count: 0,
        has_data: false,
        n_cols: 0,
        columns: [],
        primary_key: [],
        outgoing: [],
        incoming: [],
        enums: {},
        indexes: [],
        warnings: [],
      };
      this.tables.set(tbl.full_name, tbl);
    } else if (kind === "join" && payload.from_table && payload.to_table) {
      const step: JoinStep = {
        from_table: payload.from_table,
        from_col: payload.from_col,
        to_table: payload.to_table,
        to_col: payload.to_col,
        confidence: payload.confidence || "high",
        verified: true,
      };
      this.joins.push(step);
      const fromTbl = this.tables.get(step.from_table);
      if (fromTbl) fromTbl.outgoing.push(step);
      const toTbl = this.tables.get(step.to_table);
      if (toTbl) toTbl.incoming.push(step);
    } else if (kind === "enum" && payload.table_ref && payload.column) {
      const tbl = this.tables.get(payload.table_ref);
      if (tbl) {
        if (!tbl.enums[payload.column]) tbl.enums[payload.column] = [];
        tbl.enums[payload.column].push({
          value: String(payload.value),
          label_fa: payload.label_fa,
          confidence: "verified",
        });
      }
    }
  }
}

export const kb = new KnowledgeBase();
