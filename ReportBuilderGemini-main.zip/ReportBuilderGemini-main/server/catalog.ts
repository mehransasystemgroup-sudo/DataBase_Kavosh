import fs from "fs";
import path from "path";
import { SavedReport } from "./types.js";
import { SqlAssembler } from "./plan.js";
import { RdlBuilder } from "./rdl.js";

export class ReportCatalog {
  private reportsDir: string;
  private reports: Map<string, SavedReport> = new Map();

  constructor() {
    this.reportsDir = path.join(process.cwd(), "backend", "rc", "kb", "reports");
    this.loadAll();
  }

  public loadAll() {
    this.reports.clear();
    if (!fs.existsSync(this.reportsDir)) {
      fs.mkdirSync(this.reportsDir, { recursive: true });
    }
    const files = fs.readdirSync(this.reportsDir).filter((f) => f.endsWith(".json"));
    for (const file of files) {
      try {
        const content = fs.readFileSync(path.join(this.reportsDir, file), "utf-8");
        const rep: SavedReport = JSON.parse(content);
        this.reports.set(rep.slug, rep);
      } catch (e) {
        console.error(`Error loading report ${file}`, e);
      }
    }
  }

  public getAll(category?: string, query?: string): SavedReport[] {
    let list = Array.from(this.reports.values());
    if (category) {
      list = list.filter((r) => r.category === category);
    }
    if (query) {
      const qLower = query.toLowerCase();
      list = list.filter(
        (r) =>
          r.title_fa?.toLowerCase().includes(qLower) ||
          r.request_fa?.toLowerCase().includes(qLower) ||
          r.slug.toLowerCase().includes(qLower) ||
          r.tables?.some((t) => t.toLowerCase().includes(qLower))
      );
    }
    return list.sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""));
  }

  public getBySlug(slug: string): SavedReport | null {
    return this.reports.get(slug) || null;
  }

  public getCategories(): string[] {
    const set = new Set<string>();
    for (const r of this.reports.values()) {
      if (r.category) set.add(r.category);
    }
    return Array.from(set).sort();
  }

  public saveReport(report: Partial<SavedReport>): SavedReport {
    const title = report.title_fa || report.intent_fa || "گزارش جدید";
    const slug =
      report.slug ||
      title
        .replace(/[^\w\u0600-\u06FF\s-]/g, "")
        .replace(/\s+/g, "-")
        .slice(0, 80) ||
      `report-${Date.now()}`;

    const existing = this.reports.get(slug);
    const sql = report.sql || (report.plan ? SqlAssembler.build(report.plan) : "");

    const finalReport: SavedReport = {
      slug,
      title_fa: title,
      category: report.category || existing?.category || "",
      request_fa: report.request_fa || existing?.request_fa || title,
      intent_fa: report.intent_fa || existing?.intent_fa || title,
      tables: report.tables || (report.plan ? [report.plan.base_table, ...(report.plan.joins || []).map((j) => j.to_table)] : []),
      parameters: report.parameters || (report.plan?.parameters || []).map((p) => p.name),
      layout_kind: report.layout_kind || report.layout?.kind || "table",
      sql,
      plan: report.plan!,
      layout: report.layout || { kind: "table", detail_fields: [] },
      rdl_path: report.rdl_path || existing?.rdl_path || "",
      lessons: report.lessons || existing?.lessons || [],
      created_at: existing?.created_at || new Date().toISOString(),
      used_count: (existing?.used_count || 0) + 1,
      model: report.model || existing?.model || "",
    };

    this.reports.set(slug, finalReport);
    try {
      fs.writeFileSync(path.join(this.reportsDir, `${slug}.json`), JSON.stringify(finalReport, null, 2), "utf-8");
    } catch (e) {
      console.error("Failed saving report to file", e);
    }

    return finalReport;
  }

  public setCategory(slug: string, category: string): boolean {
    const r = this.reports.get(slug);
    if (!r) return false;
    r.category = category;
    try {
      fs.writeFileSync(path.join(this.reportsDir, `${slug}.json`), JSON.stringify(r, null, 2), "utf-8");
    } catch (e) {
      console.error("Failed saving report category", e);
    }
    return true;
  }

  public addLesson(slug: string, lesson: string): boolean {
    const r = this.reports.get(slug);
    if (!r) return false;
    if (!r.lessons) r.lessons = [];
    r.lessons.push(lesson);
    try {
      fs.writeFileSync(path.join(this.reportsDir, `${slug}.json`), JSON.stringify(r, null, 2), "utf-8");
    } catch (e) {
      console.error("Failed saving lesson", e);
    }
    return true;
  }

  public generateFile(slug: string, fmt: "sql" | "txt" | "rdl"): { content: string; filename: string; contentType: string } | null {
    const r = this.reports.get(slug);
    if (!r) return null;

    if (fmt === "sql") {
      return {
        content: r.sql || SqlAssembler.build(r.plan),
        filename: `${r.slug}.sql`,
        contentType: "text/plain; charset=utf-8",
      };
    }

    if (fmt === "txt") {
      const txt = `# ${r.title_fa}\n# جدول‌ها: ${r.tables.join(", ")}\n# پارامترها: ${r.parameters.join(", ")}\n\n${r.sql}\n`;
      return {
        content: txt,
        filename: `${r.slug}.txt`,
        contentType: "text/plain; charset=utf-8",
      };
    }

    if (fmt === "rdl") {
      const sql = r.sql || SqlAssembler.build(r.plan);
      const rdlXml = RdlBuilder.buildRdl(r.plan, sql, r.layout, { reportTitle: r.title_fa });
      return {
        content: rdlXml,
        filename: `${r.slug}.rdl`,
        contentType: "application/xml; charset=utf-8",
      };
    }

    return null;
  }

  public stats(): { total: number; categories: number } {
    return {
      total: this.reports.size,
      categories: this.getCategories().length,
    };
  }
}

export const catalog = new ReportCatalog();
