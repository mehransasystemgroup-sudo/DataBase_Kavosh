export interface ChatMessage {
  role: "user" | "assistant";
  text?: string;
  request?: string;
  tables?: string[];
  attempts?: any[];
  validation?: any[];
  done?: {
    sql: string;
    plan: any;
    layout: any;
    tables: string[];
    parameters: string[];
  };
  error?: string;
}

export interface ChatTurn {
  role: "user" | "assistant";
  content?: string;
  text?: string;
  meta?: any;
  done?: any;
  tables?: string[];
  validation?: any;
  attempts?: any[];
}

export interface ChatSession {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  messages: ChatMessage[];
  turns?: ChatTurn[];
}

export class SessionStore {
  private sessions: Map<string, ChatSession> = new Map();

  constructor() {
    // Seed an initial demo session if desired
  }

  public list(): Array<{ id: string; title: string; updated_at: string; message_count: number }> {
    return Array.from(this.sessions.values())
      .map((s) => ({
        id: s.id,
        title: s.title || "گفتگوی بدون عنوان",
        updated_at: s.updated_at,
        message_count: s.messages.length,
      }))
      .sort((a, b) => b.updated_at.localeCompare(a.updated_at));
  }

  public get(id: string): (ChatSession & { turns: ChatTurn[] }) | null {
    const s = this.sessions.get(id);
    if (!s) return null;
    const turns: ChatTurn[] = (s.messages || []).map((m) => ({
      role: m.role,
      content: m.text || m.request || "",
      text: m.text || m.request || "",
      meta: m.done || null,
      done: m.done || null,
      tables: m.tables || m.done?.tables || [],
      validation: m.validation || null,
      attempts: m.attempts || [],
    }));
    return {
      ...s,
      turns,
    };
  }

  public create(title?: string): ChatSession {
    const id = "sess-" + Math.random().toString(36).slice(2, 10);
    const session: ChatSession = {
      id,
      title: title || "گزارش جدید",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      messages: [],
    };
    this.sessions.set(id, session);
    return session;
  }

  public addMessage(id: string, msg: ChatMessage): ChatSession {
    let session = this.sessions.get(id);
    if (!session) {
      session = this.create(msg.text || msg.request || "گفتگو");
      session.id = id;
      this.sessions.set(id, session);
    }
    session.messages.push(msg);
    session.updated_at = new Date().toISOString();
    if (msg.role === "user" && session.messages.length <= 2) {
      session.title = (msg.text || msg.request || "گزارش").slice(0, 40);
    }
    return session;
  }

  public delete(id: string): boolean {
    return this.sessions.delete(id);
  }
}

export const sessionStore = new SessionStore();
