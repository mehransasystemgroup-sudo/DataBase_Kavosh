import fs from "fs";
import path from "path";

export interface AppSettings {
  model_preset: string;
  preset?: string;
  model: string;
  model_override?: string;
  base_url?: string;
  max_attempts: number;
  context_tables: number;
  context_tables_count?: number;
  timeout: number;
  timeout_seconds?: number;
  daily_budget_usd: number;
  daily_budget?: number;
  spent_today_usd: number;
  spent_today?: number;
  api_keys: Record<string, string>;
}

export const PRESETS_CONFIG: Record<string, { provider: string; model: string; base_url: string; local: boolean }> = {
  emergent: { provider: "emergent", model: "claude-sonnet-4-6", base_url: "anthropic", local: false },
  "emergent-gpt": { provider: "emergent", model: "gpt-5.4", base_url: "openai", local: false },
  "emergent-gemini": { provider: "emergent", model: "gemini-3.1-pro-preview", base_url: "gemini", local: false },
  claude: { provider: "anthropic", model: "claude-sonnet-4-6", base_url: "https://api.anthropic.com/v1", local: false },
  gpt: { provider: "openai", model: "gpt-4o", base_url: "https://api.openai.com/v1", local: false },
  deepseek: { provider: "openai", model: "deepseek-chat", base_url: "https://api.deepseek.com/v1", local: false },
  gemini: { provider: "google", model: "gemini-2.0-flash", base_url: "", local: false },
  ollama: { provider: "openai", model: "qwen2.5-coder:14b", base_url: "http://localhost:11434/v1", local: true },
  lmstudio: { provider: "openai", model: "local-model", base_url: "http://localhost:1234/v1", local: true },
  openrouter: { provider: "openai", model: "anthropic/claude-sonnet-4.5", base_url: "https://openrouter.ai/api/v1", local: false },
};

const DEFAULT_SETTINGS: AppSettings = {
  model_preset: "emergent-gemini",
  preset: "emergent-gemini",
  model: "gemini-3.6-flash",
  model_override: "",
  base_url: "",
  max_attempts: 4,
  context_tables: 6,
  context_tables_count: 6,
  timeout: 180,
  timeout_seconds: 45,
  daily_budget_usd: 10.0,
  daily_budget: 10.0,
  spent_today_usd: 0.042,
  spent_today: 0.042,
  api_keys: {},
};

export class SettingsStore {
  private filePath: string;
  private settings: AppSettings;

  constructor() {
    const dir = path.join(process.cwd(), "backend", "rc_data");
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    this.filePath = path.join(dir, "settings.json");
    this.settings = { ...DEFAULT_SETTINGS };
    this.load();
  }

  public load() {
    if (fs.existsSync(this.filePath)) {
      try {
        const raw = fs.readFileSync(this.filePath, "utf-8");
        const data = JSON.parse(raw);
        this.settings = {
          ...DEFAULT_SETTINGS,
          ...data,
          preset: data.model_preset || data.preset || DEFAULT_SETTINGS.model_preset,
          model_preset: data.model_preset || data.preset || DEFAULT_SETTINGS.model_preset,
          model: data.model_override || data.model || DEFAULT_SETTINGS.model,
          daily_budget: data.daily_budget_usd ?? data.daily_budget ?? DEFAULT_SETTINGS.daily_budget,
          daily_budget_usd: data.daily_budget_usd ?? data.daily_budget ?? DEFAULT_SETTINGS.daily_budget,
          spent_today: data.spent_today_usd ?? data.spent_today ?? DEFAULT_SETTINGS.spent_today,
          spent_today_usd: data.spent_today_usd ?? data.spent_today ?? DEFAULT_SETTINGS.spent_today,
          context_tables: data.context_tables ?? data.context_tables_count ?? DEFAULT_SETTINGS.context_tables,
          context_tables_count: data.context_tables ?? data.context_tables_count ?? DEFAULT_SETTINGS.context_tables,
          timeout: data.timeout ?? data.timeout_seconds ?? DEFAULT_SETTINGS.timeout,
          timeout_seconds: data.timeout ?? data.timeout_seconds ?? DEFAULT_SETTINGS.timeout,
          api_keys: data.api_keys || {},
        };
      } catch (e) {
        console.error("Error reading settings.json", e);
      }
    }
  }

  public getRawSettings(): AppSettings {
    return this.settings;
  }

  public getPublicKeys(): Record<string, boolean> {
    const keys = this.settings.api_keys || {};
    const hasGoogle = !!(keys.google || keys.gemini || process.env.GEMINI_API_KEY);
    const hasAnthropic = !!(keys.anthropic || keys.claude || process.env.ANTHROPIC_API_KEY);
    const hasOpenAI = !!(keys.openai || keys.gpt || process.env.OPENAI_API_KEY);
    const hasDeepSeek = !!(keys.deepseek || process.env.DEEPSEEK_API_KEY);

    return {
      google: hasGoogle,
      gemini: hasGoogle,
      anthropic: hasAnthropic,
      claude: hasAnthropic,
      openai: hasOpenAI,
      gpt: hasOpenAI,
      deepseek: hasDeepSeek,
      emergent: true, // Universal fallback
    };
  }

  public getSettings(): any {
    const publicKeys = this.getPublicKeys();

    const maskedApiKeys: Record<string, string> = {};
    for (const [k, v] of Object.entries(this.settings.api_keys || {})) {
      if (v) {
        maskedApiKeys[k] = v.length > 8 ? `${v.slice(0, 4)}...${v.slice(-4)}` : "••••••••";
      }
    }

    const settingsObj = {
      model_preset: this.settings.model_preset || this.settings.preset || "emergent-gemini",
      model_override: this.settings.model_override || "",
      base_url: this.settings.base_url || "",
      max_attempts: this.settings.max_attempts || 4,
      context_tables: this.settings.context_tables || 6,
      timeout: this.settings.timeout || 180,
      daily_budget_usd: this.settings.daily_budget_usd || 10.0,
      spent_today_usd: this.settings.spent_today_usd || 0.042,
    };

    return {
      ok: true,
      settings: settingsObj,
      keys: publicKeys,
      presets: PRESETS_CONFIG,
      // Backward-compatible direct keys
      preset: settingsObj.model_preset,
      model: this.settings.model_override || this.settings.model || "gemini-3.6-flash",
      daily_budget: settingsObj.daily_budget_usd,
      spent_today: settingsObj.spent_today_usd,
      timeout_seconds: this.settings.timeout || 45,
      context_tables_count: settingsObj.context_tables,
      api_keys: maskedApiKeys,
    };
  }

  public update(patch: any): any {
    const rawPatch = patch.settings || patch;

    if (rawPatch.model_preset) {
      this.settings.model_preset = rawPatch.model_preset;
      this.settings.preset = rawPatch.model_preset;
    } else if (rawPatch.preset) {
      this.settings.model_preset = rawPatch.preset;
      this.settings.preset = rawPatch.preset;
    }

    if (rawPatch.model_override !== undefined) {
      this.settings.model_override = rawPatch.model_override;
    }
    if (rawPatch.model) {
      this.settings.model = rawPatch.model;
    }

    if (rawPatch.base_url !== undefined) {
      this.settings.base_url = rawPatch.base_url;
    }

    if (rawPatch.max_attempts !== undefined) {
      this.settings.max_attempts = Number(rawPatch.max_attempts);
    }

    if (rawPatch.context_tables !== undefined || rawPatch.context_tables_count !== undefined) {
      const val = Number(rawPatch.context_tables ?? rawPatch.context_tables_count);
      this.settings.context_tables = val;
      this.settings.context_tables_count = val;
    }

    if (rawPatch.daily_budget_usd !== undefined || rawPatch.daily_budget !== undefined) {
      const val = Number(rawPatch.daily_budget_usd ?? rawPatch.daily_budget);
      this.settings.daily_budget_usd = val;
      this.settings.daily_budget = val;
    }

    if (rawPatch.timeout !== undefined || rawPatch.timeout_seconds !== undefined) {
      const val = Number(rawPatch.timeout ?? rawPatch.timeout_seconds);
      this.settings.timeout = val;
      this.settings.timeout_seconds = val;
    }

    // Merge API keys
    const incomingKeys = patch.api_keys || rawPatch.api_keys;
    if (incomingKeys && typeof incomingKeys === "object") {
      for (const [k, v] of Object.entries(incomingKeys)) {
        const strVal = String(v || "").trim();
        if (strVal && !strVal.includes("...") && !strVal.includes("••••")) {
          this.settings.api_keys[k] = strVal;
          // Alias google <-> gemini
          if (k === "google") this.settings.api_keys["gemini"] = strVal;
          if (k === "gemini") this.settings.api_keys["google"] = strVal;
          // Alias anthropic <-> claude
          if (k === "anthropic") this.settings.api_keys["claude"] = strVal;
          if (k === "claude") this.settings.api_keys["anthropic"] = strVal;
          // Alias openai <-> gpt
          if (k === "openai") this.settings.api_keys["gpt"] = strVal;
          if (k === "gpt") this.settings.api_keys["openai"] = strVal;
        }
      }
    }

    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.settings, null, 2), "utf-8");
    } catch (e) {
      console.error("Failed saving settings.json:", e);
    }

    return this.getSettings();
  }

  public recordCost(amount: number) {
    this.settings.spent_today_usd = (this.settings.spent_today_usd || 0) + amount;
    this.settings.spent_today = this.settings.spent_today_usd;
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.settings, null, 2), "utf-8");
    } catch (e) {
      // Ignore
    }
  }
}

export const settingsStore = new SettingsStore();
