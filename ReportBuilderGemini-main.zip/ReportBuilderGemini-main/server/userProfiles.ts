import fs from "fs";
import path from "path";

export interface FavoriteColumn {
  id: string;
  table: string;
  column: string;
  alias?: string;
  aggregate?: "SUM" | "COUNT" | "AVG" | "MIN" | "MAX" | null;
  category?: "dimension" | "measure";
}

export interface MatrixLayoutConfig {
  row_groups: string[];
  col_groups: string[];
  values: Array<{ column: string; aggregate: string; title?: string }>;
  show_row_totals: boolean;
  show_col_totals: boolean;
  subtotals: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  description: string;
  is_default: boolean;
  base_table?: string;
  favorite_columns: FavoriteColumn[];
  layout: {
    kind: "matrix" | "table" | "grouped";
    matrix?: MatrixLayoutConfig;
    row_groups?: string[];
    direction?: "RTL" | "LTR";
    font_size?: string;
    page_orientation?: "Landscape" | "Portrait";
  };
  created_at: string;
  updated_at: string;
}

const DEFAULT_PROFILES: UserProfile[] = [
  {
    id: "profile-sales-matrix",
    name: "مدل ماتریسی فروش ماهانه و فصلی مشتریان",
    description: "چیدمان ماتریسی تحلیلی فروش با محوریت مشتریان در سطرها و ماه‌های مالی در ستون‌ها به همراه جمع اقلام و مالیات",
    is_default: true,
    base_table: "SLS.Invoice",
    favorite_columns: [
      {
        id: "col-1",
        table: "SLS.Invoice",
        column: "CustomerTitle",
        alias: "نام مشتری / طرف حساب",
        aggregate: null,
        category: "dimension",
      },
      {
        id: "col-2",
        table: "SLS.Invoice",
        column: "InvoiceDate",
        alias: "ماه و تاریخ فاکتور",
        aggregate: null,
        category: "dimension",
      },
      {
        id: "col-3",
        table: "SLS.Invoice",
        column: "NetPrice",
        alias: "مبلغ خالص فروش",
        aggregate: "SUM",
        category: "measure",
      },
      {
        id: "col-4",
        table: "SLS.Invoice",
        column: "TotalTax",
        alias: "مجموع مالیات و عوارض",
        aggregate: "SUM",
        category: "measure",
      },
      {
        id: "col-5",
        table: "SLS.Invoice",
        column: "InvoiceNo",
        alias: "تعداد فاکتورها",
        aggregate: "COUNT",
        category: "measure",
      },
    ],
    layout: {
      kind: "matrix",
      matrix: {
        row_groups: ["CustomerTitle"],
        col_groups: ["InvoiceDate"],
        values: [
          { column: "NetPrice", aggregate: "SUM", title: "مجموع فروش خالص" },
          { column: "TotalTax", aggregate: "SUM", title: "مالیات و عوارض" },
        ],
        show_row_totals: true,
        show_col_totals: true,
        subtotals: true,
      },
      direction: "RTL",
      font_size: "9pt",
      page_orientation: "Landscape",
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "profile-acc-voucher-matrix",
    name: "مدل ماتریسی تراز و گردش اسناد حسابداری",
    description: "تحلیل ماتریسی گردش بدهکار و بستانکار سرفصل‌های کل و معین به تفکیک ماه‌های سال مالی",
    is_default: false,
    base_table: "ACC.Voucher",
    favorite_columns: [
      {
        id: "col-11",
        table: "ACC.Voucher",
        column: "VoucherNo",
        alias: "شماره سند",
        aggregate: null,
        category: "dimension",
      },
      {
        id: "col-12",
        table: "ACC.Voucher",
        column: "VoucherDate",
        alias: "تاریخ سند",
        aggregate: null,
        category: "dimension",
      },
      {
        id: "col-13",
        table: "ACC.Voucher",
        column: "Debit",
        alias: "مجموع بدهکار",
        aggregate: "SUM",
        category: "measure",
      },
      {
        id: "col-14",
        table: "ACC.Voucher",
        column: "Credit",
        alias: "مجموع بستانکار",
        aggregate: "SUM",
        category: "measure",
      },
      {
        id: "col-15",
        table: "ACC.Voucher",
        column: "FiscalYearRef",
        alias: "سال مالی",
        aggregate: null,
        category: "dimension",
      },
    ],
    layout: {
      kind: "matrix",
      matrix: {
        row_groups: ["VoucherNo"],
        col_groups: ["VoucherDate"],
        values: [
          { column: "Debit", aggregate: "SUM", title: "بدهکار" },
          { column: "Credit", aggregate: "SUM", title: "بستانکار" },
        ],
        show_row_totals: true,
        show_col_totals: true,
        subtotals: false,
      },
      direction: "RTL",
      font_size: "9pt",
      page_orientation: "Landscape",
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "profile-inv-cardex",
    name: "مدل ماتریسی موجودی و کاردکس انبار",
    description: "نمایش تقاطعی مقادیر وارده، صادره و مانده انبارها به تفکیک کدینگ کالا",
    is_default: false,
    base_table: "INV.ItemTransaction",
    favorite_columns: [
      {
        id: "col-21",
        table: "INV.ItemTransaction",
        column: "ItemRef",
        alias: "کد کالا",
        aggregate: null,
        category: "dimension",
      },
      {
        id: "col-22",
        table: "INV.ItemTransaction",
        column: "StockRef",
        alias: "کد انبار",
        aggregate: null,
        category: "dimension",
      },
      {
        id: "col-23",
        table: "INV.ItemTransaction",
        column: "Quantity",
        alias: "تعداد / مقدار",
        aggregate: "SUM",
        category: "measure",
      },
      {
        id: "col-24",
        table: "INV.ItemTransaction",
        column: "Fee",
        alias: "نرخ میانگین",
        aggregate: "AVG",
        category: "measure",
      },
    ],
    layout: {
      kind: "matrix",
      matrix: {
        row_groups: ["ItemRef"],
        col_groups: ["StockRef"],
        values: [
          { column: "Quantity", aggregate: "SUM", title: "گردش مقداری" },
        ],
        show_row_totals: true,
        show_col_totals: true,
        subtotals: true,
      },
      direction: "RTL",
      font_size: "9pt",
      page_orientation: "Landscape",
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
];

export class UserProfileStore {
  private filePath: string;
  private profiles: UserProfile[];

  constructor() {
    this.filePath = path.join(process.cwd(), "backend", "rc_data", "user_profiles.json");
    this.profiles = [...DEFAULT_PROFILES];
    this.load();
  }

  public load(): void {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, "utf-8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.profiles = parsed;
          return;
        }
      }
    } catch (err) {
      console.warn("Could not load user_profiles.json, using defaults:", err);
    }
    this.saveToDisk();
  }

  private saveToDisk(): void {
    try {
      const dir = path.dirname(this.filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.filePath, JSON.stringify(this.profiles, null, 2), "utf-8");
    } catch (err) {
      console.error("Failed to save user_profiles.json:", err);
    }
  }

  public getAll(): UserProfile[] {
    return this.profiles;
  }

  public get(id: string): UserProfile | undefined {
    return this.profiles.find((p) => p.id === id);
  }

  public getDefault(): UserProfile {
    const def = this.profiles.find((p) => p.is_default);
    return def || this.profiles[0] || DEFAULT_PROFILES[0];
  }

  public setDefault(id: string): boolean {
    let found = false;
    this.profiles = this.profiles.map((p) => {
      if (p.id === id) {
        found = true;
        return { ...p, is_default: true, updated_at: new Date().toISOString() };
      }
      return { ...p, is_default: false };
    });
    if (found) {
      this.saveToDisk();
    }
    return found;
  }

  public save(profile: Partial<UserProfile>): UserProfile {
    const now = new Date().toISOString();
    const id = profile.id || `profile-${Date.now()}`;
    const existingIndex = this.profiles.findIndex((p) => p.id === id);

    if (profile.is_default) {
      this.profiles = this.profiles.map((p) => ({ ...p, is_default: false }));
    }

    let saved: UserProfile;

    if (existingIndex >= 0) {
      saved = {
        ...this.profiles[existingIndex],
        ...profile,
        id,
        updated_at: now,
      };
      this.profiles[existingIndex] = saved;
    } else {
      saved = {
        id,
        name: profile.name || "پروفایل شخصی جدید",
        description: profile.description || "",
        is_default: !!profile.is_default || this.profiles.length === 0,
        base_table: profile.base_table || "SLS.Invoice",
        favorite_columns: profile.favorite_columns || [],
        layout: profile.layout || {
          kind: "matrix",
          matrix: {
            row_groups: [],
            col_groups: [],
            values: [],
            show_row_totals: true,
            show_col_totals: true,
            subtotals: true,
          },
          direction: "RTL",
          font_size: "9pt",
          page_orientation: "Landscape",
        },
        created_at: now,
        updated_at: now,
      };
      this.profiles.push(saved);
    }

    this.saveToDisk();
    return saved;
  }

  public delete(id: string): boolean {
    const initialLen = this.profiles.length;
    this.profiles = this.profiles.filter((p) => p.id !== id);
    if (this.profiles.length < initialLen) {
      if (!this.profiles.some((p) => p.is_default) && this.profiles.length > 0) {
        this.profiles[0].is_default = true;
      }
      this.saveToDisk();
      return true;
    }
    return false;
  }
}

export const userProfileStore = new UserProfileStore();
