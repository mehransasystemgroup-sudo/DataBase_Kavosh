export interface TableColumn {
  name: string;
  type: string;
  nullable: boolean;
  is_pk: boolean;
  ordinal?: number;
}

export interface JoinStep {
  from_table: string;
  from_col: string;
  to_table: string;
  to_col: string;
  confidence: string;
  verified: boolean;
}

export interface EnumEntry {
  value: string;
  label_fa?: string;
  confidence?: string;
  observed?: number;
}

export interface TableIndex {
  name: string;
  type?: string;
  columns: string[];
  unique: boolean;
  is_pk?: boolean;
}

export interface TableInfo {
  full_name: string;
  schema: string;
  name: string;
  title_fa?: string;
  description_fa?: string;
  kind?: string;
  row_count?: number | null;
  has_data: boolean;
  in_live_db?: number | null;
  n_cols: number;
  columns: TableColumn[];
  primary_key: string[];
  outgoing: JoinStep[];
  incoming: JoinStep[];
  enums: Record<string, EnumEntry[]>;
  indexes: TableIndex[];
  warnings: string[];
}

export interface TableHit {
  full_name: string;
  title_fa?: string;
  n_cols: number;
  row_count?: number | null;
  has_data: boolean;
  score: number;
  why: string;
  matched_columns?: Array<{ name: string; type: string }>;
}

export interface TableSearchParams {
  query?: string;
  limit?: number;
  schema?: string;
  onlyWithData?: boolean;
  fieldType?: string;
  minRows?: number;
  maxRows?: number;
  dataStatus?: "all" | "with_data" | "no_data";
  sortBy?: "score" | "row_count" | "n_cols" | "name";
  sortOrder?: "asc" | "desc";
}

export interface PlanColumn {
  table: string;
  column: string;
  aggregate?: "SUM" | "COUNT" | "COUNT_DISTINCT" | "AVG" | "MIN" | "MAX" | null;
  alias?: string | null;
}

export interface PlanJoin {
  kind: "INNER" | "LEFT";
  from_table: string;
  from_column: string;
  to_table: string;
  to_column: string;
}

export interface PlanFilter {
  table: string;
  column: string;
  op: "=" | "<>" | ">" | ">=" | "<" | "<=" | "LIKE" | "IN" | "BETWEEN" | "IS NULL" | "IS NOT NULL";
  value?: any;
  parameter?: string | null;
}

export interface PlanOrder {
  expression: string;
  direction: "ASC" | "DESC";
}

export interface PlanParameter {
  name: string;
  type: string;
  title_fa: string;
  required?: boolean;
  default?: any;
}

export interface QueryPlan {
  intent_fa: string;
  base_table: string;
  select: PlanColumn[];
  joins?: PlanJoin[];
  filters?: PlanFilter[];
  group_by?: string[];
  order_by?: PlanOrder[];
  parameters?: PlanParameter[];
  top?: number | null;
  notes?: string[];
}

export interface PlanIssue {
  severity: "error" | "warning" | "info";
  path: string;
  message: string;
  valid_options?: string[];
}

export interface ReportLayout {
  kind: "table" | "grouped" | "matrix";
  row_groups?: string[];
  column_group?: string | null;
  values?: Array<{ column: string; aggregate?: string }>;
  detail_fields?: string[];
  show_details?: boolean;
  grand_total?: boolean;
  page_header?: {
    enabled: boolean;
    height: string;
    left?: string;
    center?: string;
    right?: string;
    show_line?: boolean;
  };
  page_footer?: {
    enabled: boolean;
    height: string;
    left?: string;
    center?: string;
    right?: string;
    show_line?: boolean;
  };
}

export interface SavedReport {
  slug: string;
  title_fa: string;
  category?: string;
  request_fa?: string;
  intent_fa?: string;
  tables: string[];
  parameters: string[];
  layout_kind: string;
  sql: string;
  plan: QueryPlan;
  layout?: ReportLayout;
  rdl_path?: string;
  lessons?: string[];
  created_at: string;
  used_count: number;
  model?: string;
}
