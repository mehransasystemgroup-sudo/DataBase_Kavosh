import { QueryPlan, PlanColumn, PlanJoin, PlanFilter, PlanOrder, PlanParameter, PlanIssue } from "./types.js";
import { kb, KnowledgeBase } from "./kb.js";

export class SqlAssembler {
  private static makeAlias(full: string, used: Map<string, string>): string {
    if (!full || typeof full !== "string") return "t";
    if (used.has(full)) return used.get(full)!;
    const parts = full.split(".");
    const bare = parts[1] || parts[0] || "t";
    const uppers = bare.split("").filter((ch) => ch >= "A" && ch <= "Z").join("").toLowerCase();
    const base = uppers || bare.slice(0, 2).toLowerCase() || "t";
    let alias = base;
    let n = 1;
    const existing = new Set(used.values());
    while (existing.has(alias)) {
      n += 1;
      alias = `${base}${n}`;
    }
    used.set(full, alias);
    return alias;
  }

  private static lit(v: any): string {
    if (v === null || v === undefined) return "NULL";
    if (typeof v === "boolean") return v ? "1" : "0";
    if (typeof v === "number") return String(v);
    return `N'${String(v).replace(/'/g, "''")}'`;
  }

  public static build(plan: QueryPlan): string {
    const used = new Map<string, string>();
    const aBase = this.makeAlias(plan.base_table, used);
    for (const j of plan.joins || []) {
      this.makeAlias(j.to_table, used);
    }

    const ref = (table: string, column: string) => {
      const a = used.get(table) || table;
      return `${a}.[${column}]`;
    };

    // SELECT
    const cols: string[] = [];
    for (const c of plan.select || []) {
      let expr = ref(c.table, c.column);
      if (c.aggregate === "COUNT_DISTINCT") {
        expr = `COUNT(DISTINCT ${expr})`;
      } else if (c.aggregate) {
        expr = `${c.aggregate}(${expr})`;
      }
      const outName = c.alias || (c.aggregate ? `${c.aggregate.toLowerCase()}_${c.column}` : c.column);
      cols.push(`${expr} AS [${outName}]`);
    }

    const top = plan.top ? `TOP (${plan.top}) ` : "";
    const lines: string[] = [];
    lines.push(`SELECT ${top}` + (cols.length > 0 ? cols.join(",\n       ") : "*"));
    lines.push(`FROM   ${plan.base_table} AS ${aBase}`);

    for (const j of plan.joins || []) {
      const toAlias = used.get(j.to_table) || j.to_table;
      lines.push(`${j.kind || "INNER"} JOIN ${j.to_table} AS ${toAlias} ON ${ref(j.from_table, j.from_column)} = ${ref(j.to_table, j.to_column)}`);
    }

    // WHERE
    if (plan.filters && plan.filters.length > 0) {
      const conds: string[] = [];
      for (const f of plan.filters) {
        const left = ref(f.table, f.column);
        if (f.op === "IS NULL" || f.op === "IS NOT NULL") {
          conds.push(`${left} ${f.op}`);
        } else if (f.parameter) {
          conds.push(`${left} ${f.op} @${f.parameter}`);
        } else if (Array.isArray(f.value)) {
          if (f.op === "BETWEEN" && f.value.length === 2) {
            conds.push(`${left} BETWEEN ${this.lit(f.value[0])} AND ${this.lit(f.value[1])}`);
          } else {
            const vals = f.value.map((v) => this.lit(v)).join(", ");
            conds.push(`${left} IN (${vals})`);
          }
        } else {
          conds.push(`${left} ${f.op} ${this.lit(f.value)}`);
        }
      }
      lines.push("WHERE  " + conds.join("\n  AND  "));
    }

    // GROUP BY
    if (plan.group_by && plan.group_by.length > 0) {
      const g = plan.group_by.map((x: any) => {
        const str = typeof x === "string" ? x : (x?.column || x?.expression || "");
        if (!str || typeof str !== "string") return "";
        const p = str.split(".");
        if (p.length === 2) return `${used.get(p[0]) || p[0]}.[${p[1]}]`;
        if (p.length === 3) return `${used.get(`${p[0]}.${p[1]}`) || p[1]}.[${p[2]}]`;
        return `[${str}]`;
      }).filter(Boolean);
      if (g.length > 0) {
        lines.push("GROUP BY " + g.join(", "));
      }
    }

    // ORDER BY
    if (plan.order_by && plan.order_by.length > 0) {
      const o = plan.order_by.map((x: any) => {
        const expr = typeof x === "string" ? x : (x?.expression || x?.column || "");
        if (!expr || typeof expr !== "string") return "";
        const dir = typeof x === "object" && x?.direction ? x.direction : "ASC";
        const p = expr.split(".");
        if (p.length === 2) {
          return `${used.get(p[0]) || p[0]}.[${p[1]}] ${dir}`;
        }
        if (p.length === 3) {
          return `${used.get(`${p[0]}.${p[1]}`) || p[1]}.[${p[2]}] ${dir}`;
        }
        return `[${expr}] ${dir}`;
      }).filter(Boolean);
      if (o.length > 0) {
        lines.push("ORDER BY " + o.join(", "));
      }
    }

    let sql = lines.join("\n") + ";";

    if (plan.parameters && plan.parameters.length > 0) {
      const head = plan.parameters.map((p) => `-- @${p.name} (${p.type}) — ${p.title_fa}`).join("\n");
      sql = head + "\n\n" + sql;
    }

    return sql;
  }
}

export class PlanValidator {
  public static validate(plan: QueryPlan, currentKb: KnowledgeBase = kb): { plan: QueryPlan; ok: boolean; issues: PlanIssue[] } {
    const issues: PlanIssue[] = [];

    if (!plan.base_table) {
      issues.push({
        severity: "error",
        path: "base_table",
        message: "جدول پایه مشخص نشده است.",
      });
    } else {
      const check = currentKb.checkExists(plan.base_table);
      if (!check.ok) {
        issues.push({
          severity: "error",
          path: "base_table",
          message: check.message,
        });
      }
    }

    const validTables = new Set<string>();
    if (plan.base_table) validTables.add(plan.base_table);

    // Validate joins
    const validJoins: PlanJoin[] = [];
    for (let i = 0; i < (plan.joins || []).length; i++) {
      const j = plan.joins![i];
      const tag = `joins[${i}]`;

      const checkFrom = currentKb.checkExists(j.from_table, j.from_column);
      if (!checkFrom.ok) {
        issues.push({ severity: "error", path: `${tag}.from`, message: checkFrom.message });
      }

      const checkTo = currentKb.checkExists(j.to_table, j.to_column);
      if (!checkTo.ok) {
        issues.push({ severity: "error", path: `${tag}.to`, message: checkTo.message });
      }

      validTables.add(j.to_table);
      validJoins.push(j);
    }
    plan.joins = validJoins;

    // Validate select
    const validSelect: PlanColumn[] = [];
    for (let i = 0; i < (plan.select || []).length; i++) {
      const c = plan.select[i];
      const tag = `select[${i}]`;
      const tbl = c.table || plan.base_table;

      const check = currentKb.checkExists(tbl, c.column);
      if (!check.ok) {
        issues.push({ severity: "error", path: tag, message: check.message });
      }
      validSelect.push({ ...c, table: tbl });
    }
    plan.select = validSelect;

    // Validate filters
    for (let i = 0; i < (plan.filters || []).length; i++) {
      const f = plan.filters![i];
      const tag = `filters[${i}]`;
      const tbl = f.table || plan.base_table;
      const check = currentKb.checkExists(tbl, f.column);
      if (!check.ok) {
        issues.push({ severity: "error", path: tag, message: check.message });
      }
    }

    // Check FiscalYearRef requirement
    const allTables = new Set<string>([plan.base_table, ...(plan.joins || []).map((j) => j.to_table)]);
    const filteredFy = new Set<string>((plan.filters || []).filter((f) => f.column === "FiscalYearRef").map((f) => f.table || plan.base_table));

    for (const t of allTables) {
      const tInfo = currentKb.getTable(t);
      if (tInfo && tInfo.columns.some((c) => c.name === "FiscalYearRef") && !filteredFy.has(t)) {
        issues.push({
          severity: "error",
          path: "filters",
          message: `${t} ستون FiscalYearRef دارد ولی فیلتر نشده است. بدون آن، داده‌ی تمام سال‌های مالی ادغام می‌شود. لطفاً فیلتر با parameter="FiscalYear" اضافه کنید.`,
        });
      }
    }

    // Auto complete GROUP BY if aggregates are present
    const hasAgg = plan.select.some((c) => Boolean(c.aggregate));
    const nonAggCols = plan.select.filter((c) => !c.aggregate);
    if (hasAgg && nonAggCols.length > 0) {
      const needed = nonAggCols.map((c) => `${c.table}.${c.column}`);
      const given = new Set(plan.group_by || []);
      const missing = needed.filter((x) => !given.has(x));
      if (missing.length > 0) {
        plan.group_by = Array.from(new Set([...(plan.group_by || []), ...needed]));
        issues.push({
          severity: "warning",
          path: "group_by",
          message: `GROUP BY به طور خودکار تکمیل شد: ${missing.join(", ")}`,
        });
      }
    }

    // Auto declare parameters
    const usedParams = new Set<string>((plan.filters || []).map((f) => f.parameter).filter(Boolean) as string[]);
    const declaredParams = new Set<string>((plan.parameters || []).map((p) => p.name));

    if (!plan.parameters) plan.parameters = [];
    for (const p of usedParams) {
      if (!declaredParams.has(p)) {
        plan.parameters.push({
          name: p,
          type: "int",
          title_fa: p === "FiscalYear" ? "سال مالی" : p,
          required: true,
        });
        issues.push({
          severity: "warning",
          path: "parameters",
          message: `پارامتر «${p}» به طور خودکار تعریف شد.`,
        });
      }
    }

    const ok = !issues.some((i) => i.severity === "error");
    return { plan, ok, issues };
  }
}
