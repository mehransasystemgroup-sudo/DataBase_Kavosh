import { QueryPlan, PlanFilter, PlanColumn, PlanJoin } from "./types.js";
import { KnowledgeBase, kb } from "./kb.js";

export interface SqlSafetyIssue {
  type: "destructive_keyword" | "slow_query" | "security_risk" | "performance_hint";
  severity: "critical" | "warning" | "info";
  title_fa: string;
  message_fa: string;
  keyword?: string;
  location?: string;
  recommendation_fa?: string;
}

export interface SqlSafetyReport {
  is_safe: boolean; // false if any critical destructive keyword / injection risk exists
  has_slow_query_risks: boolean; // true if any slow query warnings exist
  score: number; // 0 to 100
  summary_fa: string;
  issues: SqlSafetyIssue[];
  metrics: {
    destructive_keywords_count: number;
    slow_query_risks_count: number;
    tables_count: number;
    joins_count: number;
    has_top_limit: boolean;
    has_where_clause: boolean;
    estimated_cost_tier: "LOW" | "MEDIUM" | "HIGH" | "VERY_HIGH";
  };
}

// Destructive and high-risk SQL keywords that should never be executed in report builder
const DESTRUCTIVE_KEYWORD_PATTERNS: Array<{ regex: RegExp; name: string; desc: string }> = [
  { regex: /\b(DROP)\s+(TABLE|DATABASE|VIEW|PROCEDURE|PROC|INDEX|TRIGGER|SCHEMA|FUNCTION)\b/i, name: "DROP", desc: "حذف ساختار پایگاه‌داده (DDL Destructive)" },
  { regex: /\b(TRUNCATE)\s+(TABLE)?\b/i, name: "TRUNCATE", desc: "تخلیه کامل جدول (TRUNCATE TABLE)" },
  { regex: /\b(DELETE)\s+(FROM)?\b/i, name: "DELETE", desc: "حذف رکوردهای جدول (DML DELETE)" },
  { regex: /\b(ALTER)\s+(TABLE|DATABASE|VIEW|PROCEDURE|INDEX)\b/i, name: "ALTER", desc: "تغییر ساختار جدول یا پایگاه‌داده (DDL ALTER)" },
  { regex: /\b(UPDATE)\s+[\w\.\[\]]+\s+SET\b/i, name: "UPDATE", desc: "تغییر و بازنویسی داده‌های رکوردی (DML UPDATE)" },
  { regex: /\b(INSERT)\s+(INTO)?\b/i, name: "INSERT", desc: "درج مستقیم داده (DML INSERT)" },
  { regex: /\b(EXEC|EXECUTE)\s*(\(|\s+)(XP_|SP_|SYS\.)?/i, name: "EXEC/EXECUTE", desc: "اجرای مستقیم رویه‌ها یا کدهای پویا (Dynamic SQL / Stored Proc Execution)" },
  { regex: /\b(XP_CMDSHELL|SP_EXECUTESQL|SP_CONFIGURE)\b/i, name: "SYSTEM_PROC", desc: "فراخوانی پروسیجرهای سیستمی و دستورات شل سیستم‌عامل" },
  { regex: /\b(GRANT|REVOKE|DENY)\b/i, name: "DCL_SECURITY", desc: "دستورات امنیتی و تغییر مجوزها (DCL)" },
  { regex: /\b(SHUTDOWN|RECONFIGURE|BACKUP|RESTORE)\b/i, name: "ADMIN_COMMAND", desc: "دستورات مدیریتی سرور و قطع سرویس" },
  { regex: /\b(OPENROWSET|OPENDATASOURCE)\b/i, name: "REMOTE_ACCESS", desc: "دسترسی به منابع خارجی و پایگاه‌داده‌های متفرقه" },
  { regex: /\b(WAITFOR\s+DELAY|WAITFOR\s+TIME)\b/i, name: "TIME_BASED_INJECTION", desc: "تعلیق پردازش و حملات مبتنی بر زمان (Time-based Injection)" },
];

export class SqlSafetyAnalyzer {
  /**
   * Analyzes both the generated SQL text and the underlying QueryPlan for security risks and slow-query bottlenecks.
   */
  public static analyze(sql: string, plan?: QueryPlan | null, currentKb: KnowledgeBase = kb): SqlSafetyReport {
    const issues: SqlSafetyIssue[] = [];
    let score = 100;
    const cleanSql = sql || "";

    // ── 1. DESTRUCTIVE KEYWORDS & SECURITY AUDIT ──
    for (const pattern of DESTRUCTIVE_KEYWORD_PATTERNS) {
      if (pattern.regex.test(cleanSql)) {
        issues.push({
          type: "destructive_keyword",
          severity: "critical",
          keyword: pattern.name,
          title_fa: `شناسایی کلمه کلیدی مخرب یا غیرمجاز: ${pattern.name}`,
          message_fa: `کوئری شامل دستور «${pattern.name}» است که برای گزارش‌گیری غیرمجاز است (${pattern.desc}). این دستور می‌تواند ساختار یا داده‌های سیستم را دستکاری کند.`,
          recommendation_fa: "کوئری‌های گزارش‌ساز صرفاً باید حاوی دستورات خواندنی (SELECT) باشند. دستورات تغییر دهنده یا اجرایی را حذف فرمایید.",
        });
        score -= 40;
      }
    }

    // Check for comment injection / stacked queries like `; DROP`
    if (/;\s*(DROP|DELETE|UPDATE|TRUNCATE|ALTER|EXEC|INSERT)/i.test(cleanSql)) {
      issues.push({
        type: "security_risk",
        severity: "critical",
        title_fa: "شناسایی دستورات چندگانه تزریقی (Stacked Queries)",
        message_fa: "وجود علامت سمیکالن (;) همراه با دستورات ثانویه می‌تواند نشانه تزریق کد (SQL Injection) یا اجرای چندین اسکریپت همزمان باشد.",
        recommendation_fa: "از اجرای چندین دستور مجزا در یک کوئری گزارش جلوگیری فرمایید.",
      });
      score -= 30;
    }

    // ── 2. SLOW QUERY & BOTTLENECK ANALYSIS ──
    const tablesCount = (plan?.joins?.length || 0) + (plan?.base_table ? 1 : 0);
    const joinsCount = plan?.joins?.length || 0;
    const hasTop = Boolean(plan?.top) || /\bTOP\s*\(\s*\d+\s*\)/i.test(cleanSql);
    const hasWhere = Boolean(plan?.filters && plan.filters.length > 0) || /\bWHERE\b/i.test(cleanSql);

    // Collect all table names involved
    const allTableNames = new Set<string>();
    if (plan?.base_table) allTableNames.add(plan.base_table);
    for (const j of plan?.joins || []) {
      if (j.to_table) allTableNames.add(j.to_table);
      if (j.from_table) allTableNames.add(j.from_table);
    }

    // Check table sizes from KnowledgeBase
    let maxRowCount = 0;
    let hasHugeTable = false;
    let hugeTableName = "";

    for (const tbl of allTableNames) {
      const info = currentKb.getTable(tbl);
      const rows = info?.row_count || 0;
      if (rows > maxRowCount) {
        maxRowCount = rows;
      }
      if (rows > 50000 || (info?.has_data && rows > 20000)) {
        hasHugeTable = true;
        hugeTableName = tbl;
      }
    }

    // Slow Query Risk A: No WHERE clause at all on database with tables
    if (!hasWhere) {
      if (hasHugeTable) {
        issues.push({
          type: "slow_query",
          severity: "warning",
          title_fa: "کوئری بسیار سنگین — عدم وجود شرط فیلتر (WHERE)",
          message_fa: `کوئری فاقد هرگونه فیلتر WHERE است و بر روی جدول با حجم بالای داده (${hugeTableName} با حدود ${maxRowCount.toLocaleString("fa")} رکورد) اجرا می‌شود. این کوئری کل داده‌ها را اسکن کرده و باعث قفل شدن جدول و افت شدید عملکرد دیتابیس می‌شود.`,
          recommendation_fa: "حداقل یک فیلتر زمانی، سال مالی یا محدوده شناسه‌ها (WHERE) اضافه نمایید یا از محدودیت TOP استفاده کنید.",
        });
        score -= 25;
      } else {
        issues.push({
          type: "performance_hint",
          severity: "info",
          title_fa: "کوئری بدون فیلتر رکوردی",
          message_fa: "هیچ شرط فیلتری برای محدود کردن ردیف‌های خروجی تعریف نشده است.",
          recommendation_fa: "در صورت عدم نیاز به تمام رکوردها، شرط‌های محدودکننده بیافزایید.",
        });
        score -= 5;
      }
    }

    // Slow Query Risk B: Missing FiscalYearRef on financial / transactional tables
    if (plan) {
      const filteredFy = new Set<string>(
        (plan.filters || [])
          .filter((f) => f.column === "FiscalYearRef" || f.parameter === "FiscalYear")
          .map((f) => f.table || plan.base_table)
      );

      for (const t of allTableNames) {
        const tInfo = currentKb.getTable(t);
        if (tInfo && tInfo.columns?.some((c) => c.name === "FiscalYearRef") && !filteredFy.has(t)) {
          issues.push({
            type: "slow_query",
            severity: "warning",
            title_fa: `فقدان فیلتر سال مالی در جدول ${t}`,
            message_fa: `جدول ${t} حاوی فیلد سال مالی (FiscalYearRef) است اما فیلتری برای آن مشخص نشده است. این موضوع باعث خواندن تمام سال‌های مالی، تلفیق اشتباه اسناد و بار سنگین روی دیسک می‌گردد.`,
            recommendation_fa: `یک شرط فیلتر به صورت FiscalYearRef = @FiscalYear برای جدول ${t} درج فرمایید.`,
          });
          score -= 20;
        }
      }
    }

    // Slow Query Risk C: Leading wildcard in LIKE operator (e.g. LIKE '%text%')
    const leadingWildcardFilters: string[] = [];
    if (plan?.filters) {
      for (const f of plan.filters) {
        if (f.op === "LIKE" && typeof f.value === "string" && f.value.startsWith("%")) {
          leadingWildcardFilters.push(`${f.table || plan.base_table}.${f.column}`);
        }
      }
    }
    if (/LIKE\s+N?'%[^']/i.test(cleanSql)) {
      issues.push({
        type: "slow_query",
        severity: "warning",
        title_fa: "جستجوی کند با پیشوند نامشخص (Leading Wildcard LIKE '%...')",
        message_fa: "استفاده از علامت درصد در ابتدای عبارت LIKE مانع از بهره‌برداری موتور SQL از ایندکس‌های B-Tree شده و موجب پیمایش کامل ایندکس یا جدول (Index/Table Scan) می‌گردد.",
        recommendation_fa: "در صورت امکان از جستجوی پیشوندی (مانند 'عبارت%') یا فیلتر مساوی استفاده فرمایید.",
      });
      score -= 15;
    }

    // Slow Query Risk D: High number of JOINs without TOP or WHERE
    if (joinsCount >= 5) {
      issues.push({
        type: "slow_query",
        severity: "warning",
        title_fa: `تعداد بالای اتصالات جدول (${joinsCount} فقره JOIN)`,
        message_fa: `کوئری شامل ${joinsCount} جدول متصل است. در صورتی که ایندکس‌های ستون‌های اتصال مناسب نباشند، کامپایل پلن اجرایی و محاسبه Nested Loops / Hash Match زمان زیادی خواهد برد.`,
        recommendation_fa: "از اتصال جداول غیرضروری خودداری کرده و از فیلترهای مناسب روی جداول اصلی اطمینان حاصل فرمایید.",
      });
      score -= 10;
    }

    // Slow Query Risk E: Huge table query without TOP limit
    if (hasHugeTable && !hasTop && (!plan?.filters || plan.filters.length <= 1)) {
      issues.push({
        type: "slow_query",
        severity: "warning",
        title_fa: "فقدان محدودیت سقف ردیف (TOP) روی جدول بزرگ",
        message_fa: `جدول ${hugeTableName} حجم دادهٔ بالایی دارد. عدم اعمال عبارت TOP (مانند TOP 1000) در محیط گزارش‌گیری ممکن است منجر به انتقال صدها هزار ردیف روی شبکه و افت پاسخگویی سیستم گردد.`,
        recommendation_fa: "تعریف یک مقدار TOP معقول (مثلاً TOP 500 یا TOP 1000) برای جلوگیری از کوئری‌های بی‌نهایت پیشنهاد می‌شود.",
      });
      score -= 15;
    }

    // Slow Query Risk F: Multiple COUNT(DISTINCT) aggregations
    const distinctCountAggs = (plan?.select || []).filter((c) => c.aggregate === "COUNT_DISTINCT");
    const distinctCountInSql = (cleanSql.match(/COUNT\s*\(\s*DISTINCT/gi) || []).length;
    if (distinctCountAggs.length >= 2 || distinctCountInSql >= 2) {
      issues.push({
        type: "slow_query",
        severity: "warning",
        title_fa: "استفاده از چندین تابع COUNT(DISTINCT)",
        message_fa: "وجود بیش از یک عبارت COUNT(DISTINCT) در کوئری نیازمند چندین مرحله مرتب‌سازی و تفکیک (Stream/Hash Aggregate) جداگانه در موتور SQL Server است که کارایی را کاهش می‌دهد.",
        recommendation_fa: "در صورت امکان این شمارش‌ها را تفکیک کرده یا در CTE‌های مجزا محاسبه نمایید.",
      });
      score -= 10;
    }

    // Slow Query Risk G: Cross Join or Missing Join conditions
    if (/\bCROSS\s+JOIN\b/i.test(cleanSql)) {
      issues.push({
        type: "slow_query",
        severity: "critical",
        title_fa: "شناسایی اتصال متقاطع (CROSS JOIN / ضرب دکارتی)",
        message_fa: "دستور CROSS JOIN سطرهای دو جدول را در یکدیگر ضرب می‌کند. در جداول با حجم ردیف متوسط به بالا، این کار باعث تولید میلیون‌ها سطر تصنعی و فریز شدن حافظه TempDB می‌گردد.",
        recommendation_fa: "اتصال را به INNER JOIN یا LEFT JOIN همراه با شرط کلید تبدیل نمایید.",
      });
      score -= 30;
    }

    // ── 3. POSITIVE CHECKS & BEST PRACTICES ──
    if (hasTop && issues.length === 0) {
      issues.push({
        type: "performance_hint",
        severity: "info",
        title_fa: "کوئری بهینه و مهارشده با محدودیت ردیف",
        message_fa: "دستور شامل محدودیت سقف ردیف (TOP) است که امنیت بار مصرفی سرور را تضمین می‌کند.",
      });
    }

    // Determine estimated cost tier
    let estimatedCost: "LOW" | "MEDIUM" | "HIGH" | "VERY_HIGH" = "LOW";
    if (!hasWhere && hasHugeTable) {
      estimatedCost = "VERY_HIGH";
    } else if (hasHugeTable && !hasTop) {
      estimatedCost = "HIGH";
    } else if (joinsCount > 4 || leadingWildcardFilters.length > 0) {
      estimatedCost = "MEDIUM";
    }

    const destructiveCount = issues.filter((i) => i.type === "destructive_keyword" || i.severity === "critical").length;
    const slowQueryCount = issues.filter((i) => i.type === "slow_query" && i.severity === "warning").length;
    const isSafe = destructiveCount === 0;
    const hasSlowRisks = slowQueryCount > 0;

    // Normalize score
    score = Math.max(10, Math.min(100, score));

    let summaryFa = "کوئری از نظر ایمنی و کارایی ارزیابی شد و مشکلی مشاهده نشد.";
    if (!isSafe) {
      summaryFa = `هشدار بحرانی: ${destructiveCount} مورد کلمات کلیدی مخرب یا غیرمجاز در کوئری شناسایی شد. اعمال نهایی مسدود است.`;
    } else if (hasSlowRisks) {
      summaryFa = `توجه: ${slowQueryCount} مورد خطر افت کارایی (Slow Query) شناسایی شد. پیشنهاد می‌شود قبل از اعمال بازبینی فرمایید.`;
    }

    return {
      is_safe: isSafe,
      has_slow_query_risks: hasSlowRisks,
      score,
      summary_fa: summaryFa,
      issues,
      metrics: {
        destructive_keywords_count: destructiveCount,
        slow_query_risks_count: slowQueryCount,
        tables_count: tablesCount,
        joins_count: joinsCount,
        has_top_limit: hasTop,
        has_where_clause: hasWhere,
        estimated_cost_tier: estimatedCost,
      },
    };
  }
}
