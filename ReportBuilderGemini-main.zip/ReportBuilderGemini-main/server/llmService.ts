import { GoogleGenAI } from "@google/genai";
import { settingsStore } from "./settings.js";
import { QueryPlan } from "./types.js";

export interface ModelTestResult {
  ok: boolean;
  success: boolean;
  provider: string;
  model: string;
  reply: string;
  latency_ms: number;
  mode: "cloud" | "heuristic";
  error?: string;
}

export class LLMService {
  /**
   * Determine the active provider, model name, and appropriate API key.
   */
  public static resolveConfig() {
    const raw = settingsStore.getRawSettings();
    const preset = raw.model_preset || raw.preset || "emergent-gemini";
    const overrideModel = (raw.model_override || "").trim();
    const baseUrl = (raw.base_url || "").trim();
    const keys = raw.api_keys || {};

    let provider = "google";
    let defaultModel = "gemini-3.6-flash";
    let apiKey = "";

    if (preset.includes("claude") || preset === "emergent" || preset.includes("anthropic")) {
      provider = "anthropic";
      defaultModel = overrideModel || "claude-3-5-sonnet-20241022";
      apiKey = keys.anthropic || keys.claude || process.env.ANTHROPIC_API_KEY || "";
    } else if (preset.includes("gpt") || preset.includes("openai")) {
      provider = "openai";
      defaultModel = overrideModel || "gpt-4o";
      apiKey = keys.openai || keys.gpt || process.env.OPENAI_API_KEY || "";
    } else if (preset.includes("deepseek")) {
      provider = "deepseek";
      defaultModel = overrideModel || "deepseek-chat";
      apiKey = keys.deepseek || process.env.DEEPSEEK_API_KEY || "";
    } else if (preset === "ollama" || preset === "lmstudio" || preset === "openrouter") {
      provider = "openai-compatible";
      defaultModel = overrideModel || (preset === "ollama" ? "qwen2.5-coder:14b" : "local-model");
      apiKey = keys.openai || keys.openrouter || "local-key";
    } else {
      // Default: Google Gemini
      provider = "google";
      defaultModel = overrideModel || "gemini-3.6-flash";
      apiKey = keys.google || keys.gemini || process.env.GEMINI_API_KEY || "";
    }

    return {
      preset,
      provider,
      model: overrideModel || defaultModel,
      apiKey,
      baseUrl,
      timeout: raw.timeout_seconds || raw.timeout || 45,
    };
  }

  /**
   * Test connection to the configured model.
   */
  public static async testConnection(): Promise<ModelTestResult> {
    const cfg = this.resolveConfig();
    const start = Date.now();

    // 1. If provider is Google Gemini
    if (cfg.provider === "google") {
      if (!cfg.apiKey) {
        return {
          ok: true,
          success: true,
          provider: "Google Gemini",
          model: cfg.model,
          reply: "موتور کاوشگر و هوش محلی (Heuristic Copilot) فعال است. جهت اتصال به سرویس ابری جِمینای، کلید API شخصی Google را در بخش کلیدها وارد نمایید.",
          latency_ms: 12,
          mode: "heuristic",
        };
      }

      try {
        const ai = new GoogleGenAI({ apiKey: cfg.apiKey });
        let response;
        const testPrompt = "یک کلمه بگو: متصل";

        try {
          response = await ai.models.generateContent({
            model: cfg.model,
            contents: testPrompt,
          });
        } catch (err: any) {
          if (err?.status === 404 || err?.message?.includes("not found")) {
            response = await ai.models.generateContent({
              model: "gemini-2.5-flash",
              contents: testPrompt,
            });
          } else {
            throw err;
          }
        }

        const replyText = response?.text?.trim() || "اتصال موفقیت‌آمیز برقرار شد.";
        const duration = Date.now() - start;

        return {
          ok: true,
          success: true,
          provider: "Google Gemini",
          model: cfg.model,
          reply: `ارتباط با موفقیت برقرار شد (پاسخ: ${replyText.slice(0, 50)})`,
          latency_ms: duration,
          mode: "cloud",
        };
      } catch (err: any) {
        return {
          ok: false,
          success: false,
          provider: "Google Gemini",
          model: cfg.model,
          reply: "",
          latency_ms: Date.now() - start,
          mode: "cloud",
          error: `خطا در اتصال به Google Gemini: ${err.message || String(err)}`,
        };
      }
    }

    // 2. If provider is Anthropic Claude
    if (cfg.provider === "anthropic") {
      if (!cfg.apiKey) {
        return {
          ok: false,
          success: false,
          provider: "Anthropic Claude",
          model: cfg.model,
          reply: "",
          latency_ms: 5,
          mode: "cloud",
          error: "کلید API شخصی Anthropic (Claude) تعریف نشده است. لطفاً کلید با پیشوند sk-ant را در تنظیمات وارد فرمایید.",
        };
      }

      try {
        const url = cfg.baseUrl ? `${cfg.baseUrl.replace(/\/$/, "")}/messages` : "https://api.anthropic.com/v1/messages";
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);

        const res = await fetch(url, {
          method: "POST",
          headers: {
            "x-api-key": cfg.apiKey,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
          },
          body: JSON.stringify({
            model: cfg.model,
            max_tokens: 30,
            messages: [{ role: "user", content: "یک کلمه بگو: متصل" }],
          }),
          signal: controller.signal,
        });
        clearTimeout(timeout);

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData?.error?.message || `HTTP ${res.status}: ${res.statusText}`);
        }

        const data: any = await res.json();
        const replyText = data?.content?.[0]?.text || "اتصال موفقیت‌آمیز";
        const duration = Date.now() - start;

        return {
          ok: true,
          success: true,
          provider: "Anthropic Claude",
          model: cfg.model,
          reply: `اتصال با Claude برقرار شد (پاسخ: ${replyText.slice(0, 50)})`,
          latency_ms: duration,
          mode: "cloud",
        };
      } catch (err: any) {
        return {
          ok: false,
          success: false,
          provider: "Anthropic Claude",
          model: cfg.model,
          reply: "",
          latency_ms: Date.now() - start,
          mode: "cloud",
          error: `خطا در اتصال به Anthropic Claude: ${err.message || String(err)}`,
        };
      }
    }

    // 3. If provider is OpenAI / DeepSeek / Local Compatible
    if (cfg.provider === "openai" || cfg.provider === "deepseek" || cfg.provider === "openai-compatible") {
      let defaultEndpoint = "https://api.openai.com/v1";
      if (cfg.provider === "deepseek") defaultEndpoint = "https://api.deepseek.com/v1";
      if (cfg.preset === "ollama") defaultEndpoint = "http://localhost:11434/v1";
      if (cfg.preset === "lmstudio") defaultEndpoint = "http://localhost:1234/v1";
      if (cfg.preset === "openrouter") defaultEndpoint = "https://openrouter.ai/api/v1";

      const endpoint = (cfg.baseUrl || defaultEndpoint).replace(/\/$/, "");

      if (!cfg.apiKey && cfg.provider !== "openai-compatible") {
        return {
          ok: false,
          success: false,
          provider: cfg.provider.toUpperCase(),
          model: cfg.model,
          reply: "",
          latency_ms: 5,
          mode: "cloud",
          error: `کلید API برای سرویس ${cfg.provider} وارد نشده است. لطفاً در بخش کلیدهای شخصی وارد فرمایید.`,
        };
      }

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);

        const res = await fetch(`${endpoint}/chat/completions`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${cfg.apiKey || "none"}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: cfg.model,
            max_tokens: 30,
            messages: [{ role: "user", content: "یک کلمه بگو: متصل" }],
          }),
          signal: controller.signal,
        });
        clearTimeout(timeout);

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData?.error?.message || `HTTP ${res.status}: ${res.statusText}`);
        }

        const data: any = await res.json();
        const replyText = data?.choices?.[0]?.message?.content || "اتصال موفقیت‌آمیز";
        const duration = Date.now() - start;

        return {
          ok: true,
          success: true,
          provider: cfg.provider.toUpperCase(),
          model: cfg.model,
          reply: `اتصال برقرار شد (پاسخ: ${replyText.slice(0, 50)})`,
          latency_ms: duration,
          mode: "cloud",
        };
      } catch (err: any) {
        return {
          ok: false,
          success: false,
          provider: cfg.provider.toUpperCase(),
          model: cfg.model,
          reply: "",
          latency_ms: Date.now() - start,
          mode: "cloud",
          error: `خطا در اتصال به ${cfg.provider}: ${err.message || String(err)}`,
        };
      }
    }

    // Default fallback
    return {
      ok: true,
      success: true,
      provider: "Heuristic Engine",
      model: "Heuristic-Copilot",
      reply: "موتور پردازشگر داخلی فعال و آماده به کار است.",
      latency_ms: 8,
      mode: "heuristic",
    };
  }

  /**
   * Universal text generation for QueryPlan creation.
   */
  public static async generateContent(prompt: string): Promise<string | null> {
    const cfg = this.resolveConfig();

    // 1. Google
    if (cfg.provider === "google" && cfg.apiKey) {
      try {
        const ai = new GoogleGenAI({ apiKey: cfg.apiKey });
        let resp;
        try {
          resp = await ai.models.generateContent({
            model: cfg.model,
            contents: prompt,
          });
        } catch (err: any) {
          if (err?.status === 404 || err?.message?.includes("not found")) {
            resp = await ai.models.generateContent({
              model: "gemini-2.5-flash",
              contents: prompt,
            });
          } else {
            throw err;
          }
        }
        return resp.text ? resp.text.trim() : null;
      } catch (e) {
        console.warn("Google GenAI call failed:", e);
        return null;
      }
    }

    // 2. Anthropic Claude
    if (cfg.provider === "anthropic" && cfg.apiKey) {
      try {
        const url = cfg.baseUrl ? `${cfg.baseUrl.replace(/\/$/, "")}/messages` : "https://api.anthropic.com/v1/messages";
        const res = await fetch(url, {
          method: "POST",
          headers: {
            "x-api-key": cfg.apiKey,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
          },
          body: JSON.stringify({
            model: cfg.model,
            max_tokens: 3000,
            messages: [{ role: "user", content: prompt }],
          }),
        });
        if (!res.ok) return null;
        const data: any = await res.json();
        return data?.content?.[0]?.text || null;
      } catch (e) {
        console.warn("Anthropic Claude call failed:", e);
        return null;
      }
    }

    // 3. OpenAI / DeepSeek / Compatible
    if ((cfg.provider === "openai" || cfg.provider === "deepseek" || cfg.provider === "openai-compatible") && cfg.apiKey) {
      try {
        let endpoint = cfg.baseUrl || (cfg.provider === "deepseek" ? "https://api.deepseek.com/v1" : "https://api.openai.com/v1");
        endpoint = endpoint.replace(/\/$/, "");

        const res = await fetch(`${endpoint}/chat/completions`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${cfg.apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: cfg.model,
            max_tokens: 3000,
            messages: [{ role: "user", content: prompt }],
          }),
        });
        if (!res.ok) return null;
        const data: any = await res.json();
        return data?.choices?.[0]?.message?.content || null;
      } catch (e) {
        console.warn("OpenAI/DeepSeek call failed:", e);
        return null;
      }
    }

    return null;
  }
}
