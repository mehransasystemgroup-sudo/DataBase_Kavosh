import { QueryPlan, ReportLayout } from "./types.js";

export class RdlBuilder {
  public static buildRdl(
    plan: QueryPlan,
    sql: string,
    layout?: ReportLayout,
    options: {
      reportTitle?: string;
      fontFamily?: string;
      direction?: "RTL" | "LTR";
      dataSource?: string;
    } = {}
  ): string {
    const title = options.reportTitle || plan.intent_fa || "گزارش سازمانی";
    const font = options.fontFamily || "Vazirmatn";
    const dir = options.direction || "RTL";
    const dataSource = options.dataSource || "ReportDataSource";

    // Fields
    const fields = (plan.select || []).map((c) => {
      const name = c.alias || (c.aggregate ? `${c.aggregate.toLowerCase()}_${c.column}` : c.column);
      return {
        name,
        dataField: name,
        type: "System.String",
      };
    });

    const datasetFieldsXml = fields
      .map(
        (f) => `      <Field Name="${f.name}">
        <DataField>${f.dataField}</DataField>
        <rd:TypeName>${f.type}</rd:TypeName>
      </Field>`
      )
      .join("\n");

    // Parameters
    const params = plan.parameters || [];
    const rdlParamsXml = params
      .map(
        (p) => `    <ReportParameter Name="${p.name}">
      <DataType>${p.type === "int" ? "Integer" : "String"}</DataType>
      <Prompt>${escapeXml(p.title_fa || p.name)}</Prompt>
    </ReportParameter>`
      )
      .join("\n");

    const datasetParamsXml = params
      .map(
        (p) => `        <QueryParameter Name="@${p.name}">
          <Value>=Parameters!${p.name}.Value</Value>
        </QueryParameter>`
      )
      .join("\n");

    // Table columns & Tablix members
    const colWidth = "3.2cm";
    const tablixColumnsXml = fields
      .map(
        () => `          <TablixColumn>
            <Width>${colWidth}</Width>
          </TablixColumn>`
      )
      .join("\n");

    const headerCellsXml = fields
      .map(
        (f) => `            <TablixCell>
              <CellContents>
                <Textbox Name="Hdr_${f.name}">
                  <CanGrow>true</CanGrow>
                  <KeepTogether>true</KeepTogether>
                  <Paragraphs>
                    <Paragraph>
                      <TextRuns>
                        <TextRun>
                          <Value>${escapeXml(f.name)}</Value>
                          <Style>
                            <FontFamily>${font}</FontFamily>
                            <FontSize>10pt</FontSize>
                            <FontWeight>Bold</FontWeight>
                            <Color>#FFFFFF</Color>
                          </Style>
                        </TextRun>
                      </TextRuns>
                      <Style>
                        <TextAlign>Center</TextAlign>
                        <Direction>${dir}</Direction>
                      </Style>
                    </Paragraph>
                  </Paragraphs>
                  <Style>
                    <BackgroundColor>#1E293B</BackgroundColor>
                    <Border>
                      <Color>#CBD5E1</Color>
                      <Style>Solid</Style>
                    </Border>
                    <PaddingLeft>2pt</PaddingLeft>
                    <PaddingRight>2pt</PaddingRight>
                    <PaddingTop>4pt</PaddingTop>
                    <PaddingBottom>4pt</PaddingBottom>
                  </Style>
                </Textbox>
              </CellContents>
            </TablixCell>`
      )
      .join("\n");

    const dataCellsXml = fields
      .map(
        (f) => `            <TablixCell>
              <CellContents>
                <Textbox Name="Txt_${f.name}">
                  <CanGrow>true</CanGrow>
                  <KeepTogether>true</KeepTogether>
                  <Paragraphs>
                    <Paragraph>
                      <TextRuns>
                        <TextRun>
                          <Value>=Fields!${f.name}.Value</Value>
                          <Style>
                            <FontFamily>${font}</FontFamily>
                            <FontSize>9pt</FontSize>
                          </Style>
                        </TextRun>
                      </TextRuns>
                      <Style>
                        <TextAlign>Center</TextAlign>
                        <Direction>${dir}</Direction>
                      </Style>
                    </Paragraph>
                  </Paragraphs>
                  <Style>
                    <Border>
                      <Color>#E2E8F0</Color>
                      <Style>Solid</Style>
                    </Border>
                    <PaddingLeft>2pt</PaddingLeft>
                    <PaddingRight>2pt</PaddingRight>
                    <PaddingTop>3pt</PaddingTop>
                    <PaddingBottom>3pt</PaddingBottom>
                  </Style>
                </Textbox>
              </CellContents>
            </TablixCell>`
      )
      .join("\n");

    const tablixMembersXml = fields.map(() => `            <TablixMember />`).join("\n");

    return `<?xml version="1.0" encoding="utf-8"?>
<Report xmlns="http://schemas.microsoft.com/sqlserver/reporting/2016/01/reportdefinition" xmlns:rd="http://schemas.microsoft.com/SQLServer/reporting/reportdesigner">
  <AutoRefresh>0</AutoRefresh>
  <DataSources>
    <DataSource Name="${dataSource}">
      <ConnectionProperties>
        <DataProvider>SQL</DataProvider>
        <ConnectString />
        <IntegratedSecurity>true</IntegratedSecurity>
      </ConnectionProperties>
      <rd:SecurityType>Integrated</rd:SecurityType>
    </DataSource>
  </DataSources>
  <DataSets>
    <DataSet Name="DataSet1">
      <Query>
        <DataSourceName>${dataSource}</DataSourceName>
        <CommandText>${escapeXml(sql)}</CommandText>
        <QueryParameters>
${datasetParamsXml}
        </QueryParameters>
      </Query>
      <Fields>
${datasetFieldsXml}
      </Fields>
    </DataSet>
  </DataSets>
  <ReportParameters>
${rdlParamsXml}
  </ReportParameters>
  <ReportSections>
    <ReportSection>
      <Body>
        <ReportItems>
          <Textbox Name="ReportTitle">
            <CanGrow>true</CanGrow>
            <KeepTogether>true</KeepTogether>
            <Paragraphs>
              <Paragraph>
                <TextRuns>
                  <TextRun>
                    <Value>${escapeXml(title)}</Value>
                    <Style>
                      <FontFamily>${font}</FontFamily>
                      <FontSize>16pt</FontSize>
                      <FontWeight>Bold</FontWeight>
                      <Color>#0F172A</Color>
                    </Style>
                  </TextRun>
                </TextRuns>
                <Style>
                  <TextAlign>Center</TextAlign>
                  <Direction>${dir}</Direction>
                </Style>
              </Paragraph>
            </Paragraphs>
            <Top>0.5cm</Top>
            <Left>0.5cm</Left>
            <Height>1.0cm</Height>
            <Width>20cm</Width>
            <Style>
              <Border>
                <Style>None</Style>
              </Border>
              <PaddingTop>2pt</PaddingTop>
              <PaddingBottom>2pt</PaddingBottom>
            </Style>
          </Textbox>
          <Tablix Name="Tablix1">
            <TablixBody>
              <TablixColumns>
${tablixColumnsXml}
              </TablixColumns>
              <TablixRows>
                <TablixRow>
                  <Height>0.8cm</Height>
                  <TablixCells>
${headerCellsXml}
                  </TablixCells>
                </TablixRow>
                <TablixRow>
                  <Height>0.7cm</Height>
                  <TablixCells>
${dataCellsXml}
                  </TablixCells>
                </TablixRow>
              </TablixRows>
            </TablixBody>
            <TablixColumnHierarchy>
              <TablixMembers>
${tablixMembersXml}
              </TablixMembers>
            </TablixColumnHierarchy>
            <TablixRowHierarchy>
              <TablixMembers>
                <TablixMember>
                  <KeepWithGroup>After</KeepWithGroup>
                  <RepeatOnNewPage>true</RepeatOnNewPage>
                </TablixMember>
                <TablixMember>
                  <Group Name="Details" />
                </TablixMember>
              </TablixMembers>
            </TablixRowHierarchy>
            <DataSetName>DataSet1</DataSetName>
            <Top>1.8cm</Top>
            <Left>0.5cm</Left>
            <Height>1.5cm</Height>
            <Width>${(fields.length * 3.2).toFixed(1)}cm</Width>
            <Style>
              <Border>
                <Color>#CBD5E1</Color>
                <Style>Solid</Style>
              </Border>
            </Style>
          </Tablix>
        </ReportItems>
        <Height>4.0cm</Height>
        <Style />
      </Body>
      <Width>28cm</Width>
      <Page>
        <PageHeader>
          <Height>1.0cm</Height>
          <PrintOnFirstPage>true</PrintOnFirstPage>
          <PrintOnLastPage>true</PrintOnLastPage>
          <ReportItems>
            <Textbox Name="HeaderDate">
              <Paragraphs>
                <Paragraph>
                  <TextRuns>
                    <TextRun>
                      <Value>=Globals!ExecutionTime</Value>
                      <Style>
                        <FontFamily>${font}</FontFamily>
                        <FontSize>8pt</FontSize>
                        <Format>yyyy/MM/dd</Format>
                      </Style>
                    </TextRun>
                  </TextRuns>
                  <Style>
                    <TextAlign>Right</TextAlign>
                  </Style>
                </Paragraph>
              </Paragraphs>
              <Top>0.2cm</Top>
              <Left>0.5cm</Left>
              <Height>0.6cm</Height>
              <Width>4cm</Width>
              <Style>
                <Border>
                  <Style>None</Style>
                </Border>
              </Style>
            </Textbox>
          </ReportItems>
          <Style />
        </PageHeader>
        <PageFooter>
          <Height>1.0cm</Height>
          <PrintOnFirstPage>true</PrintOnFirstPage>
          <PrintOnLastPage>true</PrintOnLastPage>
          <ReportItems>
            <Textbox Name="FooterPageNumber">
              <Paragraphs>
                <Paragraph>
                  <TextRuns>
                    <TextRun>
                      <Value>="صفحه " &amp; Globals!PageNumber &amp; " از " &amp; Globals!TotalPages</Value>
                      <Style>
                        <FontFamily>${font}</FontFamily>
                        <FontSize>8pt</FontSize>
                      </Style>
                    </TextRun>
                  </TextRuns>
                  <Style>
                    <TextAlign>Center</TextAlign>
                    <Direction>${dir}</Direction>
                  </Style>
                </Paragraph>
              </Paragraphs>
              <Top>0.2cm</Top>
              <Left>10cm</Left>
              <Height>0.6cm</Height>
              <Width>8cm</Width>
              <Style>
                <Border>
                  <Style>None</Style>
                </Border>
              </Style>
            </Textbox>
          </ReportItems>
          <Style />
        </PageFooter>
        <PageHeight>21cm</PageHeight>
        <PageWidth>29.7cm</PageWidth>
        <LeftMargin>0.5cm</LeftMargin>
        <RightMargin>0.5cm</RightMargin>
        <TopMargin>0.5cm</TopMargin>
        <BottomMargin>0.5cm</BottomMargin>
        <Style />
      </Page>
    </ReportSection>
  </ReportSections>
  <Language>fa-IR</Language>
  <rd:ReportUnitType>Cm</rd:ReportUnitType>
  <rd:ReportID>${generateUuid()}</rd:ReportID>
</Report>`;
  }

  public static validateRdl(rdlXml: string): { ok: boolean; issues: string[] } {
    const issues: string[] = [];
    if (!rdlXml.includes("<Report")) issues.push("تگ ریشه <Report> یافت نشد.");
    if (!rdlXml.includes("<DataSet")) issues.push("هیچ <DataSet> در فایل RDL تعریف نشده است.");
    if (!rdlXml.includes("<Tablix")) issues.push("هیچ عنصر نمایش جدول (<Tablix>) تعریف نشده است.");
    return { ok: issues.length === 0, issues };
  }
}

function escapeXml(unsafe: string): string {
  return (unsafe || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function generateUuid(): string {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
