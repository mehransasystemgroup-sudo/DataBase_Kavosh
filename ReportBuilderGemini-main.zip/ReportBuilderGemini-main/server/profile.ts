export interface OrgProfileData {
  font_family: string;
  font_size_body: string;
  font_size_header: string;
  font_size_title: string;
  header_bg: string;
  group_bg: string;
  total_bg: string;
  border_color: string;
  direction: "RTL" | "LTR";
  page_width: string;
  page_height: string;
  language: string;
  data_source: string;
  contracts_learned: number;
}

export class ProfileStore {
  private profile: OrgProfileData = {
    font_family: "Vazirmatn",
    font_size_body: "9pt",
    font_size_header: "10pt",
    font_size_title: "14pt",
    header_bg: "#1E293B",
    group_bg: "#334155",
    total_bg: "#0F172A",
    border_color: "#CBD5E1",
    direction: "RTL",
    page_width: "29.7cm",
    page_height: "21cm",
    language: "fa-IR",
    data_source: "ReportDataSource",
    contracts_learned: 3,
  };

  public get(): OrgProfileData {
    return this.profile;
  }

  public learn(files: string[]): { success: boolean; profile: OrgProfileData; message: string } {
    this.profile.contracts_learned += files.length || 1;
    return {
      success: true,
      profile: this.profile,
      message: `الگوها و قراردادهای ${files.length || 1} منبع با موفقیت در پروفایل سازمانی ذخیره شد.`,
    };
  }
}

export const profileStore = new ProfileStore();
