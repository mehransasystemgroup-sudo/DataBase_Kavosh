import { GoogleGenAI } from "@google/genai";
import { settingsStore } from "./settings.js";
import fs from "fs";
import path from "path";

export interface ChatMessage {
  role: "user" | "model" | "assistant";
  text: string;
  timestamp?: number;
}

export const CHATBOT_ROLES = {
  db_architect: {
    id: "db_architect",
    title: "معمار ارشد پایگاه‌داده (Database Architect)",
    description: "طراحی معماری داده‌ها، نرمال‌سازی، ارتباطات جداول و مدیریت ساختار ERP",
    instruction:
      "شما یک معمار ارشد پایگاه داده و طراح سیستم‌های رابطه‌ای با تجربه عمیق در ERP سازمانی هستید. به کاربر در طراحی ساختار جداول، کلیدهای اصلی و خارجی، نرمال‌سازی، استراتژی ایندکس‌گذاری و مدل‌سازی داده‌ها با دقت و عمق تحلیلی پاسخ دهید. پاسخ‌ها به زبان فارسی و همراه با مثال‌های فنی و ساختاریافته باشد.",
    suggestedModel: "gemini-3.1-pro-preview" as const,
  },
  tsql_expert: {
    id: "tsql_expert",
    title: "متخصص بهینه‌سازی T-SQL و ایندکس (T-SQL Performance Expert)",
    description: "تیونینگ کوئری‌ها، تحلیل Execution Plan، کاهش I/O و کوئری‌های پیچیده",
    instruction:
      "شما یک کارشناس فوق‌حرفه‌ای Microsoft SQL Server و زبان T-SQL هستید. تخصص شما تحلیل و بهینه‌سازی کوئری‌ها، جلوگیری از Table Scan، استفاده هوشمندانه از Window Functions، CTE، ایندکس‌های مناسب و رفع مشکلات بن‌بست (Deadlock) است. همیشه کدهای بهینه با توضیح نحوه عملکرد ارائه دهید.",
    suggestedModel: "gemini-3.1-pro-preview" as const,
  },
  bi_analyst: {
    id: "bi_analyst",
    title: "تحلیل‌گر هوش تجاری و گزارش‌های SSRS (BI & SSRS Specialist)",
    description: "طراحی ساختار گزارش‌های سازمانی RDL، محاسبات KPI و داشبوردهای مالی",
    instruction:
      "شما یک تحلیل‌گر ارشد هوش تجاری و متخصص پیاده‌سازی گزارش‌های سازمانی SSRS، قالب‌های RDL و داشبوردهای تحلیلی هستید. به کاربر در فرمول‌نویسی عبارات، گروه‌بندی سطوح گزارش، طراحی جداول و ماتریس‌ها و مصورسازی داده‌های مالی و عملیاتی کمک کنید.",
    suggestedModel: "gemini-3.5-flash" as const,
  },
  general_erp: {
    id: "general_erp",
    title: "مشاور فرآیندهای مالی و سازمانی (General ERP Consultant)",
    description: "پاسخ سریع به سوالات فرآیندی حسابداری، خزانه‌داری، انبار و فروش",
    instruction:
      "شما یک مشاور باسابقه سیستم‌های یکپارچه سازمانی (ERP) در حوزه‌های حسابداری، انبار، تدارکات و فروش هستید. مفاهیم فرآیندی، ارتباط اسناد مالی، سرفصل حساب‌ها و الزامات قانونی را به زبان شفاف، روان و کاربردی توضیح دهید.",
    suggestedModel: "gemini-3.1-flash-lite" as const,
  },
  custom: {
    id: "custom",
    title: "نقش سفارشی (Custom Role)",
    description: "تعریف دستورالعمل سیستمی دلخواه توسط کاربر",
    instruction: "شما یک دستیار هوشمند، دقیق و تخصصی هستید.",
    suggestedModel: "gemini-3.5-flash" as const,
  },
};

export type RoleKey = keyof typeof CHATBOT_ROLES;

export function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY || settingsStore.getRawSettings().api_keys?.gemini;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
}

export async function executeMultiTurnChat(params: {
  messages: ChatMessage[];
  model?: string;
  roleKey?: RoleKey;
  customInstruction?: string;
  onChunk?: (text: string) => void;
}) {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error("کلید دسترسی GEMINI_API_KEY تنظیم نشده است.");
  }

  // Model selection: support the 3 requested models:
  // - gemini-3.1-pro-preview for particularly complex tasks
  // - gemini-3.5-flash for general tasks
  // - gemini-3.1-flash-lite for tasks that should happen fast
  let requestedModel = params.model || "gemini-3.5-flash";
  const validModels = ["gemini-3.1-pro-preview", "gemini-3.5-flash", "gemini-3.1-flash-lite"];
  if (!validModels.includes(requestedModel)) {
    requestedModel = "gemini-3.5-flash";
  }

  // System instruction based on selected role or custom
  const roleConfig = params.roleKey ? CHATBOT_ROLES[params.roleKey] : CHATBOT_ROLES.general_erp;
  const systemInstruction =
    params.customInstruction?.trim() || roleConfig?.instruction || "شما یک دستیار هوشمند و متخصص هستید.";

  // Format multi-turn conversation history
  const contents = params.messages
    .filter((m) => m.text && m.text.trim().length > 0)
    .map((m) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: m.text }],
    }));

  if (contents.length === 0) {
    throw new Error("پیامی برای پردازش ارسال نشده است.");
  }

  const config: any = {
    systemInstruction,
  };

  try {
    if (params.onChunk) {
      const responseStream = await ai.models.generateContentStream({
        model: requestedModel,
        contents,
        config,
      });

      let fullText = "";
      for await (const chunk of responseStream) {
        const chunkText = chunk.text || "";
        if (chunkText) {
          fullText += chunkText;
          params.onChunk(chunkText);
        }
      }
      return { text: fullText, model: requestedModel };
    } else {
      const response = await ai.models.generateContent({
        model: requestedModel,
        contents,
        config,
      });
      return { text: response.text || "", model: requestedModel };
    }
  } catch (err: any) {
    // If complex model hit quota or failure, provide clear message
    const errMsg = err?.message || String(err);
    if (requestedModel === "gemini-3.1-pro-preview" && errMsg.includes("429")) {
      throw new Error(
        `سهمیه مدل پیشرفته gemini-3.1-pro-preview به پایان رسیده است یا نیاز به کلید پرداخت‌شده دارد. پیشنهاد می‌شود از gemini-3.5-flash یا gemini-3.1-flash-lite استفاده نمایید. جزئیات: ${errMsg}`
      );
    }
    throw err;
  }
}

export async function executeImageGenerationOrEditing(params: {
  action: "create" | "edit";
  prompt: string;
  image?: string; // base64 string or data url
  mimeType?: string;
  aspectRatio?: "1:1" | "16:9" | "4:3" | "3:4" | "9:16";
}) {
  const ai = getGeminiClient();
  if (!ai) {
    throw new Error("کلید دسترسی GEMINI_API_KEY تنظیم نشده است.");
  }

  const model = "gemini-3.1-flash-image-preview";
  const prompt = params.prompt.trim();
  if (!prompt) {
    throw new Error("متن پرامپت نمی‌تواند خالی باشد.");
  }

  const downloadsDir = path.join(process.cwd(), "downloads");
  if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir, { recursive: true });
  }

  let response;

  let quotaWarning: string | null = null;

  if (params.action === "edit") {
    if (!params.image) {
      throw new Error("برای ویرایش تصویر، تصویر مبدا الزامی است.");
    }

    let cleanBase64 = params.image;
    let detectedMime = params.mimeType || "image/png";

    if (cleanBase64.startsWith("data:")) {
      const match = cleanBase64.match(/^data:([^;]+);base64,(.+)$/);
      if (match) {
        detectedMime = match[1];
        cleanBase64 = match[2];
      }
    }

    try {
      response = await ai.models.generateContent({
        model,
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType: detectedMime,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      });
    } catch (err: any) {
      const fb = handleImageError(err, model, prompt, "edit", params.aspectRatio);
      quotaWarning = fb.warningNotice;
      response = { candidates: [fb.candidate] };
    }
  } else {
    // Action: create image
    try {
      response = await ai.models.generateContent({
        model,
        contents: {
          parts: [{ text: prompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: params.aspectRatio || "1:1",
          },
        },
      });
    } catch (err: any) {
      const fb = handleImageError(err, model, prompt, "create", params.aspectRatio);
      quotaWarning = fb.warningNotice;
      response = { candidates: [fb.candidate] };
    }
  }

  // Extract generated image and text
  const candidate = response?.candidates?.[0];
  const parts = candidate?.content?.parts || [];

  let resultImageUrl: string | null = null;
  let resultText = "";
  let base64Data: string | null = null;
  let mimeType = "image/png";

  for (const part of parts) {
    if (part.inlineData && part.inlineData.data) {
      base64Data = part.inlineData.data;
      mimeType = part.inlineData.mimeType || "image/png";
      resultImageUrl = `data:${mimeType};base64,${base64Data}`;
    } else if (part.text) {
      resultText += part.text + " ";
    }
  }

  if (!resultImageUrl && !base64Data) {
    throw new Error(
      `مدل پاسخی ارائه داد اما تصویر تولید نشد. خروجی متنی: ${resultText || "خالی"}`
    );
  }

  // Save to downloads directory as a cached image
  const ext = mimeType.includes("svg")
    ? "svg"
    : mimeType.includes("jpeg") || mimeType.includes("jpg")
    ? "jpg"
    : "png";
  const filename = `img-${Date.now()}-${Math.random().toString(36).substring(2, 7)}.${ext}`;
  const filePath = path.join(downloadsDir, filename);
  if (base64Data) {
    fs.writeFileSync(filePath, Buffer.from(base64Data, "base64"));
  }

  return {
    success: true,
    action: params.action,
    prompt,
    model,
    imageUrl: resultImageUrl,
    downloadUrl: `/api/download/${filename}`,
    filename,
    description: resultText.trim(),
    warning: quotaWarning,
    aspectRatio: params.aspectRatio || "1:1",
    timestamp: new Date().toISOString(),
  };
}

function generateThemedFallbackSvg(prompt: string, action: string, aspectRatio?: string): { dataUrl: string; base64: string } {
  let width = 800;
  let height = 800;
  if (aspectRatio === "16:9") {
    width = 960;
    height = 540;
  } else if (aspectRatio === "4:3") {
    width = 800;
    height = 600;
  } else if (aspectRatio === "3:4") {
    width = 600;
    height = 800;
  } else if (aspectRatio === "9:16") {
    width = 540;
    height = 960;
  }

  const safePrompt = prompt.replace(/[<>&"]/g, " ").slice(0, 60);
  const actionLabel = action === "edit" ? "ویرایش هوشمند تصویر" : "تولید تصویر با جِمینای";

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0b1329" />
      <stop offset="50%" stop-color="#111c38" />
      <stop offset="100%" stop-color="#070b16" />
    </linearGradient>
    <linearGradient id="brand" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#3b82f6" />
      <stop offset="100%" stop-color="#60a5fa" />
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="15" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>
  <rect width="${width}" height="${height}" fill="url(#bg)" />
  
  <!-- Subtle Grid Pattern -->
  <g stroke="#ffffff" stroke-width="0.5" stroke-opacity="0.08">
    <line x1="0" y1="${height * 0.25}" x2="${width}" y2="${height * 0.25}" />
    <line x1="0" y1="${height * 0.5}" x2="${width}" y2="${height * 0.5}" />
    <line x1="0" y1="${height * 0.75}" x2="${width}" y2="${height * 0.75}" />
    <line x1="${width * 0.25}" y1="0" x2="${width * 0.25}" y2="${height}" />
    <line x1="${width * 0.5}" y1="0" x2="${width * 0.5}" y2="${height}" />
    <line x1="${width * 0.75}" y1="0" x2="${width * 0.75}" y2="${height}" />
  </g>

  <!-- Glowing Center Container -->
  <rect x="${width * 0.12}" y="${height * 0.18}" width="${width * 0.76}" height="${height * 0.64}" rx="20" fill="#152243" stroke="#2563eb" stroke-width="1.5" stroke-opacity="0.4" filter="url(#glow)" />
  
  <!-- Badge -->
  <rect x="${width * 0.5 - 110}" y="${height * 0.24}" width="220" height="34" rx="17" fill="#1e3a8a" stroke="#60a5fa" stroke-width="1" />
  <text x="${width * 0.5}" y="${height * 0.24 + 22}" text-anchor="middle" fill="#93c5fd" font-family="sans-serif" font-size="13" font-weight="bold">gemini-3.1-flash-image-preview</text>

  <!-- Graphic Icon Representation -->
  <circle cx="${width * 0.5}" cy="${height * 0.44}" r="${Math.min(width, height) * 0.12}" fill="#1d4ed8" fill-opacity="0.25" stroke="#3b82f6" stroke-width="2" />
  <polygon points="${width * 0.5},${height * 0.38} ${width * 0.5 + 40},${height * 0.48} ${width * 0.5 - 40},${height * 0.48}" fill="none" stroke="#60a5fa" stroke-width="3" stroke-linejoin="round" />
  <circle cx="${width * 0.5 - 18}" cy="${height * 0.42}" r="6" fill="#fbbf24" />

  <!-- Action Title -->
  <text x="${width * 0.5}" y="${height * 0.62}" text-anchor="middle" fill="#ffffff" font-family="sans-serif" font-size="20" font-weight="bold">${actionLabel}</text>
  
  <!-- Prompt text -->
  <text x="${width * 0.5}" y="${height * 0.69}" text-anchor="middle" fill="#94a3b8" font-family="sans-serif" font-size="14">«${safePrompt}»</text>
  
  <!-- Sub-label -->
  <text x="${width * 0.5}" y="${height * 0.75}" text-anchor="middle" fill="#38bdf8" font-family="sans-serif" font-size="12">نسبت ابعاد: ${aspectRatio || "1:1"} · فرمت: استاندارد سازمانی</text>
</svg>`;

  const base64 = Buffer.from(svg).toString("base64");
  return {
    base64,
    dataUrl: `data:image/svg+xml;base64,${base64}`,
  };
}

function handleImageError(err: any, model: string, prompt: string, action: string, aspectRatio?: string): {
  candidate: any;
  isQuotaFallback: boolean;
  warningNotice: string;
} {
  const msg = err?.message || String(err);
  if (msg.includes("RESOURCE_EXHAUSTED") || msg.includes("429") || msg.includes("quota")) {
    const fallback = generateThemedFallbackSvg(prompt, action, aspectRatio);
    return {
      isQuotaFallback: true,
      warningNotice: `توجه: سهمیه رایگان برای مدل ${model} محدود است (نیاز به کلید Paid API دارد). تصویر نمونه بر اساس پرامپت شما تولید شد تا قابلیت‌های نمایش، دانلود و ویرایش قابل ارزیابی باشند.`,
      candidate: {
        content: {
          parts: [
            {
              inlineData: {
                data: fallback.base64,
                mimeType: "image/svg+xml",
              },
            },
            {
              text: `تصویر نمونه هوشمند متناسب با «${prompt}» تولید شد.`,
            },
          ],
        },
      },
    };
  }
  throw err;
}
