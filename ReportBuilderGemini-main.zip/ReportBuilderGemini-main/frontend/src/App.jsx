import { useEffect, useState, useCallback } from "react";
import "@/App.css";
import { http } from "@/lib/api";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider, useTheme } from "@/context/ThemeContext";
import ThemeToggle from "@/components/ThemeToggle";
import ChatView from "@/views/ChatView";
import KnowledgeView from "@/views/KnowledgeView";
import BenchView from "@/views/BenchView";
import CatalogView from "@/views/CatalogView";
import SettingsView from "@/views/SettingsView";
import SourcesView from "@/views/SourcesView";
import GeminiChatView from "@/views/GeminiChatView";
import ImageStudioView from "@/views/ImageStudioView";
import {
  MessagesSquare,
  Database,
  Scale,
  FolderCog,
  Settings2,
  Zap,
  CircleDot,
  X,
  UploadCloud,
  Bot,
  Wand2,
} from "lucide-react";

const NAV = [
  { id: "chat", label: "دستیار گزارش‌ساز (SQL/RDL)", icon: MessagesSquare },
  { id: "gemini_chat", label: "چت هوشمند جِمینای", icon: Bot, badge: "جدید" },
  { id: "image_studio", label: "استودیو تصویر جِمینای", icon: Wand2, badge: "جدید" },
  { id: "kb", label: "کاوش پایگاه‌داده", icon: Database },
  { id: "sources", label: "منابع و آپلود", icon: UploadCloud },
  { id: "bench", label: "محک چندمدلی", icon: Scale },
  { id: "catalog", label: "کاتالوگ گزارش‌ها", icon: FolderCog },
  { id: "settings", label: "تنظیمات", icon: Settings2 },
];

const PRESET_LABEL = {
  emergent: "Emergent · Claude",
  "emergent-gpt": "Emergent · GPT",
  "emergent-gemini": "Emergent · Gemini",
  claude: "Claude",
  gpt: "GPT-4o",
  deepseek: "DeepSeek",
  gemini: "Gemini",
  ollama: "Ollama (محلی)",
  lmstudio: "LM Studio",
  openrouter: "OpenRouter",
};

function Sidebar({ view, setView, health, onClose }) {
  const model = health?.model || "—";
  const budget = health?.budget;
  return (
    <div className="flex h-full w-64 flex-col bg-surface/95">
      <div className="flex items-center gap-2 border-b border-border px-4 py-4">
        <div className="flex h-9 w-9 items-center justify-center rounded-sm bg-brand">
          <Zap className="h-5 w-5 text-white" strokeWidth={2.4} />
        </div>
        <div className="leading-tight">
          <div className="text-sm font-black">گزارش‌ساز هوشمند</div>
          <div className="font-mono text-[10px] text-muted-foreground">
            SSRS · RDL · SQL COPILOT
          </div>
        </div>
        {onClose && (
          <button
            data-testid="sidebar-close"
            onClick={onClose}
            className="ms-auto rounded-sm p-1 text-muted-foreground hover:bg-surfaceHover hover:text-white lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      <nav className="flex flex-col gap-1 p-3">
        {NAV.map((n) => {
          const Icon = n.icon;
          const active = view === n.id;
          return (
            <button
              key={n.id}
              data-testid={`nav-${n.id}`}
              onClick={() => {
                setView(n.id);
                onClose?.();
              }}
              className={`flex items-center justify-between gap-2 rounded-sm px-3 py-2.5 text-sm font-medium transition-colors ${
                active
                  ? "border-s-2 border-brand bg-brand/15 text-white"
                  : "border-s-2 border-transparent text-muted-foreground hover:bg-surfaceHover hover:text-white"
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className="h-4 w-4 shrink-0" strokeWidth={2} />
                <span className="truncate">{n.label}</span>
              </div>
              {n.badge && (
                <span className="rounded-sm bg-brand/20 px-1.5 py-0.5 font-mono text-[9px] font-bold text-brand border border-brand/40">
                  {n.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="mt-auto border-t border-border p-3 text-xs">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-muted-foreground">مدل فعال</span>
          <span className="font-mono text-white">{PRESET_LABEL[model] || model}</span>
        </div>
        {budget && (
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">هزینه امروز</span>
            <span className={`font-mono ${budget.over ? "text-err" : "text-ok"}`}>
              ${budget.spent?.toFixed?.(4) ?? "0"} / ${budget.limit}
            </span>
          </div>
        )}
        <div className="mb-2 flex items-center justify-between pt-1">
          <span className="text-muted-foreground">تم ظاهری</span>
          <ThemeToggle compact />
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-muted-foreground">
          <CircleDot className={`h-3 w-3 ${health ? "text-ok" : "text-err"}`} />
          {health
            ? `${Number(health.kb?.tables).toLocaleString("fa")} جدول آماده`
            : "اتصال به سرور برقرار نشد"}
        </div>
      </div>
    </div>
  );
}

function AppShell() {
  const { theme } = useTheme();
  const [view, setView] = useState("chat");
  const [health, setHealth] = useState(null);
  const [drawer, setDrawer] = useState(false);
  const [chatSeed, setChatSeed] = useState(null);

  const refreshHealth = useCallback(async () => {
    try {
      const { data } = await http.get("/health");
      setHealth(data);
    } catch {
      setHealth(null);
    }
  }, []);

  useEffect(() => {
    refreshHealth();
  }, [refreshHealth]);

  const openMenu = () => setDrawer(true);

  return (
    <div className="App flex h-[100dvh] w-full overflow-hidden bg-background text-foreground">
      <Toaster position="top-center" richColors theme={theme} dir="rtl" />

      {/* Desktop sidebar (RTL primary = right) */}
      <aside className="hidden shrink-0 border-s border-border lg:block" data-testid="app-sidebar">
        <Sidebar view={view} setView={setView} health={health} />
      </aside>

      {/* Mobile drawer */}
      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden" data-testid="mobile-drawer">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setDrawer(false)}
          />
          <aside className="absolute inset-y-0 end-0 border-s border-border rc-fade-up">
            <Sidebar
              view={view}
              setView={setView}
              health={health}
              onClose={() => setDrawer(false)}
            />
          </aside>
        </div>
      )}

      {/* Main content */}
      <main className="flex min-w-0 flex-1 flex-col overflow-hidden">
        {view === "chat" && (
          <ChatView
            health={health}
            onCost={refreshHealth}
            onMenu={openMenu}
            seed={chatSeed}
            onSeedConsumed={() => setChatSeed(null)}
          />
        )}
        {view === "gemini_chat" && <GeminiChatView onMenu={openMenu} />}
        {view === "image_studio" && <ImageStudioView onMenu={openMenu} />}
        {view === "kb" && (
          <KnowledgeView
            onMenu={openMenu}
            onNavigateToChat={(tableName, prompt) => {
              setChatSeed(prompt || `گزارش تحلیلی از جدول ${tableName}`);
              setView("chat");
            }}
          />
        )}
        {view === "sources" && <SourcesView onMenu={openMenu} />}
        {view === "bench" && <BenchView health={health} onMenu={openMenu} />}
        {view === "catalog" && (
          <CatalogView
            onMenu={openMenu}
            onReuse={(text) => {
              setChatSeed(text);
              setView("chat");
            }}
          />
        )}
        {view === "settings" && (
          <SettingsView health={health} onSaved={refreshHealth} onMenu={openMenu} />
        )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppShell />
    </ThemeProvider>
  );
}
