import React, { useState, useMemo, useRef } from "react";
import {
  GitFork,
  Link2,
  ArrowRightLeft,
  ArrowLeft,
  ArrowRight,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Search,
  KeyRound,
  Database,
  ExternalLink,
  Layers,
  Code,
  Copy,
  Check,
  Sparkles,
  Info,
  ShieldCheck,
  HelpCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sev } from "@/views/shared";
import { toast } from "sonner";

// Distinct color accents for ERP schemas
const SCHEMA_COLORS = {
  FIN3: { border: "border-emerald-500/40", text: "text-emerald-400", bg: "bg-emerald-500/10", badge: "bg-emerald-500/20 text-emerald-300" },
  GNR3: { border: "border-sky-500/40", text: "text-sky-400", bg: "bg-sky-500/10", badge: "bg-sky-500/20 text-sky-300" },
  HCM3: { border: "border-purple-500/40", text: "text-purple-400", bg: "bg-purple-500/10", badge: "bg-purple-500/20 text-purple-300" },
  RPA3: { border: "border-amber-500/40", text: "text-amber-400", bg: "bg-amber-500/10", badge: "bg-amber-500/20 text-amber-300" },
  LGS3: { border: "border-indigo-500/40", text: "text-indigo-400", bg: "bg-indigo-500/10", badge: "bg-indigo-500/20 text-indigo-300" },
  BDG3: { border: "border-pink-500/40", text: "text-pink-400", bg: "bg-pink-500/10", badge: "bg-pink-500/20 text-pink-300" },
  SLS3: { border: "border-cyan-500/40", text: "text-cyan-400", bg: "bg-cyan-500/10", badge: "bg-cyan-500/20 text-cyan-300" },
  FMK: { border: "border-teal-500/40", text: "text-teal-400", bg: "bg-teal-500/10", badge: "bg-teal-500/20 text-teal-300" },
  DEFAULT: { border: "border-brand/40", text: "text-brand", bg: "bg-brand/10", badge: "bg-brand/20 text-brand" },
};

function getSchemaColor(schemaName) {
  return SCHEMA_COLORS[schemaName] || SCHEMA_COLORS.DEFAULT;
}

export default function TableRelationshipDiagram({ table, onSelectTable }) {
  const [activeTab, setActiveTab] = useState("graph"); // "graph" | "matrix" | "mermaid"
  const [filterQuery, setFilterQuery] = useState("");
  const [relFilter, setRelFilter] = useState("all"); // "all" | "outgoing" | "incoming"
  const [zoom, setZoom] = useState(1);
  const [hoveredRel, setHoveredRel] = useState(null);
  const [selectedRel, setSelectedRel] = useState(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copiedMermaid, setCopiedMermaid] = useState(false);
  const containerRef = useRef(null);

  const outgoing = table.outgoing || [];
  const incoming = table.incoming || [];
  const totalRels = outgoing.length + incoming.length;

  // Filtered lists
  const filteredOutgoing = useMemo(() => {
    return outgoing.filter((j) => {
      if (relFilter === "incoming") return false;
      if (!filterQuery.trim()) return true;
      const q = filterQuery.toLowerCase();
      return (
        j.to_table.toLowerCase().includes(q) ||
        j.from_col.toLowerCase().includes(q) ||
        j.to_col.toLowerCase().includes(q)
      );
    });
  }, [outgoing, filterQuery, relFilter]);

  const filteredIncoming = useMemo(() => {
    return incoming.filter((j) => {
      if (relFilter === "outgoing") return false;
      if (!filterQuery.trim()) return true;
      const q = filterQuery.toLowerCase();
      return (
        j.from_table.toLowerCase().includes(q) ||
        j.from_col.toLowerCase().includes(q) ||
        j.to_col.toLowerCase().includes(q)
      );
    });
  }, [incoming, filterQuery, relFilter]);

  // Mermaid ERD representation
  const mermaidCode = useMemo(() => {
    const cleanName = (t) => t.replace(/[^a-zA-Z0-9_]/g, "_");
    const centerClean = cleanName(table.full_name);
    let code = "erDiagram\n";
    code += `    ${centerClean} {\n`;
    table.columns?.slice(0, 8).forEach((c) => {
      const pk = table.primary_key?.includes(c.name) ? "PK" : "";
      code += `        ${c.type.replace(/\(.*?\)/g, "")} ${c.name} ${pk}\n`;
    });
    if ((table.columns?.length || 0) > 8) {
      code += `        string more_columns "..."\n`;
    }
    code += `    }\n`;

    outgoing.forEach((o) => {
      const targetClean = cleanName(o.to_table);
      code += `    ${centerClean} }o--|| ${targetClean} : "${o.from_col} -> ${o.to_col}"\n`;
    });

    incoming.forEach((inc) => {
      const srcClean = cleanName(inc.from_table);
      code += `    ${srcClean} }o--|| ${centerClean} : "${inc.from_col} -> ${inc.to_col}"\n`;
    });

    return code;
  }, [table, outgoing, incoming]);

  const handleCopyMermaid = () => {
    navigator.clipboard.writeText(mermaidCode);
    setCopiedMermaid(true);
    toast.success("کد ERD (فرمت Mermaid) در حافظه کپی شد.");
    setTimeout(() => setCopiedMermaid(false), 2000);
  };

  const currentSchema = table.schema || table.full_name.split(".")[0];
  const centerColors = getSchemaColor(currentSchema);

  return (
    <div
      ref={containerRef}
      className={`rounded-sm border border-border bg-ink transition-all ${
        isFullscreen
          ? "fixed inset-4 z-50 flex flex-col bg-surface shadow-2xl ring-1 ring-border"
          : "relative overflow-hidden"
      }`}
    >
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-surface/80 px-3.5 py-2.5">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-sm bg-brand/10 text-brand">
            <GitFork className="h-4 w-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-200">
                دیاگرام و شماتیک روابط جدول
              </span>
              <span className="rounded bg-surfaceHover px-1.5 py-0.5 font-mono text-[11px] text-brand">
                {totalRels.toLocaleString("fa")} اتصال
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground">
              ارتباطات کلیدهای خارجی (Foreign Keys) ورودی و خروجی با جداول دیگر
            </p>
          </div>
        </div>

        {/* View Switchers and Controls */}
        <div className="flex flex-wrap items-center gap-1.5">
          <div className="flex rounded-sm border border-border bg-ink p-0.5 text-xs">
            <button
              onClick={() => setActiveTab("graph")}
              className={`flex items-center gap-1 rounded-sm px-2.5 py-1 transition-colors ${
                activeTab === "graph"
                  ? "bg-brand font-medium text-ink"
                  : "text-muted-foreground hover:text-white"
              }`}
            >
              <GitFork className="h-3.5 w-3.5" />
              <span>دیاگرام گراف</span>
            </button>
            <button
              onClick={() => setActiveTab("matrix")}
              className={`flex items-center gap-1 rounded-sm px-2.5 py-1 transition-colors ${
                activeTab === "matrix"
                  ? "bg-brand font-medium text-ink"
                  : "text-muted-foreground hover:text-white"
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              <span>ماتریس روابط</span>
            </button>
            <button
              onClick={() => setActiveTab("mermaid")}
              className={`flex items-center gap-1 rounded-sm px-2.5 py-1 transition-colors ${
                activeTab === "mermaid"
                  ? "bg-brand font-medium text-ink"
                  : "text-muted-foreground hover:text-white"
              }`}
            >
              <Code className="h-3.5 w-3.5" />
              <span>کد ERD</span>
            </button>
          </div>

          <Button
            size="sm"
            variant="ghost"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="h-7 w-7 p-0 text-muted-foreground hover:text-white"
            title={isFullscreen ? "خروج از تمام‌صفحه" : "نمایش تمام‌صفحه"}
          >
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Filter / Search Bar if more than 3 rels */}
      {totalRels > 0 && activeTab !== "mermaid" && (
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 bg-surface/30 px-3 py-1.5 text-xs">
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute right-2 top-2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="فیلتر جدول یا ستون مرتبط…"
                className="h-7.5 w-48 rounded-sm border-border bg-ink pe-2 ps-7 text-xs"
              />
            </div>

            <div className="flex items-center gap-1 text-[11px]">
              <button
                onClick={() => setRelFilter("all")}
                className={`rounded px-2 py-0.5 transition-colors ${
                  relFilter === "all" ? "bg-surfaceHover text-brand font-semibold" : "text-muted-foreground hover:text-white"
                }`}
              >
                همه ({totalRels})
              </button>
              <button
                onClick={() => setRelFilter("outgoing")}
                className={`rounded px-2 py-0.5 transition-colors ${
                  relFilter === "outgoing" ? "bg-surfaceHover text-emerald-400 font-semibold" : "text-muted-foreground hover:text-white"
                }`}
              >
                جداول مقصد ({outgoing.length})
              </button>
              <button
                onClick={() => setRelFilter("incoming")}
                className={`rounded px-2 py-0.5 transition-colors ${
                  relFilter === "incoming" ? "bg-surfaceHover text-sky-400 font-semibold" : "text-muted-foreground hover:text-white"
                }`}
              >
                جداول وابسته ({incoming.length})
              </button>
            </div>
          </div>

          {activeTab === "graph" && (
            <div className="flex items-center gap-1">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setZoom((z) => Math.min(z + 0.15, 1.6))}
                className="h-6 w-6 p-0 text-muted-foreground hover:text-white"
                title="بزرگ‌نمایی"
              >
                <ZoomIn className="h-3.5 w-3.5" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setZoom((z) => Math.max(z - 0.15, 0.65))}
                className="h-6 w-6 p-0 text-muted-foreground hover:text-white"
                title="کوچک‌نمایی"
              >
                <ZoomOut className="h-3.5 w-3.5" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setZoom(1)}
                className="h-6 px-1.5 text-[10px] font-mono text-muted-foreground hover:text-white"
                title="بازنشانی زوم"
              >
                {Math.round(zoom * 100)}%
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Main Body Content */}
      {totalRels === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 text-center text-sm text-muted-foreground">
          <Database className="mb-2 h-8 w-8 text-muted-foreground/40" />
          <p>هیچ رابطه یا کلید خارجی برای این جدول ثبت نشده است.</p>
          <p className="mt-1 text-xs text-muted-foreground/70">
            می‌توانید با دکمه «بهبود دانش» روابط جدید را برای این جدول تعریف کنید.
          </p>
        </div>
      ) : activeTab === "graph" ? (
        /* GRAPH / SCHEMATIC VISUAL VIEW */
        <div className="relative min-h-[380px] flex-1 overflow-auto p-4 sm:p-6" style={{ direction: "ltr" }}>
          {/* Legend */}
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 text-xs" style={{ direction: "rtl" }}>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-1.5">
                <span className="inline-block h-2.5 w-2.5 rounded-full bg-emerald-400"></span>
                <span className="text-slate-300">جداول والد (مقصد FK - Outgoing)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="inline-block h-2.5 w-2.5 rounded-full bg-sky-400"></span>
                <span className="text-slate-300">جداول فرزند (ارجاع‌دهنده - Incoming)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-ok" />
                <span className="text-slate-300">رابطه قطعی/تأییدشده</span>
              </div>
            </div>
            <div className="text-[11px] text-muted-foreground">
              روی هر جدول کلیک کنید تا جزئیات آن باز شود.
            </div>
          </div>

          <div
            className="flex items-center justify-center transition-transform duration-150"
            style={{
              transform: `scale(${zoom})`,
              transformOrigin: "center top",
            }}
          >
            <div className="grid w-full max-w-5xl grid-cols-1 items-center gap-6 lg:grid-cols-11">
              {/* LEFT COLUMN: Outgoing Parent Tables */}
              <div className="flex flex-col gap-3 lg:col-span-4">
                <div className="flex items-center justify-between border-b border-border/40 pb-1 text-xs font-semibold text-emerald-400">
                  <span className="flex items-center gap-1">
                    <ArrowRight className="h-3.5 w-3.5" /> جداول مقصد (Foreign Keys)
                  </span>
                  <span className="font-mono text-[10px] text-muted-foreground">
                    ({filteredOutgoing.length})
                  </span>
                </div>

                {filteredOutgoing.length === 0 ? (
                  <div className="rounded-sm border border-dashed border-border/40 p-4 text-center text-xs text-muted-foreground">
                    موردی یافت نشد
                  </div>
                ) : (
                  filteredOutgoing.map((rel, idx) => {
                    const schema = rel.to_table.split(".")[0];
                    const sc = getSchemaColor(schema);
                    const isHovered = hoveredRel === `out-${idx}`;
                    return (
                      <div
                        key={idx}
                        onMouseEnter={() => setHoveredRel(`out-${idx}`)}
                        onMouseLeave={() => setHoveredRel(null)}
                        onClick={() => onSelectTable?.(rel.to_table)}
                        className={`group cursor-pointer rounded-sm border p-2.5 transition-all hover:scale-[1.02] ${
                          isHovered
                            ? "border-emerald-400 bg-emerald-950/30 shadow-md shadow-emerald-500/10"
                            : `${sc.border} bg-surface/70 hover:bg-surfaceHover`
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className={`font-mono text-xs font-semibold ${sc.text}`}>
                            {rel.to_table}
                          </span>
                          <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                            {rel.verified ? (
                              <span className="text-ok" title="تأییدشده">✓</span>
                            ) : (
                              <span className="text-warn" title="استنتاجی">~</span>
                            )}
                            <ExternalLink className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-100" />
                          </span>
                        </div>

                        {/* Column mapping */}
                        <div className="mt-1.5 flex items-center justify-between rounded bg-ink/80 px-2 py-1 font-mono text-[11px] text-slate-300">
                          <span className="text-amber-400">{rel.from_col}</span>
                          <span className="text-muted-foreground">→</span>
                          <span className="text-emerald-300">{rel.to_col}</span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* CENTER COLUMN: The Selected Table */}
              <div className="flex flex-col items-center justify-center lg:col-span-3">
                <div
                  className={`w-full rounded-md border-2 p-4 shadow-xl ring-2 ring-brand/20 ${centerColors.border} ${centerColors.bg} bg-surface`}
                >
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <span className="rounded bg-brand/20 px-2 py-0.5 font-mono text-[10px] font-bold text-brand">
                      جدول انتخاب‌شده
                    </span>
                    {table.has_data ? (
                      <span className="rounded bg-ok/20 px-1.5 py-0.5 font-mono text-[10px] text-ok">
                        {Number(table.row_count || 0).toLocaleString("fa")} ردیف
                      </span>
                    ) : (
                      <span className="rounded bg-warn/20 px-1.5 py-0.5 text-[10px] text-warn">
                        بدون داده
                      </span>
                    )}
                  </div>

                  <h4 className="font-mono text-sm font-bold text-white sm:text-base">
                    {table.full_name}
                  </h4>
                  {table.title_fa && (
                    <p className="mt-1 text-xs font-semibold text-slate-300">
                      {table.title_fa}
                    </p>
                  )}

                  {/* Primary Keys */}
                  {table.primary_key?.length > 0 && (
                    <div className="mt-2.5 flex items-center gap-1.5 rounded bg-ink/90 px-2 py-1 font-mono text-[11px] text-warn">
                      <KeyRound className="h-3 w-3 shrink-0" />
                      <span className="truncate">PK: {table.primary_key.join(", ")}</span>
                    </div>
                  )}

                  {/* Sample Key Columns */}
                  <div className="mt-3 space-y-1 border-t border-border/40 pt-2 text-[11px]">
                    <div className="text-muted-foreground">
                      شامل {table.columns?.length || 0} ستون
                    </div>
                    <div className="max-h-24 space-y-0.5 overflow-y-auto font-mono text-[10px] text-slate-400">
                      {table.columns?.slice(0, 5).map((col) => (
                        <div key={col.name} className="flex justify-between truncate">
                          <span className={table.primary_key?.includes(col.name) ? "text-warn" : ""}>
                            {col.name}
                          </span>
                          <span className="text-muted-foreground/60">{col.type}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT COLUMN: Incoming Referencing Tables */}
              <div className="flex flex-col gap-3 lg:col-span-4">
                <div className="flex items-center justify-between border-b border-border/40 pb-1 text-xs font-semibold text-sky-400">
                  <span className="flex items-center gap-1">
                    <ArrowLeft className="h-3.5 w-3.5" /> جداول وابسته (ارباب‌رجوع به این جدول)
                  </span>
                  <span className="font-mono text-[10px] text-muted-foreground">
                    ({filteredIncoming.length})
                  </span>
                </div>

                {filteredIncoming.length === 0 ? (
                  <div className="rounded-sm border border-dashed border-border/40 p-4 text-center text-xs text-muted-foreground">
                    موردی یافت نشد
                  </div>
                ) : (
                  filteredIncoming.map((rel, idx) => {
                    const schema = rel.from_table.split(".")[0];
                    const sc = getSchemaColor(schema);
                    const isHovered = hoveredRel === `inc-${idx}`;
                    return (
                      <div
                        key={idx}
                        onMouseEnter={() => setHoveredRel(`inc-${idx}`)}
                        onMouseLeave={() => setHoveredRel(null)}
                        onClick={() => onSelectTable?.(rel.from_table)}
                        className={`group cursor-pointer rounded-sm border p-2.5 transition-all hover:scale-[1.02] ${
                          isHovered
                            ? "border-sky-400 bg-sky-950/30 shadow-md shadow-sky-500/10"
                            : `${sc.border} bg-surface/70 hover:bg-surfaceHover`
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className={`font-mono text-xs font-semibold ${sc.text}`}>
                            {rel.from_table}
                          </span>
                          <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                            {rel.verified ? (
                              <span className="text-ok" title="تأییدشده">✓</span>
                            ) : (
                              <span className="text-warn" title="استنتاجی">~</span>
                            )}
                            <ExternalLink className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-100" />
                          </span>
                        </div>

                        {/* Column mapping */}
                        <div className="mt-1.5 flex items-center justify-between rounded bg-ink/80 px-2 py-1 font-mono text-[11px] text-slate-300">
                          <span className="text-sky-300">{rel.from_col}</span>
                          <span className="text-muted-foreground">→</span>
                          <span className="text-amber-400">{rel.to_col}</span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      ) : activeTab === "matrix" ? (
        /* TABLE / MATRIX VIEW */
        <div className="p-4">
          <div className="overflow-x-auto rounded-sm border border-border">
            <table className="w-full border-collapse text-xs" dir="rtl">
              <thead>
                <tr className="bg-surface text-muted-foreground">
                  <th className="border-b border-border px-3 py-2 text-start">نوع رابطه</th>
                  <th className="border-b border-border px-3 py-2 text-start">جدول مبدأ</th>
                  <th className="border-b border-border px-3 py-2 text-start">ستون مبدأ</th>
                  <th className="border-b border-border px-3 py-2 text-start">جدول مقصد</th>
                  <th className="border-b border-border px-3 py-2 text-start">ستون مقصد</th>
                  <th className="border-b border-border px-3 py-2 text-start">وضعیت اطمینان</th>
                  <th className="border-b border-border px-3 py-2 text-start">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {outgoing.map((j, i) => (
                  <tr key={`out-${i}`} className="transition-colors hover:bg-surfaceHover">
                    <td className="border-b border-border px-3 py-2 text-emerald-400 font-semibold">
                      جداول والد (FK Out)
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-slate-300">
                      {table.full_name}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-amber-400 font-bold">
                      {j.from_col}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-brand">
                      {j.to_table}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-slate-300">
                      {j.to_col}
                    </td>
                    <td className="border-b border-border px-3 py-2">
                      {j.verified ? (
                        <Sev severity="success">تأییدشده</Sev>
                      ) : (
                        <Sev severity="warning">استنتاج از الگو</Sev>
                      )}
                    </td>
                    <td className="border-b border-border px-3 py-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => onSelectTable?.(j.to_table)}
                        className="h-6 gap-1 px-2 text-[11px] text-brand hover:bg-brand/10"
                      >
                        مشاهده جدول <ArrowLeft className="h-3 w-3" />
                      </Button>
                    </td>
                  </tr>
                ))}

                {incoming.map((j, i) => (
                  <tr key={`inc-${i}`} className="transition-colors hover:bg-surfaceHover">
                    <td className="border-b border-border px-3 py-2 text-sky-400 font-semibold">
                      جداول فرزند (FK In)
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-brand">
                      {j.from_table}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-sky-300 font-bold">
                      {j.from_col}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-slate-300">
                      {table.full_name}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-amber-400">
                      {j.to_col}
                    </td>
                    <td className="border-b border-border px-3 py-2">
                      {j.verified ? (
                        <Sev severity="success">تأییدشده</Sev>
                      ) : (
                        <Sev severity="warning">استنتاج از الگو</Sev>
                      )}
                    </td>
                    <td className="border-b border-border px-3 py-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => onSelectTable?.(j.from_table)}
                        className="h-6 gap-1 px-2 text-[11px] text-brand hover:bg-brand/10"
                      >
                        مشاهده جدول <ArrowLeft className="h-3 w-3" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* MERMAID ERD CODE VIEW */
        <div className="p-4 space-y-3" style={{ direction: "ltr" }}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-muted-foreground">
              Mermaid Entity-Relationship Format
            </span>
            <Button
              size="sm"
              variant="outline"
              onClick={handleCopyMermaid}
              className="gap-1.5 rounded-sm border-border bg-surface text-xs"
            >
              {copiedMermaid ? <Check className="h-3.5 w-3.5 text-ok" /> : <Copy className="h-3.5 w-3.5" />}
              کپی کد Mermaid
            </Button>
          </div>
          <pre className="overflow-x-auto rounded-sm border border-border bg-ink p-3 font-mono text-xs leading-5 text-slate-200">
            <code>{mermaidCode}</code>
          </pre>
        </div>
      )}
    </div>
  );
}
