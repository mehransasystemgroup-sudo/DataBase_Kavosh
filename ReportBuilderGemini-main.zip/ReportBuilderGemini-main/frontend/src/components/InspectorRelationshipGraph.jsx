import React, { useEffect, useRef, useState, useMemo, useCallback } from "react";
import * as d3 from "d3";
import { http } from "@/lib/api";
import {
  Link2,
  ExternalLink,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Maximize2,
  Minimize2,
  Layers,
  KeyRound,
  Database,
  ArrowRight,
  ArrowLeft,
  Filter,
  Sparkles,
  Info,
  RefreshCw,
  Loader2,
  GitFork,
  Compass,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// Color mappings for schemas and directions
const SCHEMA_PALETTE = {
  FIN3: { border: "#10b981", bg: "#064e3b", text: "#34d399" },
  GNR3: { border: "#38bdf8", bg: "#0c4a6e", text: "#7dd3fc" },
  HCM3: { border: "#c084fc", bg: "#581c87", text: "#e9d5ff" },
  RPA3: { border: "#fbbf24", bg: "#78350f", text: "#fde68a" },
  LGS3: { border: "#818cf8", bg: "#312e81", text: "#c7d2fe" },
  BDG3: { border: "#f472b6", bg: "#831843", text: "#fbcfe8" },
  SLS3: { border: "#22d3ee", bg: "#164e63", text: "#a5f3fc" },
  FMK: { border: "#2dd4bf", bg: "#134e4a", text: "#99f6e4" },
  DEFAULT: { border: "#64748b", bg: "#1e293b", text: "#cbd5e1" },
};

function getSchemaColor(schema) {
  return SCHEMA_PALETTE[schema] || SCHEMA_PALETTE.DEFAULT;
}

/**
 * InspectorRelationshipGraph
 * Interactive D3.js Foreign Key relationship graph designed for the Inspector (Insp) panel.
 * Shows center table, outgoing FK parents (green), and incoming FK children (blue).
 * Clicking any node triggers onSelectTable.
 */
export default function InspectorRelationshipGraph({
  table, // Can be full table detail object or table summary object { full_name, id, ... }
  tableName, // Optional fallback string
  onSelectTable,
  height = 280,
  showHeader = true,
  embedded = false,
}) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const simulationRef = useRef(null);
  const zoomRef = useRef(null);
  const dimensionsRef = useRef({ width: 320, height: 280 });

  const [loading, setLoading] = useState(false);
  const [tableDetail, setTableDetail] = useState(null);
  const [filterQuery, setFilterQuery] = useState("");
  const [filterType, setFilterType] = useState("all"); // "all" | "outgoing" | "incoming"
  const [selectedHoverNode, setSelectedHoverNode] = useState(null);
  const [hoveredLink, setHoveredLink] = useState(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [graphLayout, setGraphLayout] = useState("force"); // "force" | "radial"

  const targetFullName = useMemo(() => {
    if (typeof table === "string") return table;
    if (table?.full_name) return table.full_name;
    if (table?.id) return table.id;
    if (tableName) return tableName;
    return null;
  }, [table, tableName]);

  // Fetch full details if table doesn't already contain outgoing/incoming arrays
  useEffect(() => {
    if (!targetFullName) return;

    if (table?.outgoing !== undefined && table?.incoming !== undefined) {
      setTableDetail(table);
      return;
    }

    let isMounted = true;
    setLoading(true);
    http
      .get(`/table/${encodeURIComponent(targetFullName)}`)
      .then(({ data }) => {
        if (isMounted) {
          setTableDetail(data);
        }
      })
      .catch((err) => {
        console.error("Failed to load table details for Inspector graph:", err);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [targetFullName, table]);

  // Process and filter nodes & links
  const graphData = useMemo(() => {
    if (!tableDetail || !targetFullName) {
      return { nodes: [], links: [], outgoingCount: 0, incomingCount: 0 };
    }

    const centerFullName = targetFullName;
    const centerSchema = centerFullName.split(".")[0];
    const centerName = centerFullName.split(".").slice(1).join(".") || centerFullName;

    const outgoing = tableDetail.outgoing || [];
    const incoming = tableDetail.incoming || [];

    const nodesMap = new Map();

    // 1. Add center node
    nodesMap.set(centerFullName, {
      id: centerFullName,
      name: centerName,
      full_name: centerFullName,
      schema: centerSchema,
      title_fa: tableDetail.title_fa || "",
      isCenter: true,
      type: "center",
      radius: 22,
    });

    const links = [];

    // 2. Add outgoing FKs (Center -> Parent)
    outgoing.forEach((fk, idx) => {
      if (filterType === "incoming") return;
      const targetName = fk.to_table;
      if (!targetName) return;

      if (filterQuery.trim()) {
        const q = filterQuery.trim().toLowerCase();
        if (
          !targetName.toLowerCase().includes(q) &&
          !fk.from_col.toLowerCase().includes(q) &&
          !fk.to_col.toLowerCase().includes(q)
        ) {
          return;
        }
      }

      const tSchema = targetName.split(".")[0];
      const tShort = targetName.split(".").slice(1).join(".") || targetName;

      if (!nodesMap.has(targetName)) {
        nodesMap.set(targetName, {
          id: targetName,
          name: tShort,
          full_name: targetName,
          schema: tSchema,
          isCenter: false,
          type: "outgoing", // parent
          verified: fk.verified,
          radius: 16,
        });
      }

      links.push({
        id: `out-${idx}-${fk.from_col}-${fk.to_col}`,
        source: centerFullName,
        target: targetName,
        from_col: fk.from_col,
        to_col: fk.to_col,
        type: "outgoing",
        verified: fk.verified,
      });
    });

    // 3. Add incoming FKs (Child -> Center)
    incoming.forEach((fk, idx) => {
      if (filterType === "outgoing") return;
      const srcName = fk.from_table;
      if (!srcName) return;

      if (filterQuery.trim()) {
        const q = filterQuery.trim().toLowerCase();
        if (
          !srcName.toLowerCase().includes(q) &&
          !fk.from_col.toLowerCase().includes(q) &&
          !fk.to_col.toLowerCase().includes(q)
        ) {
          return;
        }
      }

      const sSchema = srcName.split(".")[0];
      const sShort = srcName.split(".").slice(1).join(".") || srcName;

      if (!nodesMap.has(srcName)) {
        nodesMap.set(srcName, {
          id: srcName,
          name: sShort,
          full_name: srcName,
          schema: sSchema,
          isCenter: false,
          type: "incoming", // child
          verified: fk.verified,
          radius: 16,
        });
      }

      links.push({
        id: `in-${idx}-${fk.from_col}-${fk.to_col}`,
        source: srcName,
        target: centerFullName,
        from_col: fk.from_col,
        to_col: fk.to_col,
        type: "incoming",
        verified: fk.verified,
      });
    });

    return {
      nodes: Array.from(nodesMap.values()),
      links,
      outgoingCount: outgoing.length,
      incomingCount: incoming.length,
    };
  }, [tableDetail, targetFullName, filterType, filterQuery]);

  // Render D3 Simulation
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;
    if (graphData.nodes.length === 0) return;

    const container = containerRef.current;
    const width = container.clientWidth || 320;
    const effectiveHeight = isExpanded ? Math.max(height + 140, 420) : height;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    svg
      .attr("viewBox", `0 0 ${width} ${effectiveHeight}`)
      .attr("width", "100%")
      .attr("height", effectiveHeight);

    // Defs & Arrow markers
    const defs = svg.append("defs");

    // Glow filter for center node
    const filter = defs.append("filter").attr("id", "insp-glow").attr("x", "-30%").attr("y", "-30%").attr("width", "160%").attr("height", "160%");
    filter.append("feGaussianBlur").attr("stdDeviation", "4").attr("result", "blur");
    const feMerge = filter.append("feMerge");
    feMerge.append("feMergeNode").attr("in", "blur");
    feMerge.append("feMergeNode").attr("in", "SourceGraphic");

    // Arrow for outgoing (green)
    defs
      .append("marker")
      .attr("id", "arrow-outgoing")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 26)
      .attr("refY", 0)
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-4L9,0L0,4")
      .attr("fill", "#10b981");

    // Arrow for incoming (blue)
    defs
      .append("marker")
      .attr("id", "arrow-incoming")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 26)
      .attr("refY", 0)
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-4L9,0L0,4")
      .attr("fill", "#38bdf8");

    // Zoom container
    const g = svg.append("g").attr("class", "zoom-content");

    const zoom = d3
      .zoom()
      .scaleExtent([0.4, 3])
      .on("zoom", (event) => {
        g.attr("transform", event.transform);
      });

    svg.call(zoom);
    zoomRef.current = zoom;
    dimensionsRef.current = { width, effectiveHeight };

    // Deep copy data for simulation
    const simNodes = graphData.nodes.map((d) => ({ ...d }));
    const simLinks = graphData.links.map((d) => ({ ...d }));

    // Simulation Setup
    let simulation;

    if (graphLayout === "radial") {
      const centerNode = simNodes.find((n) => n.isCenter);
      if (centerNode) {
        centerNode.fx = width / 2;
        centerNode.fy = effectiveHeight / 2;
      }

      const others = simNodes.filter((n) => !n.isCenter);
      const angleStep = others.length > 0 ? (2 * Math.PI) / others.length : 0;
      const radiusDist = Math.min(width, effectiveHeight) * 0.35;

      others.forEach((n, i) => {
        const angle = i * angleStep;
        n.x = width / 2 + radiusDist * Math.cos(angle);
        n.y = effectiveHeight / 2 + radiusDist * Math.sin(angle);
      });

      simulation = d3
        .forceSimulation(simNodes)
        .force(
          "link",
          d3
            .forceLink(simLinks)
            .id((d) => d.id)
            .distance(radiusDist)
        )
        .force("charge", d3.forceManyBody().strength(-150))
        .force("center", d3.forceCenter(width / 2, effectiveHeight / 2));
    } else {
      // Force Layout
      const centerNode = simNodes.find((n) => n.isCenter);
      if (centerNode) {
        centerNode.fx = width / 2;
        centerNode.fy = effectiveHeight / 2;
      }

      simulation = d3
        .forceSimulation(simNodes)
        .force(
          "link",
          d3
            .forceLink(simLinks)
            .id((d) => d.id)
            .distance((d) => (d.type === "outgoing" ? 85 : 80))
        )
        .force("charge", d3.forceManyBody().strength(-200))
        .force("collide", d3.forceCollide().radius(28))
        .force("center", d3.forceCenter(width / 2, effectiveHeight / 2));
    }

    simulationRef.current = simulation;

    // Links Rendering
    const link = g
      .append("g")
      .attr("class", "links")
      .selectAll("line")
      .data(simLinks)
      .enter()
      .append("line")
      .attr("stroke", (d) => (d.type === "outgoing" ? "#10b981" : "#38bdf8"))
      .attr("stroke-width", 1.8)
      .attr("stroke-opacity", 0.65)
      .attr("stroke-dasharray", (d) => (d.verified ? "none" : "3,3"))
      .attr("marker-end", (d) =>
        d.type === "outgoing" ? "url(#arrow-outgoing)" : "url(#arrow-incoming)"
      )
      .style("cursor", "pointer")
      .on("mouseenter", (event, d) => {
        d3.select(event.currentTarget).attr("stroke-width", 3).attr("stroke-opacity", 1);
        setHoveredLink(d);
      })
      .on("mouseleave", (event) => {
        d3.select(event.currentTarget).attr("stroke-width", 1.8).attr("stroke-opacity", 0.65);
        setHoveredLink(null);
      });

    // Drag Behavior
    const drag = d3
      .drag()
      .on("start", (event, d) => {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
      })
      .on("drag", (event, d) => {
        d.fx = event.x;
        d.fy = event.y;
      })
      .on("end", (event, d) => {
        if (!event.active) simulation.alphaTarget(0);
        if (!d.isCenter) {
          d.fx = null;
          d.fy = null;
        }
      });

    // Nodes Rendering
    const node = g
      .append("g")
      .attr("class", "nodes")
      .selectAll("g")
      .data(simNodes)
      .enter()
      .append("g")
      .call(drag)
      .style("cursor", (d) => (d.isCenter ? "default" : "pointer"))
      .on("click", (event, d) => {
        if (!d.isCenter && onSelectTable) {
          onSelectTable(d.full_name || d.id);
        }
      })
      .on("mouseenter", (event, d) => {
        setSelectedHoverNode(d);
        d3.select(event.currentTarget)
          .select("circle")
          .transition()
          .duration(150)
          .attr("r", (d) => (d.isCenter ? 26 : 20));
      })
      .on("mouseleave", (event) => {
        setSelectedHoverNode(null);
        d3.select(event.currentTarget)
          .select("circle")
          .transition()
          .duration(150)
          .attr("r", (d) => d.radius);
      });

    // Node Circle
    node
      .append("circle")
      .attr("r", (d) => d.radius)
      .attr("fill", (d) => {
        if (d.isCenter) return "#f59e0b"; // Center accent amber/brand
        const pal = getSchemaColor(d.schema);
        return d.type === "outgoing" ? "#064e3b" : "#0c4a6e";
      })
      .attr("stroke", (d) => {
        if (d.isCenter) return "#fbbf24";
        return d.type === "outgoing" ? "#10b981" : "#38bdf8";
      })
      .attr("stroke-width", (d) => (d.isCenter ? 3 : 2))
      .attr("filter", (d) => (d.isCenter ? "url(#insp-glow)" : null));

    // Center Node Inner Ring
    node
      .filter((d) => d.isCenter)
      .append("circle")
      .attr("r", 15)
      .attr("fill", "#78350f")
      .attr("stroke", "#fde68a")
      .attr("stroke-width", 1);

    // Schema icon/label inside circle
    node
      .append("text")
      .attr("text-anchor", "middle")
      .attr("dy", "0.35em")
      .attr("font-size", (d) => (d.isCenter ? "10px" : "8px"))
      .attr("font-weight", "bold")
      .attr("font-family", "monospace")
      .attr("fill", (d) => (d.isCenter ? "#ffffff" : d.type === "outgoing" ? "#34d399" : "#7dd3fc"))
      .text((d) => d.schema);

    // Node Name Label
    node
      .append("text")
      .attr("text-anchor", "middle")
      .attr("dy", (d) => d.radius + 12)
      .attr("font-size", (d) => (d.isCenter ? "11px" : "9.5px"))
      .attr("font-weight", (d) => (d.isCenter ? "bold" : "600"))
      .attr("font-family", "monospace")
      .attr("fill", (d) => (d.isCenter ? "#f8fafc" : "#cbd5e1"))
      .text((d) => {
        const str = d.name || d.id;
        return str.length > 14 ? str.substring(0, 12) + "…" : str;
      })
      .append("title")
      .text((d) => d.full_name);

    // Direction indicators on non-center nodes
    node
      .filter((d) => !d.isCenter)
      .append("text")
      .attr("text-anchor", "middle")
      .attr("dy", (d) => d.radius + 22)
      .attr("font-size", "8px")
      .attr("fill", (d) => (d.type === "outgoing" ? "#10b981" : "#38bdf8"))
      .text((d) => (d.type === "outgoing" ? "والد ➔" : "⬅ فرزند"));

    // Simulation Tick
    simulation.on("tick", () => {
      link
        .attr("x1", (d) => d.source.x)
        .attr("y1", (d) => d.source.y)
        .attr("x2", (d) => d.target.x)
        .attr("y2", (d) => d.target.y);

      node.attr("transform", (d) => `translate(${d.x},${d.y})`);
    });

    // Initial Zoom Fit
    const initialTransform = d3.zoomIdentity.translate(0, 0).scale(0.95);
    svg.call(zoom.transform, initialTransform);

    return () => {
      simulation.stop();
    };
  }, [graphData, isExpanded, height, graphLayout, onSelectTable]);

  // Reset View handler - restores initial zoom level and centered layout for all nodes
  const handleResetView = useCallback(() => {
    if (!svgRef.current || !zoomRef.current) return;
    const svg = d3.select(svgRef.current);
    const zoom = zoomRef.current;

    // 1. Smoothly reset zoom and pan to center
    svg
      .transition()
      .duration(350)
      .call(zoom.transform, d3.zoomIdentity.translate(0, 0).scale(0.95));

    // 2. Reset nodes coordinates and restart simulation to relax to center
    if (simulationRef.current) {
      const sim = simulationRef.current;
      const nodes = sim.nodes();
      const { width, effectiveHeight } = dimensionsRef.current;

      if (graphLayout === "radial") {
        const centerNode = nodes.find((n) => n.isCenter);
        if (centerNode) {
          centerNode.fx = width / 2;
          centerNode.fy = effectiveHeight / 2;
          centerNode.x = width / 2;
          centerNode.y = effectiveHeight / 2;
        }
        const others = nodes.filter((n) => !n.isCenter);
        const angleStep = others.length > 0 ? (2 * Math.PI) / others.length : 0;
        const radiusDist = Math.min(width, effectiveHeight) * 0.35;
        others.forEach((n, i) => {
          n.fx = null;
          n.fy = null;
          const angle = i * angleStep;
          n.x = width / 2 + radiusDist * Math.cos(angle);
          n.y = effectiveHeight / 2 + radiusDist * Math.sin(angle);
        });
      } else {
        const centerNode = nodes.find((n) => n.isCenter);
        if (centerNode) {
          centerNode.fx = width / 2;
          centerNode.fy = effectiveHeight / 2;
          centerNode.x = width / 2;
          centerNode.y = effectiveHeight / 2;
        }
        nodes.forEach((n) => {
          if (!n.isCenter) {
            n.fx = null;
            n.fy = null;
          }
        });
      }

      sim.alpha(0.4).restart();
    }
  }, [graphLayout]);

  const totalConnections = graphData.outgoingCount + graphData.incomingCount;

  return (
    <div
      ref={containerRef}
      data-testid="inspector-d3-relationship-graph"
      className={`relative flex flex-col rounded-md border border-border bg-[#050811] text-foreground transition-all duration-200 overflow-hidden ${
        embedded ? "" : "shadow-md"
      }`}
    >
      {/* Header Bar */}
      {showHeader && (
        <div className="flex flex-wrap items-center justify-between gap-1.5 border-b border-border/70 bg-surface/80 px-2.5 py-1.5 text-xs">
          <div className="flex items-center gap-1.5 min-w-0">
            <Link2 className="h-3.5 w-3.5 text-brand shrink-0" />
            <span className="font-semibold text-foreground text-[11px] truncate">
              گراف روابط کلید خارجی (D3 Graph)
            </span>
            <span className="rounded bg-brand/15 px-1.5 py-0.2 font-mono text-[10px] text-brand">
              {totalConnections} رابطه
            </span>
          </div>

          <div className="flex items-center gap-1">
            {/* Filter Type Pills */}
            <div className="flex items-center rounded border border-border/80 bg-ink p-0.5 text-[10px]">
              <button
                type="button"
                onClick={() => setFilterType("all")}
                className={`rounded px-1.5 py-0.5 transition-colors ${
                  filterType === "all" ? "bg-brand text-white font-medium" : "text-muted-foreground hover:text-foreground"
                }`}
                title="نمایش تمام روابط والد و فرزند"
              >
                همه ({totalConnections})
              </button>
              <button
                type="button"
                onClick={() => setFilterType("outgoing")}
                className={`rounded px-1.5 py-0.5 transition-colors ${
                  filterType === "outgoing"
                    ? "bg-emerald-600 text-white font-medium"
                    : "text-muted-foreground hover:text-emerald-400"
                }`}
                title="فقط کلیدهای خارجی به جداول والد"
              >
                والد ({graphData.outgoingCount})
              </button>
              <button
                type="button"
                onClick={() => setFilterType("incoming")}
                className={`rounded px-1.5 py-0.5 transition-colors ${
                  filterType === "incoming"
                    ? "bg-sky-600 text-white font-medium"
                    : "text-muted-foreground hover:text-sky-400"
                }`}
                title="فقط جدول‌های وابسته ارجاع‌دهنده"
              >
                فرزند ({graphData.incomingCount})
              </button>
            </div>

            {/* Layout Mode Toggle */}
            <button
              type="button"
              onClick={() => setGraphLayout(graphLayout === "force" ? "radial" : "force")}
              className="rounded border border-border bg-ink p-1 text-muted-foreground hover:text-foreground transition-colors"
              title={graphLayout === "force" ? "تغییر به چیدمان دایره‌ای (Radial)" : "تغییر به چیدمان نیرو (Force)"}
            >
              <Compass className="h-3 w-3" />
            </button>

            {/* Expand Height Toggle */}
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="rounded border border-border bg-ink p-1 text-muted-foreground hover:text-foreground transition-colors"
              title={isExpanded ? "کوچک‌نمایی ارتفاع گراف" : "گسترش گراف روابط"}
            >
              {isExpanded ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
            </button>
          </div>
        </div>
      )}

      {/* Main SVG Area */}
      <div
        className="relative flex-1 w-full overflow-hidden bg-[#060a14]"
        style={{ height: isExpanded ? Math.max(height + 140, 420) : height }}
      >
        {loading ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-ink/80 text-xs text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin text-brand" />
            <span>در حال بارگذاری ساختار اتصالات D3…</span>
          </div>
        ) : graphData.nodes.length === 0 ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center text-xs text-muted-foreground gap-1.5">
            <Link2 className="h-6 w-6 text-muted-foreground/40" />
            <span>هیچ رابطه کلید خارجی (FK) برای این جدول یافت نشد.</span>
          </div>
        ) : (
          <>
            <svg
              ref={svgRef}
              className="w-full h-full cursor-grab active:cursor-grabbing select-none"
            />

            {/* Floating Reset View & Quick Zoom Controls in Graph Area */}
            <div className="absolute top-2 start-2 flex items-center gap-1 z-20">
              <button
                type="button"
                data-testid="inspector-reset-view-btn"
                onClick={handleResetView}
                className="flex items-center gap-1 rounded bg-surface/90 backdrop-blur border border-border/80 px-2 py-1 text-[10px] font-medium text-foreground hover:bg-brand hover:text-white shadow-md transition-all active:scale-95"
                title="بازنشانی بزرگ‌نمایی و چیدمان گره‌ها به مرکز (Reset View)"
              >
                <RotateCcw className="h-3 w-3 text-brand hover:text-white" />
                <span>بازنشانی نما</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!svgRef.current || !zoomRef.current) return;
                  d3.select(svgRef.current).transition().duration(200).call(zoomRef.current.scaleBy, 1.25);
                }}
                className="rounded bg-surface/90 backdrop-blur border border-border/80 p-1 text-muted-foreground hover:text-foreground shadow-md transition-colors"
                title="بزرگ‌نمایی (+)"
              >
                <ZoomIn className="h-3 w-3" />
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!svgRef.current || !zoomRef.current) return;
                  d3.select(svgRef.current).transition().duration(200).call(zoomRef.current.scaleBy, 0.8);
                }}
                className="rounded bg-surface/90 backdrop-blur border border-border/80 p-1 text-muted-foreground hover:text-foreground shadow-md transition-colors"
                title="کوچک‌نمایی (-)"
              >
                <ZoomOut className="h-3 w-3" />
              </button>
            </div>

            {/* Interactive Tooltip Card for hovered node */}
            {selectedHoverNode && !selectedHoverNode.isCenter && (
              <div className="absolute start-2 bottom-2 max-w-[240px] rounded border border-border/90 bg-surface/95 backdrop-blur p-2 shadow-xl text-[11px] pointer-events-none animate-in fade-in zoom-in-95 duration-150 z-20">
                <div className="flex items-center gap-1 font-mono font-bold text-foreground">
                  <span
                    className="inline-block h-2 w-2 rounded-full"
                    style={{ backgroundColor: selectedHoverNode.type === "outgoing" ? "#10b981" : "#38bdf8" }}
                  />
                  <span>{selectedHoverNode.full_name}</span>
                </div>
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  {selectedHoverNode.type === "outgoing"
                    ? "جدول مقصد والد (Outgoing FK)"
                    : "جدول وابسته ارجاع‌دهنده (Incoming Reference)"}
                </div>
                <div className="mt-1 text-[10px] text-brand font-semibold flex items-center gap-1">
                  <ExternalLink className="h-2.5 w-2.5" />
                  کلیک روی گره جهت انتخاب این جدول
                </div>
              </div>
            )}

            {/* Hovered Link Details */}
            {hoveredLink && (
              <div className="absolute start-2 top-10 rounded border border-border/90 bg-surface/95 backdrop-blur px-2.5 py-1 text-[10px] font-mono text-amber-300 shadow-lg pointer-events-none z-20">
                {hoveredLink.from_col} ➔ {hoveredLink.to_col}{" "}
                <span className="text-muted-foreground">({hoveredLink.verified ? "تأییدشده ✓" : "استنتاجی"})</span>
              </div>
            )}

            {/* Bottom Legend */}
            <div className="absolute end-2 bottom-2 flex items-center gap-2 rounded bg-surface/80 backdrop-blur px-2 py-0.5 text-[9px] text-muted-foreground border border-border/50 pointer-events-none">
              <span className="flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-amber-400" /> جدول جاری
              </span>
              <span className="flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> والد (FK)
              </span>
              <span className="flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-sky-400" /> فرزند
              </span>
            </div>
          </>
        )}
      </div>

      {/* Footer Controls & Quick Node Click Notice */}
      <div className="flex items-center justify-between border-t border-border/60 bg-surface/60 px-2.5 py-1 text-[10px] text-muted-foreground">
        <span className="flex items-center gap-1">
          <Sparkles className="h-3 w-3 text-brand" />
          <span>روی هر گره کلیک کنید تا آن جدول انتخاب شود.</span>
        </span>
        <button
          type="button"
          onClick={handleResetView}
          className="flex items-center gap-1 rounded px-1.5 py-0.5 hover:bg-ink hover:text-foreground text-[10px] transition-colors"
          title="بازنشانی بزرگ‌نمایی و چیدمان گره‌ها"
        >
          <RotateCcw className="h-2.5 w-2.5" />
          <span>بازنشانی نما</span>
        </button>
      </div>
    </div>
  );
}
