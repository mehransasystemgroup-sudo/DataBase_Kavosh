import { useState, useEffect, useMemo } from "react";
import { http } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  SlidersHorizontal,
  Plus,
  Trash2,
  Copy,
  Check,
  Code,
  Sparkles,
  RefreshCw,
  Table2,
  Filter,
  Layers,
  Loader2,
  X,
  Zap,
  Gauge,
  Info,
  ChevronDown,
  ChevronUp,
  Star,
  Grid,
} from "lucide-react";

export function PlanEditorModal({
  isOpen,
  onClose,
  initialPlan,
  initialLayout,
  onApply,
}) {
  const [plan, setPlan] = useState(null);
  const [layout, setLayout] = useState({ kind: "table" });
  const [activeTab, setActiveTab] = useState("columns"); // "columns" | "filters" | "layout" | "safety" | "preview"
  const [generatedSql, setGeneratedSql] = useState("");
  const [validationIssues, setValidationIssues] = useState([]);
  const [safetyReport, setSafetyReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [applying, setApplying] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showSlowConfirmModal, setShowSlowConfirmModal] = useState(false);
  const [expandedIssueIndex, setExpandedIssueIndex] = useState(null);
  const [userProfiles, setUserProfiles] = useState([]);

  // Load user profiles on open
  useEffect(() => {
    if (isOpen) {
      http.get("/user-profiles").then(({ data }) => {
        if (data?.profiles) setUserProfiles(data.profiles);
      }).catch(() => {});
    }
  }, [isOpen]);

  // Apply a personal user profile to the current query plan and layout
  const applyUserProfile = (prof) => {
    if (!prof || !plan) return;
    const cols = (prof.favorite_columns || []).map((c) => ({
      table: c.table || plan.base_table,
      column: c.column,
      aggregate: c.aggregate || null,
      alias: c.alias || null,
    }));

    const updatedPlan = {
      ...plan,
      select: cols.length > 0 ? cols : plan.select,
      base_table: prof.base_table || plan.base_table,
    };

    setPlan(updatedPlan);
    if (prof.layout) {
      setLayout(JSON.parse(JSON.stringify(prof.layout)));
    }
    validateAndAnalyze(updatedPlan);
    toast.success(`پروفایل «${prof.name}» با موفقیت اعمال گردید.`);
  };

  // New column & filter form states
  const [newColName, setNewColName] = useState("");
  const [newColTable, setNewColTable] = useState("");
  const [newColAlias, setNewColAlias] = useState("");
  const [newColAgg, setNewColAgg] = useState("");

  const [newFilterCol, setNewFilterCol] = useState("");
  const [newFilterTable, setNewFilterTable] = useState("");
  const [newFilterOp, setNewFilterOp] = useState("=");
  const [newFilterVal, setNewFilterVal] = useState("");

  // Initialize data on open
  useEffect(() => {
    if (isOpen && initialPlan) {
      const clonedPlan = JSON.parse(JSON.stringify(initialPlan));
      const clonedLayout = initialLayout
        ? JSON.parse(JSON.stringify(initialLayout))
        : { kind: "table" };
      setPlan(clonedPlan);
      setLayout(clonedLayout);
      setNewColTable(clonedPlan.base_table || "");
      setNewFilterTable(clonedPlan.base_table || "");
      setShowSlowConfirmModal(false);
      setSafetyReport(null);
      setValidationIssues([]);

      // Auto run initial validation & safety check
      validateAndAnalyze(clonedPlan);
    }
  }, [isOpen, initialPlan, initialLayout]);

  const validateAndAnalyze = async (targetPlan = plan) => {
    if (!targetPlan || !targetPlan.base_table) return null;
    setLoading(true);
    try {
      const { data } = await http.post("/validate-plan", { plan: targetPlan });
      setGeneratedSql(data.sql || "");
      setValidationIssues(data.issues || []);
      setSafetyReport(data.safety || null);
      return data;
    } catch (err) {
      const msg = err.response?.data?.detail || err.message || "خطا در بررسی نقشه";
      toast.error(msg);
      return null;
    } finally {
      setLoading(false);
    }
  };

  // ── Column Management ──
  const removeColumn = (idx) => {
    if (!plan) return;
    const newSelect = [...plan.select];
    newSelect.splice(idx, 1);
    const updated = { ...plan, select: newSelect };
    setPlan(updated);
    validateAndAnalyze(updated);
  };

  const updateColumn = (idx, field, value) => {
    if (!plan) return;
    const newSelect = [...plan.select];
    newSelect[idx] = { ...newSelect[idx], [field]: value || null };
    const updated = { ...plan, select: newSelect };
    setPlan(updated);
    validateAndAnalyze(updated);
  };

  const addColumn = () => {
    if (!newColName.trim()) {
      toast.warning("لطفاً نام ستون را وارد کنید.");
      return;
    }
    const newCol = {
      table: newColTable.trim() || plan.base_table,
      column: newColName.trim(),
      aggregate: newColAgg || null,
      alias: newColAlias.trim() || null,
    };
    const updated = { ...plan, select: [...(plan.select || []), newCol] };
    setPlan(updated);
    setNewColName("");
    setNewColAlias("");
    setNewColAgg("");
    validateAndAnalyze(updated);
    toast.success(`ستون ${newCol.column} اضافه شد.`);
  };

  // ── Filter Management ──
  const removeFilter = (idx) => {
    if (!plan) return;
    const newFilters = [...(plan.filters || [])];
    newFilters.splice(idx, 1);
    const updated = { ...plan, filters: newFilters };
    setPlan(updated);
    validateAndAnalyze(updated);
  };

  const updateFilter = (idx, field, value) => {
    if (!plan) return;
    const newFilters = [...(plan.filters || [])];
    newFilters[idx] = { ...newFilters[idx], [field]: value };
    const updated = { ...plan, filters: newFilters };
    setPlan(updated);
    validateAndAnalyze(updated);
  };

  const addFilter = () => {
    if (!newFilterCol.trim()) {
      toast.warning("لطفاً نام ستون فیلتر را مشخص نمایید.");
      return;
    }
    const isParam = newFilterVal.trim().startsWith("@");
    const val = newFilterVal.trim();
    const newF = {
      table: newFilterTable.trim() || plan.base_table,
      column: newFilterCol.trim(),
      op: newFilterOp,
      parameter: isParam ? val.slice(1) : null,
      value: !isParam ? (isNaN(val) || val === "" ? val : Number(val)) : null,
    };
    const updated = { ...plan, filters: [...(plan.filters || []), newF] };
    setPlan(updated);
    setNewFilterCol("");
    setNewFilterVal("");
    validateAndAnalyze(updated);
    toast.success(`فیلتر روی ${newF.column} اضافه شد.`);
  };

  // ── Quick Optimizers (Slow Query Fixes) ──
  const applyAddTopLimit = (topN = 1000) => {
    if (!plan) return;
    const updated = { ...plan, top: topN };
    setPlan(updated);
    validateAndAnalyze(updated);
    toast.success(`محدودیت سقف ردیف TOP ${topN} اعمال گردید.`);
  };

  const applyAddFiscalYearFilter = () => {
    if (!plan) return;
    const existing = (plan.filters || []).some(
      (f) => f.column === "FiscalYearRef" || f.parameter === "FiscalYear"
    );
    if (existing) {
      toast.info("فیلتر سال مالی از قبل موجود است.");
      return;
    }
    const newF = {
      table: plan.base_table,
      column: "FiscalYearRef",
      op: "=",
      parameter: "FiscalYear",
      value: null,
    };
    const updated = {
      ...plan,
      filters: [...(plan.filters || []), newF],
      parameters: [
        ...(plan.parameters || []),
        { name: "FiscalYear", type: "int", title_fa: "سال مالی", required: true },
      ],
    };
    setPlan(updated);
    validateAndAnalyze(updated);
    toast.success("فیلتر سال مالی (@FiscalYear) به نقشه اضافه شد.");
  };

  // ── Final Apply Workflow with Safety & Slow Query Inspection ──
  const handleFinalApply = async (forceProceed = false) => {
    if (!plan) return;
    setApplying(true);

    try {
      // Re-validate and analyze latest state
      const validationResult = await validateAndAnalyze(plan);
      if (!validationResult) return;

      const { ok, safety, sql } = validationResult;

      // 1. Block if structural errors
      if (!ok) {
        toast.error("نقشه دارای خطاهای ساختاری است. لطفاً موارد خطا را اصلاح فرمایید.");
        setActiveTab("safety");
        return;
      }

      // 2. CRITICAL BLOCK: Destructive Keywords
      if (safety && !safety.is_safe) {
        toast.error("خطای امنیتی: کلمات کلیدی مخرب شناسایی شد. اعمال نهایی امکان‌پذیر نیست.");
        setActiveTab("safety");
        return;
      }

      // 3. WARNING CHECK: Slow Query Risks
      if (safety && safety.has_slow_query_risks && !forceProceed) {
        setShowSlowConfirmModal(true);
        setActiveTab("safety");
        return;
      }

      // 4. Clean Apply
      onApply?.(plan, layout, sql);
      onClose();
      toast.success("نقشه با موفقیت اعتبارسنجی و اعمال نهایی گردید.");
    } catch (err) {
      toast.error("خطا در اعمال نقشه: " + (err?.message || String(err)));
    } finally {
      setApplying(false);
    }
  };

  const copySql = () => {
    if (!generatedSql) return;
    navigator.clipboard.writeText(generatedSql);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("کوئری در کلیپ‌بورد کپی شد.");
  };

  if (!isOpen || !plan) return null;

  const destructiveIssues = (safetyReport?.issues || []).filter(
    (i) => i.type === "destructive_keyword" || i.severity === "critical"
  );
  const slowQueryIssues = (safetyReport?.issues || []).filter(
    (i) => i.type === "slow_query"
  );
  const isSafe = safetyReport?.is_safe ?? true;
  const hasSlowRisks = safetyReport?.has_slow_query_risks ?? false;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-3 sm:p-5 overflow-y-auto">
      <div className="relative flex flex-col w-full max-w-4xl max-h-[92vh] rounded-lg border border-border bg-surface shadow-2xl text-foreground">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-4 py-3 bg-surfaceHover/50">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-brand/10 border border-brand/30 text-brand">
              <SlidersHorizontal className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
                ویرایش نقشه و چیدمان کوئری
                {plan.base_table && (
                  <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-ink border border-border text-slate-300">
                    {plan.base_table}
                  </span>
                )}
              </h2>
              <p className="text-[11px] text-muted-foreground">
                تنظیم ستون‌ها، فیلترها و بررسی ایمنی و کوئری‌های سنگین قبل از اعمال نهایی
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Safety Badge Indicator in Header */}
            {safetyReport && (
              <div
                onClick={() => setActiveTab("safety")}
                className={`cursor-pointer flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
                  !isSafe
                    ? "bg-red-500/10 border-red-500/40 text-red-400 animate-pulse"
                    : hasSlowRisks
                    ? "bg-amber-500/10 border-amber-500/40 text-amber-400"
                    : "bg-emerald-500/10 border-emerald-500/40 text-emerald-400"
                }`}
                title="مشاهده گزارش ایمنی و سرعت"
              >
                {!isSafe ? (
                  <>
                    <ShieldAlert className="h-3.5 w-3.5" />
                    <span>مخرب / ناامن</span>
                  </>
                ) : hasSlowRisks ? (
                  <>
                    <AlertTriangle className="h-3.5 w-3.5" />
                    <span>هشدار کوئری سنگین ({slowQueryIssues.length})</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="h-3.5 w-3.5" />
                    <span>ایمن و بهینه ({safetyReport.score}٪)</span>
                  </>
                )}
              </div>
            )}

            <button
              type="button"
              onClick={onClose}
              className="rounded-md p-1.5 text-muted-foreground hover:bg-surfaceHover hover:text-foreground transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 border-b border-border bg-ink/40 px-4 pt-2">
          {[
            { id: "columns", label: `ستون‌ها (${plan.select?.length || 0})`, icon: Table2 },
            { id: "filters", label: `فیلترها (${plan.filters?.length || 0})`, icon: Filter },
            { id: "layout", label: "چیدمان و نمایش", icon: Layers },
            { id: "preview", label: "پیش‌نمایش T-SQL", icon: Code },
            {
              id: "safety",
              label: (
                <span className="flex items-center gap-1">
                  <span>بررسی ایمنی و کارایی</span>
                  {!isSafe && <span className="h-2 w-2 rounded-full bg-red-500 animate-ping" />}
                  {isSafe && hasSlowRisks && (
                    <span className="h-2 w-2 rounded-full bg-amber-400" />
                  )}
                </span>
              ),
              icon: Gauge,
            },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition-all ${
                  isActive
                    ? "border-brand text-brand bg-surface font-semibold"
                    : "border-transparent text-muted-foreground hover:text-foreground hover:bg-surfaceHover/50"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {tab.label}
              </button>
            );
          })}

          <div className="ms-auto flex items-center gap-2 pb-1.5">
            <Button
              variant="outline"
              size="sm"
              onClick={() => validateAndAnalyze()}
              disabled={loading}
              className="h-7 text-xs gap-1 border-border bg-ink text-muted-foreground hover:text-foreground"
            >
              <RefreshCw className={`h-3 w-3 ${loading ? "animate-spin" : ""}`} />
              <span>ارزیابی مجدد</span>
            </Button>
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Quick User Profile Selector Banner */}
          {userProfiles.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-brand/30 bg-brand/5 px-3 py-2 text-xs">
              <div className="flex items-center gap-2">
                <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
                <span className="font-bold text-foreground">پروفایل شخصی کاربر:</span>
                <span className="text-[11px] text-muted-foreground hidden sm:inline">
                  اعمال سریع ستون‌های برگزیده و چیدمان ماتریسی ذخیره‌شده
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <select
                  onChange={(e) => {
                    const selected = userProfiles.find((p) => p.id === e.target.value);
                    if (selected) applyUserProfile(selected);
                  }}
                  defaultValue=""
                  className="h-7 rounded border border-border bg-ink px-2 text-xs text-foreground font-medium"
                >
                  <option value="" disabled>
                    انتخاب پروفایل شخصی...
                  </option>
                  {userProfiles.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.layout?.kind === "matrix" ? "مدل ماتریسی" : "جدولی"})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* TAB 1: COLUMNS */}
          {activeTab === "columns" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-foreground">
                  ستون‌های خروجی گزارش (SELECT Columns)
                </span>
                <span className="text-[11px] text-muted-foreground">
                  ترتیب و توابع تجمیعی را ویرایش کنید
                </span>
              </div>

              {/* Columns List */}
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {(plan.select || []).map((col, idx) => (
                  <div
                    key={idx}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border bg-ink p-2.5 text-xs"
                  >
                    <div className="flex items-center gap-2 min-w-44">
                      <span className="font-mono text-muted-foreground text-[11px] w-4">
                        {idx + 1}
                      </span>
                      <div className="font-mono text-foreground font-semibold">
                        <span className="text-muted-foreground text-[10px] block">
                          {col.table}
                        </span>
                        {col.column}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-1 justify-end flex-wrap">
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-muted-foreground">تجمع:</span>
                        <select
                          value={col.aggregate || ""}
                          onChange={(e) => updateColumn(idx, "aggregate", e.target.value)}
                          className="h-7 rounded border border-border bg-surface px-1.5 text-xs font-mono text-foreground"
                        >
                          <option value="">بدون تابع</option>
                          <option value="SUM">SUM</option>
                          <option value="COUNT">COUNT</option>
                          <option value="COUNT_DISTINCT">COUNT DISTINCT</option>
                          <option value="AVG">AVG</option>
                          <option value="MIN">MIN</option>
                          <option value="MAX">MAX</option>
                        </select>
                      </div>

                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-muted-foreground">نام خروجی:</span>
                        <Input
                          value={col.alias || ""}
                          placeholder={col.column}
                          onChange={(e) => updateColumn(idx, "alias", e.target.value)}
                          className="h-7 w-28 text-xs font-mono bg-surface border-border"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={() => removeColumn(idx)}
                        className="rounded p-1 text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition-colors"
                        title="حذف ستون"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add New Column Box */}
              <div className="rounded-md border border-dashed border-border/80 bg-surface/40 p-3 space-y-2">
                <span className="text-xs font-semibold text-brand flex items-center gap-1">
                  <Plus className="h-3.5 w-3.5" /> افزودن ستون جدید به نقشه
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  <Input
                    placeholder="جدول (اختیاری)"
                    value={newColTable}
                    onChange={(e) => setNewColTable(e.target.value)}
                    className="h-8 text-xs font-mono bg-ink border-border"
                  />
                  <Input
                    placeholder="نام ستون (الزامی)"
                    value={newColName}
                    onChange={(e) => setNewColName(e.target.value)}
                    className="h-8 text-xs font-mono bg-ink border-border"
                  />
                  <select
                    value={newColAgg}
                    onChange={(e) => setNewColAgg(e.target.value)}
                    className="h-8 rounded border border-border bg-ink px-2 text-xs font-mono text-foreground"
                  >
                    <option value="">بدون تجمع</option>
                    <option value="SUM">SUM</option>
                    <option value="COUNT">COUNT</option>
                    <option value="COUNT_DISTINCT">COUNT DISTINCT</option>
                    <option value="AVG">AVG</option>
                    <option value="MIN">MIN</option>
                    <option value="MAX">MAX</option>
                  </select>
                  <Input
                    placeholder="نام نمایشی خروجی"
                    value={newColAlias}
                    onChange={(e) => setNewColAlias(e.target.value)}
                    className="h-8 text-xs font-mono bg-ink border-border"
                  />
                </div>
                <div className="flex justify-end pt-1">
                  <Button
                    size="sm"
                    onClick={addColumn}
                    className="h-7 text-xs gap-1 bg-brand text-white hover:bg-brand/90"
                  >
                    <Plus className="h-3 w-3" /> افزودن به لیست ستون‌ها
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: FILTERS */}
          {activeTab === "filters" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-foreground">
                  شرط‌های فیلتر (WHERE Clause)
                </span>
                <span className="text-[11px] text-muted-foreground">
                  مدیریت پارامترها و شروط محدودکننده
                </span>
              </div>

              {/* Filters List */}
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {(plan.filters || []).length === 0 ? (
                  <div className="rounded border border-amber-500/30 bg-amber-500/5 p-3 text-center text-xs text-amber-300">
                    ⚠️ هیچ فیلتری تعریف نشده است! برای جلوگیری از اسکن کامل جدول و کندی شدید، حداقل یک فیلتر سال مالی یا تاریخی اضافه فرمایید.
                  </div>
                ) : (
                  (plan.filters || []).map((f, idx) => (
                    <div
                      key={idx}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border bg-ink p-2.5 text-xs"
                    >
                      <div className="flex items-center gap-2 min-w-44">
                        <span className="font-mono text-muted-foreground text-[11px] w-4">
                          {idx + 1}
                        </span>
                        <div className="font-mono text-foreground font-semibold">
                          <span className="text-muted-foreground text-[10px] block">
                            {f.table}
                          </span>
                          {f.column}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 flex-1 justify-end flex-wrap">
                        <select
                          value={f.op}
                          onChange={(e) => updateFilter(idx, "op", e.target.value)}
                          className="h-7 rounded border border-border bg-surface px-2 text-xs font-mono text-foreground"
                        >
                          {["=", "<>", ">", ">=", "<", "<=", "LIKE", "IN", "IS NULL", "IS NOT NULL"].map(
                            (o) => (
                              <option key={o} value={o}>
                                {o}
                              </option>
                            )
                          )}
                        </select>

                        <Input
                          value={f.parameter ? `@${f.parameter}` : f.value ?? ""}
                          placeholder="مقدار یا @نام_پارامتر"
                          onChange={(e) => {
                            const val = e.target.value;
                            if (val.startsWith("@")) {
                              updateFilter(idx, "parameter", val.slice(1));
                              updateFilter(idx, "value", null);
                            } else {
                              updateFilter(idx, "parameter", null);
                              updateFilter(idx, "value", val);
                            }
                          }}
                          className="h-7 w-36 text-xs font-mono bg-surface border-border"
                        />

                        <button
                          type="button"
                          onClick={() => removeFilter(idx)}
                          className="rounded p-1 text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition-colors"
                          title="حذف فیلتر"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Quick Preset Buttons for Safe Queries */}
              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-border/60">
                <span className="text-[11px] text-muted-foreground">اقدامات پیشگیرانه کارایی:</span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={applyAddFiscalYearFilter}
                  className="h-7 text-xs gap-1 border-brand/40 text-brand hover:bg-brand/10"
                >
                  <Sparkles className="h-3 w-3" />
                  <span>افزودن فیلتر سال مالی (@FiscalYear)</span>
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => applyAddTopLimit(1000)}
                  className="h-7 text-xs gap-1 border-border bg-ink text-foreground hover:bg-surfaceHover"
                >
                  <Zap className="h-3 w-3 text-amber-400" />
                  <span>محدودسازی سقف به ۱۰۰۰ ردیف (TOP 1000)</span>
                </Button>
              </div>

              {/* Add New Filter Box */}
              <div className="rounded-md border border-dashed border-border/80 bg-surface/40 p-3 space-y-2">
                <span className="text-xs font-semibold text-brand flex items-center gap-1">
                  <Plus className="h-3.5 w-3.5" /> افزودن شرط فیلتر جدید
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  <Input
                    placeholder="جدول"
                    value={newFilterTable}
                    onChange={(e) => setNewFilterTable(e.target.value)}
                    className="h-8 text-xs font-mono bg-ink border-border"
                  />
                  <Input
                    placeholder="نام ستون (مثال: VoucherDate)"
                    value={newFilterCol}
                    onChange={(e) => setNewFilterCol(e.target.value)}
                    className="h-8 text-xs font-mono bg-ink border-border"
                  />
                  <select
                    value={newFilterOp}
                    onChange={(e) => setNewFilterOp(e.target.value)}
                    className="h-8 rounded border border-border bg-ink px-2 text-xs font-mono text-foreground"
                  >
                    {["=", "<>", ">", ">=", "<", "<=", "LIKE", "IN", "IS NULL", "IS NOT NULL"].map(
                      (o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      )
                    )}
                  </select>
                  <Input
                    placeholder="مقدار یا @پارامتر"
                    value={newFilterVal}
                    onChange={(e) => setNewFilterVal(e.target.value)}
                    className="h-8 text-xs font-mono bg-ink border-border"
                  />
                </div>
                <div className="flex justify-end pt-1">
                  <Button
                    size="sm"
                    onClick={addFilter}
                    className="h-7 text-xs gap-1 bg-brand text-white hover:bg-brand/90"
                  >
                    <Plus className="h-3 w-3" /> افزودن فیلتر
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LAYOUT */}
          {activeTab === "layout" && (
            <div className="space-y-3">
              <span className="text-xs font-semibold text-foreground block">
                نوع چیدمان RDL و ساختار نمایش داده‌ها
              </span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "table", title: "جدولی (Table)", desc: "نمایش تخت ردیف‌ها بدون گروه‌بندی" },
                  { id: "grouped", title: "گروه‌بندی‌شده (Grouped)", desc: "دسته‌بندی با سطرهای جمع فرعی" },
                  { id: "matrix", title: "ماتریسی / پیوت (Matrix)", desc: "سرستون‌های پویا و مقادیر تقاطعی" },
                ].map((k) => (
                  <button
                    key={k.id}
                    type="button"
                    onClick={() => setLayout({ ...layout, kind: k.id })}
                    className={`rounded-md border p-3 text-start transition-all ${
                      layout.kind === k.id
                        ? "border-brand bg-brand/10 text-brand ring-1 ring-brand"
                        : "border-border bg-ink text-muted-foreground hover:text-foreground hover:bg-surfaceHover"
                    }`}
                  >
                    <div className="font-semibold text-xs text-foreground mb-1">{k.title}</div>
                    <div className="text-[11px] opacity-80">{k.desc}</div>
                  </button>
                ))}
              </div>

              {/* Grouping specifics */}
              {layout.kind === "grouped" && (
                <div className="rounded-md border border-border bg-ink p-3 space-y-2 text-xs">
                  <span className="font-semibold text-foreground block">ستون‌های گروه‌بندی:</span>
                  <div className="flex flex-wrap gap-2">
                    {(plan.select || []).map((col) => {
                      const colName = col.alias || col.column;
                      const isGroup = (layout.row_groups || []).includes(colName);
                      return (
                        <button
                          key={colName}
                          type="button"
                          onClick={() => {
                            const cur = layout.row_groups || [];
                            const next = isGroup
                              ? cur.filter((g) => g !== colName)
                              : [...cur, colName];
                            setLayout({ ...layout, row_groups: next });
                          }}
                          className={`rounded px-2.5 py-1 text-xs border transition-colors ${
                            isGroup
                              ? "border-brand bg-brand text-white font-medium"
                              : "border-border bg-surface text-muted-foreground hover:text-foreground"
                          }`}
                        >
                          {colName} {isGroup ? "✓" : "+"}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Matrix specifics */}
              {layout.kind === "matrix" && (
                <div className="rounded-md border border-border bg-ink p-3 space-y-3 text-xs">
                  <div className="flex items-center justify-between border-b border-border/80 pb-2">
                    <span className="font-bold text-foreground flex items-center gap-1.5">
                      <Grid className="h-4 w-4 text-brand" /> تنظیمات مدل ماتریسی (Matrix Pivot)
                    </span>
                    <span className="text-[11px] text-muted-foreground">
                      انتخاب سطرها، ستون‌های تقاطعی و سنجه‌ها
                    </span>
                  </div>

                  {/* Matrix Row Groups */}
                  <div className="space-y-1.5">
                    <span className="font-semibold text-foreground block">
                      ۱. سطرها (Row Groups):
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {(plan.select || []).map((col) => {
                        const colName = col.alias || col.column;
                        const isRow = (layout.matrix?.row_groups || []).includes(colName);
                        return (
                          <button
                            key={colName}
                            type="button"
                            onClick={() => {
                              const cur = layout.matrix?.row_groups || [];
                              const next = isRow
                                ? cur.filter((g) => g !== colName)
                                : [...cur, colName];
                              setLayout({
                                ...layout,
                                matrix: {
                                  ...layout.matrix,
                                  row_groups: next,
                                },
                              });
                            }}
                            className={`rounded px-2.5 py-1 text-xs border transition-colors ${
                              isRow
                                ? "border-brand bg-brand text-white font-medium"
                                : "border-border bg-surface text-muted-foreground hover:text-foreground"
                            }`}
                          >
                            {colName} {isRow ? "✓ سطر" : "+"}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Matrix Col Groups */}
                  <div className="space-y-1.5 pt-2 border-t border-border/60">
                    <span className="font-semibold text-foreground block">
                      ۲. ستون‌های پویا (Column Groups - مقادیر بازه زمانی/دسته):
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {(plan.select || []).map((col) => {
                        const colName = col.alias || col.column;
                        const isCol = (layout.matrix?.col_groups || []).includes(colName);
                        return (
                          <button
                            key={colName}
                            type="button"
                            onClick={() => {
                              const cur = layout.matrix?.col_groups || [];
                              const next = isCol
                                ? cur.filter((g) => g !== colName)
                                : [...cur, colName];
                              setLayout({
                                ...layout,
                                matrix: {
                                  ...layout.matrix,
                                  col_groups: next,
                                },
                              });
                            }}
                            className={`rounded px-2.5 py-1 text-xs border transition-colors ${
                              isCol
                                ? "border-brand bg-brand text-white font-medium"
                                : "border-border bg-surface text-muted-foreground hover:text-foreground"
                            }`}
                          >
                            {colName} {isCol ? "✓ ستون" : "+"}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Matrix Totals Checkboxes */}
                  <div className="flex flex-wrap gap-4 pt-2 border-t border-border/60">
                    <label className="flex items-center gap-1.5 cursor-pointer text-xs">
                      <input
                        type="checkbox"
                        checked={layout.matrix?.show_row_totals ?? true}
                        onChange={(e) =>
                          setLayout({
                            ...layout,
                            matrix: {
                              ...layout.matrix,
                              show_row_totals: e.target.checked,
                            },
                          })
                        }
                        className="rounded border-border accent-brand"
                      />
                      <span>نمایش جمع سطرها (Row Totals)</span>
                    </label>

                    <label className="flex items-center gap-1.5 cursor-pointer text-xs">
                      <input
                        type="checkbox"
                        checked={layout.matrix?.show_col_totals ?? true}
                        onChange={(e) =>
                          setLayout({
                            ...layout,
                            matrix: {
                              ...layout.matrix,
                              show_col_totals: e.target.checked,
                            },
                          })
                        }
                        className="rounded border-border accent-brand"
                      />
                      <span>نمایش جمع ستون‌ها (Col Totals)</span>
                    </label>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: SQL PREVIEW */}
          {activeTab === "preview" && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-foreground flex items-center gap-1.5">
                  <Code className="h-4 w-4 text-brand" /> کد T-SQL نهایی تولیدشده از نقشه
                </span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={copySql}
                  className="h-7 text-xs gap-1 border-border bg-ink"
                >
                  {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copied ? "کپی شد" : "کپی کوئری"}</span>
                </Button>
              </div>

              <div className="rounded-md border border-border bg-ink p-3 font-mono text-xs text-sky-200 dir-ltr text-start overflow-x-auto max-h-72 select-all leading-relaxed">
                <pre>{generatedSql || "-- در حال مونتاژ SQL..."}</pre>
              </div>
            </div>
          )}

          {/* TAB 5: SAFETY & SLOW QUERY INSPECTOR */}
          {activeTab === "safety" && (
            <div className="space-y-4">
              {/* Summary Dashboard Header */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* 1. Safety Status */}
                <div
                  className={`rounded-md border p-3 flex flex-col justify-between ${
                    !isSafe
                      ? "border-red-500/40 bg-red-500/10 text-red-400"
                      : hasSlowRisks
                      ? "border-amber-500/40 bg-amber-500/10 text-amber-400"
                      : "border-emerald-500/40 bg-emerald-500/10 text-emerald-400"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold">وضعیت ایمنی کوئری</span>
                    {!isSafe ? (
                      <ShieldAlert className="h-5 w-5" />
                    ) : hasSlowRisks ? (
                      <AlertTriangle className="h-5 w-5" />
                    ) : (
                      <ShieldCheck className="h-5 w-5" />
                    )}
                  </div>
                  <div className="text-sm font-bold mt-2">
                    {!isSafe
                      ? "شناسایی کلمات مخرب / مسدود"
                      : hasSlowRisks
                      ? "هشدار کوئری سنگین"
                      : "کاملاً ایمن (Read-Only)"}
                  </div>
                </div>

                {/* 2. Slow Query & Performance Tier */}
                <div className="rounded-md border border-border bg-ink p-3 flex flex-col justify-between">
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>تخمین بار پردازشی سرور</span>
                    <Gauge className="h-5 w-5 text-brand" />
                  </div>
                  <div className="text-sm font-bold text-foreground mt-2 flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-xs ${
                        safetyReport?.metrics.estimated_cost_tier === "VERY_HIGH"
                          ? "bg-red-500/20 text-red-400"
                          : safetyReport?.metrics.estimated_cost_tier === "HIGH"
                          ? "bg-amber-500/20 text-amber-400"
                          : safetyReport?.metrics.estimated_cost_tier === "MEDIUM"
                          ? "bg-blue-500/20 text-blue-400"
                          : "bg-emerald-500/20 text-emerald-400"
                      }`}
                    >
                      {safetyReport?.metrics.estimated_cost_tier === "VERY_HIGH"
                        ? "بسیار سنگین (Very High)"
                        : safetyReport?.metrics.estimated_cost_tier === "HIGH"
                        ? "سنگین (High)"
                        : safetyReport?.metrics.estimated_cost_tier === "MEDIUM"
                        ? "متوسط (Medium)"
                        : "سبک و سریع (Low)"}
                    </span>
                    <span className="text-xs font-mono text-muted-foreground">
                      امتیاز: {safetyReport?.score || 100}/100
                    </span>
                  </div>
                </div>

                {/* 3. Structural Metrics */}
                <div className="rounded-md border border-border bg-ink p-3 flex flex-col justify-between text-xs">
                  <div className="text-muted-foreground font-semibold">مشخصات ساختاری کوئری</div>
                  <div className="grid grid-cols-2 gap-1 text-[11px] mt-1 font-mono text-slate-300">
                    <div>اتصالات: {safetyReport?.metrics.joins_count || 0} جدول</div>
                    <div>
                      محدودیت TOP:{" "}
                      {safetyReport?.metrics.has_top_limit ? (
                        <span className="text-emerald-400">دارد ✓</span>
                      ) : (
                        <span className="text-amber-400">ندارد ⚠</span>
                      )}
                    </div>
                    <div>
                      فیلتر WHERE:{" "}
                      {safetyReport?.metrics.has_where_clause ? (
                        <span className="text-emerald-400">دارد ✓</span>
                      ) : (
                        <span className="text-amber-400">ندارد ⚠</span>
                      )}
                    </div>
                    <div>جداول: {safetyReport?.metrics.tables_count || 1}</div>
                  </div>
                </div>
              </div>

              {/* CRITICAL ALERT BANNER: Destructive Keywords */}
              {destructiveIssues.length > 0 && (
                <div className="rounded-md border border-red-500/60 bg-red-950/40 p-3.5 space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
                    <ShieldAlert className="h-5 w-5 shrink-0" />
                    <span>کلمات کلیدی مخرب یا غیرمجاز گزارش‌گیری شناسایی گردید:</span>
                  </div>
                  <p className="text-slate-300 text-[12px] leading-relaxed">
                    سیستم گزارش‌ساز صرفاً مجاز به خواندن داده‌ها (SELECT) است. استفاده از دستورات مخرب یا تغییر دهنده داده (DDL / DML / EXEC) مسدود گردیده است.
                  </p>
                  <div className="space-y-1.5 pt-1">
                    {destructiveIssues.map((issue, i) => (
                      <div
                        key={i}
                        className="rounded border border-red-500/30 bg-red-950/60 p-2 text-red-200"
                      >
                        <div className="font-semibold text-red-300">{issue.title_fa}</div>
                        <div className="text-[11px] text-slate-300 mt-0.5">{issue.message_fa}</div>
                        {issue.recommendation_fa && (
                          <div className="text-[10px] text-red-400 mt-1">
                            راهکار: {issue.recommendation_fa}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* WARNING BANNER: Slow Query Risks */}
              {slowQueryIssues.length > 0 && (
                <div className="rounded-md border border-amber-500/50 bg-amber-950/30 p-3.5 space-y-2.5 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                      <AlertTriangle className="h-5 w-5 shrink-0 text-amber-400" />
                      <span>هشدارهای کوئری بسیار سنگین (Slow Query Bottlenecks):</span>
                    </div>
                    <span className="text-[11px] text-amber-300 font-mono">
                      {slowQueryIssues.length} ریسک افت سرعت
                    </span>
                  </div>

                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    الگوهای زیر در صورت اجرا روی پایگاه داده سازمانی با حجم بالای تراکنش‌ها، منجر به زمان پاسخگویی طولانی (Timeout) یا قفل شدن جداول می‌شوند:
                  </p>

                  <div className="space-y-2">
                    {slowQueryIssues.map((issue, i) => (
                      <div
                        key={i}
                        className="rounded border border-amber-500/30 bg-ink p-2.5 space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-amber-300 text-xs">
                            {issue.title_fa}
                          </span>
                        </div>
                        <div className="text-xs text-slate-300 leading-relaxed">
                          {issue.message_fa}
                        </div>
                        {issue.recommendation_fa && (
                          <div className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1 bg-emerald-950/30 rounded px-2 py-1 border border-emerald-800/30">
                            <Sparkles className="h-3 w-3 shrink-0" />
                            <span>پیشنهاد بهینه‌سازی: {issue.recommendation_fa}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Quick One-Click Fixes */}
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-amber-500/30">
                    <span className="text-[11px] text-muted-foreground">اعمال رفع سریع:</span>
                    <Button
                      size="sm"
                      onClick={() => applyAddTopLimit(1000)}
                      className="h-7 text-xs bg-amber-500 text-black hover:bg-amber-400 font-semibold gap-1"
                    >
                      <Zap className="h-3 w-3" />
                      <span>افزودن سقف TOP 1000</span>
                    </Button>
                    <Button
                      size="sm"
                      onClick={applyAddFiscalYearFilter}
                      className="h-7 text-xs bg-brand text-white hover:bg-brand/90 font-semibold gap-1"
                    >
                      <Sparkles className="h-3 w-3" />
                      <span>افزودن فیلتر سال مالی</span>
                    </Button>
                  </div>
                </div>
              )}

              {/* Clean Bill of Health */}
              {isSafe && slowQueryIssues.length === 0 && (
                <div className="rounded-md border border-emerald-500/40 bg-emerald-950/20 p-4 text-center space-y-2">
                  <CheckCircle2 className="h-8 w-8 text-emerald-400 mx-auto" />
                  <div className="font-bold text-emerald-300 text-sm">
                    کوئری کاملاً بهینه و فاقد کلمات کلیدی مخرب است
                  </div>
                  <p className="text-xs text-slate-300 max-w-md mx-auto">
                    ساختار فیلترها و اتصالات نقشه طبق استانداردهای گزارش‌ساز امن و سریع طراحی شده و با اطمینان کامل قابل اعمال است.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3 bg-surfaceHover/50">
          <div className="flex items-center gap-2 text-xs">
            {safetyReport && (
              <span className="text-muted-foreground flex items-center gap-1">
                <span>امتیاز بهینگی:</span>
                <b
                  className={`font-mono ${
                    safetyReport.score >= 80
                      ? "text-emerald-400"
                      : safetyReport.score >= 50
                      ? "text-amber-400"
                      : "text-red-400"
                  }`}
                >
                  {safetyReport.score}/100
                </b>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
              className="h-8 text-xs border-border bg-ink text-foreground hover:bg-surfaceHover"
            >
              انصراف
            </Button>

            <Button
              size="sm"
              onClick={() => handleFinalApply(false)}
              disabled={applying || (safetyReport && !safetyReport.is_safe)}
              className={`h-8 text-xs gap-1.5 font-semibold text-white shadow-sm ${
                safetyReport && !safetyReport.is_safe
                  ? "bg-gray-600 opacity-50 cursor-not-allowed"
                  : safetyReport && safetyReport.has_slow_query_risks
                  ? "bg-amber-600 hover:bg-amber-500"
                  : "bg-brand hover:bg-brand/90"
              }`}
            >
              {applying ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Check className="h-3.5 w-3.5" />
              )}
              <span>اعمال نهایی و ساخت SQL</span>
            </Button>
          </div>
        </div>

        {/* Confirmation Modal for Slow Queries */}
        {showSlowConfirmModal && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 rounded-lg">
            <div className="w-full max-w-md rounded-lg border border-amber-500/50 bg-surface p-4 space-y-3 shadow-2xl text-foreground">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <AlertTriangle className="h-5 w-5" />
                <span>هشدار اعمال کوئری بسیار سنگین (Slow Query)</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                کوئری دارای {slowQueryIssues.length} مورد ریسک افت کارایی (مانند عدم وجود فیلتر بر روی جداول میلیونی، فقدان فیلتر سال مالی یا عدم وجود سقف TOP) است. این امر ممکن است منجر به تأخیر در اجرای گزارش و افزایش بار سرور گردد.
              </p>
              <div className="bg-ink rounded p-2.5 text-[11px] text-amber-200/90 space-y-1 border border-border">
                {slowQueryIssues.map((w, idx) => (
                  <div key={idx} className="flex items-center gap-1">
                    <span>•</span>
                    <span>{w.title_fa}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-border">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowSlowConfirmModal(false)}
                  className="h-8 text-xs border-border bg-ink text-foreground"
                >
                  بازگشت و بهینه‌سازی
                </Button>
                <Button
                  size="sm"
                  onClick={() => {
                    setShowSlowConfirmModal(false);
                    handleFinalApply(true); // force apply with user consent
                  }}
                  className="h-8 text-xs bg-amber-600 text-white hover:bg-amber-500 font-semibold"
                >
                  ادامه و اعمال با وجود ریسک
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
