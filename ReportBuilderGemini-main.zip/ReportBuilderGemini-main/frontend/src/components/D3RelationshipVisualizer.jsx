import React, { useEffect, useRef, useState, useMemo, useCallback } from "react";
import * as d3 from "d3";
import {
  GitFork,
  Network,
  GitGraph,
  Layers,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Maximize2,
  Minimize2,
  Search,
  KeyRound,
  Database,
  ExternalLink,
  Play,
  Pause,
  Filter,
  Sparkles,
  ShieldCheck,
  HelpCircle,
  ArrowRight,
  ArrowLeft,
  Info,
  Check,
  Copy,
  Code,
  Smartphone,
  Monitor,
  SplitSquareVertical,
  SplitSquareHorizontal,
  Scan,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

// Schema color accents
const SCHEMA_COLORS = {
  FIN3: { border: "#10b981", bg: "#064e3b", text: "#34d399", fill: "#022c22", label: "مالی (FIN3)" },
  GNR3: { border: "#38bdf8", bg: "#0c4a6e", text: "#7dd3fc", fill: "#082f49", label: "عمومی (GNR3)" },
  HCM3: { border: "#c084fc", bg: "#581c87", text: "#e9d5ff", fill: "#3b0764", label: "منابع انسانی (HCM3)" },
  RPA3: { border: "#fbbf24", bg: "#78350f", text: "#fde68a", fill: "#451a03", label: "دریافت/پرداخت (RPA3)" },
  LGS3: { border: "#818cf8", bg: "#312e81", text: "#c7d2fe", fill: "#1e1b4b", label: "لجستیک (LGS3)" },
  BDG3: { border: "#f472b6", bg: "#831843", text: "#fbcfe8", fill: "#500724", label: "بودجه (BDG3)" },
  SLS3: { border: "#22d3ee", bg: "#164e63", text: "#a5f3fc", fill: "#083344", label: "فروش (SLS3)" },
  FMK: { border: "#2dd4bf", bg: "#134e4a", text: "#99f6e4", fill: "#042f2e", label: "فریم‌ورک (FMK)" },
  DEFAULT: { border: "#38bdf8", bg: "#1e293b", text: "#94a3b8", fill: "#0f172a", label: "سایر" },
};

function getSchemaColor(schema) {
  return SCHEMA_COLORS[schema] || SCHEMA_COLORS.DEFAULT;
}

export default function D3RelationshipVisualizer({ table, onSelectTable, initialLayout = "force" }) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);

  // States
  const [layoutMode, setLayoutMode] = useState(initialLayout); // "force" | "tree" | "radial" | "matrix" | "erd"
  const [treeOrientation, setTreeOrientation] = useState("horizontal"); // "horizontal" | "vertical"
  const [containerWidth, setContainerWidth] = useState(800);

  useEffect(() => {
    if (initialLayout) {
      setLayoutMode(initialLayout);
    }
  }, [initialLayout, table?.full_name]);

  // Responsive container observer
  useEffect(() => {
    if (!containerRef.current) return;
    const updateSize = () => {
      if (containerRef.current) {
        const w = containerRef.current.clientWidth;
        setContainerWidth(w);
      }
    };
    updateSize();

    let ro;
    if (window.ResizeObserver) {
      ro = new ResizeObserver(() => updateSize());
      ro.observe(containerRef.current);
    } else {
      window.addEventListener("resize", updateSize);
    }
    return () => {
      if (ro) ro.disconnect();
      else window.removeEventListener("resize", updateSize);
    };
  }, []);

  const [filterQuery, setFilterQuery] = useState("");
  const [schemaFilter, setSchemaFilter] = useState("ALL");
  const [typeFilter, setTypeFilter] = useState("ALL"); // "ALL" | "OUTGOING" | "INCOMING"
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPhysicsRunning, setIsPhysicsRunning] = useState(true);
  const [hoveredNode, setHoveredNode] = useState(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [copiedErd, setCopiedErd] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);

  // D3 Refs for interactive control
  const zoomBehaviorRef = useRef(null);
  const simulationRef = useRef(null);
  const activeGroupRef = useRef(null);
  const fitToViewRef = useRef(null);

  const outgoing = table.outgoing || [];
  const incoming = table.incoming || [];
  const totalRels = outgoing.length + incoming.length;

  // Distinct schemas involved
  const availableSchemas = useMemo(() => {
    const s = new Set();
    if (table.schema) s.add(table.schema);
    outgoing.forEach((o) => s.add(o.to_table.split(".")[0]));
    incoming.forEach((i) => s.add(i.from_table.split(".")[0]));
    return Array.from(s);
  }, [table, outgoing, incoming]);

  // Filtered lists
  const filteredOutgoing = useMemo(() => {
    return outgoing.filter((o) => {
      if (typeFilter === "INCOMING") return false;
      const targetSchema = o.to_table.split(".")[0];
      if (schemaFilter !== "ALL" && targetSchema !== schemaFilter) return false;
      if (!filterQuery.trim()) return true;
      const q = filterQuery.toLowerCase();
      return (
        o.to_table.toLowerCase().includes(q) ||
        o.from_col.toLowerCase().includes(q) ||
        o.to_col.toLowerCase().includes(q)
      );
    });
  }, [outgoing, typeFilter, schemaFilter, filterQuery]);

  const filteredIncoming = useMemo(() => {
    return incoming.filter((i) => {
      if (typeFilter === "OUTGOING") return false;
      const srcSchema = i.from_table.split(".")[0];
      if (schemaFilter !== "ALL" && srcSchema !== schemaFilter) return false;
      if (!filterQuery.trim()) return true;
      const q = filterQuery.toLowerCase();
      return (
        i.from_table.toLowerCase().includes(q) ||
        i.from_col.toLowerCase().includes(q) ||
        i.to_col.toLowerCase().includes(q)
      );
    });
  }, [incoming, typeFilter, schemaFilter, filterQuery]);

  // Transform relationships into Graph data (Nodes & Links)
  const graphData = useMemo(() => {
    const centerSchema = table.schema || table.full_name.split(".")[0];
    const nodes = [
      {
        id: table.full_name,
        name: table.name || table.full_name.split(".")[1] || table.full_name,
        schema: centerSchema,
        full_name: table.full_name,
        title_fa: table.title_fa || "",
        type: "center",
        rowCount: table.row_count || 0,
        hasData: table.has_data,
        columnsCount: table.columns?.length || 0,
        pk: table.primary_key || [],
      },
    ];

    const links = [];
    const addedNodeIds = new Set([table.full_name]);

    // Add Outgoing Links (FKs: this table -> target)
    filteredOutgoing.forEach((rel) => {
      const targetId = rel.to_table;
      const targetSchema = targetId.split(".")[0];
      const targetName = targetId.split(".")[1] || targetId;

      if (!addedNodeIds.has(targetId)) {
        nodes.push({
          id: targetId,
          name: targetName,
          schema: targetSchema,
          full_name: targetId,
          type: "outgoing", // parent/target
          rowCount: null,
          hasData: true,
          columnsCount: null,
          pk: [],
        });
        addedNodeIds.add(targetId);
      }

      links.push({
        source: table.full_name,
        target: targetId,
        from_col: rel.from_col,
        to_col: rel.to_col,
        verified: rel.verified,
        confidence: rel.confidence || "inferred",
        direction: "outgoing",
        id: `${table.full_name}->${targetId}:${rel.from_col}`,
      });
    });

    // Add Incoming Links (FKs: src table -> this table)
    filteredIncoming.forEach((rel) => {
      const srcId = rel.from_table;
      const srcSchema = srcId.split(".")[0];
      const srcName = srcId.split(".")[1] || srcId;

      if (!addedNodeIds.has(srcId)) {
        nodes.push({
          id: srcId,
          name: srcName,
          schema: srcSchema,
          full_name: srcId,
          type: "incoming", // child/dependent
          rowCount: null,
          hasData: true,
          columnsCount: null,
          pk: [],
        });
        addedNodeIds.add(srcId);
      }

      links.push({
        source: srcId,
        target: table.full_name,
        from_col: rel.from_col,
        to_col: rel.to_col,
        verified: rel.verified,
        confidence: rel.confidence || "inferred",
        direction: "incoming",
        id: `${srcId}->${table.full_name}:${rel.from_col}`,
      });
    });

    return { nodes, links };
  }, [table, filteredOutgoing, filteredIncoming]);

  // Mermaid ERD representation
  const mermaidErd = useMemo(() => {
    const clean = (s) => s.replace(/[^a-zA-Z0-9_]/g, "_");
    const centerClean = clean(table.full_name);
    let code = "erDiagram\n";
    code += `    ${centerClean} {\n`;
    table.columns?.slice(0, 10).forEach((c) => {
      const isPk = table.primary_key?.includes(c.name) ? "PK" : "";
      code += `        ${c.type.replace(/\(.*?\)/g, "")} ${c.name} ${isPk}\n`;
    });
    if ((table.columns?.length || 0) > 10) {
      code += `        string more_columns "..."\n`;
    }
    code += `    }\n`;

    filteredOutgoing.forEach((o) => {
      code += `    ${centerClean} }o--|| ${clean(o.to_table)} : "${o.from_col} -> ${o.to_col}"\n`;
    });
    filteredIncoming.forEach((i) => {
      code += `    ${clean(i.from_table)} }o--|| ${centerClean} : "${i.from_col} -> ${i.to_col}"\n`;
    });
    return code;
  }, [table, filteredOutgoing, filteredIncoming]);

  // RENDER D3 VISUALIZATION
  useEffect(() => {
    if (layoutMode === "matrix" || layoutMode === "erd") return;
    if (!svgRef.current || !containerRef.current) return;

    const svgElement = d3.select(svgRef.current);
    svgElement.selectAll("*").remove(); // Clear canvas

    const width = containerRef.current.clientWidth || containerWidth || 800;
    const isMobile = width < 640;
    const height = isFullscreen
      ? Math.max(380, window.innerHeight - (isMobile ? 130 : 160))
      : (isMobile ? 390 : 480);

    svgElement.attr("width", width).attr("height", height);

    // Defs: Gradients, Glow filters, and Arrow markers
    const defs = svgElement.append("defs");

    // Glow Filter
    const filter = defs.append("filter").attr("id", "glow").attr("x", "-50%").attr("y", "-50%").attr("width", "200%").attr("height", "200%");
    filter.append("feGaussianBlur").attr("stdDeviation", "4").attr("result", "coloredBlur");
    const feMerge = filter.append("feMerge");
    feMerge.append("feMergeNode").attr("in", "coloredBlur");
    feMerge.append("feMergeNode").attr("in", "SourceGraphic");

    // Arrowhead Markers
    const createMarker = (id, color) => {
      defs
        .append("marker")
        .attr("id", id)
        .attr("viewBox", "0 -5 10 10")
        .attr("refX", 26)
        .attr("refY", 0)
        .attr("markerWidth", 7)
        .attr("markerHeight", 7)
        .attr("orient", "auto")
        .append("path")
        .attr("d", "M0,-4L9,0L0,4")
        .attr("fill", color);
    };

    createMarker("arrow-center", "#38bdf8");
    createMarker("arrow-outgoing", "#10b981");
    createMarker("arrow-incoming", "#38bdf8");
    createMarker("arrow-dim", "#475569");

    // Root Group for Zooming & Panning
    const g = svgElement.append("g").attr("class", "zoom-root");

    // Zoom behavior
    const zoom = d3
      .zoom()
      .scaleExtent([0.15, 3.5])
      .on("zoom", (event) => {
        g.attr("transform", event.transform);
        setZoomLevel(Math.round(event.transform.k * 100));
      });

    svgElement.call(zoom);
    zoomBehaviorRef.current = zoom;

    // Helper: Fit D3 group to viewport bounds dynamically
    const fitToView = (targetGroup, pad = isMobile ? 18 : 36, animated = false) => {
      try {
        const node = targetGroup?.node();
        if (!node) return;
        const bbox = node.getBBox();
        if (!bbox || bbox.width <= 0 || bbox.height <= 0) {
          const defaultK = isMobile ? 0.72 : 0.95;
          const fallbackTransform = d3.zoomIdentity.translate(width / 2, height / 2).scale(defaultK);
          svgElement.call(zoom.transform, fallbackTransform);
          setZoomLevel(Math.round(defaultK * 100));
          return;
        }

        const fullW = bbox.width + pad * 2;
        const fullH = bbox.height + pad * 2;
        const midX = bbox.x + bbox.width / 2;
        const midY = bbox.y + bbox.height / 2;

        const scaleX = (width - pad) / fullW;
        const scaleY = (height - pad) / fullH;
        const targetK = Math.min(Math.max(Math.min(scaleX, scaleY), 0.18), isMobile ? 0.92 : 1.15);

        const targetTransform = d3.zoomIdentity
          .translate(width / 2 - midX * targetK, height / 2 - midY * targetK)
          .scale(targetK);

        if (animated) {
          svgElement.transition().duration(350).call(zoom.transform, targetTransform);
        } else {
          svgElement.call(zoom.transform, targetTransform);
        }
        setZoomLevel(Math.round(targetK * 100));
      } catch (err) {
        console.warn("fitToView caught:", err);
      }
    };
    fitToViewRef.current = fitToView;

    // Default center focal point
    const initialTransform = d3.zoomIdentity.translate(width / 2, height / 2).scale(isMobile ? 0.75 : 0.95);
    svgElement.call(zoom.transform, initialTransform);

    // =========================================================================
    // LAYOUT 1: FORCE-DIRECTED GRAPH
    // =========================================================================
    if (layoutMode === "force") {
      const nodesData = graphData.nodes.map((d) => ({ ...d }));
      const linksData = graphData.links.map((d) => ({ ...d }));

      const simulation = d3
        .forceSimulation(nodesData)
        .force(
          "link",
          d3
            .forceLink(linksData)
            .id((d) => d.id)
            .distance((d) => (d.direction === "outgoing" ? 180 : 210))
            .strength(0.7)
        )
        .force("charge", d3.forceManyBody().strength((d) => (d.type === "center" ? -1200 : -500)))
        .force("collide", d3.forceCollide().radius(70).iterations(3))
        .force("center", d3.forceCenter(0, 0))
        .force("x", d3.forceX(0).strength(0.08))
        .force("y", d3.forceY(0).strength(0.08));

      simulationRef.current = simulation;

      // Draw Links
      const linkGroup = g.append("g").attr("class", "links");
      const link = linkGroup
        .selectAll("g.link-item")
        .data(linksData)
        .enter()
        .append("g")
        .attr("class", "link-item");

      const linkPath = link
        .append("path")
        .attr("class", "link-path")
        .attr("stroke", (d) => (d.direction === "outgoing" ? "#10b981" : "#38bdf8"))
        .attr("stroke-width", 1.8)
        .attr("stroke-opacity", 0.65)
        .attr("stroke-dasharray", (d) => (d.verified ? "none" : "5,4"))
        .attr("fill", "none")
        .attr("marker-end", (d) => (d.direction === "outgoing" ? "url(#arrow-outgoing)" : "url(#arrow-incoming)"));

      // Link Labels (Column Mappings)
      const linkLabel = link
        .append("g")
        .attr("class", "link-label")
        .style("cursor", "pointer")
        .on("click", (e, d) => {
          setSelectedNode(d);
        });

      linkLabel
        .append("rect")
        .attr("rx", 4)
        .attr("ry", 4)
        .attr("fill", "#090d16")
        .attr("stroke", "#1e293b")
        .attr("stroke-width", 1)
        .attr("opacity", 0.9);

      linkLabel
        .append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "0.32em")
        .attr("font-family", "ui-monospace, monospace")
        .attr("font-size", "10px")
        .attr("fill", "#94a3b8")
        .text((d) => `${d.from_col} → ${d.to_col}`);

      // Size background rects for link labels
      linkLabel.each(function () {
        const textNode = d3.select(this).select("text").node();
        if (textNode) {
          const bbox = textNode.getBBox();
          d3.select(this)
            .select("rect")
            .attr("x", bbox.x - 5)
            .attr("y", bbox.y - 2)
            .attr("width", bbox.width + 10)
            .attr("height", bbox.height + 4);
        }
      });

      // Draw Nodes
      const nodeGroup = g.append("g").attr("class", "nodes");
      const node = nodeGroup
        .selectAll("g.node")
        .data(nodesData)
        .enter()
        .append("g")
        .attr("class", "node")
        .style("cursor", "pointer")
        .call(
          d3
            .drag()
            .on("start", (event, d) => {
              if (!event.active) simulation.alphaTarget(0.3).restart();
              d.fx = d.x;
              d.fy = d.y;
            })
            .on("drag", (event, d) => {
              d.fx = event.x;
              d.fy = event.y;
            })
            .on("end", (event, d) => {
              if (!event.active) simulation.alphaTarget(0);
              if (!isPhysicsRunning) {
                d.fx = event.x;
                d.fy = event.y;
              } else {
                d.fx = null;
                d.fy = null;
              }
            })
        );

      // Node Card / Shape
      node.each(function (d) {
        const el = d3.select(this);
        const sc = getSchemaColor(d.schema);

        if (d.type === "center") {
          // Center Focal Node: Premium glowing card
          const w = 170;
          const h = 76;

          el.append("rect")
            .attr("x", -w / 2)
            .attr("y", -h / 2)
            .attr("width", w)
            .attr("height", h)
            .attr("rx", 10)
            .attr("fill", "#090e1a")
            .attr("stroke", "#38bdf8")
            .attr("stroke-width", 2.5)
            .attr("filter", "url(#glow)");

          // Schema tag badge
          el.append("rect")
            .attr("x", -w / 2 + 10)
            .attr("y", -h / 2 + 8)
            .attr("width", 48)
            .attr("height", 16)
            .attr("rx", 3)
            .attr("fill", "#0284c7")
            .attr("opacity", 0.9);

          el.append("text")
            .attr("x", -w / 2 + 34)
            .attr("y", -h / 2 + 19)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "9px")
            .attr("font-weight", "bold")
            .attr("fill", "#ffffff")
            .text(d.schema);

          // Center Label (Focal)
          el.append("text")
            .attr("x", w / 2 - 10)
            .attr("y", -h / 2 + 20)
            .attr("text-anchor", "end")
            .attr("font-size", "9px")
            .attr("fill", "#38bdf8")
            .attr("font-weight", "bold")
            .text("★ جدول جاری");

          // Table Full Name
          el.append("text")
            .attr("x", 0)
            .attr("y", 6)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "12.5px")
            .attr("font-weight", "bold")
            .attr("fill", "#ffffff")
            .text(d.full_name);

          // Rows & Columns metric
          const metaText = d.rowCount
            ? `${Number(d.rowCount).toLocaleString("fa")} ردیف • ${d.columnsCount} ستون`
            : `${d.columnsCount} ستون`;
          el.append("text")
            .attr("x", 0)
            .attr("y", 25)
            .attr("text-anchor", "middle")
            .attr("font-size", "10px")
            .attr("fill", "#94a3b8")
            .text(metaText);
        } else {
          // Connected Satellite Nodes (Outgoing & Incoming)
          const w = 150;
          const h = 54;
          const isOut = d.type === "outgoing";

          el.append("rect")
            .attr("x", -w / 2)
            .attr("y", -h / 2)
            .attr("width", w)
            .attr("height", h)
            .attr("rx", 6)
            .attr("fill", "#0b1120")
            .attr("stroke", isOut ? "#10b981" : "#38bdf8")
            .attr("stroke-width", 1.5)
            .attr("stroke-opacity", 0.75);

          // Schema tag badge
          el.append("rect")
            .attr("x", -w / 2 + 8)
            .attr("y", -h / 2 + 6)
            .attr("width", 42)
            .attr("height", 14)
            .attr("rx", 2)
            .attr("fill", sc.border)
            .attr("opacity", 0.3);

          el.append("text")
            .attr("x", -w / 2 + 29)
            .attr("y", -h / 2 + 16)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "8.5px")
            .attr("font-weight", "bold")
            .attr("fill", sc.text)
            .text(d.schema);

          // Direction label
          el.append("text")
            .attr("x", w / 2 - 8)
            .attr("y", -h / 2 + 16)
            .attr("text-anchor", "end")
            .attr("font-size", "8.5px")
            .attr("fill", isOut ? "#34d399" : "#7dd3fc")
            .text(isOut ? "والد (FK)" : "وابسته (فرزند)");

          // Table Name
          el.append("text")
            .attr("x", 0)
            .attr("y", 12)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "11.5px")
            .attr("font-weight", "600")
            .attr("fill", "#f1f5f9")
            .text(d.full_name);
        }
      });

      // Hover & Click Interactions
      node
        .on("mouseenter", (event, d) => {
          setHoveredNode(d);
          // Highlight connected edges
          linkPath
            .attr("stroke-opacity", (l) => (l.source.id === d.id || l.target.id === d.id ? 1 : 0.12))
            .attr("stroke-width", (l) => (l.source.id === d.id || l.target.id === d.id ? 2.5 : 1));
          node.attr("opacity", (n) => {
            if (n.id === d.id) return 1;
            const isConnected = linksData.some(
              (l) => (l.source.id === d.id && l.target.id === n.id) || (l.target.id === d.id && l.source.id === n.id)
            );
            return isConnected ? 1 : 0.25;
          });
        })
        .on("mouseleave", () => {
          setHoveredNode(null);
          linkPath.attr("stroke-opacity", 0.65).attr("stroke-width", 1.8);
          node.attr("opacity", 1);
        })
        .on("click", (event, d) => {
          event.stopPropagation();
          setSelectedNode(d);
          if (d.type !== "center" && onSelectTable) {
            // Can choose to open table details directly or via action
          }
        });

      // Simulation Tick
      simulation.on("tick", () => {
        linkPath.attr("d", (d) => {
          const dx = d.target.x - d.source.x;
          const dy = d.target.y - d.source.y;
          const dr = Math.sqrt(dx * dx + dy * dy) * 1.6;
          // Slight curve for better visibility
          return `M${d.source.x},${d.source.y}A${dr},${dr} 0 0,1 ${d.target.x},${d.target.y}`;
        });

        linkLabel.attr("transform", (d) => {
          const x = (d.source.x + d.target.x) / 2;
          const y = (d.source.y + d.target.y) / 2;
          return `translate(${x}, ${y})`;
        });

        node.attr("transform", (d) => `translate(${d.x}, ${d.y})`);
      });
    }

    // =========================================================================
    // LAYOUT 2: D3 HIERARCHICAL TREE DIAGRAM (Adaptive Mobile & Desktop)
    // =========================================================================
    else if (layoutMode === "tree") {
      const treeGroup = g.append("g").attr("class", "tree-container");
      activeGroupRef.current = treeGroup;

      const isVertical = treeOrientation === "vertical";

      // Card Dimensions (scaled comfortably for touch & small viewports)
      const cw = isMobile ? 152 : 176;
      const ch = isMobile ? 68 : 78;
      const nw = isMobile ? 138 : 158;
      const nh = isMobile ? 50 : 56;

      // Draw Center Focal Node at (0, 0)
      const centerG = treeGroup.append("g").attr("transform", "translate(0, 0)");

      centerG
        .append("rect")
        .attr("x", -cw / 2)
        .attr("y", -ch / 2)
        .attr("width", cw)
        .attr("height", ch)
        .attr("rx", 10)
        .attr("fill", "#070c18")
        .attr("stroke", "#38bdf8")
        .attr("stroke-width", 2.5)
        .attr("filter", "url(#glow)");

      centerG
        .append("text")
        .attr("x", 0)
        .attr("y", -ch / 2 + (isMobile ? 16 : 20))
        .attr("text-anchor", "middle")
        .attr("font-size", isMobile ? "9px" : "10px")
        .attr("fill", "#38bdf8")
        .attr("font-weight", "bold")
        .text("★ جدول اصلی (کانون)");

      centerG
        .append("text")
        .attr("x", 0)
        .attr("y", isMobile ? 2 : 4)
        .attr("text-anchor", "middle")
        .attr("font-family", "ui-monospace, monospace")
        .attr("font-size", isMobile ? "11.5px" : "13px")
        .attr("font-weight", "bold")
        .attr("fill", "#ffffff")
        .text(table.full_name);

      centerG
        .append("text")
        .attr("x", 0)
        .attr("y", isMobile ? 20 : 24)
        .attr("text-anchor", "middle")
        .attr("font-size", isMobile ? "9px" : "10px")
        .attr("fill", "#94a3b8")
        .text(`${filteredOutgoing.length} والد • ${filteredIncoming.length} فرزند`);

      if (!isVertical) {
        // --- HORIZONTAL TREE (Left: Outgoing/Parents, Right: Incoming/Children) ---
        const leftX = isMobile ? -230 : -310;
        const outCount = filteredOutgoing.length;
        const outSpacing = Math.max(nh + 12, Math.min(84, 400 / Math.max(outCount, 1)));
        const outStartY = -((outCount - 1) * outSpacing) / 2;

        filteredOutgoing.forEach((rel, idx) => {
          const y = outStartY + idx * outSpacing;
          const targetId = rel.to_table;
          const schema = targetId.split(".")[0];
          const sc = getSchemaColor(schema);

          // Bezier link from Center Left to Target Right
          const linkD = d3.linkHorizontal()({
            source: [-cw / 2, 0],
            target: [leftX + nw / 2, y],
          });

          treeGroup
            .append("path")
            .attr("d", linkD)
            .attr("fill", "none")
            .attr("stroke", "#10b981")
            .attr("stroke-width", 1.8)
            .attr("stroke-dasharray", rel.verified ? "none" : "5,4")
            .attr("marker-end", "url(#arrow-outgoing)");

          // Outgoing Node Card
          const ng = treeGroup
            .append("g")
            .attr("transform", `translate(${leftX}, ${y})`)
            .style("cursor", "pointer")
            .on("click", () => {
              setSelectedNode({
                ...rel,
                id: targetId,
                full_name: targetId,
                schema,
                type: "outgoing",
                direction: true,
              });
            });

          ng.append("rect")
            .attr("x", -nw / 2)
            .attr("y", -nh / 2)
            .attr("width", nw)
            .attr("height", nh)
            .attr("rx", 6)
            .attr("fill", "#0b1120")
            .attr("stroke", "#10b981")
            .attr("stroke-width", 1.5)
            .attr("class", "hover:stroke-emerald-400");

          // Schema pill
          ng.append("text")
            .attr("x", -nw / 2 + 8)
            .attr("y", -nh / 2 + 14)
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "8.5px")
            .attr("font-weight", "bold")
            .attr("fill", sc.text)
            .text(schema);

          ng.append("text")
            .attr("x", nw / 2 - 8)
            .attr("y", -nh / 2 + 14)
            .attr("text-anchor", "end")
            .attr("font-size", "8.5px")
            .attr("fill", "#34d399")
            .text("والد (FK)");

          ng.append("text")
            .attr("x", 0)
            .attr("y", 2)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", isMobile ? "10px" : "11.5px")
            .attr("font-weight", "bold")
            .attr("fill", "#f8fafc")
            .text(targetId);

          ng.append("text")
            .attr("x", 0)
            .attr("y", 18)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "9px")
            .attr("fill", "#94a3b8")
            .text(`${rel.from_col} → ${rel.to_col}`);
        });

        // Incoming / Right
        const rightX = isMobile ? 230 : 310;
        const inCount = filteredIncoming.length;
        const inSpacing = Math.max(nh + 12, Math.min(84, 400 / Math.max(inCount, 1)));
        const inStartY = -((inCount - 1) * inSpacing) / 2;

        filteredIncoming.forEach((rel, idx) => {
          const y = inStartY + idx * inSpacing;
          const srcId = rel.from_table;
          const schema = srcId.split(".")[0];
          const sc = getSchemaColor(schema);

          const linkD = d3.linkHorizontal()({
            source: [rightX - nw / 2, y],
            target: [cw / 2, 0],
          });

          treeGroup
            .append("path")
            .attr("d", linkD)
            .attr("fill", "none")
            .attr("stroke", "#38bdf8")
            .attr("stroke-width", 1.8)
            .attr("stroke-dasharray", rel.verified ? "none" : "5,4")
            .attr("marker-end", "url(#arrow-incoming)");

          const ng = treeGroup
            .append("g")
            .attr("transform", `translate(${rightX}, ${y})`)
            .style("cursor", "pointer")
            .on("click", () => {
              setSelectedNode({
                ...rel,
                id: srcId,
                full_name: srcId,
                schema,
                type: "incoming",
                direction: true,
              });
            });

          ng.append("rect")
            .attr("x", -nw / 2)
            .attr("y", -nh / 2)
            .attr("width", nw)
            .attr("height", nh)
            .attr("rx", 6)
            .attr("fill", "#0b1120")
            .attr("stroke", "#38bdf8")
            .attr("stroke-width", 1.5);

          ng.append("text")
            .attr("x", -nw / 2 + 8)
            .attr("y", -nh / 2 + 14)
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "8.5px")
            .attr("font-weight", "bold")
            .attr("fill", sc.text)
            .text(schema);

          ng.append("text")
            .attr("x", nw / 2 - 8)
            .attr("y", -nh / 2 + 14)
            .attr("text-anchor", "end")
            .attr("font-size", "8.5px")
            .attr("fill", "#7dd3fc")
            .text("فرزند (FK)");

          ng.append("text")
            .attr("x", 0)
            .attr("y", 2)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", isMobile ? "10px" : "11.5px")
            .attr("font-weight", "bold")
            .attr("fill", "#f8fafc")
            .text(srcId);

          ng.append("text")
            .attr("x", 0)
            .attr("y", 18)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "9px")
            .attr("fill", "#94a3b8")
            .text(`${rel.from_col} → ${rel.to_col}`);
        });
      } else {
        // --- VERTICAL TREE (Top: Outgoing/Parents, Bottom: Incoming/Children) ---
        // Perfect for mobile portrait orientation
        const topY = isMobile ? -145 : -190;
        const outCount = filteredOutgoing.length;
        const outSpacingX = Math.max(nw + 12, Math.min(220, (Math.max(width, 600) * 0.9) / Math.max(outCount, 1)));
        const outStartX = -((outCount - 1) * outSpacingX) / 2;

        filteredOutgoing.forEach((rel, idx) => {
          const x = outStartX + idx * outSpacingX;
          const targetId = rel.to_table;
          const schema = targetId.split(".")[0];
          const sc = getSchemaColor(schema);

          const linkD = d3.linkVertical()({
            source: [0, -ch / 2],
            target: [x, topY + nh / 2],
          });

          treeGroup
            .append("path")
            .attr("d", linkD)
            .attr("fill", "none")
            .attr("stroke", "#10b981")
            .attr("stroke-width", 1.8)
            .attr("stroke-dasharray", rel.verified ? "none" : "5,4")
            .attr("marker-end", "url(#arrow-outgoing)");

          const ng = treeGroup
            .append("g")
            .attr("transform", `translate(${x}, ${topY})`)
            .style("cursor", "pointer")
            .on("click", () => {
              setSelectedNode({
                ...rel,
                id: targetId,
                full_name: targetId,
                schema,
                type: "outgoing",
                direction: true,
              });
            });

          ng.append("rect")
            .attr("x", -nw / 2)
            .attr("y", -nh / 2)
            .attr("width", nw)
            .attr("height", nh)
            .attr("rx", 6)
            .attr("fill", "#0b1120")
            .attr("stroke", "#10b981")
            .attr("stroke-width", 1.5);

          ng.append("text")
            .attr("x", -nw / 2 + 8)
            .attr("y", -nh / 2 + 14)
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "8.5px")
            .attr("font-weight", "bold")
            .attr("fill", sc.text)
            .text(schema);

          ng.append("text")
            .attr("x", nw / 2 - 8)
            .attr("y", -nh / 2 + 14)
            .attr("text-anchor", "end")
            .attr("font-size", "8.5px")
            .attr("fill", "#34d399")
            .text("والد (FK)");

          ng.append("text")
            .attr("x", 0)
            .attr("y", 2)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", isMobile ? "10px" : "11.5px")
            .attr("font-weight", "bold")
            .attr("fill", "#f8fafc")
            .text(targetId);

          ng.append("text")
            .attr("x", 0)
            .attr("y", 18)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "9px")
            .attr("fill", "#94a3b8")
            .text(`${rel.from_col} → ${rel.to_col}`);
        });

        // Bottom: Incoming / Children
        const bottomY = isMobile ? 145 : 190;
        const inCount = filteredIncoming.length;
        const inSpacingX = Math.max(nw + 12, Math.min(220, (Math.max(width, 600) * 0.9) / Math.max(inCount, 1)));
        const inStartX = -((inCount - 1) * inSpacingX) / 2;

        filteredIncoming.forEach((rel, idx) => {
          const x = inStartX + idx * inSpacingX;
          const srcId = rel.from_table;
          const schema = srcId.split(".")[0];
          const sc = getSchemaColor(schema);

          const linkD = d3.linkVertical()({
            source: [x, bottomY - nh / 2],
            target: [0, ch / 2],
          });

          treeGroup
            .append("path")
            .attr("d", linkD)
            .attr("fill", "none")
            .attr("stroke", "#38bdf8")
            .attr("stroke-width", 1.8)
            .attr("stroke-dasharray", rel.verified ? "none" : "5,4")
            .attr("marker-end", "url(#arrow-incoming)");

          const ng = treeGroup
            .append("g")
            .attr("transform", `translate(${x}, ${bottomY})`)
            .style("cursor", "pointer")
            .on("click", () => {
              setSelectedNode({
                ...rel,
                id: srcId,
                full_name: srcId,
                schema,
                type: "incoming",
                direction: true,
              });
            });

          ng.append("rect")
            .attr("x", -nw / 2)
            .attr("y", -nh / 2)
            .attr("width", nw)
            .attr("height", nh)
            .attr("rx", 6)
            .attr("fill", "#0b1120")
            .attr("stroke", "#38bdf8")
            .attr("stroke-width", 1.5);

          ng.append("text")
            .attr("x", -nw / 2 + 8)
            .attr("y", -nh / 2 + 14)
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "8.5px")
            .attr("font-weight", "bold")
            .attr("fill", sc.text)
            .text(schema);

          ng.append("text")
            .attr("x", nw / 2 - 8)
            .attr("y", -nh / 2 + 14)
            .attr("text-anchor", "end")
            .attr("font-size", "8.5px")
            .attr("fill", "#7dd3fc")
            .text("فرزند (FK)");

          ng.append("text")
            .attr("x", 0)
            .attr("y", 2)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", isMobile ? "10px" : "11.5px")
            .attr("font-weight", "bold")
            .attr("fill", "#f8fafc")
            .text(srcId);

          ng.append("text")
            .attr("x", 0)
            .attr("y", 18)
            .attr("text-anchor", "middle")
            .attr("font-family", "ui-monospace, monospace")
            .attr("font-size", "9px")
            .attr("fill", "#94a3b8")
            .text(`${rel.from_col} → ${rel.to_col}`);
        });
      }

      // Automatically fit tree perfectly to container on first load
      setTimeout(() => {
        fitToView(treeGroup, isMobile ? 18 : 36, false);
      }, 40);
    }

    // =========================================================================
    // LAYOUT 3: D3 RADIAL / CIRCLE DIAGRAM
    // =========================================================================
    else if (layoutMode === "radial") {
      const radialGroup = g.append("g").attr("class", "radial-container");
      const radius = 220;

      // Draw Center Node at (0, 0)
      const centerG = radialGroup.append("g").attr("transform", "translate(0, 0)");
      centerG
        .append("circle")
        .attr("r", 48)
        .attr("fill", "#070c18")
        .attr("stroke", "#38bdf8")
        .attr("stroke-width", 2.5)
        .attr("filter", "url(#glow)");

      centerG
        .append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "-0.6em")
        .attr("font-size", "9px")
        .attr("fill", "#38bdf8")
        .attr("font-weight", "bold")
        .text("جدول اصلی");

      centerG
        .append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "0.4em")
        .attr("font-family", "ui-monospace, monospace")
        .attr("font-size", "10.5px")
        .attr("font-weight", "bold")
        .attr("fill", "#ffffff")
        .text(table.name || table.full_name);

      centerG
        .append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "1.7em")
        .attr("font-size", "8.5px")
        .attr("fill", "#94a3b8")
        .text(table.schema);

      // Arrange all connected tables around the circle
      const allRels = [
        ...filteredOutgoing.map((o) => ({ ...o, type: "outgoing", table: o.to_table })),
        ...filteredIncoming.map((i) => ({ ...i, type: "incoming", table: i.from_table })),
      ];

      const angleStep = (2 * Math.PI) / Math.max(allRels.length, 1);

      allRels.forEach((item, idx) => {
        const angle = idx * angleStep - Math.PI / 2;
        const x = radius * Math.cos(angle);
        const y = radius * Math.sin(angle);
        const isOut = item.type === "outgoing";
        const schema = item.table.split(".")[0];
        const sc = getSchemaColor(schema);

        // Curve from center to node
        radialGroup
          .append("line")
          .attr("x1", 0)
          .attr("y1", 0)
          .attr("x2", x)
          .attr("y2", y)
          .attr("stroke", isOut ? "#10b981" : "#38bdf8")
          .attr("stroke-width", 1.6)
          .attr("stroke-opacity", 0.6)
          .attr("stroke-dasharray", item.verified ? "none" : "4,4");

        const nodeG = radialGroup
          .append("g")
          .attr("transform", `translate(${x}, ${y})`)
          .style("cursor", "pointer")
          .on("click", () => onSelectTable?.(item.table));

        nodeG
          .append("circle")
          .attr("r", 28)
          .attr("fill", "#0b1120")
          .attr("stroke", isOut ? "#10b981" : "#38bdf8")
          .attr("stroke-width", 1.8);

        nodeG
          .append("text")
          .attr("text-anchor", "middle")
          .attr("dy", "-0.3em")
          .attr("font-family", "ui-monospace, monospace")
          .attr("font-size", "8px")
          .attr("font-weight", "bold")
          .attr("fill", sc.text)
          .text(schema);

        nodeG
          .append("text")
          .attr("text-anchor", "middle")
          .attr("dy", "0.9em")
          .attr("font-family", "ui-monospace, monospace")
          .attr("font-size", "9px")
          .attr("font-weight", "600")
          .attr("fill", "#f1f5f9")
          .text(item.table.split(".")[1] || item.table);
      });
    }

    return () => {
      if (simulationRef.current) simulationRef.current.stop();
    };
  }, [layoutMode, treeOrientation, containerWidth, graphData, filteredOutgoing, filteredIncoming, isFullscreen, table, isPhysicsRunning, onSelectTable]);

  // CONTROLS
  const handleZoomIn = () => {
    if (!svgRef.current || !zoomBehaviorRef.current) return;
    d3.select(svgRef.current).transition().duration(250).call(zoomBehaviorRef.current.scaleBy, 1.25);
  };

  const handleZoomOut = () => {
    if (!svgRef.current || !zoomBehaviorRef.current) return;
    d3.select(svgRef.current).transition().duration(250).call(zoomBehaviorRef.current.scaleBy, 0.8);
  };

  const handleFitToScreen = () => {
    if (fitToViewRef.current && activeGroupRef.current) {
      fitToViewRef.current(activeGroupRef.current, containerWidth < 640 ? 18 : 36, true);
    } else {
      handleResetZoom();
    }
  };

  const handleResetZoom = () => {
    if (!svgRef.current || !zoomBehaviorRef.current || !containerRef.current) return;
    const width = containerRef.current.clientWidth || containerWidth || 800;
    const isMobile = width < 640;
    const height = isFullscreen
      ? Math.max(380, window.innerHeight - (isMobile ? 130 : 160))
      : (isMobile ? 390 : 480);
    const defaultScale = isMobile ? 0.75 : 0.95;
    d3.select(svgRef.current)
      .transition()
      .duration(350)
      .call(zoomBehaviorRef.current.transform, d3.zoomIdentity.translate(width / 2, height / 2).scale(defaultScale));
    setZoomLevel(Math.round(defaultScale * 100));

    // Restore node positions and restart simulation
    if (simulationRef.current) {
      const nodes = simulationRef.current.nodes();
      nodes.forEach((n) => {
        if (n.id !== table.full_name) {
          n.fx = null;
          n.fy = null;
        }
      });
      simulationRef.current.alpha(0.35).restart();
      setIsPhysicsRunning(true);
    }
  };

  const handleTogglePhysics = () => {
    if (!simulationRef.current) return;
    if (isPhysicsRunning) {
      simulationRef.current.stop();
      setIsPhysicsRunning(false);
      toast.info("شبیه‌ساز فیزیک D3 متوقف شد.");
    } else {
      simulationRef.current.alpha(0.3).restart();
      setIsPhysicsRunning(true);
      toast.info("شبیه‌ساز فیزیک D3 فعال شد.");
    }
  };

  const handleCopyErd = () => {
    navigator.clipboard.writeText(mermaidErd);
    setCopiedErd(true);
    toast.success("کد دیاگرام Mermaid در حافظه کپی شد.");
    setTimeout(() => setCopiedErd(false), 2000);
  };

  return (
    <div
      ref={containerRef}
      className={`rounded-sm border border-border bg-ink transition-all ${
        isFullscreen
          ? "fixed inset-3 z-50 flex flex-col bg-surface shadow-2xl ring-1 ring-border"
          : "relative overflow-hidden"
      }`}
    >
      {/* HEADER TOOLBAR */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-border bg-surface/80 px-3 py-2.5">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-sm bg-brand/10 text-brand shadow-inner">
            <GitFork className="h-4 w-4" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold text-slate-100 truncate">
                گراف و دیاگرام بصری ارتباطات (D3 Visualization)
              </span>
              <span className="rounded bg-brand/15 px-2 py-0.5 font-mono text-[11px] font-bold text-brand shrink-0">
                {totalRels.toLocaleString("fa")} رابطه
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground truncate">
              ارتباطات کلید خارجی (FK) با موتور تعاملی D3.js
            </p>
          </div>
        </div>

        {/* View Layout Tabs & Actions */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none -mx-1 px-1 sm:mx-0 sm:px-0">
          <div className="flex rounded-sm border border-border bg-ink p-0.5 text-xs shrink-0">
            <button
              onClick={() => setLayoutMode("force")}
              className={`flex items-center gap-1.5 rounded-sm px-2 sm:px-2.5 py-1 whitespace-nowrap transition-colors ${
                layoutMode === "force"
                  ? "bg-brand font-medium text-ink shadow-sm"
                  : "text-muted-foreground hover:text-white"
              }`}
              title="گراف تعاملی نیروگاهی با D3 Force Simulation"
            >
              <Network className="h-3.5 w-3.5" />
              <span>گراف پویا</span>
            </button>
            <button
              onClick={() => setLayoutMode("tree")}
              className={`flex items-center gap-1.5 rounded-sm px-2 sm:px-2.5 py-1 whitespace-nowrap transition-colors ${
                layoutMode === "tree"
                  ? "bg-brand font-medium text-ink shadow-sm"
                  : "text-muted-foreground hover:text-white"
              }`}
              title="نمودار درختی دوطرفه والد و فرزند"
            >
              <GitGraph className="h-3.5 w-3.5" />
              <span>دیاگرام درختی</span>
            </button>
            <button
              onClick={() => setLayoutMode("radial")}
              className={`flex items-center gap-1.5 rounded-sm px-2 sm:px-2.5 py-1 whitespace-nowrap transition-colors ${
                layoutMode === "radial"
                  ? "bg-brand font-medium text-ink shadow-sm"
                  : "text-muted-foreground hover:text-white"
              }`}
              title="نمای خوشه‌ای شعاعی"
            >
              <GitFork className="h-3.5 w-3.5 rotate-90" />
              <span>شعاعی</span>
            </button>
            <button
              onClick={() => setLayoutMode("matrix")}
              className={`flex items-center gap-1.5 rounded-sm px-2 sm:px-2.5 py-1 whitespace-nowrap transition-colors ${
                layoutMode === "matrix"
                  ? "bg-brand font-medium text-ink shadow-sm"
                  : "text-muted-foreground hover:text-white"
              }`}
              title="ماتریس جدول روابط"
            >
              <Layers className="h-3.5 w-3.5" />
              <span>ماتریس</span>
            </button>
            <button
              onClick={() => setLayoutMode("erd")}
              className={`flex items-center gap-1.5 rounded-sm px-2 sm:px-2.5 py-1 whitespace-nowrap transition-colors ${
                layoutMode === "erd"
                  ? "bg-brand font-medium text-ink shadow-sm"
                  : "text-muted-foreground hover:text-white"
              }`}
              title="کد متنی دیاگرام Mermaid ERD"
            >
              <Code className="h-3.5 w-3.5" />
              <span>ERD</span>
            </button>
          </div>

          {/* Orientation switch for Tree */}
          {layoutMode === "tree" && (
            <button
              onClick={() => setTreeOrientation(treeOrientation === "horizontal" ? "vertical" : "horizontal")}
              className="flex items-center gap-1 rounded-sm border border-brand/40 bg-brand/10 px-2 py-1 text-xs text-brand hover:bg-brand/20 transition-colors shrink-0"
              title={treeOrientation === "horizontal" ? "تغییر به چیدمان درختی عمودی (بهینه موبایل)" : "تغییر به چیدمان درختی افقی (دسکتاپ)"}
            >
              {treeOrientation === "horizontal" ? (
                <>
                  <SplitSquareVertical className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">درخت عمودی</span>
                  <span className="sm:hidden">عمودی</span>
                </>
              ) : (
                <>
                  <SplitSquareHorizontal className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">درخت افقی</span>
                  <span className="sm:hidden">افقی</span>
                </>
              )}
            </button>
          )}

          <Button
            size="sm"
            variant="ghost"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="h-7 w-7 p-0 shrink-0 text-muted-foreground hover:text-white"
            title={isFullscreen ? "خروج از تمام‌صفحه" : "نمایش تمام‌صفحه"}
          >
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* SUB-TOOLBAR: Filters & D3 Canvas Controls */}
      {totalRels > 0 && layoutMode !== "erd" && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-border/60 bg-surface/40 px-3 py-2 text-xs">
          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative w-full sm:w-44">
              <Search className="absolute right-2 top-2 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="فیلتر جدول یا فیلد…"
                className="h-7.5 w-full rounded-sm border-border bg-ink pe-2 ps-7 text-xs"
              />
            </div>

            {/* Type selector */}
            <div className="flex items-center gap-1 text-[11px] overflow-x-auto scrollbar-none py-0.5">
              <button
                onClick={() => setTypeFilter("ALL")}
                className={`rounded px-2 py-0.5 whitespace-nowrap transition-colors ${
                  typeFilter === "ALL" ? "bg-surfaceHover font-bold text-brand" : "text-muted-foreground hover:text-white"
                }`}
              >
                همه ({totalRels})
              </button>
              <button
                onClick={() => setTypeFilter("OUTGOING")}
                className={`rounded px-2 py-0.5 whitespace-nowrap transition-colors ${
                  typeFilter === "OUTGOING" ? "bg-surfaceHover font-bold text-emerald-400" : "text-muted-foreground hover:text-white"
                }`}
              >
                والد ({outgoing.length})
              </button>
              <button
                onClick={() => setTypeFilter("INCOMING")}
                className={`rounded px-2 py-0.5 whitespace-nowrap transition-colors ${
                  typeFilter === "INCOMING" ? "bg-surfaceHover font-bold text-sky-400" : "text-muted-foreground hover:text-white"
                }`}
              >
                فرزند ({incoming.length})
              </button>
            </div>

            {/* Schema Filter */}
            {availableSchemas.length > 2 && (
              <select
                value={schemaFilter}
                onChange={(e) => setSchemaFilter(e.target.value)}
                className="h-7 rounded-sm border border-border bg-ink px-2 text-[11px] text-slate-300 outline-none"
              >
                <option value="ALL">همه اسکیماها ({availableSchemas.length})</option>
                {availableSchemas.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* D3 Canvas Navigation Controls */}
          {layoutMode !== "matrix" && (
            <div className="flex items-center justify-end gap-1 shrink-0 pt-1 sm:pt-0 border-t border-border/30 sm:border-t-0">
              {layoutMode === "force" && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleTogglePhysics}
                  className="h-6 gap-1 px-1.5 text-[11px] text-muted-foreground hover:text-white"
                  title={isPhysicsRunning ? "توقف فیزیک" : "ادامه حرکت فیزیک"}
                >
                  {isPhysicsRunning ? <Pause className="h-3 w-3 text-amber-400" /> : <Play className="h-3 w-3 text-ok" />}
                  <span className="hidden sm:inline">{isPhysicsRunning ? "توقف فیزیک" : "حرکت"}</span>
                </Button>
              )}

              <Button
                size="sm"
                variant="ghost"
                onClick={handleFitToScreen}
                className="h-6 gap-1 px-1.5 text-[11px] text-muted-foreground hover:text-white"
                title="تنظیم دیاگرام با کادر صفحه (Fit to View)"
              >
                <Scan className="h-3.5 w-3.5 text-brand" />
                <span className="text-[11px]">انطباق</span>
              </Button>

              <Button
                size="sm"
                variant="ghost"
                onClick={handleZoomIn}
                className="h-6 w-6 p-0 text-muted-foreground hover:text-white"
                title="بزرگ‌نمایی (Zoom In)"
              >
                <ZoomIn className="h-3.5 w-3.5" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleZoomOut}
                className="h-6 w-6 p-0 text-muted-foreground hover:text-white"
                title="کوچک‌نمایی (Zoom Out)"
              >
                <ZoomOut className="h-3.5 w-3.5" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleResetZoom}
                className="h-6 px-1.5 text-[10px] font-mono text-muted-foreground hover:text-white"
                title="بازنشانی موقعیت به مرکز"
              >
                <RotateCcw className="mr-0.5 inline h-2.5 w-2.5" /> {zoomLevel}%
              </Button>
            </div>
          )}
        </div>
      )}

      {/* MAIN CONTENT AREA */}
      {totalRels === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 text-center text-sm text-muted-foreground">
          <Database className="mb-2 h-8 w-8 text-muted-foreground/40" />
          <p>هیچ رابطه یا کلید خارجی برای جدول «{table.full_name}» ثبت نشده است.</p>
          <p className="mt-1 text-xs text-muted-foreground/70">
            می‌توانید با دکمه «بهبود دانش» روابط جدید را برای این جدول ثبت و بازسازی نمایید.
          </p>
        </div>
      ) : layoutMode === "matrix" ? (
        /* TABLE / MATRIX VIEW */
        <div className="p-4">
          <div className="overflow-x-auto rounded-sm border border-border">
            <table className="w-full border-collapse text-xs" dir="rtl">
              <thead>
                <tr className="bg-surface text-muted-foreground">
                  <th className="border-b border-border px-3 py-2 text-start">نوع اتصال</th>
                  <th className="border-b border-border px-3 py-2 text-start">جدول مبدأ</th>
                  <th className="border-b border-border px-3 py-2 text-start">ستون مبدأ (FK)</th>
                  <th className="border-b border-border px-3 py-2 text-start">جدول مقصد</th>
                  <th className="border-b border-border px-3 py-2 text-start">ستون مقصد (PK/Ref)</th>
                  <th className="border-b border-border px-3 py-2 text-start">اعتبار</th>
                  <th className="border-b border-border px-3 py-2 text-start">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {filteredOutgoing.map((j, i) => (
                  <tr key={`out-${i}`} className="transition-colors hover:bg-surfaceHover">
                    <td className="border-b border-border px-3 py-2 font-semibold text-emerald-400">
                      والد (FK Outgoing)
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-slate-300">
                      {table.full_name}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono font-bold text-amber-400">
                      {j.from_col}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-brand">
                      {j.to_table}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-slate-300">
                      {j.to_col}
                    </td>
                    <td className="border-b border-border px-3 py-2">
                      {j.verified ? (
                        <span className="rounded bg-ok/15 px-1.5 py-0.5 text-[10px] text-ok">تأییدشده</span>
                      ) : (
                        <span className="rounded bg-warn/15 px-1.5 py-0.5 text-[10px] text-warn">استنتاجی</span>
                      )}
                    </td>
                    <td className="border-b border-border px-3 py-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => onSelectTable?.(j.to_table)}
                        className="h-6 gap-1 px-2 text-[11px] text-brand hover:bg-brand/10"
                      >
                        کاوش جدول <ArrowLeft className="h-3 w-3" />
                      </Button>
                    </td>
                  </tr>
                ))}

                {filteredIncoming.map((j, i) => (
                  <tr key={`inc-${i}`} className="transition-colors hover:bg-surfaceHover">
                    <td className="border-b border-border px-3 py-2 font-semibold text-sky-400">
                      فرزند (FK Incoming)
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-brand">
                      {j.from_table}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono font-bold text-sky-300">
                      {j.from_col}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-slate-300">
                      {table.full_name}
                    </td>
                    <td className="border-b border-border px-3 py-2 font-mono text-amber-400">
                      {j.to_col}
                    </td>
                    <td className="border-b border-border px-3 py-2">
                      {j.verified ? (
                        <span className="rounded bg-ok/15 px-1.5 py-0.5 text-[10px] text-ok">تأییک‌شده</span>
                      ) : (
                        <span className="rounded bg-warn/15 px-1.5 py-0.5 text-[10px] text-warn">استنتاجی</span>
                      )}
                    </td>
                    <td className="border-b border-border px-3 py-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => onSelectTable?.(j.from_table)}
                        className="h-6 gap-1 px-2 text-[11px] text-brand hover:bg-brand/10"
                      >
                        کاوش جدول <ArrowLeft className="h-3 w-3" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : layoutMode === "erd" ? (
        /* ERD CODE VIEW */
        <div className="space-y-3 p-4" style={{ direction: "ltr" }}>
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs text-muted-foreground">
              Mermaid Entity-Relationship Diagram Code
            </span>
            <Button
              size="sm"
              variant="outline"
              onClick={handleCopyErd}
              className="gap-1.5 rounded-sm border-border bg-surface text-xs"
            >
              {copiedErd ? <Check className="h-3.5 w-3.5 text-ok" /> : <Copy className="h-3.5 w-3.5" />}
              کپی کد دیاگرام
            </Button>
          </div>
          <pre className="overflow-x-auto rounded-sm border border-border bg-ink p-3 font-mono text-xs leading-5 text-slate-200">
            <code>{mermaidErd}</code>
          </pre>
        </div>
      ) : (
        /* D3 SVG CANVAS VIEW */
        <div
          className="relative flex-1 overflow-hidden select-none"
          style={{
            minHeight: isFullscreen ? "calc(100vh - 180px)" : (containerWidth < 640 ? "390px" : "480px"),
            height: isFullscreen ? "100%" : (containerWidth < 640 ? "400px" : "480px"),
          }}
        >
          <svg ref={svgRef} className="h-full w-full bg-[#050811] cursor-grab active:cursor-grabbing" />

          {/* Floating Canvas Reset & Quick Controls */}
          <div className="absolute top-2.5 start-2.5 flex items-center gap-1.5 z-20">
            <Button
              data-testid="d3-visualizer-reset-view-btn"
              variant="outline"
              size="sm"
              onClick={handleResetZoom}
              className="h-7 gap-1.5 rounded-md border-border/80 bg-ink/90 backdrop-blur px-2 text-xs font-semibold text-foreground hover:bg-brand hover:text-white shadow-md transition-all active:scale-95"
              title="بازنشانی بزرگ‌نمایی و موقعیت گره‌ها به مرکز (Reset View)"
            >
              <RotateCcw className="h-3 w-3 text-brand group-hover:text-white" />
              <span>بازنشانی نما</span>
            </Button>
          </div>

          {/* Canvas Guide Legend overlay */}
          <div className="pointer-events-none absolute bottom-2.5 right-2.5 max-w-[calc(100%-20px)] flex flex-wrap items-center gap-2 sm:gap-3 rounded bg-surface/90 px-2.5 py-1 sm:px-3 sm:py-1.5 text-[10px] sm:text-[11px] backdrop-blur border border-border/60 shadow-lg">
            <div className="flex items-center gap-1.5">
              <span className="inline-block h-2 w-2 rounded-full bg-emerald-400"></span>
              <span className="text-slate-300">والد (FK Out)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="inline-block h-2 w-2 rounded-full bg-sky-400"></span>
              <span className="text-slate-300">فرزند (FK In)</span>
            </div>
            <div className="hidden xs:flex items-center gap-1.5">
              <span className="inline-block h-0.5 w-3.5 bg-slate-400"></span>
              <span className="text-muted-foreground">تأییدشده</span>
            </div>
          </div>

          {/* Quick Node Details / Inspector Overlay */}
          {selectedNode && (
            <div className="fixed sm:absolute bottom-3 inset-x-3 sm:bottom-auto sm:inset-x-auto sm:left-3 sm:top-3 z-30 sm:w-72 max-h-[75vh] overflow-y-auto rounded-lg sm:rounded-sm border border-border bg-surface/98 p-3 shadow-2xl backdrop-blur ring-1 ring-border">
              <div className="flex items-center justify-between border-b border-border/50 pb-2">
                <span className="font-mono text-xs font-bold text-white truncate">
                  {selectedNode.full_name || selectedNode.id}
                </span>
                <button
                  onClick={() => setSelectedNode(null)}
                  className="text-xs text-muted-foreground hover:text-white p-1"
                >
                  ✕
                </button>
              </div>

              <div className="mt-2 space-y-1.5 text-xs">
                {selectedNode.direction ? (
                  <>
                    <div className="text-muted-foreground">جزئیات رابطه کلید خارجی:</div>
                    <div className="rounded bg-ink p-1.5 font-mono text-[11px] text-amber-400">
                      {selectedNode.from_col} → {selectedNode.to_col}
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">نوع ارتباط:</span>
                      <span className={selectedNode.type === "outgoing" ? "text-emerald-400 font-bold" : "text-sky-400 font-bold"}>
                        {selectedNode.type === "outgoing" ? "والد (FK Out)" : "فرزند (FK In)"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">نوع اطمینان:</span>
                      <span>{selectedNode.verified ? "تأییدشده ✓" : "استنتاجی ~"}</span>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => {
                        onSelectTable?.(selectedNode.id || selectedNode.full_name);
                        setSelectedNode(null);
                      }}
                      className="mt-2 w-full gap-1.5 bg-brand text-xs font-semibold text-ink hover:bg-brand/90"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      کاوش این جدول
                    </Button>
                  </>
                ) : (
                  <>
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">ماژول / اسکیما:</span>
                      <span className="font-mono font-bold text-brand">{selectedNode.schema}</span>
                    </div>
                    {selectedNode.type !== "center" && (
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-muted-foreground">نقش ارتباطی:</span>
                        <span className={selectedNode.type === "outgoing" ? "text-emerald-400" : "text-sky-400"}>
                          {selectedNode.type === "outgoing" ? "جدول مقصد (والد)" : "جدول ارجاع‌دهنده (فرزند)"}
                        </span>
                      </div>
                    )}
                    {selectedNode.type !== "center" && (
                      <Button
                        size="sm"
                        onClick={() => {
                          onSelectTable?.(selectedNode.full_name || selectedNode.id);
                          setSelectedNode(null);
                        }}
                        className="mt-2 w-full gap-1.5 bg-brand text-xs font-semibold text-ink hover:bg-brand/90"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        مشاهده و کاوش این جدول
                      </Button>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
