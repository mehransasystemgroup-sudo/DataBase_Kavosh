import React, { useEffect, useRef, useState, useMemo, useCallback } from "react";
import * as d3 from "d3";
import { http } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import InspectorRelationshipGraph from "./InspectorRelationshipGraph";
import {
  Network,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Maximize2,
  Minimize2,
  Search,
  KeyRound,
  Database,
  ExternalLink,
  Play,
  Pause,
  Filter,
  Layers,
  Sparkles,
  Link2,
  Table2,
  Check,
  Copy,
  Info,
  Layers2,
  RefreshCw,
  Eye,
  SlidersHorizontal,
  FolderTree,
  ChevronRight,
  ChevronLeft,
  X,
  Radio,
  Share2,
} from "lucide-react";

// Distinct color palettes for ERP schemas
const SCHEMA_ACCENTS = {
  FIN3: { primary: "#10b981", bg: "#064e3b", light: "#d1fae5", border: "rgba(16, 185, 129, 0.4)", label: "مالی (FIN3)" },
  GNR3: { primary: "#38bdf8", bg: "#0c4a6e", light: "#e0f2fe", border: "rgba(56, 189, 248, 0.4)", label: "عمومی (GNR3)" },
  ACC: { primary: "#06b6d4", bg: "#164e63", light: "#cffafe", border: "rgba(6, 182, 212, 0.4)", label: "حسابداری (ACC)" },
  HCM3: { primary: "#c084fc", bg: "#581c87", light: "#f3e8ff", border: "rgba(192, 132, 252, 0.4)", label: "پرسنلی (HCM3)" },
  RPA3: { primary: "#fbbf24", bg: "#78350f", light: "#fef3c7", border: "rgba(251, 191, 36, 0.4)", label: "دریافت/پرداخت (RPA3)" },
  LGS3: { primary: "#818cf8", bg: "#312e81", light: "#e0e7ff", border: "rgba(129, 140, 248, 0.4)", label: "لجستیک (LGS3)" },
  MMG3: { primary: "#f59e0b", bg: "#78350f", light: "#fef3c7", border: "rgba(245, 158, 11, 0.4)", label: "انبار (MMG3)" },
  SLS3: { primary: "#14b8a6", bg: "#134e4a", light: "#ccfbf1", border: "rgba(20, 184, 166, 0.4)", label: "فروش (SLS3)" },
  BDG3: { primary: "#f472b6", bg: "#831843", light: "#fce7f3", border: "rgba(244, 114, 182, 0.4)", label: "بودجه (BDG3)" },
  FMK: { primary: "#2dd4bf", bg: "#134e4a", light: "#ccfbf1", border: "rgba(45, 212, 191, 0.4)", label: "فریم‌ورک (FMK)" },
  DEFAULT: { primary: "#60a5fa", bg: "#1e3a8a", light: "#dbeafe", border: "rgba(96, 165, 250, 0.4)", label: "سایر اسکیماها" },
};

function getSchemaAccent(schemaName) {
  return SCHEMA_ACCENTS[schemaName] || SCHEMA_ACCENTS.DEFAULT;
}

export default function SchemaNodeGraph({
  initialSchema = "ACC",
  onSelectTable,
  height = "600px",
  embedded = false,
}) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const zoomBehaviorRef = useRef(null);
  const simulationRef = useRef(null);

  // States
  const [currentSchema, setCurrentSchema] = useState(initialSchema || "ACC");
  const [availableSchemas, setAvailableSchemas] = useState([]);
  const [graphData, setGraphData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters & Controls
  const [searchQuery, setSearchQuery] = useState("");
  const [includeExternal, setIncludeExternal] = useState(true);
  const [onlyWithData, setOnlyWithData] = useState(false);
  const [minDegree, setMinDegree] = useState(0); // 0 = all, 1 = connected, 2 = hubs
  const [layoutMode, setLayoutMode] = useState("force"); // "force" | "radial" | "cluster"
  const [isPhysicsRunning, setIsPhysicsRunning] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Selection & Details
  const [selectedNode, setSelectedNode] = useState(null);
  const [hoveredNode, setHoveredNode] = useState(null);
  const [selectedLink, setSelectedLink] = useState(null);
  const [copiedQuery, setCopiedQuery] = useState(false);
  const [showInspector, setShowInspector] = useState(true);
  const [inspectorTab, setInspectorTab] = useState("graph"); // "graph" | "columns" | "neighbors"

  // Handler for selecting node from inside Inspector D3 Graph
  const handleInspectorSelectTable = useCallback((tblName) => {
    if (!tblName) return;
    const found = (graphData?.nodes || []).find((n) => n.id === tblName || n.full_name === tblName);
    if (found) {
      setSelectedNode(found);
    } else {
      const schema = tblName.split(".")[0];
      const name = tblName.split(".").slice(1).join(".") || tblName;
      setSelectedNode({
        id: tblName,
        name,
        full_name: tblName,
        schema,
        n_cols: 0,
        degree: 1,
        has_data: true,
      });
    }
  }, [graphData]);

  // Update currentSchema if prop changes
  useEffect(() => {
    if (initialSchema && initialSchema !== currentSchema) {
      setCurrentSchema(initialSchema);
    }
  }, [initialSchema]);

  // Load available schemas list
  useEffect(() => {
    http.get("/schemas")
      .then(({ data }) => {
        if (data.schemas) {
          setAvailableSchemas(data.schemas);
        }
      })
      .catch(() => {});
  }, []);

  // Fetch graph data for current schema and filters
  const fetchGraph = useCallback(async () => {
    if (!currentSchema) return;
    setLoading(true);
    setError(null);
    try {
      const { data } = await http.get(`/schema/${encodeURIComponent(currentSchema)}/graph`, {
        params: {
          includeExternal,
          onlyWithData,
          maxNodes: 75,
        },
      });
      setGraphData(data);
      setSelectedNode(null);
      setSelectedLink(null);
    } catch (err) {
      const msg = err.response?.data?.detail || err.message || "خطا در بارگذاری گراف اسکیما";
      setError(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }, [currentSchema, includeExternal, onlyWithData]);

  useEffect(() => {
    fetchGraph();
  }, [fetchGraph]);

  // Filter nodes & links based on search and minDegree
  const filteredData = useMemo(() => {
    if (!graphData || !graphData.nodes) return { nodes: [], links: [] };

    let nodes = [...graphData.nodes];

    // Filter by min degree
    if (minDegree > 0) {
      nodes = nodes.filter((n) => n.degree >= minDegree);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      nodes = nodes.filter(
        (n) =>
          n.name.toLowerCase().includes(q) ||
          n.full_name.toLowerCase().includes(q) ||
          (n.title_fa && n.title_fa.toLowerCase().includes(q))
      );
    }

    const nodeIds = new Set(nodes.map((n) => n.id));
    const links = (graphData.links || []).filter((l) => {
      const srcId = typeof l.source === "object" ? l.source.id : l.source;
      const tgtId = typeof l.target === "object" ? l.target.id : l.target;
      return nodeIds.has(srcId) && nodeIds.has(tgtId);
    });

    return { nodes, links };
  }, [graphData, minDegree, searchQuery]);

  // Build direct neighbor connections map for selected or hovered node
  const neighborSet = useMemo(() => {
    const active = hoveredNode || selectedNode;
    if (!active || !filteredData.links) return null;

    const set = new Set();
    set.add(active.id);

    filteredData.links.forEach((l) => {
      const sId = typeof l.source === "object" ? l.source.id : l.source;
      const tId = typeof l.target === "object" ? l.target.id : l.target;
      if (sId === active.id) set.add(tId);
      if (tId === active.id) set.add(sId);
    });

    return set;
  }, [hoveredNode, selectedNode, filteredData.links]);

  // Render D3 Graph
  useEffect(() => {
    if (!svgRef.current || !filteredData.nodes || filteredData.nodes.length === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const container = containerRef.current;
    const width = container?.clientWidth || 900;
    const heightVal = container?.clientHeight || 600;

    // Define defs & markers for arrows
    const defs = svg.append("defs");

    // Arrow markers
    defs
      .append("marker")
      .attr("id", "arrow-intra")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 22)
      .attr("refY", 0)
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-5L10,0L0,5")
      .attr("fill", "#0284c7");

    defs
      .append("marker")
      .attr("id", "arrow-cross")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 22)
      .attr("refY", 0)
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-5L10,0L0,5")
      .attr("fill", "#f59e0b");

    defs
      .append("marker")
      .attr("id", "arrow-highlight")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 22)
      .attr("refY", 0)
      .attr("markerWidth", 7)
      .attr("markerHeight", 7)
      .attr("orient", "auto")
      .append("path")
      .attr("d", "M0,-5L10,0L0,5")
      .attr("fill", "#38bdf8");

    // Glow filter for highlighted nodes
    const filter = defs.append("filter").attr("id", "glow").attr("x", "-20%").attr("y", "-20%").attr("width", "140%").attr("height", "140%");
    filter.append("feGaussianBlur").attr("stdDeviation", "4").attr("result", "blur");
    filter.append("feComposite").attr("in", "SourceGraphic").attr("in2", "blur").attr("operator", "over");

    // Graph Root Group for Pan & Zoom
    const g = svg.append("g").attr("class", "graph-content");

    // Setup Zoom Behavior
    const zoom = d3
      .zoom()
      .scaleExtent([0.2, 3])
      .on("zoom", (event) => {
        g.attr("transform", event.transform);
      });

    svg.call(zoom);
    zoomBehaviorRef.current = { zoom, svg, g, width, heightVal };

    // Initial transform centered
    svg.call(zoom.transform, d3.zoomIdentity.translate(width / 2, heightVal / 2).scale(0.85));

    // Deep copy nodes and links for simulation
    const nodes = filteredData.nodes.map((d) => ({ ...d }));
    const links = filteredData.links.map((d) => ({ ...d }));

    // Simulation
    const simulation = d3
      .forceSimulation(nodes)
      .force(
        "link",
        d3
          .forceLink(links)
          .id((d) => d.id)
          .distance((d) => (d.isCrossSchema ? 170 : 130))
          .strength((d) => (d.isCrossSchema ? 0.35 : 0.6))
      )
      .force("charge", d3.forceManyBody().strength(-420).distanceMax(600))
      .force("collision", d3.forceCollide().radius((d) => Math.max(48, Math.min(75, 42 + d.degree * 3))))
      .force("center", d3.forceCenter(0, 0).strength(0.08))
      .force("x", d3.forceX(0).strength(0.05))
      .force("y", d3.forceY(0).strength(0.05));

    simulationRef.current = simulation;

    // Apply Radial layout positions if selected
    if (layoutMode === "radial") {
      const radiusStep = 130;
      const sortedByDegree = [...nodes].sort((a, b) => b.degree - a.degree);
      sortedByDegree.forEach((node, idx) => {
        const ring = Math.floor(idx / 10);
        const angle = ((idx % 10) / 10) * 2 * Math.PI;
        const r = (ring + 1) * radiusStep;
        node.fx = Math.cos(angle) * r;
        node.fy = Math.sin(angle) * r;
      });
    } else if (layoutMode === "cluster") {
      nodes.forEach((node) => {
        const targetX = node.isCore ? -180 : 220;
        node.fx = targetX + (Math.random() - 0.5) * 120;
      });
    }

    // Links container
    const linkGroup = g.append("g").attr("class", "links-layer");

    const link = linkGroup
      .selectAll(".schema-link")
      .data(links)
      .enter()
      .append("path")
      .attr("class", "schema-link")
      .attr("stroke", (d) => (d.isCrossSchema ? "#f59e0b" : "#0284c7"))
      .attr("stroke-width", (d) => (d.verified ? 1.8 : 1.2))
      .attr("stroke-dasharray", (d) => (d.verified ? null : "4,3"))
      .attr("stroke-opacity", 0.65)
      .attr("fill", "none")
      .attr("marker-end", (d) => (d.isCrossSchema ? "url(#arrow-cross)" : "url(#arrow-intra)"))
      .style("cursor", "pointer")
      .on("click", (event, d) => {
        event.stopPropagation();
        setSelectedLink(d);
        toast.info(`ارتباط: ${d.from_col} ➔ ${d.to_col}`);
      });

    // Nodes container
    const nodeGroup = g.append("g").attr("class", "nodes-layer");

    // Drag behavior
    const drag = d3
      .drag()
      .on("start", (event, d) => {
        if (!event.active && isPhysicsRunning) simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
      })
      .on("drag", (event, d) => {
        d.fx = event.x;
        d.fy = event.y;
      })
      .on("end", (event, d) => {
        if (!event.active && isPhysicsRunning) simulation.alphaTarget(0);
        if (layoutMode === "force") {
          d.fx = null;
          d.fy = null;
        }
      });

    const node = nodeGroup
      .selectAll(".schema-node")
      .data(nodes)
      .enter()
      .append("g")
      .attr("class", "schema-node")
      .style("cursor", "grab")
      .call(drag)
      .on("click", (event, d) => {
        event.stopPropagation();
        setSelectedNode(d);
        setSelectedLink(null);
      })
      .on("mouseenter", (event, d) => {
        setHoveredNode(d);
      })
      .on("mouseleave", () => {
        setHoveredNode(null);
      });

    // Node card background
    node
      .append("rect")
      .attr("class", "node-card-bg")
      .attr("x", (d) => -Math.max(55, Math.min(85, 50 + d.name.length * 3.5)))
      .attr("y", -24)
      .attr("width", (d) => Math.max(110, Math.min(170, 100 + d.name.length * 7)))
      .attr("height", 48)
      .attr("rx", 6)
      .attr("ry", 6)
      .attr("fill", (d) => (d.isCore ? "#0f172a" : "#1e1b4b"))
      .attr("stroke", (d) => {
        const accent = getSchemaAccent(d.schema);
        return d.isCore ? accent.primary : "#818cf8";
      })
      .attr("stroke-width", (d) => (d.degree >= 3 ? 2.2 : 1.4))
      .attr("filter", "drop-shadow(0 2px 4px rgba(0,0,0,0.3))");

    // Node top schema badge bar
    node
      .append("rect")
      .attr("x", (d) => -Math.max(55, Math.min(85, 50 + d.name.length * 3.5)))
      .attr("y", -24)
      .attr("width", 6)
      .attr("height", 48)
      .attr("rx", 3)
      .attr("fill", (d) => getSchemaAccent(d.schema).primary);

    // Node Table Name text
    node
      .append("text")
      .attr("class", "node-name")
      .attr("x", -8)
      .attr("y", -6)
      .attr("text-anchor", "middle")
      .attr("fill", "#f8fafc")
      .attr("font-family", "ui-monospace, monospace")
      .attr("font-size", "11px")
      .attr("font-weight", "bold")
      .text((d) => {
        const maxLen = 16;
        return d.name.length > maxLen ? d.name.slice(0, maxLen - 1) + "…" : d.name;
      });

    // Node Persian title or schema subtext
    node
      .append("text")
      .attr("class", "node-subtext")
      .attr("x", -8)
      .attr("y", 12)
      .attr("text-anchor", "middle")
      .attr("fill", (d) => (d.isCore ? "#94a3b8" : "#a5b4fc"))
      .attr("font-size", "9.5px")
      .text((d) => {
        if (d.title_fa) {
          const maxFa = 16;
          return d.title_fa.length > maxFa ? d.title_fa.slice(0, maxFa) + "…" : d.title_fa;
        }
        return `${d.schema} · ${d.n_cols} ستون`;
      });

    // Node Connection Degree Badge (circle in top-right)
    const badgeG = node.append("g").attr("class", "node-badge-g");

    badgeG
      .append("circle")
      .attr("cx", (d) => Math.max(55, Math.min(85, 50 + d.name.length * 3.5)) - 8)
      .attr("cy", -14)
      .attr("r", 9)
      .attr("fill", (d) => {
        if (d.degree >= 4) return "#ef4444";
        if (d.degree >= 2) return "#0284c7";
        return "#334155";
      })
      .attr("stroke", "#0f172a")
      .attr("stroke-width", 1.5);

    badgeG
      .append("text")
      .attr("cx", (d) => Math.max(55, Math.min(85, 50 + d.name.length * 3.5)) - 8)
      .attr("cy", -10.5)
      .attr("x", (d) => Math.max(55, Math.min(85, 50 + d.name.length * 3.5)) - 8)
      .attr("y", -11)
      .attr("text-anchor", "middle")
      .attr("dominant-baseline", "central")
      .attr("fill", "#ffffff")
      .attr("font-size", "8.5px")
      .attr("font-weight", "bold")
      .attr("font-family", "ui-monospace, monospace")
      .text((d) => d.degree);

    // Node Data status indicator (small dot in bottom-right)
    node
      .append("circle")
      .attr("cx", (d) => Math.max(55, Math.min(85, 50 + d.name.length * 3.5)) - 8)
      .attr("cy", 12)
      .attr("r", 3.5)
      .attr("fill", (d) => (d.has_data ? "#10b981" : "#64748b"))
      .attr("title", (d) => (d.has_data ? "دارای رکورد" : "بدون داده"));

    // Simulation tick handler
    simulation.on("tick", () => {
      link.attr("d", (d) => {
        const dx = d.target.x - d.source.x;
        const dy = d.target.y - d.source.y;
        const dr = Math.sqrt(dx * dx + dy * dy) * 1.3;
        return `M${d.source.x},${d.source.y}A${dr},${dr} 0 0,1 ${d.target.x},${d.target.y}`;
      });

      node.attr("transform", (d) => `translate(${d.x},${d.y})`);
    });

    return () => {
      simulation.stop();
    };
  }, [filteredData, layoutMode, isPhysicsRunning]);

  // Update styles for neighbor highlighting
  useEffect(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);

    const active = hoveredNode || selectedNode;

    if (!active) {
      svg.selectAll(".schema-node").style("opacity", 1);
      svg.selectAll(".schema-link").style("opacity", 0.65).attr("stroke-width", 1.5);
      return;
    }

    // Dim or highlight nodes
    svg.selectAll(".schema-node").style("opacity", (d) => {
      if (d.id === active.id) return 1;
      return neighborSet?.has(d.id) ? 0.95 : 0.2;
    });

    // Dim or highlight links
    svg.selectAll(".schema-link").each(function (d) {
      const sId = typeof d.source === "object" ? d.source.id : d.source;
      const tId = typeof d.target === "object" ? d.target.id : d.target;
      const isConnected = sId === active.id || tId === active.id;

      d3.select(this)
        .style("opacity", isConnected ? 1 : 0.08)
        .attr("stroke-width", isConnected ? 2.5 : 1)
        .attr("marker-end", isConnected ? "url(#arrow-highlight)" : d.isCrossSchema ? "url(#arrow-cross)" : "url(#arrow-intra)");
    });
  }, [hoveredNode, selectedNode, neighborSet]);

  // Zoom & View controls helpers
  const handleZoom = (direction) => {
    if (!zoomBehaviorRef.current) return;
    const { zoom, svg } = zoomBehaviorRef.current;
    if (direction === "in") svg.transition().duration(250).call(zoom.scaleBy, 1.25);
    else if (direction === "out") svg.transition().duration(250).call(zoom.scaleBy, 0.8);
    else if (direction === "reset") {
      handleResetView();
    }
  };

  // Reset view: restores initial zoom scale, centers viewport and relaxes node layout
  const handleResetView = () => {
    if (!zoomBehaviorRef.current) return;
    const { zoom, svg, width, heightVal } = zoomBehaviorRef.current;

    // 1. Reset zoom and pan with smooth animation to center
    svg
      .transition()
      .duration(400)
      .call(zoom.transform, d3.zoomIdentity.translate(width / 2, heightVal / 2).scale(0.85));

    // 2. Unpin manually dragged nodes and restore centered layout
    if (simulationRef.current) {
      const nodes = simulationRef.current.nodes();
      if (layoutMode === "force") {
        nodes.forEach((n) => {
          n.fx = null;
          n.fy = null;
        });
      } else if (layoutMode === "radial") {
        const radiusStep = 130;
        const sortedByDegree = [...nodes].sort((a, b) => b.degree - a.degree);
        sortedByDegree.forEach((node, idx) => {
          const ring = Math.floor(idx / 10);
          const angle = ((idx % 10) / 10) * 2 * Math.PI;
          const r = (ring + 1) * radiusStep;
          node.fx = Math.cos(angle) * r;
          node.fy = Math.sin(angle) * r;
        });
      } else if (layoutMode === "cluster") {
        nodes.forEach((node) => {
          const targetX = node.isCore ? -180 : 220;
          node.fx = targetX;
        });
      }

      // Re-heat simulation to settle nodes smoothly back to center
      simulationRef.current.alpha(0.4).restart();
      setIsPhysicsRunning(true);
    }

    toast.success("موقعیت نما و چیدمان گره‌ها بازنشانی شد");
  };

  const togglePhysics = () => {
    if (!simulationRef.current) return;
    if (isPhysicsRunning) {
      simulationRef.current.stop();
      setIsPhysicsRunning(false);
      toast.info("شبیه‌سازی فیزیک متوقف شد");
    } else {
      simulationRef.current.alpha(0.3).restart();
      setIsPhysicsRunning(true);
      toast.info("شبیه‌سازی فیزیک فعال شد");
    }
  };

  const handleCopyQuery = async (node) => {
    if (!node) return;
    const pk = node.primary_key?.[0] || "*";
    const sql = `SELECT TOP 50 *\nFROM ${node.full_name}\nORDER BY 1 DESC;`;
    await navigator.clipboard.writeText(sql);
    setCopiedQuery(true);
    toast.success("کوئری آزمایشی T-SQL کپی شد");
    setTimeout(() => setCopiedQuery(false), 2000);
  };

  const currentAccent = getSchemaAccent(currentSchema);

  return (
    <div
      ref={containerRef}
      className={`relative flex flex-col rounded-md border border-border bg-surface overflow-hidden ${
        isFullscreen ? "fixed inset-2 z-50 shadow-2xl" : ""
      }`}
      style={{ height: isFullscreen ? "auto" : height }}
    >
      {/* Top Header & Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border/80 bg-ink/70 p-2.5 sm:px-4">
        {/* Left: Schema Selector & Info */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2">
            <div
              className="flex h-7 w-7 items-center justify-center rounded-sm border shadow-sm"
              style={{
                borderColor: currentAccent.border,
                backgroundColor: currentAccent.bg + "30",
                color: currentAccent.primary,
              }}
            >
              <Network className="h-4 w-4" />
            </div>

            {/* Schema Selector Dropdown */}
            <div className="flex items-center gap-1.5">
              <label className="text-xs font-medium text-muted-foreground hidden sm:inline">اسکیما:</label>
              <select
                data-testid="schema-graph-select"
                value={currentSchema}
                onChange={(e) => setCurrentSchema(e.target.value)}
                className="h-8 rounded-sm border border-border bg-surface px-2.5 font-mono text-xs font-bold text-foreground focus:border-brand focus:outline-none"
              >
                {availableSchemas.map((s) => (
                  <option key={s.schema} value={s.schema}>
                    {s.schema} ({s.tableCount} جدول · {s.relationshipsCount} اتصال)
                  </option>
                ))}
                {availableSchemas.length === 0 && (
                  <option value={currentSchema}>{currentSchema}</option>
                )}
              </select>
            </div>
          </div>

          {/* Schema Stats Badges */}
          {graphData?.stats && (
            <div className="hidden lg:flex items-center gap-2 font-mono text-[11px] text-muted-foreground">
              <span className="rounded-sm bg-surface px-1.5 py-0.5 border border-border">
                <b className="text-foreground">{filteredData.nodes.length}</b> گره جدول
              </span>
              <span className="rounded-sm bg-surface px-1.5 py-0.5 border border-border">
                <b className="text-foreground">{filteredData.links.length}</b> اتصال کلید خارجی
              </span>
              {graphData.stats.crossSchemaLinksCount > 0 && (
                <span className="rounded-sm bg-amber-500/15 text-amber-300 px-1.5 py-0.5 border border-amber-500/30">
                  {graphData.stats.crossSchemaLinksCount} بین‌اسکیمایی
                </span>
              )}
            </div>
          )}
        </div>

        {/* Right: Quick Search & Layout Controls */}
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Quick Search */}
          <div className="relative">
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="فیلتر نام جدول در گراف…"
              className="h-7 w-36 sm:w-44 rounded-sm border-border bg-surface text-xs placeholder:text-muted-foreground pe-6"
            />
            {searchQuery ? (
              <button
                type="button"
                onClick={() => setSearchQuery("")}
                className="absolute end-1.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="h-3 w-3" />
              </button>
            ) : (
              <Search className="absolute end-1.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
            )}
          </div>

          {/* Layout Mode Selector */}
          <div className="hidden sm:flex items-center rounded-sm border border-border bg-surface p-0.5">
            <button
              type="button"
              onClick={() => setLayoutMode("force")}
              className={`rounded-sm px-2 py-1 text-[10px] font-medium transition-colors ${
                layoutMode === "force" ? "bg-brand text-white" : "text-muted-foreground hover:text-foreground"
              }`}
              title="چینش آزاد بر پایه فیزیک D3"
            >
              دینامیک
            </button>
            <button
              type="button"
              onClick={() => setLayoutMode("radial")}
              className={`rounded-sm px-2 py-1 text-[10px] font-medium transition-colors ${
                layoutMode === "radial" ? "bg-brand text-white" : "text-muted-foreground hover:text-foreground"
              }`}
              title="چینش دوار بر اساس مرکزیت گره‌ها"
            >
              شعاعی
            </button>
            <button
              type="button"
              onClick={() => setLayoutMode("cluster")}
              className={`rounded-sm px-2 py-1 text-[10px] font-medium transition-colors ${
                layoutMode === "cluster" ? "bg-brand text-white" : "text-muted-foreground hover:text-foreground"
              }`}
              title="چینش خوشه‌ای داخلی و خارجی"
            >
              خوشه‌ای
            </button>
          </div>

          {/* Zoom & Fit Buttons */}
          <div className="flex items-center gap-0.5 rounded-sm border border-border bg-surface p-0.5">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleZoom("in")}
              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
              title="بزرگ‌نمایی (+)"
            >
              <ZoomIn className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleZoom("out")}
              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
              title="کوچک‌نمایی (-)"
            >
              <ZoomOut className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleZoom("reset")}
              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
              title="بازنشانی موقعیت نما"
            >
              <RotateCcw className="h-3 w-3" />
            </Button>
          </div>

          {/* Play/Pause Physics */}
          <Button
            variant="outline"
            size="sm"
            onClick={togglePhysics}
            className="h-7 w-7 p-0 border-border bg-surface text-muted-foreground hover:text-foreground"
            title={isPhysicsRunning ? "توقف فیزیک" : "ادامه فیزیک"}
          >
            {isPhysicsRunning ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
          </Button>

          {/* Inspector Panel Toggle Button */}
          <Button
            data-testid="toggle-inspector-btn"
            variant={showInspector ? "default" : "outline"}
            size="sm"
            onClick={() => setShowInspector(!showInspector)}
            className={`h-7 px-2 text-xs gap-1 font-semibold transition-all ${
              showInspector
                ? "bg-brand text-white hover:bg-brand/90"
                : "border-border bg-surface text-muted-foreground hover:text-foreground"
            }`}
            title="تغییر وضعیت نمایش پنل بازرسی (Insp)"
          >
            <SlidersHorizontal className="h-3 w-3" />
            <span>Insp</span>
            {selectedNode && (
              <span className="h-1.5 w-1.5 rounded-full bg-amber-400" />
            )}
          </Button>

          {/* Fullscreen Toggle */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="h-7 w-7 p-0 border-border bg-surface text-muted-foreground hover:text-foreground"
            title={isFullscreen ? "خروج از تمام‌صفحه" : "تمام‌صفحه"}
          >
            {isFullscreen ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
          </Button>
        </div>
      </div>

      {/* Filter Options Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 bg-ink/40 px-3 py-1.5 text-xs text-muted-foreground">
        <div className="flex flex-wrap items-center gap-4">
          {/* Include External Tables */}
          <label className="flex items-center gap-1.5 cursor-pointer select-none">
            <Switch checked={includeExternal} onCheckedChange={setIncludeExternal} className="scale-75" />
            <span className="text-[11px]">نمایش جداول مرتبط خارجی</span>
          </label>

          {/* Only with Data */}
          <label className="flex items-center gap-1.5 cursor-pointer select-none">
            <Switch checked={onlyWithData} onCheckedChange={setOnlyWithData} className="scale-75" />
            <span className="text-[11px]">فقط جدول‌های دارای داده</span>
          </label>

          {/* Minimum Degree Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px]">حداقل اتصالات:</span>
            <select
              value={minDegree}
              onChange={(e) => setMinDegree(Number(e.target.value))}
              className="h-6 rounded border border-border bg-surface px-1.5 text-[10px] text-foreground focus:outline-none"
            >
              <option value={0}>همه جدول‌ها</option>
              <option value={1}>حداقل ۱ اتصال (متصل)</option>
              <option value={2}>حداقل ۲ اتصال</option>
              <option value={3}>هاب‌های اصلی (۳+)</option>
            </select>
          </div>
        </div>

        {/* Legend */}
        <div className="hidden md:flex items-center gap-3 text-[10px]">
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-brand" /> درون اسکیما
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-amber-400" /> بین‌اسکیمایی
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-emerald-400" /> دارای داده
          </span>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="relative flex-1 min-h-0 bg-[#080d1a] overflow-hidden">
        {/* Loading Spinner */}
        {loading && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-ink/80 backdrop-blur-sm gap-2">
            <RefreshCw className="h-6 w-6 animate-spin text-brand" />
            <span className="text-xs text-muted-foreground font-medium">در حال ترسیم گراف روابط اسکیما {currentSchema}…</span>
          </div>
        )}

        {/* Error Message */}
        {error && !loading && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 p-6 text-center">
            <div className="rounded-sm border border-err/40 bg-err/10 p-3 text-xs text-err max-w-md">
              {error}
            </div>
            <Button size="sm" onClick={fetchGraph} className="gap-1.5 rounded-sm bg-brand text-xs">
              <RefreshCw className="h-3.5 w-3.5" />
              تلاش دوباره
            </Button>
          </div>
        )}

        {/* Empty State */}
        {!loading && !error && filteredData.nodes.length === 0 && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 text-center text-muted-foreground p-4">
            <Table2 className="h-8 w-8 text-muted-foreground/40" />
            <p className="text-xs">هیچ جدولی منطبق بر فیلترهای جاری در اسکیما یافت نشد.</p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSearchQuery("");
                setMinDegree(0);
                setOnlyWithData(false);
                setIncludeExternal(true);
              }}
              className="text-xs h-7 mt-1 border-border"
            >
              پاک‌کردن فیلترها
            </Button>
          </div>
        )}

        {/* SVG Canvas */}
        <svg
          ref={svgRef}
          className="w-full h-full select-none"
          style={{ cursor: "crosshair" }}
          onClick={() => {
            setSelectedNode(null);
            setSelectedLink(null);
          }}
        />

        {/* Floating Reset View & Canvas Controls in Graph Area */}
        <div className="absolute start-3 bottom-3 flex items-center gap-1.5 z-20">
          <Button
            data-testid="reset-view-graph-btn"
            variant="outline"
            size="sm"
            onClick={handleResetView}
            className="h-7 gap-1.5 rounded-md border-border/80 bg-ink/90 backdrop-blur-md px-2.5 text-xs font-semibold text-foreground hover:bg-brand hover:text-white shadow-lg transition-all active:scale-95"
            title="بازنشانی بزرگ‌نمایی و موقعیت گره‌ها به مرکز (Reset View)"
          >
            <RotateCcw className="h-3.5 w-3.5 text-brand group-hover:text-white" />
            <span>بازنشانی نما</span>
          </Button>

          <div className="flex items-center gap-0.5 rounded-md border border-border/80 bg-ink/90 backdrop-blur-md p-0.5 shadow-lg">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleZoom("in")}
              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
              title="بزرگ‌نمایی (+)"
            >
              <ZoomIn className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleZoom("out")}
              className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
              title="کوچک‌نمایی (-)"
            >
              <ZoomOut className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {/* Selected Node Details Drawer / Inspector */}
        {selectedNode && showInspector && (
          <div
            data-testid="schema-node-inspector"
            className="absolute end-3 top-3 bottom-3 w-80 sm:w-96 rounded-md border border-border bg-ink/95 backdrop-blur-md p-4 shadow-xl z-30 flex flex-col justify-between overflow-hidden animate-in fade-in slide-in-from-end duration-200"
          >
            <div className="space-y-3 overflow-y-auto pe-1">
              {/* Header */}
              <div className="flex items-start justify-between border-b border-border/80 pb-2.5">
                <div>
                  <div className="flex items-center gap-1.5 font-mono text-xs font-bold text-foreground">
                    <span
                      className="px-1.5 py-0.2 rounded-sm text-[10px]"
                      style={{
                        backgroundColor: getSchemaAccent(selectedNode.schema).bg,
                        color: getSchemaAccent(selectedNode.schema).primary,
                      }}
                    >
                      {selectedNode.schema}
                    </span>
                    <span className="text-brand">{selectedNode.name}</span>
                  </div>
                  {selectedNode.title_fa && (
                    <div className="mt-1 text-xs font-medium text-foreground">{selectedNode.title_fa}</div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedNode(null)}
                  className="rounded p-1 text-muted-foreground hover:bg-surface hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Badges / Stats */}
              <div className="grid grid-cols-3 gap-1.5 text-center font-mono text-xs">
                <div className="rounded border border-border bg-surface/60 p-1.5">
                  <div className="text-[10px] text-muted-foreground">ستون‌ها</div>
                  <div className="font-bold text-foreground">{selectedNode.n_cols}</div>
                </div>
                <div className="rounded border border-border bg-surface/60 p-1.5">
                  <div className="text-[10px] text-muted-foreground">اتصالات</div>
                  <div className="font-bold text-brand">{selectedNode.degree}</div>
                </div>
                <div className="rounded border border-border bg-surface/60 p-1.5">
                  <div className="text-[10px] text-muted-foreground">وضعیت داده</div>
                  <div className={`font-bold ${selectedNode.has_data ? "text-ok" : "text-muted-foreground"}`}>
                    {selectedNode.has_data ? "دارای داده" : "خالی"}
                  </div>
                </div>
              </div>

              {/* Inspector Section Switcher Tabs */}
              <div className="flex items-center gap-1 rounded-sm border border-border bg-surface p-0.5 text-[10px]">
                <button
                  type="button"
                  onClick={() => setInspectorTab("graph")}
                  className={`flex-1 flex items-center justify-center gap-1 py-1 rounded-sm font-medium transition-colors ${
                    inspectorTab === "graph"
                      ? "bg-brand text-white shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  title="نمایش گراف تعاملی D3 روابط این جدول"
                >
                  <Link2 className="h-3 w-3" />
                  <span>گراف روابط D3</span>
                </button>
                <button
                  type="button"
                  onClick={() => setInspectorTab("columns")}
                  className={`flex-1 flex items-center justify-center gap-1 py-1 rounded-sm font-medium transition-colors ${
                    inspectorTab === "columns"
                      ? "bg-brand text-white shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  title="نمایش ستون‌ها و کلید اصلی"
                >
                  <KeyRound className="h-3 w-3" />
                  <span>ستون‌ها</span>
                </button>
                <button
                  type="button"
                  onClick={() => setInspectorTab("neighbors")}
                  className={`flex-1 flex items-center justify-center gap-1 py-1 rounded-sm font-medium transition-colors ${
                    inspectorTab === "neighbors"
                      ? "bg-brand text-white shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  title="فهرست جدول‌های متصل"
                >
                  <Layers className="h-3 w-3" />
                  <span>لیست اتصالات</span>
                </button>
              </div>

              {/* TAB 1: D3 RELATIONSHIP GRAPH */}
              {inspectorTab === "graph" && (
                <div className="space-y-2">
                  <InspectorRelationshipGraph
                    table={selectedNode}
                    onSelectTable={handleInspectorSelectTable}
                    height={230}
                    showHeader={true}
                    embedded={true}
                  />
                </div>
              )}

              {/* TAB 2: COLUMNS & PRIMARY KEYS */}
              {inspectorTab === "columns" && (
                <div className="space-y-2">
                  {/* Primary Keys */}
                  {selectedNode.primary_key?.length > 0 && (
                    <div className="rounded border border-amber-500/30 bg-amber-500/10 p-2 text-xs">
                      <div className="flex items-center gap-1 font-semibold text-amber-400 text-[11px] mb-1">
                        <KeyRound className="h-3 w-3" /> کلید اصلی (Primary Key):
                      </div>
                      <div className="font-mono text-[11px] text-amber-200">
                        {selectedNode.primary_key.join(", ")}
                      </div>
                    </div>
                  )}

                  {/* Columns Sample */}
                  {selectedNode.columns?.length > 0 ? (
                    <div>
                      <div className="mb-1 text-[11px] font-semibold text-muted-foreground">ستون‌های شاخص جدول:</div>
                      <div className="max-h-48 overflow-y-auto rounded border border-border/80 bg-surface/40 p-1.5 space-y-1">
                        {selectedNode.columns.map((col, idx) => (
                          <div key={idx} className="flex items-center justify-between text-[10px] font-mono py-0.5 border-b border-border/30 last:border-0">
                            <span className={`flex items-center gap-1 ${col.is_pk ? "text-amber-400 font-bold" : "text-foreground"}`}>
                              {col.is_pk && <KeyRound className="h-2.5 w-2.5 text-amber-400" />}
                              {col.name}
                            </span>
                            <span className="text-muted-foreground">{col.type}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 text-center text-xs text-muted-foreground">
                      لیست ستون‌ها در دسترس نیست. برای اطلاعات تفصیلی روی دکمه مشاهده کامل کلیک کنید.
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: CONNECTED NEIGHBOR TABLES LIST */}
              {inspectorTab === "neighbors" && (
                <div>
                  <div className="mb-1 text-[11px] font-semibold text-muted-foreground flex items-center justify-between">
                    <span>اتصالات و روابط این جدول:</span>
                    <span className="font-mono text-[10px]">{neighborSet ? neighborSet.size - 1 : 0} جدول</span>
                  </div>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {filteredData.links
                      .filter((l) => {
                        const sId = typeof l.source === "object" ? l.source.id : l.source;
                        const tId = typeof l.target === "object" ? l.target.id : l.target;
                        return sId === selectedNode.id || tId === selectedNode.id;
                      })
                      .map((l, i) => {
                        const isOutgoing = (typeof l.source === "object" ? l.source.id : l.source) === selectedNode.id;
                        const otherId = isOutgoing
                          ? (typeof l.target === "object" ? l.target.id : l.target)
                          : (typeof l.source === "object" ? l.source.id : l.source);

                        return (
                          <div
                            key={i}
                            className="flex items-center justify-between rounded border border-border/60 bg-surface/50 px-2 py-1 text-[11px]"
                          >
                            <div className="truncate font-mono">
                              <span className="text-muted-foreground text-[10px] me-1">
                                {isOutgoing ? "➔ خروجی:" : "⬅ ورودی:"}
                              </span>
                              <span className="text-foreground font-medium">{otherId}</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                handleInspectorSelectTable(otherId);
                              }}
                              className="rounded p-1 text-brand hover:bg-brand/10 text-[10px]"
                              title="تمرکز بر این جدول"
                            >
                              <ChevronLeft className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}
            </div>

            {/* Actions Footer */}
            <div className="mt-3 space-y-2 border-t border-border/80 pt-2.5">
              <Button
                data-testid="inspect-table-details-btn"
                onClick={() => onSelectTable?.(selectedNode.id)}
                className="w-full gap-1.5 rounded-sm bg-brand text-xs font-semibold text-white hover:bg-brand/90"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                <span>مشاهده جزئیات و ساختار کامل جدول</span>
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => handleCopyQuery(selectedNode)}
                className="w-full gap-1.5 rounded-sm border-border bg-surface text-[11px] text-muted-foreground hover:text-foreground"
              >
                {copiedQuery ? <Check className="h-3 w-3 text-ok" /> : <Copy className="h-3 w-3" />}
                <span>{copiedQuery ? "کوئری کپی شد" : "کپی کوئری نمونه T-SQL"}</span>
              </Button>
            </div>
          </div>
        )}

        {/* Selected Link Tooltip Card */}
        {selectedLink && !selectedNode && (
          <div className="absolute bottom-4 start-4 z-20 rounded-md border border-brand/50 bg-ink/95 p-3 text-xs shadow-lg max-w-sm">
            <div className="flex items-center justify-between border-b border-border pb-1.5 mb-2">
              <span className="font-semibold text-brand flex items-center gap-1">
                <Link2 className="h-3.5 w-3.5" /> جزئیات اتصال کلید خارجی:
              </span>
              <button onClick={() => setSelectedLink(null)} className="text-muted-foreground hover:text-foreground">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="space-y-1 font-mono text-[11px]">
              <div>
                <span className="text-muted-foreground">جدول مبدأ:</span>{" "}
                <b className="text-foreground">
                  {typeof selectedLink.source === "object" ? selectedLink.source.id : selectedLink.source}
                </b>
              </div>
              <div>
                <span className="text-muted-foreground">ستون کلید مبدأ:</span>{" "}
                <span className="text-sky-400 font-bold">{selectedLink.from_col}</span>
              </div>
              <div className="pt-1 border-t border-border/40">
                <span className="text-muted-foreground">جدول مقصد:</span>{" "}
                <b className="text-foreground">
                  {typeof selectedLink.target === "object" ? selectedLink.target.id : selectedLink.target}
                </b>
              </div>
              <div>
                <span className="text-muted-foreground">ستون کلید مقصد:</span>{" "}
                <span className="text-emerald-400 font-bold">{selectedLink.to_col}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
