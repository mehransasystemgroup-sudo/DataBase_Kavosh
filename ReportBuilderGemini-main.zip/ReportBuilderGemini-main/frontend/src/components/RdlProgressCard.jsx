import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  CheckCircle2,
  AlertTriangle,
  FileDown,
  FileCode,
  Loader2,
  Eye,
  EyeOff,
  Copy,
  Check,
  Sparkles,
  Layers,
  Table2,
  Database,
  RefreshCw,
  Download,
  Terminal,
} from "lucide-react";

const STAGES = [
  {
    id: 1,
    pct: 20,
    title: "اعتبارسنجی کوئری T-SQL",
    desc: "بررسی ساختار دستورات SELECT، پارامترهای گزارش و نوع داده‌ها",
    icon: Database,
  },
  {
    id: 2,
    pct: 45,
    title: "تعریف DataSet و نگاشت فیلدها",
    desc: "استخراج متادیتای ستون‌ها و ایجاد فیلدهای محاسباتی در دیتاست",
    icon: Layers,
  },
  {
    id: 3,
    pct: 70,
    title: "پیکربندی چیدمان بصری (Tablix)",
    desc: "طراحی ساختار جداول، گروه‌بندی‌ها، سرستون‌های RTL و استایل‌های سازمانی",
    icon: Table2,
  },
  {
    id: 4,
    pct: 90,
    title: "کامپایل سند XML بر اساس RDL 2016",
    desc: "تولید سلسله‌مراتب تگ‌های Microsoft Reporting Services و اعتبارسنجی اسکیما",
    icon: FileCode,
  },
  {
    id: 5,
    pct: 100,
    title: "تکمیل و اعتبارسنجی یکپارچگی فایل",
    desc: "فایل آماده دانلود و استقرار در Report Server / Power BI Report Builder است",
    icon: CheckCircle2,
  },
];

export default function RdlProgressCard({
  building,
  progress,
  currentStageIndex,
  rdl,
  error,
  onBuild,
  onReset,
}) {
  const [showXmlPreview, setShowXmlPreview] = useState(false);
  const [copiedXml, setCopiedXml] = useState(false);

  const activeStage = STAGES[Math.min(currentStageIndex, STAGES.length - 1)] || STAGES[0];
  const isDone = Boolean(rdl && !building && !error);

  const handleCopyXml = async () => {
    if (!rdl?.xml) return;
    await navigator.clipboard.writeText(rdl.xml);
    setCopiedXml(true);
    toast.success("کد منبع RDL XML در حافظه کپی شد");
    setTimeout(() => setCopiedXml(false), 2000);
  };

  // If not started yet and not building
  if (!building && !rdl && !error) {
    return (
      <div className="rounded-sm border border-border/80 bg-surface/40 p-3.5 transition-all hover:border-brand/40">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-sm border border-brand/30 bg-brand/10 text-brand">
              <FileDown className="h-4 w-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-foreground">
                <span>تولید فایل گزارش سازمانی (SSRS RDL)</span>
                <span className="rounded-sm bg-brand/15 px-1.5 py-0.2 font-mono text-[10px] text-brand">
                  RDL 2016 Spec
                </span>
              </div>
              <p className="text-[11px] text-muted-foreground">
                تولید خودکار فایل سازگار با SQL Server Reporting Services و Power BI
              </p>
            </div>
          </div>
          <Button
            data-testid="build-rdl-btn"
            size="sm"
            onClick={onBuild}
            className="gap-2 rounded-sm bg-brand px-4 text-xs font-semibold text-white shadow-sm hover:bg-brand/90"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>ساخت فایل RDL</span>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      data-testid="rdl-progress-container"
      className={`rounded-sm border p-4 transition-all duration-300 ${
        isDone
          ? "border-ok/40 bg-surface shadow-sm"
          : error
          ? "border-err/40 bg-surface"
          : "border-brand/40 bg-surface shadow-sm"
      }`}
    >
      {/* Header status */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-border/60 pb-2.5">
        <div className="flex items-center gap-2">
          {building ? (
            <div className="flex h-7 w-7 items-center justify-center rounded-sm border border-brand/40 bg-brand/10 text-brand">
              <Loader2 className="h-4 w-4 animate-spin" />
            </div>
          ) : isDone ? (
            <div className="flex h-7 w-7 items-center justify-center rounded-sm border border-ok/40 bg-ok/10 text-ok">
              <CheckCircle2 className="h-4 w-4" />
            </div>
          ) : (
            <div className="flex h-7 w-7 items-center justify-center rounded-sm border border-err/40 bg-err/10 text-err">
              <AlertTriangle className="h-4 w-4" />
            </div>
          )}

          <div>
            <h4 className="text-xs font-bold text-foreground">
              {building
                ? "در حال تولید فایل ساختاریافته RDL…"
                : isDone
                ? "فایل گزارش RDL با موفقیت تولید و اعتبارسنجی شد"
                : "خطا در فرآیند تولید RDL"}
            </h4>
            <p className="text-[11px] text-muted-foreground">
              {building
                ? activeStage.desc
                : isDone
                ? `آماده استفاده در SSRS، Report Builder و پورتال‌های سازمانی`
                : error || "عملیات تولید با مشکل مواجه گردید."}
            </p>
          </div>
        </div>

        {/* Progress Percentage Badge */}
        <div className="flex items-center gap-2">
          <span
            data-testid="rdl-progress-percent"
            className={`font-mono text-xs font-bold px-2 py-0.5 rounded-sm border ${
              isDone
                ? "border-ok/30 bg-ok/10 text-ok"
                : error
                ? "border-err/30 bg-err/10 text-err"
                : "border-brand/30 bg-brand/10 text-brand animate-pulse"
            }`}
          >
            {Math.round(progress)}%
          </span>
          {isDone && (
            <Button
              variant="outline"
              size="sm"
              onClick={onBuild}
              className="h-7 gap-1 rounded-sm border-border bg-ink px-2 text-[11px] text-muted-foreground hover:text-foreground"
              title="تولید مجدد فایل"
            >
              <RefreshCw className="h-3 w-3" />
              <span>تولید مجدد</span>
            </Button>
          )}
        </div>
      </div>

      {/* Progress Track & Animated Bar */}
      <div className="mb-3 space-y-1.5">
        <div className="relative h-2.5 w-full overflow-hidden rounded-full bg-ink border border-border/50">
          <div
            data-testid="rdl-progress-bar-fill"
            className={`h-full transition-all duration-300 ease-out rounded-full ${
              isDone
                ? "bg-gradient-to-r from-emerald-500 via-teal-400 to-ok"
                : error
                ? "bg-err"
                : "bg-gradient-to-r from-blue-600 via-brand to-cyan-400"
            }`}
            style={{ width: `${Math.min(100, Math.max(4, progress))}%` }}
          />
          {building && (
            <div
              className="absolute inset-0 bg-white/10 animate-pulse pointer-events-none"
              style={{ width: `${Math.min(100, progress)}%` }}
            />
          )}
        </div>

        {/* Step Indicator Pills */}
        <div className="grid grid-cols-5 gap-1 pt-1">
          {STAGES.map((stg, i) => {
            const isPassed = currentStageIndex > i || isDone;
            const isCurrent = currentStageIndex === i && building;
            const Icon = stg.icon;

            return (
              <div
                key={stg.id}
                className={`flex flex-col items-center justify-center rounded-sm py-1.5 px-1 text-center transition-all ${
                  isCurrent
                    ? "border border-brand/50 bg-brand/15 text-brand shadow-sm"
                    : isPassed
                    ? "border border-ok/30 bg-ok/10 text-ok"
                    : "border border-transparent bg-ink/50 text-muted-foreground/50 opacity-60"
                }`}
              >
                <div className="flex items-center gap-1 mb-0.5">
                  {isCurrent ? (
                    <Loader2 className="h-3 w-3 animate-spin text-brand" />
                  ) : (
                    <Icon className="h-3 w-3" />
                  )}
                  <span className="font-mono text-[9px] font-bold">گام {stg.id}</span>
                </div>
                <span className="hidden sm:inline-block truncate text-[10px] font-medium leading-tight max-w-[110px]">
                  {stg.title}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Done State Details & Actions */}
      {isDone && rdl && (
        <div className="mt-3 space-y-3 pt-2 border-t border-border/60">
          {/* File summary badges */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-3 text-muted-foreground">
              <span className="flex items-center gap-1 font-mono text-foreground font-semibold">
                <FileCode className="h-3.5 w-3.5 text-brand" />
                {rdl.filename}
              </span>
              <span>حجم: <b className="font-mono text-foreground">{(rdl.size / 1024).toFixed(1)} KB</b></span>
              {rdl.fieldsCount !== undefined && (
                <span>فیلدها: <b className="font-mono text-foreground">{rdl.fieldsCount}</b></span>
              )}
              {rdl.parametersCount !== undefined && (
                <span>پارامترها: <b className="font-mono text-foreground">{rdl.parametersCount}</b></span>
              )}
            </div>

            <div className="flex items-center gap-2">
              {rdl.xml && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowXmlPreview(!showXmlPreview)}
                  className="h-8 gap-1.5 rounded-sm border-border bg-ink text-xs text-muted-foreground hover:text-foreground"
                >
                  {showXmlPreview ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                  <span>{showXmlPreview ? "بستن پیش‌نمایش XML" : "مشاهده XML"}</span>
                </Button>
              )}

              <a
                data-testid="download-rdl-link"
                href={`/api/download/${encodeURIComponent(rdl.filename)}`}
                download={rdl.filename}
                className="flex h-8 items-center gap-1.5 rounded-sm bg-brand px-3.5 text-xs font-semibold text-white transition-colors hover:bg-brand/90 shadow-sm"
              >
                <Download className="h-3.5 w-3.5" />
                <span>دانلود فایل RDL</span>
              </a>
            </div>
          </div>

          {/* Warnings if any */}
          {rdl.warnings?.length > 0 && (
            <div className="rounded-sm border border-amber-500/30 bg-amber-500/10 p-2.5 text-xs text-amber-200">
              <div className="mb-1 flex items-center gap-1.5 font-bold text-amber-400">
                <AlertTriangle className="h-3.5 w-3.5" /> هشدارهای اعتبارسنجی RDL:
              </div>
              <ul className="list-disc space-y-0.5 pe-4 text-[11px]">
                {rdl.warnings.map((w, i) => (
                  <li key={`rdl-warn-${i}`}>{w}</li>
                ))}
              </ul>
            </div>
          )}

          {/* XML Code preview viewer */}
          {showXmlPreview && rdl.xml && (
            <div className="relative rounded-sm border border-border bg-ink p-3 text-xs font-mono rc-fade-up">
              <div className="mb-2 flex items-center justify-between border-b border-border/50 pb-1.5">
                <span className="flex items-center gap-1.5 text-muted-foreground text-[11px]">
                  <Terminal className="h-3.5 w-3.5 text-brand" /> کد سند XML (RDL Definition):
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCopyXml}
                  className="h-6 gap-1 px-2 text-[10px] text-muted-foreground hover:text-foreground"
                >
                  {copiedXml ? <Check className="h-3 w-3 text-ok" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedXml ? "کپی شد" : "کپی تمام XML"}</span>
                </Button>
              </div>
              <pre
                dir="ltr"
                className="max-h-56 overflow-auto text-[11px] leading-relaxed text-slate-300 select-all"
              >
                {rdl.xml}
              </pre>
            </div>
          )}
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="mt-3 flex items-center justify-between gap-3 rounded-sm border border-err/30 bg-err/10 p-2.5 text-xs text-err">
          <span>{error}</span>
          <Button
            size="sm"
            onClick={onBuild}
            variant="outline"
            className="h-7 border-err/40 text-err hover:bg-err/20 text-xs"
          >
            تلاش مجدد
          </Button>
        </div>
      )}
    </div>
  );
}
