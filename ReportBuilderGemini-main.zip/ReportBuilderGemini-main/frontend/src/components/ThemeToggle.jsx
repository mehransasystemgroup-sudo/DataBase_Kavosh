import { Sun, Moon } from "lucide-react";
import { useTheme } from "@/context/ThemeContext";

export default function ThemeToggle({ className = "", compact = false }) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <button
      type="button"
      data-testid="theme-toggle"
      onClick={toggleTheme}
      title={isDark ? "تغییر به حالت روشن (Light Mode)" : "تغییر به حالت تاریک (Dark Mode)"}
      aria-label={isDark ? "تغییر به حالت روشن" : "تغییر به حالت تاریک"}
      className={`group relative flex items-center justify-center gap-1.5 rounded-sm border border-border bg-surface px-2.5 py-1.5 text-xs font-medium text-foreground transition-all duration-200 hover:border-brand/50 hover:bg-surfaceHover hover:text-brand focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-brand shrink-0 ${className}`}
    >
      <div className="relative flex h-4 w-4 items-center justify-center overflow-hidden">
        {isDark ? (
          <Sun className="h-4 w-4 text-amber-400 transition-transform duration-300 group-hover:rotate-45" />
        ) : (
          <Moon className="h-4 w-4 text-indigo-600 transition-transform duration-300 group-hover:-rotate-12" />
        )}
      </div>
      {!compact && (
        <span className="hidden text-[11px] sm:inline-block font-sans select-none">
          {isDark ? "روشن" : "تاریک"}
        </span>
      )}
    </button>
  );
}
