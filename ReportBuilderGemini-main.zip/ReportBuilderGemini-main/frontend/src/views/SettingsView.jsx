import { useEffect, useState, useMemo } from "react";
import { http } from "@/lib/api";
import { ViewHeader, Sev } from "@/views/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import {
  Save,
  PlugZap,
  Loader2,
  KeyRound,
  Cpu,
  Wallet,
  Table2,
  Layers,
  Grid,
  Plus,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Star,
  Sparkles,
  Eye,
  Activity,
  Check,
  FileText,
  Sliders,
  Settings2,
} from "lucide-react";

const PRESET_INFO = {
  emergent: { label: "Emergent · Claude", provider: "emergent", desc: "مدل کلاد از طریق ارائه‌دهنده سازمانی Emergent" },
  "emergent-gpt": { label: "Emergent · GPT", provider: "emergent", desc: "مدل GPT-5/4o از طریق Emergent" },
  "emergent-gemini": { label: "Emergent · Gemini", provider: "emergent", desc: "مدل جِمینای از طریق Emergent" },
  gemini: { label: "Google Gemini", provider: "google", desc: "اتصال مستقیم به Gemini 2.5/3.6 با کلید شخصی" },
  claude: { label: "Anthropic Claude", provider: "anthropic", desc: "اتصال مستقیم به Claude 3.5 Sonnet با کلید شخصی" },
  gpt: { label: "OpenAI GPT-4o", provider: "openai", desc: "اتصال مستقیم به OpenAI با کلید شخصی" },
  deepseek: { label: "DeepSeek", provider: "deepseek", desc: "مدل تخصصی کوئری‌نویسی و کد DeepSeek V3" },
  ollama: { label: "Ollama (محلی)", provider: "openai", desc: "مدل‌های لوکال آفلاین بدون هزینه (پورت ۱۱۴۳۴)" },
  lmstudio: { label: "LM Studio (محلی)", provider: "openai", desc: "سرور محلی سازگار با OpenAI (پورت ۱۲۳۴)" },
  openrouter: { label: "OpenRouter", provider: "openai", desc: "هاب مولتی‌مدل OpenRouter با کلید شخصی" },
};

const KEY_FIELDS = [
  { id: "google", label: "Google (Gemini)", ph: "AIzaSy…", desc: "جهت استفاده از مدل‌های Gemini 2.5 Flash و Pro" },
  { id: "anthropic", label: "Anthropic (Claude)", ph: "sk-ant-…", desc: "جهت استفاده از Claude 3.5 Sonnet و Haiku" },
  { id: "openai", label: "OpenAI (GPT)", ph: "sk-proj-…", desc: "جهت استفاده از GPT-4o و GPT-4o-mini" },
  { id: "deepseek", label: "DeepSeek", ph: "sk-…", desc: "جهت استفاده از API سازگار DeepSeek Chat" },
];

export default function SettingsView({ health, onSaved, onMenu }) {
  const [activeTab, setActiveTab] = useState("profiles"); // "profiles" | "models" | "diagnostics"
  const [settings, setSettings] = useState(null);
  const [presets, setPresets] = useState({});
  const [keys, setKeys] = useState({});
  const [keyInput, setKeyInput] = useState({});
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  // User Personal Profiles State
  const [profiles, setProfiles] = useState([]);
  const [activeProfileId, setActiveProfileId] = useState("");
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [savingProfile, setSavingProfile] = useState(false);

  // New Favorite Column form state
  const [newFavTable, setNewFavTable] = useState("SLS.Invoice");
  const [newFavCol, setNewFavCol] = useState("");
  const [newFavAlias, setNewFavAlias] = useState("");
  const [newFavCategory, setNewFavCategory] = useState("dimension");
  const [newFavAgg, setNewFavAgg] = useState("");

  // New Matrix Row/Col Groups & Measure helpers
  const [newMatrixRowGroup, setNewMatrixRowGroup] = useState("");
  const [newMatrixColGroup, setNewMatrixColGroup] = useState("");
  const [newMatrixMeasureCol, setNewMatrixMeasureCol] = useState("");
  const [newMatrixMeasureAgg, setNewMatrixMeasureAgg] = useState("SUM");
  const [newMatrixMeasureTitle, setNewMatrixMeasureTitle] = useState("");

  // Diagnostics State
  const [runningDiag, setRunningDiag] = useState(false);
  const [diagnosticsResult, setDiagnosticsResult] = useState(null);

  // Load Settings and Profiles
  const load = async () => {
    try {
      const { data } = await http.get("/settings");
      // Backward and forward compatibility
      const s = data.settings || {
        model_preset: data.preset || "emergent-gemini",
        model_override: data.model || "",
        base_url: "",
        max_attempts: 4,
        context_tables: data.context_tables_count || 6,
        timeout: data.timeout_seconds || 180,
        daily_budget_usd: data.daily_budget || 10.0,
      };
      setSettings(s);
      setPresets(data.presets || {});
      setKeys(data.keys || {});

      const profs = data.profiles || [];
      setProfiles(profs);
      const defId = data.active_profile_id || profs.find((p) => p.is_default)?.id || profs[0]?.id || "";
      setActiveProfileId(defId);
      const cur = profs.find((p) => p.id === defId) || profs[0] || null;
      setSelectedProfile(cur ? JSON.parse(JSON.stringify(cur)) : null);
    } catch (e) {
      toast.error("خطا در بارگذاری تنظیمات: " + (e.message || ""));
    }
  };

  useEffect(() => {
    load();
  }, []);

  const patch = (k, v) => setSettings((s) => ({ ...s, [k]: v }));

  // Save Settings & API Keys
  const saveSettings = async () => {
    setSaving(true);
    try {
      const api_keys = {};
      for (const [k, v] of Object.entries(keyInput)) {
        if (v?.trim()) api_keys[k] = v.trim();
      }

      const { data } = await http.post("/settings", {
        settings: {
          model_preset: settings.model_preset,
          model_override: settings.model_override,
          base_url: settings.base_url,
          max_attempts: Number(settings.max_attempts),
          context_tables: Number(settings.context_tables),
          daily_budget_usd: Number(settings.daily_budget_usd),
          timeout: Number(settings.timeout || 180),
        },
        api_keys,
        active_profile_id: activeProfileId,
      });

      if (data.keys) setKeys(data.keys);
      setKeyInput({});
      toast.success("تنظیمات و کلیدهای هوش مصنوعی با موفقیت ذخیره شد");
      onSaved?.();
    } catch (e) {
      toast.error("خطا در ذخیره تنظیمات: " + (e.message || ""));
    } finally {
      setSaving(false);
    }
  };

  // Test Model Connection
  const testModel = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const { data } = await http.post("/test-model");
      setTestResult(data);
      if (data.ok || data.success) {
        toast.success(`اتصال برقرار شد: ${data.reply?.slice(0, 60) || "پاسخ دریافت شد"}`);
      } else {
        toast.error(`اتصال ناموفق: ${data.error || "خطای نامشخص"}`);
      }
    } catch (e) {
      setTestResult({ ok: false, error: e.message || "خطا در ارتباط با سرور" });
      toast.error("خطا در آزمایش اتصال: " + (e.message || ""));
    } finally {
      setTesting(false);
    }
  };

  // Run System Diagnostics
  const runDiagnostics = async () => {
    setRunningDiag(true);
    try {
      const { data } = await http.post("/settings/diagnostics");
      setDiagnosticsResult(data);
      toast.success("آزمون تشخیصی با موفقیت تکمیل گردید.");
    } catch (e) {
      toast.error("خطا در اجرای آزمون تشخیصی: " + (e.message || ""));
    } finally {
      setRunningDiag(false);
    }
  };

  // Switch selected profile
  const handleSelectProfile = (pId) => {
    setActiveProfileId(pId);
    const prof = profiles.find((p) => p.id === pId);
    if (prof) {
      setSelectedProfile(JSON.parse(JSON.stringify(prof)));
    }
  };

  // Set active default profile
  const handleSetDefaultProfile = async (pId) => {
    try {
      const { data } = await http.post(`/user-profiles/${pId}/set-default`);
      if (data.success) {
        setProfiles(data.profiles);
        setActiveProfileId(pId);
        toast.success("پروفایل به عنوان پیش‌فرض گزارش‌ساز فعال شد.");
      }
    } catch (e) {
      toast.error("خطا در تغییر پروفایل پیش‌فرض: " + (e.message || ""));
    }
  };

  // Create new profile template
  const handleCreateNewProfile = () => {
    const newId = `profile-${Date.now()}`;
    const newProf = {
      id: newId,
      name: `پروفایل شخصی ${profiles.length + 1}`,
      description: "پروفایل سفارشی جدید با ستون‌های منتخب و چیدمان ماتریسی",
      is_default: profiles.length === 0,
      base_table: "SLS.Invoice",
      favorite_columns: [
        {
          id: `col-${Date.now()}-1`,
          table: "SLS.Invoice",
          column: "CustomerTitle",
          alias: "نام مشتری",
          aggregate: null,
          category: "dimension",
        },
        {
          id: `col-${Date.now()}-2`,
          table: "SLS.Invoice",
          column: "NetPrice",
          alias: "مبلغ خالص فروش",
          aggregate: "SUM",
          category: "measure",
        },
      ],
      layout: {
        kind: "matrix",
        matrix: {
          row_groups: ["CustomerTitle"],
          col_groups: ["InvoiceDate"],
          values: [{ column: "NetPrice", aggregate: "SUM", title: "مجموع فروش خالص" }],
          show_row_totals: true,
          show_col_totals: true,
          subtotals: true,
        },
        direction: "RTL",
        font_size: "9pt",
        page_orientation: "Landscape",
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    setSelectedProfile(newProf);
  };

  // Save current selected profile
  const handleSaveProfile = async () => {
    if (!selectedProfile) return;
    setSavingProfile(true);
    try {
      const { data } = await http.post("/user-profiles", selectedProfile);
      if (data.success) {
        setProfiles(data.profiles);
        setSelectedProfile(data.profile);
        setActiveProfileId(data.profile.id);
        toast.success(`پروفایل «${data.profile.name}» با موفقیت ذخیره شد.`);
      }
    } catch (e) {
      toast.error("خطا در ذخیره پروفایل: " + (e.message || ""));
    } finally {
      setSavingProfile(false);
    }
  };

  // Delete profile
  const handleDeleteProfile = async (pId) => {
    if (profiles.length <= 1) {
      toast.warning("حداقل یک پروفایل باید در سیستم باقی بماند.");
      return;
    }
    try {
      const { data } = await http.delete(`/user-profiles/${pId}`);
      if (data.success) {
        setProfiles(data.profiles);
        const next = data.profiles[0];
        setActiveProfileId(next.id);
        setSelectedProfile(JSON.parse(JSON.stringify(next)));
        toast.success("پروفایل با موفقیت حذف شد.");
      }
    } catch (e) {
      toast.error("خطا در حذف پروفایل: " + (e.message || ""));
    }
  };

  // Add Favorite Column to Profile
  const handleAddFavoriteColumn = () => {
    if (!selectedProfile) return;
    if (!newFavCol.trim()) {
      toast.warning("نام ستون الزامی است.");
      return;
    }

    const newCol = {
      id: `col-${Date.now()}`,
      table: newFavTable.trim() || selectedProfile.base_table || "SLS.Invoice",
      column: newFavCol.trim(),
      alias: newFavAlias.trim() || newFavCol.trim(),
      aggregate: newFavAgg || null,
      category: newFavCategory,
    };

    setSelectedProfile({
      ...selectedProfile,
      favorite_columns: [...(selectedProfile.favorite_columns || []), newCol],
    });

    setNewFavCol("");
    setNewFavAlias("");
    setNewFavAgg("");
    toast.success("ستون به فهرست علاقه‌مندی‌ها اضافه شد.");
  };

  // Remove Favorite Column
  const handleRemoveFavoriteColumn = (colId) => {
    if (!selectedProfile) return;
    setSelectedProfile({
      ...selectedProfile,
      favorite_columns: selectedProfile.favorite_columns.filter((c) => c.id !== colId),
    });
  };

  // Add Matrix Row Group
  const handleAddMatrixRowGroup = () => {
    if (!newMatrixRowGroup.trim() || !selectedProfile) return;
    const cur = selectedProfile.layout?.matrix?.row_groups || [];
    if (!cur.includes(newMatrixRowGroup.trim())) {
      setSelectedProfile({
        ...selectedProfile,
        layout: {
          ...selectedProfile.layout,
          matrix: {
            ...selectedProfile.layout.matrix,
            row_groups: [...cur, newMatrixRowGroup.trim()],
          },
        },
      });
      setNewMatrixRowGroup("");
    }
  };

  // Add Matrix Col Group
  const handleAddMatrixColGroup = () => {
    if (!newMatrixColGroup.trim() || !selectedProfile) return;
    const cur = selectedProfile.layout?.matrix?.col_groups || [];
    if (!cur.includes(newMatrixColGroup.trim())) {
      setSelectedProfile({
        ...selectedProfile,
        layout: {
          ...selectedProfile.layout,
          matrix: {
            ...selectedProfile.layout.matrix,
            col_groups: [...cur, newMatrixColGroup.trim()],
          },
        },
      });
      setNewMatrixColGroup("");
    }
  };

  // Add Matrix Measure
  const handleAddMatrixMeasure = () => {
    if (!newMatrixMeasureCol.trim() || !selectedProfile) return;
    const cur = selectedProfile.layout?.matrix?.values || [];
    const newMeasure = {
      column: newMatrixMeasureCol.trim(),
      aggregate: newMatrixMeasureAgg || "SUM",
      title: newMatrixMeasureTitle.trim() || `${newMatrixMeasureAgg || "SUM"}(${newMatrixMeasureCol})`,
    };
    setSelectedProfile({
      ...selectedProfile,
      layout: {
        ...selectedProfile.layout,
        matrix: {
          ...selectedProfile.layout.matrix,
          values: [...cur, newMeasure],
        },
      },
    });
    setNewMatrixMeasureCol("");
    setNewMatrixMeasureTitle("");
  };

  if (!settings) {
    return (
      <div className="flex h-full w-full items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-brand" />
        <span className="ms-2 text-sm text-muted-foreground">در حال بارگذاری تنظیمات...</span>
      </div>
    );
  }

  return (
    <>
      <ViewHeader
        title="تنظیمات سیستم و پروفایل‌های کاربر"
        subtitle="مدیریت پروفایل‌های اختصاصی، مدل‌های چیدمان ماتریسی، کلیدهای هوش مصنوعی و آزمون‌های سلامت"
        onMenu={onMenu}
      >
        <div className="flex items-center gap-2">
          {activeTab === "profiles" && (
            <Button
              onClick={handleSaveProfile}
              disabled={savingProfile}
              className="gap-1.5 rounded-sm bg-brand text-white hover:bg-brand/90"
            >
              {savingProfile ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              ذخیره پروفایل
            </Button>
          )}
          {activeTab === "models" && (
            <Button
              onClick={saveSettings}
              disabled={saving}
              className="gap-1.5 rounded-sm bg-brand text-white hover:bg-brand/90"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              ذخیره تنظیمات
            </Button>
          )}
        </div>
      </ViewHeader>

      {/* Tabs Bar */}
      <div className="border-b border-border bg-surface/80 px-6 pt-2">
        <div className="mx-auto flex max-w-5xl gap-2">
          <button
            onClick={() => setActiveTab("profiles")}
            className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs font-bold transition-all ${
              activeTab === "profiles"
                ? "border-brand text-brand"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Table2 className="h-4 w-4" />
            <span>پروفایل‌های شخصی و مدل ماتریسی</span>
            <span className="rounded-full bg-brand/20 px-2 py-0.5 text-[10px] text-brand">
              {profiles.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab("models")}
            className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs font-bold transition-all ${
              activeTab === "models"
                ? "border-brand text-brand"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Cpu className="h-4 w-4" />
            <span>مدل‌های هوش مصنوعی و کلیدهای API</span>
          </button>

          <button
            onClick={() => setActiveTab("diagnostics")}
            className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs font-bold transition-all ${
              activeTab === "diagnostics"
                ? "border-brand text-brand"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Activity className="h-4 w-4" />
            <span>آزمون سلامت و عیب‌یابی جامع</span>
          </button>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="mx-auto max-w-5xl space-y-6 p-6">
          {/* ══════════════════ TAB 1: USER PROFILES & MATRIX LAYOUT ══════════════════ */}
          {activeTab === "profiles" && (
            <div className="space-y-6">
              {/* Profile Selector Toolbar */}
              <section className="rounded-md border border-border bg-surface p-4">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-3">
                  <div className="flex items-center gap-2">
                    <Sliders className="h-5 w-5 text-brand" />
                    <div>
                      <h3 className="text-sm font-bold text-foreground">پروفایل شخصی کاربر (Personal Profile)</h3>
                      <p className="text-[11px] text-muted-foreground">
                        ستون‌های منتخب و تنظیمات چیدمان خاص (ماتریسی / پیوت) را ذخیره و در گزارش‌ساز فراخوانی نمایید.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleCreateNewProfile}
                      className="h-8 gap-1 border-border bg-ink text-xs hover:bg-surfaceHover"
                    >
                      <Plus className="h-3.5 w-3.5 text-brand" />
                      <span>پروفایل جدید</span>
                    </Button>
                    {selectedProfile && !selectedProfile.is_default && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSetDefaultProfile(selectedProfile.id)}
                        className="h-8 gap-1 border-amber-500/40 text-amber-400 hover:bg-amber-500/10 text-xs"
                      >
                        <Star className="h-3.5 w-3.5" />
                        <span>انتخاب به عنوان پیش‌فرض</span>
                      </Button>
                    )}
                    {selectedProfile && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteProfile(selectedProfile.id)}
                        className="h-8 gap-1 border-err/30 text-err hover:bg-err/10 text-xs"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>حذف</span>
                      </Button>
                    )}
                  </div>
                </div>

                {/* Profiles Cards / Pills */}
                <div className="mt-3 flex flex-wrap gap-2">
                  {profiles.map((p) => {
                    const isSelected = selectedProfile?.id === p.id;
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => handleSelectProfile(p.id)}
                        className={`flex items-center gap-2 rounded-md border px-3 py-2 text-xs transition-all ${
                          isSelected
                            ? "border-brand bg-brand/10 text-white ring-1 ring-brand"
                            : "border-border bg-ink text-muted-foreground hover:bg-surfaceHover hover:text-foreground"
                        }`}
                      >
                        <span className="font-semibold">{p.name}</span>
                        {p.is_default && (
                          <span className="flex items-center gap-0.5 rounded bg-amber-500/20 px-1.5 py-0.5 text-[9px] font-bold text-amber-300 border border-amber-500/40">
                            <Star className="h-2.5 w-2.5 fill-amber-300" /> پیش‌فرض
                          </span>
                        )}
                        <span className="font-mono text-[10px] text-muted-foreground">
                          ({p.layout?.kind === "matrix" ? "مدل ماتریسی" : "جدولی"})
                        </span>
                      </button>
                    );
                  })}
                </div>

                {selectedProfile && (
                  <div className="mt-4 grid gap-3 pt-3 border-t border-border sm:grid-cols-2">
                    <Field label="نام پروفایل">
                      <Input
                        value={selectedProfile.name}
                        onChange={(e) => setSelectedProfile({ ...selectedProfile, name: e.target.value })}
                        className="h-8 rounded border-border bg-ink text-xs"
                      />
                    </Field>
                    <Field label="جدول پایه پیشنهادی (Base Table)">
                      <Input
                        value={selectedProfile.base_table || ""}
                        onChange={(e) => setSelectedProfile({ ...selectedProfile, base_table: e.target.value })}
                        placeholder="مثال: SLS.Invoice یا ACC.Voucher"
                        className="h-8 rounded border-border bg-ink font-mono text-xs"
                        dir="ltr"
                      />
                    </Field>
                    <div className="sm:col-span-2">
                      <Field label="توضیحات و یادداشت‌های کاربر">
                        <Input
                          value={selectedProfile.description || ""}
                          onChange={(e) => setSelectedProfile({ ...selectedProfile, description: e.target.value })}
                          placeholder="توضیحات تکمیلی در مورد نحوه کاربرد این مدل گزارش..."
                          className="h-8 rounded border-border bg-ink text-xs"
                        />
                      </Field>
                    </div>
                  </div>
                )}
              </section>

              {selectedProfile && (
                <>
                  {/* Favorite Columns Section */}
                  <section className="rounded-md border border-border bg-surface p-4">
                    <div className="mb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
                        <h4 className="text-sm font-bold text-foreground">ستون‌های مورد علاقه کاربر (Favorite Columns)</h4>
                      </div>
                      <span className="text-[11px] text-muted-foreground">
                        {selectedProfile.favorite_columns?.length || 0} ستون انتخاب شده
                      </span>
                    </div>

                    {/* Columns List Chips */}
                    <div className="flex flex-wrap gap-2 mb-4 min-h-[48px] rounded border border-dashed border-border/80 p-2.5 bg-ink/40">
                      {(selectedProfile.favorite_columns || []).length === 0 ? (
                        <span className="text-xs text-muted-foreground py-1">
                          هنوز ستونی به این پروفایل اضافه نشده است. از فرم زیر ستون‌های دلخواه را بیافزایید.
                        </span>
                      ) : (
                        selectedProfile.favorite_columns.map((c) => (
                          <div
                            key={c.id}
                            className="flex items-center gap-1.5 rounded border border-border bg-surface px-2.5 py-1 text-xs text-foreground shadow-sm"
                          >
                            <span className="font-semibold">{c.alias || c.column}</span>
                            <span className="font-mono text-[10px] text-muted-foreground" dir="ltr">
                              [{c.table}].[{c.column}]
                            </span>
                            {c.aggregate && (
                              <span className="rounded bg-brand/20 px-1 py-0.2 font-mono text-[9px] text-brand">
                                {c.aggregate}
                              </span>
                            )}
                            <span className="rounded bg-border px-1 py-0.2 text-[9px] text-muted-foreground">
                              {c.category === "measure" ? "سنجه محاسباتی" : "بُعد"}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleRemoveFavoriteColumn(c.id)}
                              className="ms-1 text-muted-foreground hover:text-err"
                              title="حذف ستون"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Add Column Form */}
                    <div className="rounded border border-border/60 bg-ink p-3 space-y-2">
                      <span className="text-xs font-semibold text-brand flex items-center gap-1">
                        <Plus className="h-3.5 w-3.5" /> افزودن ستون جدید به علاقه‌مندی‌ها
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                        <Input
                          placeholder="جدول (مثال: SLS.Invoice)"
                          value={newFavTable}
                          onChange={(e) => setNewFavTable(e.target.value)}
                          className="h-8 text-xs font-mono bg-surface border-border"
                          dir="ltr"
                        />
                        <Input
                          placeholder="نام فیلد (مثال: NetPrice)"
                          value={newFavCol}
                          onChange={(e) => setNewFavCol(e.target.value)}
                          className="h-8 text-xs font-mono bg-surface border-border"
                          dir="ltr"
                        />
                        <Input
                          placeholder="عنوان فارسی (مثال: مبلغ خالص)"
                          value={newFavAlias}
                          onChange={(e) => setNewFavAlias(e.target.value)}
                          className="h-8 text-xs bg-surface border-border"
                        />
                        <select
                          value={newFavCategory}
                          onChange={(e) => setNewFavCategory(e.target.value)}
                          className="h-8 rounded border border-border bg-surface px-2 text-xs text-foreground"
                        >
                          <option value="dimension">بُعد سطر/ستون (Dimension)</option>
                          <option value="measure">سنجه محاسباتی (Measure)</option>
                        </select>
                        <select
                          value={newFavAgg}
                          onChange={(e) => setNewFavAgg(e.target.value)}
                          className="h-8 rounded border border-border bg-surface px-2 text-xs font-mono text-foreground"
                        >
                          <option value="">بدون تابع تجمیعی</option>
                          <option value="SUM">SUM (جمع)</option>
                          <option value="COUNT">COUNT (تعداد)</option>
                          <option value="AVG">AVG (میانگین)</option>
                          <option value="MIN">MIN (کمترین)</option>
                          <option value="MAX">MAX (بیشترین)</option>
                        </select>
                      </div>
                      <div className="flex justify-end pt-1">
                        <Button
                          size="sm"
                          onClick={handleAddFavoriteColumn}
                          className="h-7 text-xs gap-1 bg-brand text-white hover:bg-brand/90"
                        >
                          <Plus className="h-3 w-3" /> افزودن ستون
                        </Button>
                      </div>
                    </div>
                  </section>

                  {/* Matrix Layout & Configuration Section */}
                  <section className="rounded-md border border-border bg-surface p-4 space-y-4">
                    <div className="flex items-center justify-between border-b border-border pb-3">
                      <div className="flex items-center gap-2">
                        <Grid className="h-4 w-4 text-brand" />
                        <h4 className="text-sm font-bold text-foreground">
                          تنظیمات چیدمان اختصاصی و مدل ماتریسی (Matrix Model)
                        </h4>
                      </div>
                      <div className="flex gap-1.5">
                        {[
                          { id: "matrix", label: "مدل ماتریسی (Matrix / Pivot)" },
                          { id: "table", label: "جدولی تخت (Table)" },
                          { id: "grouped", label: "گروه‌بندی شده (Grouped)" },
                        ].map((k) => (
                          <button
                            key={k.id}
                            type="button"
                            onClick={() =>
                              setSelectedProfile({
                                ...selectedProfile,
                                layout: { ...selectedProfile.layout, kind: k.id },
                              })
                            }
                            className={`rounded px-2.5 py-1 text-xs border transition-colors ${
                              selectedProfile.layout?.kind === k.id
                                ? "border-brand bg-brand text-white font-medium"
                                : "border-border bg-ink text-muted-foreground hover:text-foreground"
                            }`}
                          >
                            {k.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Detailed Matrix Configuration */}
                    {selectedProfile.layout?.kind === "matrix" && (
                      <div className="space-y-4">
                        <div className="grid gap-4 md:grid-cols-2">
                          {/* Row Groups */}
                          <div className="rounded border border-border bg-ink p-3 space-y-2">
                            <span className="text-xs font-bold text-foreground block">
                              ۱. گروه‌بندی سطرها (Row Groups):
                            </span>
                            <div className="flex flex-wrap gap-1.5 min-h-[32px]">
                              {(selectedProfile.layout?.matrix?.row_groups || []).map((rg) => (
                                <span
                                  key={rg}
                                  className="flex items-center gap-1 rounded bg-surface border border-border px-2 py-0.5 text-xs"
                                >
                                  {rg}
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setSelectedProfile({
                                        ...selectedProfile,
                                        layout: {
                                          ...selectedProfile.layout,
                                          matrix: {
                                            ...selectedProfile.layout.matrix,
                                            row_groups: selectedProfile.layout.matrix.row_groups.filter(
                                              (g) => g !== rg
                                            ),
                                          },
                                        },
                                      })
                                    }
                                    className="text-muted-foreground hover:text-err"
                                  >
                                    ×
                                  </button>
                                </span>
                              ))}
                            </div>
                            <div className="flex gap-1.5 pt-1">
                              <Input
                                placeholder="فیلد سطر (مثال: CustomerTitle)"
                                value={newMatrixRowGroup}
                                onChange={(e) => setNewMatrixRowGroup(e.target.value)}
                                className="h-7 text-xs bg-surface border-border font-mono"
                                dir="ltr"
                              />
                              <Button
                                size="sm"
                                onClick={handleAddMatrixRowGroup}
                                className="h-7 text-xs bg-brand text-white hover:bg-brand/90"
                              >
                                افزودن
                              </Button>
                            </div>
                          </div>

                          {/* Column Groups */}
                          <div className="rounded border border-border bg-ink p-3 space-y-2">
                            <span className="text-xs font-bold text-foreground block">
                              ۲. گروه‌بندی ستون‌ها (Column Groups - سرستون‌های پویا):
                            </span>
                            <div className="flex flex-wrap gap-1.5 min-h-[32px]">
                              {(selectedProfile.layout?.matrix?.col_groups || []).map((cg) => (
                                <span
                                  key={cg}
                                  className="flex items-center gap-1 rounded bg-surface border border-border px-2 py-0.5 text-xs"
                                >
                                  {cg}
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setSelectedProfile({
                                        ...selectedProfile,
                                        layout: {
                                          ...selectedProfile.layout,
                                          matrix: {
                                            ...selectedProfile.layout.matrix,
                                            col_groups: selectedProfile.layout.matrix.col_groups.filter(
                                              (g) => g !== cg
                                            ),
                                          },
                                        },
                                      })
                                    }
                                    className="text-muted-foreground hover:text-err"
                                  >
                                    ×
                                  </button>
                                </span>
                              ))}
                            </div>
                            <div className="flex gap-1.5 pt-1">
                              <Input
                                placeholder="فیلد ستون (مثال: InvoiceDate یا Month)"
                                value={newMatrixColGroup}
                                onChange={(e) => setNewMatrixColGroup(e.target.value)}
                                className="h-7 text-xs bg-surface border-border font-mono"
                                dir="ltr"
                              />
                              <Button
                                size="sm"
                                onClick={handleAddMatrixColGroup}
                                className="h-7 text-xs bg-brand text-white hover:bg-brand/90"
                              >
                                افزودن
                              </Button>
                            </div>
                          </div>
                        </div>

                        {/* Matrix Measures / Values */}
                        <div className="rounded border border-border bg-ink p-3 space-y-2">
                          <span className="text-xs font-bold text-foreground block">
                            ۳. مقادیر و سنجه‌های محاسباتی در تقاطع سطر و ستون (Matrix Measures):
                          </span>
                          <div className="flex flex-wrap gap-2 min-h-[32px]">
                            {(selectedProfile.layout?.matrix?.values || []).map((m, idx) => (
                              <div
                                key={idx}
                                className="flex items-center gap-1.5 rounded bg-surface border border-border px-2.5 py-1 text-xs"
                              >
                                <span className="font-semibold text-brand">{m.title || m.column}</span>
                                <span className="font-mono text-[10px] text-muted-foreground">
                                  {m.aggregate}({m.column})
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setSelectedProfile({
                                      ...selectedProfile,
                                      layout: {
                                        ...selectedProfile.layout,
                                        matrix: {
                                          ...selectedProfile.layout.matrix,
                                          values: selectedProfile.layout.matrix.values.filter(
                                            (_, i) => i !== idx
                                          ),
                                        },
                                      },
                                    })
                                  }
                                  className="text-muted-foreground hover:text-err"
                                >
                                  <Trash2 className="h-3 w-3" />
                                </button>
                              </div>
                            ))}
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-1">
                            <Input
                              placeholder="فیلد محاسباتی (مثال: NetPrice)"
                              value={newMatrixMeasureCol}
                              onChange={(e) => setNewMatrixMeasureCol(e.target.value)}
                              className="h-7 text-xs bg-surface border-border font-mono"
                              dir="ltr"
                            />
                            <select
                              value={newMatrixMeasureAgg}
                              onChange={(e) => setNewMatrixMeasureAgg(e.target.value)}
                              className="h-7 rounded border border-border bg-surface px-2 text-xs font-mono text-foreground"
                            >
                              <option value="SUM">SUM (مجموع)</option>
                              <option value="COUNT">COUNT (تعداد)</option>
                              <option value="AVG">AVG (میانگین)</option>
                              <option value="MIN">MIN (کمترین)</option>
                              <option value="MAX">MAX (بیشترین)</option>
                            </select>
                            <Input
                              placeholder="عنوان نمایشی (مثال: جمع خالص فروش)"
                              value={newMatrixMeasureTitle}
                              onChange={(e) => setNewMatrixMeasureTitle(e.target.value)}
                              className="h-7 text-xs bg-surface border-border"
                            />
                            <Button
                              size="sm"
                              onClick={handleAddMatrixMeasure}
                              className="h-7 text-xs bg-brand text-white hover:bg-brand/90"
                            >
                              <Plus className="h-3 w-3" /> افزودن سنجه
                            </Button>
                          </div>
                        </div>

                        {/* Matrix Options: Totals & Subtotals */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                          <label className="flex items-center gap-2 rounded border border-border bg-ink p-2 text-xs cursor-pointer">
                            <input
                              type="checkbox"
                              checked={!!selectedProfile.layout?.matrix?.show_row_totals}
                              onChange={(e) =>
                                setSelectedProfile({
                                  ...selectedProfile,
                                  layout: {
                                    ...selectedProfile.layout,
                                    matrix: {
                                      ...selectedProfile.layout.matrix,
                                      show_row_totals: e.target.checked,
                                    },
                                  },
                                })
                              }
                              className="rounded border-border accent-brand"
                            />
                            <span>محاسبه جمع افقی سطرها (Row Totals)</span>
                          </label>

                          <label className="flex items-center gap-2 rounded border border-border bg-ink p-2 text-xs cursor-pointer">
                            <input
                              type="checkbox"
                              checked={!!selectedProfile.layout?.matrix?.show_col_totals}
                              onChange={(e) =>
                                setSelectedProfile({
                                  ...selectedProfile,
                                  layout: {
                                    ...selectedProfile.layout,
                                    matrix: {
                                      ...selectedProfile.layout.matrix,
                                      show_col_totals: e.target.checked,
                                    },
                                  },
                                })
                              }
                              className="rounded border-border accent-brand"
                            />
                            <span>محاسبه جمع عمودی ستون‌ها (Col Totals)</span>
                          </label>

                          <label className="flex items-center gap-2 rounded border border-border bg-ink p-2 text-xs cursor-pointer">
                            <input
                              type="checkbox"
                              checked={!!selectedProfile.layout?.matrix?.subtotals}
                              onChange={(e) =>
                                setSelectedProfile({
                                  ...selectedProfile,
                                  layout: {
                                    ...selectedProfile.layout,
                                    matrix: {
                                      ...selectedProfile.layout.matrix,
                                      subtotals: e.target.checked,
                                    },
                                  },
                                })
                              }
                              className="rounded border-border accent-brand"
                            />
                            <span>ریزجمع‌های سطوح فرعی (Subtotals)</span>
                          </label>
                        </div>

                        {/* Interactive Matrix Visual Simulation Preview */}
                        <div className="rounded border border-border bg-ink/70 p-3 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
                              <Eye className="h-3.5 w-3.5 text-brand" /> پیش‌نمایش بصری ساختار ماتریسی در گزارش RDL
                            </span>
                            <span className="font-mono text-[10px] text-muted-foreground">
                              چیدمان افقی {selectedProfile.layout.page_orientation || "Landscape"} · جهت{" "}
                              {selectedProfile.layout.direction || "RTL"}
                            </span>
                          </div>

                          <div className="overflow-x-auto rounded border border-border bg-surface">
                            <table className="w-full text-center text-xs border-collapse font-mono">
                              <thead>
                                <tr className="bg-slate-900 text-white font-sans text-[11px]">
                                  <th
                                    rowSpan={2}
                                    className="border border-border p-2 font-bold bg-slate-800"
                                  >
                                    سطرها (
                                    {selectedProfile.layout?.matrix?.row_groups?.join(" / ") || "گروه سطر"}
                                    )
                                  </th>
                                  <th
                                    colSpan={3}
                                    className="border border-border p-2 bg-brand/30 text-brand font-bold"
                                  >
                                    ستون پویا:{" "}
                                    {selectedProfile.layout?.matrix?.col_groups?.join(" / ") || "مقادیر بازه زمانی"}
                                  </th>
                                  {selectedProfile.layout?.matrix?.show_row_totals && (
                                    <th
                                      rowSpan={2}
                                      className="border border-border p-2 bg-slate-800 text-amber-300 font-bold"
                                    >
                                      جمع کل سطر
                                    </th>
                                  )}
                                </tr>
                                <tr className="bg-slate-800/80 text-foreground text-[10px]">
                                  <th className="border border-border p-1.5">دوره ۱</th>
                                  <th className="border border-border p-1.5">دوره ۲</th>
                                  <th className="border border-border p-1.5">دوره ۳</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-border text-foreground/90 text-[11px]">
                                <tr>
                                  <td className="border border-border p-2 text-start font-sans font-medium bg-surfaceHover/30">
                                    نمونه ردیف الف
                                  </td>
                                  <td className="border border-border p-2">۱۲,۵۰۰,۰۰۰</td>
                                  <td className="border border-border p-2">۱۸,۲۰۰,۰۰۰</td>
                                  <td className="border border-border p-2">۱۴,۷۰۰,۰۰۰</td>
                                  {selectedProfile.layout?.matrix?.show_row_totals && (
                                    <td className="border border-border p-2 font-bold text-amber-300 bg-surfaceHover/40">
                                      ۴۵,۴۰۰,۰۰۰
                                    </td>
                                  )}
                                </tr>
                                <tr>
                                  <td className="border border-border p-2 text-start font-sans font-medium bg-surfaceHover/30">
                                    نمونه ردیف ب
                                  </td>
                                  <td className="border border-border p-2">۹,۱۰۰,۰۰۰</td>
                                  <td className="border border-border p-2">۲۲,۰۰۰,۰۰۰</td>
                                  <td className="border border-border p-2">۱۱,۵۰۰,۰۰۰</td>
                                  {selectedProfile.layout?.matrix?.show_row_totals && (
                                    <td className="border border-border p-2 font-bold text-amber-300 bg-surfaceHover/40">
                                      ۴۲,۶۰۰,۰۰۰
                                    </td>
                                  )}
                                </tr>
                                {selectedProfile.layout?.matrix?.show_col_totals && (
                                  <tr className="bg-slate-900/60 font-bold text-amber-300">
                                    <td className="border border-border p-2 text-start font-sans">
                                      جمع کل ستون‌ها
                                    </td>
                                    <td className="border border-border p-2">۲۱,۶۰۰,۰۰۰</td>
                                    <td className="border border-border p-2">۴۰,۲۰۰,۰۰۰</td>
                                    <td className="border border-border p-2">۲۶,۲۰۰,۰۰۰</td>
                                    {selectedProfile.layout?.matrix?.show_row_totals && (
                                      <td className="border border-border p-2 text-emerald-400 bg-slate-900">
                                        ۸۸,۰۰۰,۰۰۰
                                      </td>
                                    )}
                                  </tr>
                                )}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    )}
                  </section>
                </>
              )}
            </div>
          )}

          {/* ══════════════════ TAB 2: AI MODELS & API KEYS ══════════════════ */}
          {activeTab === "models" && (
            <div className="space-y-6">
              {/* model preset */}
              <section className="rounded-md border border-border bg-surface p-4">
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-bold">
                    <Cpu className="h-4 w-4 text-brand" />
                    <span>انتخاب مدل فعال و ارائه‌دهنده (Active Provider & Preset)</span>
                  </div>
                  <span className="font-mono text-xs text-muted-foreground">
                    فعال: {settings.model_preset}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {Object.keys(PRESET_INFO).map((id) => {
                    const on = settings.model_preset === id;
                    const info = PRESET_INFO[id];
                    const ready =
                      info.provider === "emergent"
                        ? keys.emergent
                        : keys[info.provider] || presets[id]?.local;

                    return (
                      <button
                        key={id}
                        data-testid={`preset-${id}`}
                        onClick={() => patch("model_preset", id)}
                        className={`flex flex-col items-start gap-1 rounded-md border p-3 text-start text-xs transition-all ${
                          on
                            ? "border-brand bg-brand/10 text-white ring-1 ring-brand"
                            : "border-border text-muted-foreground hover:bg-surfaceHover hover:text-foreground"
                        }`}
                      >
                        <div className="flex w-full items-center justify-between">
                          <span className="font-semibold text-foreground">{info.label}</span>
                          <span
                            className={`font-mono text-[9px] ${
                              ready ? "text-ok" : "text-muted-foreground"
                            }`}
                          >
                            {ready ? "● آماده" : "○ بدون کلید"}
                          </span>
                        </div>
                        <span className="text-[10px] text-muted-foreground line-clamp-2">
                          {info.desc}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <div className="mt-4 grid gap-3 sm:grid-cols-2 pt-3 border-t border-border">
                  <Field label="نام مدل دلخواه یا نگارش خاص (Model Override - اختیاری)">
                    <Input
                      data-testid="model-override"
                      value={settings.model_override || ""}
                      onChange={(e) => patch("model_override", e.target.value)}
                      placeholder="مثلاً claude-3-7-sonnet یا gemini-3.1-pro-preview"
                      className="rounded-sm border-border bg-ink font-mono text-xs"
                      dir="ltr"
                    />
                  </Field>
                  <Field label="آدرس سرویس سازگار یا پراکسی (Base URL - اختیاری)">
                    <Input
                      data-testid="base-url"
                      value={settings.base_url || ""}
                      onChange={(e) => patch("base_url", e.target.value)}
                      placeholder="http://localhost:11434/v1 یا https://api.deepseek.com/v1"
                      className="rounded-sm border-border bg-ink font-mono text-xs"
                      dir="ltr"
                    />
                  </Field>
                </div>

                {/* Test Model Connection Button & Output */}
                <div className="mt-4 pt-3 border-t border-border flex flex-wrap items-center justify-between gap-3">
                  <Button
                    data-testid="test-model-btn"
                    onClick={testModel}
                    disabled={testing}
                    variant="outline"
                    size="sm"
                    className="gap-1.5 rounded border-border bg-ink hover:bg-surfaceHover text-xs"
                  >
                    {testing ? (
                      <Loader2 className="h-4 w-4 animate-spin text-brand" />
                    ) : (
                      <PlugZap className="h-4 w-4 text-brand" />
                    )}
                    <span>آزمایش اتصال به مدل فعال</span>
                  </Button>

                  {testResult && (
                    <div
                      className={`flex items-center gap-2 rounded px-3 py-1.5 text-xs border ${
                        testResult.ok
                          ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                          : "border-err/30 bg-err/10 text-err"
                      }`}
                    >
                      {testResult.ok ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-err" />
                      )}
                      <span>
                        {testResult.ok
                          ? `${testResult.reply} (${testResult.latency_ms}ms)`
                          : testResult.error}
                      </span>
                    </div>
                  )}
                </div>
              </section>

              {/* Personal API Keys Section */}
              <section className="rounded-md border border-border bg-surface p-4">
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-bold">
                    <KeyRound className="h-4 w-4 text-brand" />
                    <span>کلیدهای API شخصی کاربر (Personal API Keys)</span>
                  </div>
                  <span className="text-[11px] text-muted-foreground">
                    امکان استفاده از کلید اختصاصی Google Gemini, Anthropic Claude یا OpenAI
                  </span>
                </div>
                <p className="mb-4 text-xs text-muted-foreground leading-relaxed">
                  کلیدهای واردشده به‌صورت ایمن نگهداری شده و در صورت خالی بودن، موتور پردازشگر محلی (Heuristic Copilot)
                  یا کلید ابری سیستم به عنوان پشتیبان فعال خواهد بود.
                </p>

                <div className="grid gap-3 sm:grid-cols-2">
                  {KEY_FIELDS.map((f) => {
                    const isConfigured = keys[f.id];
                    return (
                      <div key={f.id} className="rounded border border-border bg-ink p-3 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-foreground">{f.label}</span>
                          {isConfigured ? (
                            <Sev severity="success">کلید تنظیم شده است</Sev>
                          ) : (
                            <span className="font-mono text-[10px] text-muted-foreground">
                              بدون کلید شخصی
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-muted-foreground">{f.desc}</p>
                        <Input
                          data-testid={`key-${f.id}`}
                          type="password"
                          value={keyInput[f.id] || ""}
                          onChange={(e) =>
                            setKeyInput((k) => ({ ...k, [f.id]: e.target.value }))
                          }
                          placeholder={isConfigured ? "•••••••••••• (جهت تغییر کلید تایپ کنید)" : f.ph}
                          className="h-8 rounded border-border bg-surface font-mono text-xs"
                          dir="ltr"
                        />
                      </div>
                    );
                  })}
                </div>
              </section>

              {/* Budget and loop config */}
              <section className="rounded-md border border-border bg-surface p-4">
                <div className="mb-3 flex items-center gap-2 text-sm font-bold">
                  <Wallet className="h-4 w-4 text-brand" /> سقف هزینه، جداول زمینه و مهلت پاسخ
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  <Field label="سقف هزینه روزانه ($)">
                    <Input
                      data-testid="budget"
                      type="number"
                      step="0.5"
                      value={settings.daily_budget_usd}
                      onChange={(e) => patch("daily_budget_usd", e.target.value)}
                      className="rounded-sm border-border bg-ink font-mono text-xs"
                      dir="ltr"
                    />
                  </Field>
                  <Field label="حداکثر تلاش خوداصلاحی">
                    <Input
                      data-testid="max-attempts"
                      type="number"
                      min="1"
                      max="8"
                      value={settings.max_attempts}
                      onChange={(e) => patch("max_attempts", e.target.value)}
                      className="rounded-sm border-border bg-ink font-mono text-xs"
                      dir="ltr"
                    />
                  </Field>
                  <Field label="تعداد جدول زمینه (Context Tables)">
                    <Input
                      data-testid="context-tables"
                      type="number"
                      min="2"
                      max="14"
                      value={settings.context_tables}
                      onChange={(e) => patch("context_tables", e.target.value)}
                      className="rounded-sm border-border bg-ink font-mono text-xs"
                      dir="ltr"
                    />
                  </Field>
                </div>
              </section>
            </div>
          )}

          {/* ══════════════════ TAB 3: DIAGNOSTICS ══════════════════ */}
          {activeTab === "diagnostics" && (
            <div className="space-y-4">
              <section className="rounded-md border border-border bg-surface p-4">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-foreground">
                      مرکز پایش سلامت و آزمون جامع سیستم (System Diagnostics)
                    </h3>
                    <p className="text-[11px] text-muted-foreground">
                      بررسی یکپارچه پایگاه دانش، اتصال هوش مصنوعی، کاتالوگ گزارش‌ها و پایگاه پروفایل‌های کاربر
                    </p>
                  </div>
                  <Button
                    onClick={runDiagnostics}
                    disabled={runningDiag}
                    className="h-8 gap-1.5 rounded bg-brand text-white text-xs hover:bg-brand/90"
                  >
                    {runningDiag ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <RefreshCw className="h-4 w-4" />
                    )}
                    <span>اجرای آزمون جامع تمام بخش‌ها</span>
                  </Button>
                </div>

                {!diagnosticsResult ? (
                  <div className="py-8 text-center text-xs text-muted-foreground">
                    جهت بررسی سلامت تمام ماژول‌ها و صحت اتصالات، دکمه «اجرای آزمون جامع تمام بخش‌ها» را کلیک نمایید.
                  </div>
                ) : (
                  <div className="mt-4 grid gap-3 sm:grid-cols-2">
                    {Object.entries(diagnosticsResult.diagnostics || {}).map(([key, item]) => (
                      <div
                        key={key}
                        className={`rounded border p-3.5 space-y-2 ${
                          item.status === "healthy"
                            ? "border-emerald-500/30 bg-emerald-500/5"
                            : "border-amber-500/30 bg-amber-500/5"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-foreground">{item.title}</span>
                          <span
                            className={`flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-bold ${
                              item.status === "healthy"
                                ? "bg-emerald-500/20 text-emerald-300"
                                : "bg-amber-500/20 text-amber-300"
                            }`}
                          >
                            {item.status === "healthy" ? (
                              <CheckCircle2 className="h-3 w-3" />
                            ) : (
                              <AlertTriangle className="h-3 w-3" />
                            )}
                            {item.status === "healthy" ? "سالم و آماده" : "نیازمند بررسی"}
                          </span>
                        </div>
                        <p className="text-xs text-foreground/80 leading-relaxed">{item.message}</p>
                        {item.latency_ms !== undefined && (
                          <div className="font-mono text-[10px] text-muted-foreground">
                            زمان پاسخ: {item.latency_ms} میلی‌ثانیه
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>
          )}
        </div>
      </ScrollArea>
    </>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-medium text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
