import { useState, useEffect, useRef } from "react";
import { http } from "@/lib/api";
import { ViewHeader } from "@/views/shared";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import Markdown from "react-markdown";
import { toast } from "sonner";
import {
  Send,
  Loader2,
  Sparkles,
  Bot,
  User,
  Trash2,
  Copy,
  Check,
  Settings2,
  Zap,
  ShieldCheck,
  BrainCircuit,
  SlidersHorizontal,
  FileCode2,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

const MODEL_CONFIGS = [
  {
    id: "gemini-3.1-pro-preview",
    label: "Gemini 3.1 Pro Preview",
    badge: "تحلیلی و عمیق",
    purpose: "وظایف تحلیلی پیچیده، معماری داده، تیونینگ سطح بالا (Complex Tasks)",
    icon: BrainCircuit,
    color: "text-purple-400 border-purple-500/30 bg-purple-500/10",
  },
  {
    id: "gemini-3.5-flash",
    label: "Gemini 3.5 Flash",
    badge: "عمومی و متوازن",
    purpose: "کارهای عمومی، فرمول‌نویسی SSRS، منطق کسب‌وکار (General Tasks)",
    icon: Sparkles,
    color: "text-brand border-brand/30 bg-brand/10",
    isDefault: true,
  },
  {
    id: "gemini-3.1-flash-lite",
    label: "Gemini 3.1 Flash Lite",
    badge: "فوق سریع",
    purpose: "پاسخ‌های بلادرنگ، راهنمای سریع و مفاهیم سبک (Fast Tasks)",
    icon: Zap,
    color: "text-amber-400 border-amber-500/30 bg-amber-500/10",
  },
];

const PRESET_ROLE_PROMPTS = {
  db_architect: [
    "چگونه ساختار ارتباطی بین جداول Voucher و VoucherDetail را برای سال‌های مالی متعدد بهینه کنم؟",
    "تفاوت Surrogate Key و Natural Key در سیستم‌های ERP سازمانی چیست و چه زمانی کدام را انتخاب کنیم؟",
    "یک استراتژی Partitioning برای جدول لاگ تراکنش‌های با حجم بالای ۵۰ میلیون رکورد پیشنهاد بده.",
  ],
  tsql_expert: [
    "کوئری محاسبه مانده تجمعی (Running Balance) حساب‌ها با Window Functions در SQL Server را بنویس.",
    "چگونه از بروز Implicit Conversion و افت کارایی در فیلترهای nvarchar جلوگیری کنیم؟",
    "تفاوت EXISTS با IN در ساب‌کوئری‌های T-SQL و تاثیر آن بر روی Execution Plan چیست؟",
  ],
  bi_analyst: [
    "چگونه یک گزارش ماتریسی SSRS با گروه‌بندی مرکز هزینه و سرستون ماه‌های سال ایجاد کنیم؟",
    "فرمول محاسبه درصد انحراف از بودجه و نمایش رنگی شرطی (KPI Indicator) در RDL را بگو.",
    "بهترین الگو برای مدیریت پارامترهای چندمقداره (Multi-value Parameters) در گزارش‌های سنگین چیست؟",
  ],
  general_erp: [
    "مراحل سند بستن حساب‌های موقت و انتقال سود و زیان انباشته در پایان سال مالی چگونه است؟",
    "تفاوت روش‌های قیمت‌گذاری انبار (میانگین موزون در مقابل FIFO) در گزارش بهای تمام شده چیست؟",
    "اصول ممیزی داخلی در گردش کار تایید فاکتور خرید و سند انبار در سیستم ERP چیست؟",
  ],
  custom: [
    "یک شرح مختصر از قابلیت‌های پایگاه داده و گزارش‌ساز بده.",
    "چگونه امنیت داده‌ها و تفکیک دسترسی شعب را در ERP رعایت کنیم؟",
  ],
};

export default function GeminiChatView({ onMenu }) {
  const [messages, setMessages] = useState([
    {
      role: "model",
      text: "سلام! من دستیار هوشمند جِمینای هستم. آماده‌ام به عنوان معمار پایگاه‌داده، متخصص بهینه‌سازی T-SQL یا مشاور ERP در کنار شما باشم. نقش و مدل مورد نظر خود را در بالا انتخاب کنید و سوال خود را مطرح نمایید.",
      timestamp: Date.now(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [roles, setRoles] = useState([]);
  const [selectedRoleKey, setSelectedRoleKey] = useState("db_architect");
  const [selectedModel, setSelectedModel] = useState("gemini-3.5-flash");
  const [customInstruction, setCustomInstruction] = useState("");
  const [showSystemPrompt, setShowSystemPrompt] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState(null);

  const scrollRef = useRef(null);

  // Load roles on mount
  useEffect(() => {
    http
      .get("/gemini/roles")
      .then(({ data }) => {
        if (data.roles) {
          setRoles(data.roles);
          const current = data.roles.find((r) => r.id === "db_architect");
          if (current) {
            setCustomInstruction(current.instruction);
          }
        }
      })
      .catch((err) => console.error("Failed to load roles:", err));
  }, []);

  // When role changes, update customInstruction preview
  const handleRoleChange = (roleId) => {
    setSelectedRoleKey(roleId);
    const r = roles.find((item) => item.id === roleId);
    if (r) {
      setCustomInstruction(r.instruction);
      if (r.suggestedModel) {
        setSelectedModel(r.suggestedModel);
      }
    }
  };

  // Scroll to bottom whenever messages update
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const activeRole = roles.find((r) => r.id === selectedRoleKey) || {
    id: selectedRoleKey,
    title: "معمار ارشد پایگاه‌داده",
    description: "طراحی معماری داده‌ها و مدیریت ساختار ERP",
  };

  const activeModelConfig =
    MODEL_CONFIGS.find((m) => m.id === selectedModel) || MODEL_CONFIGS[1];

  const handleSend = async (overrideText) => {
    const textToSend = (overrideText ?? input).trim();
    if (!textToSend || loading) return;

    const userMessage = {
      role: "user",
      text: textToSend,
      timestamp: Date.now(),
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInput("");
    setLoading(true);

    try {
      const payload = {
        messages: newHistory.map((m) => ({
          role: m.role === "user" ? "user" : "model",
          text: m.text,
        })),
        model: selectedModel,
        roleKey: selectedRoleKey,
        customInstruction: customInstruction.trim() || undefined,
        stream: false,
      };

      const { data } = await http.post("/gemini/chat", payload);

      if (data.text) {
        setMessages((prev) => [
          ...prev,
          {
            role: "model",
            text: data.text,
            model: data.model || selectedModel,
            timestamp: Date.now(),
          },
        ]);
      } else {
        toast.error("پاسخی از مدل دریافت نشد.");
      }
    } catch (err) {
      const msg = err.response?.data?.detail || err.message || "خطا در برقراری ارتباط با چت هوشمند";
      toast.error(msg);
      setMessages((prev) => [
        ...prev,
        {
          role: "model",
          text: `⚠️ **خطا در پردازش:** ${msg}`,
          isError: true,
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = () => {
    setMessages([
      {
        role: "model",
        text: `گفتگوی جدید آغاز شد. در حال حاضر به عنوان «${activeRole.title}» با مدل «${activeModelConfig.label}» آماده پاسخگویی هستم.`,
        timestamp: Date.now(),
      },
    ]);
    toast.success("تاریخچه گفتگو بازنشانی شد");
  };

  const handleCopyMessage = async (text, idx) => {
    await navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    toast.success("متن پیام کپی شد");
    setTimeout(() => setCopiedIndex(null), 1500);
  };

  const handleCopyConversation = async () => {
    const fullText = messages
      .map((m) => `[${m.role === "user" ? "کاربر" : "دستیار جِمینای"}]:\n${m.text}\n`)
      .join("\n---\n\n");
    await navigator.clipboard.writeText(fullText);
    toast.success("تمام متن گفتگو در حافظه کپی شد");
  };

  return (
    <div className="flex h-full flex-col overflow-hidden bg-background">
      <ViewHeader
        title="چت چندمرحله‌ای جِمینای (Multi-Turn Chat)"
        subtitle="گفتگو با نگهداری تاریخچه پیام‌ها، نقش‌های تخصصی و مدل‌های اختصاصی نسل ۳ جِمینای"
        onMenu={onMenu}
      >
        <Button
          variant="outline"
          size="sm"
          onClick={handleCopyConversation}
          className="gap-1.5 rounded-sm border-border bg-surface text-xs"
        >
          <Copy className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">کپی گفتگو</span>
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleClearHistory}
          className="gap-1.5 rounded-sm border-border bg-surface text-xs hover:text-err"
        >
          <Trash2 className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">پاکسازی</span>
        </Button>
      </ViewHeader>

      {/* Control Bar: Roles + Models + System Instruction Toggle */}
      <div className="border-b border-border bg-surface/60 p-3 sm:px-6">
        <div className="mx-auto flex max-w-5xl flex-col gap-3">
          {/* Upper row: Role Selector and Model Selector */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Roles Bar */}
            <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5">
              <span className="flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                <Bot className="h-3.5 w-3.5 text-brand" /> نقش دستیار:
              </span>
              <div className="flex flex-wrap gap-1">
                {(roles.length > 0
                  ? roles
                  : [
                      { id: "db_architect", title: "معمار پایگاه‌داده" },
                      { id: "tsql_expert", title: "متخصص T-SQL" },
                      { id: "bi_analyst", title: "تحلیل‌گر BI/SSRS" },
                      { id: "general_erp", title: "مشاور ERP" },
                      { id: "custom", title: "نقش سفارشی" },
                    ]
                ).map((r) => {
                  const active = selectedRoleKey === r.id;
                  return (
                    <button
                      key={r.id}
                      onClick={() => handleRoleChange(r.id)}
                      data-testid={`role-btn-${r.id}`}
                      className={`rounded-sm border px-2.5 py-1 text-xs font-medium transition-all ${
                        active
                          ? "border-brand bg-brand/15 text-white shadow-sm"
                          : "border-border bg-surface text-muted-foreground hover:bg-surfaceHover hover:text-foreground"
                      }`}
                    >
                      {r.title.split("(")[0].trim()}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Model Selector */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold text-muted-foreground">مدل:</span>
              <div className="flex items-center gap-1 rounded-sm border border-border bg-ink p-0.5">
                {MODEL_CONFIGS.map((m) => {
                  const active = selectedModel === m.id;
                  const Icon = m.icon;
                  return (
                    <button
                      key={m.id}
                      onClick={() => setSelectedModel(m.id)}
                      data-testid={`model-select-${m.id}`}
                      title={m.purpose}
                      className={`flex items-center gap-1.5 rounded-sm px-2 py-1 text-[11px] font-medium transition-all ${
                        active
                          ? "bg-surface text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <Icon className="h-3 w-3" />
                      <span className="hidden md:inline">{m.label.replace("Gemini ", "")}</span>
                      <span className="md:hidden">{m.badge}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Collapsible System Instruction Editor */}
          <div className="rounded-sm border border-border/70 bg-ink/50 p-2 text-xs">
            <button
              onClick={() => setShowSystemPrompt(!showSystemPrompt)}
              className="flex w-full items-center justify-between text-muted-foreground hover:text-foreground"
            >
              <span className="flex items-center gap-1.5">
                <SlidersHorizontal className="h-3.5 w-3.5 text-brand" />
                <span>
                  دستورالعمل سیستمی فعال (System Instruction):{" "}
                  <b className="font-normal text-foreground">{activeRole.title}</b>
                </span>
              </span>
              {showSystemPrompt ? (
                <ChevronUp className="h-3.5 w-3.5" />
              ) : (
                <ChevronDown className="h-3.5 w-3.5" />
              )}
            </button>

            {showSystemPrompt && (
              <div className="mt-2.5 space-y-2 pt-2 border-t border-border/50">
                <p className="text-[11px] text-muted-foreground">
                  این دستورالعمل به عنوان هویت و چارچوب فکری (System Prompt) در ابتدای چت به مدل منتقل
                  می‌گردد:
                </p>
                <Textarea
                  value={customInstruction}
                  onChange={(e) => setCustomInstruction(e.target.value)}
                  rows={3}
                  className="rounded-sm border-border bg-surface text-xs leading-relaxed"
                  placeholder="دستورالعمل نقشه دستیار را در اینجا ویرایش نمایید..."
                />
                <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                  <span>مدل پیشنهادی برای این نقش: <span className="font-mono text-brand">{selectedModel}</span></span>
                  <button
                    onClick={() => {
                      const r = roles.find((item) => item.id === selectedRoleKey);
                      if (r) setCustomInstruction(r.instruction);
                    }}
                    className="text-brand hover:underline"
                  >
                    بازنشانی به متن پیش‌فرض نقش
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Scrollable Message Thread */}
      <div className="flex-1 overflow-hidden">
        <div ref={scrollRef} className="h-full space-y-4 overflow-y-auto p-4 sm:p-6">
          <div className="mx-auto max-w-4xl space-y-4">
            {messages.map((m, idx) => {
              const isUser = m.role === "user";
              return (
                <div
                  key={`chat-msg-${idx}`}
                  data-testid={`message-${m.role}-${idx}`}
                  className={`flex gap-3 rc-fade-up ${isUser ? "flex-row-reverse" : "flex-row"}`}
                >
                  {/* Avatar */}
                  <div
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-sm ${
                      isUser ? "bg-brand text-white" : "bg-surface border border-border text-brand"
                    }`}
                  >
                    {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                  </div>

                  {/* Message Bubble */}
                  <div
                    className={`max-w-[85%] rounded-sm border p-3.5 sm:max-w-[78%] ${
                      isUser
                        ? "border-brand/40 bg-brand/10 text-foreground"
                        : m.isError
                        ? "border-err/40 bg-err/10 text-foreground"
                        : "border-border bg-surface text-foreground"
                    }`}
                  >
                    {/* Header */}
                    <div className="mb-2 flex items-center justify-between gap-3 border-b border-border/40 pb-1.5 text-[11px] text-muted-foreground">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-foreground">
                          {isUser ? "شما" : activeRole.title.split("(")[0]}
                        </span>
                        {!isUser && m.model && (
                          <span className="rounded-sm bg-ink px-1.5 py-0.2 font-mono text-[10px] text-brand border border-brand/20">
                            {m.model}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {m.timestamp && (
                          <span className="text-[10px] opacity-70">
                            {new Date(m.timestamp).toLocaleTimeString("fa-IR", {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                        )}
                        <button
                          onClick={() => handleCopyMessage(m.text, idx)}
                          title="کپی پیام"
                          className="text-muted-foreground hover:text-foreground"
                        >
                          {copiedIndex === idx ? (
                            <Check className="h-3.5 w-3.5 text-ok" />
                          ) : (
                            <Copy className="h-3.5 w-3.5" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Body */}
                    <div className="markdown-body text-sm leading-relaxed" dir="auto">
                      <Markdown>{m.text}</Markdown>
                    </div>
                  </div>
                </div>
              );
            })}

            {loading && (
              <div className="flex gap-3 rc-fade-up">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-sm border border-border bg-surface text-brand">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
                <div className="rounded-sm border border-border bg-surface p-3 text-xs text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <span>در حال تفکر و پردازش با {activeModelConfig.label}…</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Suggested Prompts for active role */}
      {PRESET_ROLE_PROMPTS[selectedRoleKey]?.length > 0 && (
        <div className="border-t border-border/60 bg-surface/30 px-4 py-2 sm:px-6">
          <div className="mx-auto flex max-w-4xl items-center gap-2 overflow-x-auto text-xs scrollbar-none">
            <span className="shrink-0 text-[11px] font-medium text-muted-foreground flex items-center gap-1">
              <Sparkles className="h-3 w-3 text-brand" /> پیشنهاد:
            </span>
            {PRESET_ROLE_PROMPTS[selectedRoleKey].map((prompt, i) => (
              <button
                key={`preset-${i}`}
                onClick={() => handleSend(prompt)}
                disabled={loading}
                className="shrink-0 rounded-sm border border-border bg-surface px-2.5 py-1 text-[11px] text-muted-foreground transition-colors hover:border-brand/50 hover:bg-surfaceHover hover:text-foreground"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Composer Input Area */}
      <div className="border-t border-border bg-surface/80 p-3 sm:px-6 sm:py-4">
        <div className="mx-auto flex max-w-4xl items-end gap-2">
          <div className="relative flex-1">
            <Textarea
              data-testid="gemini-chat-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={`از ${activeRole.title.split("(")[0]} سوال بپرسید... (Shift+Enter برای خط جدید)`}
              rows={2}
              className="min-h-[56px] resize-none rounded-sm border-border bg-ink px-3 py-2 text-sm leading-relaxed"
            />
          </div>
          <Button
            data-testid="gemini-chat-send"
            onClick={() => handleSend()}
            disabled={loading || !input.trim()}
            className="h-[56px] shrink-0 gap-2 rounded-sm bg-brand px-6 hover:bg-brand/90"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
            <span>ارسال</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
