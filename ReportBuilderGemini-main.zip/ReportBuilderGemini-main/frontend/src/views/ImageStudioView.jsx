import { useState, useEffect, useRef } from "react";
import { http } from "@/lib/api";
import { ViewHeader } from "@/views/shared";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  Wand2,
  Image as ImageIcon,
  Upload,
  Download,
  Loader2,
  Sparkles,
  RefreshCw,
  Sliders,
  Layers,
  Check,
  Copy,
  ExternalLink,
  ArrowRight,
  Edit3,
  X,
  FileImage,
  AlertCircle,
} from "lucide-react";

const ASPECT_RATIOS = [
  { id: "1:1", label: "1:1", desc: "مربع (Square)" },
  { id: "16:9", label: "16:9", desc: "عریض (Landscape)" },
  { id: "4:3", label: "4:3", desc: "استاندارد (Classic)" },
  { id: "9:16", label: "9:16", desc: "عمودی (Portrait)" },
  { id: "3:4", label: "3:4", desc: "عمودی استاندارد" },
];

const PRESET_IMAGE_PROMPTS = [
  "داشبورد تحلیلی مدرن با نمودارهای مالی و کارت‌های آماری در تم تیره نئونی",
  "دیاگرام ارتباطات پایگاه داده ERP با جداول سند حسابداری و ماتریس ارتباطی ERD",
  "لوگوی سازمانی حرفه‌ای و مینیمال برای سامانه گزارش‌ساز سازمانی SSRS",
  "اینفوگرافیک فرآیند گردش اسناد مالی و انبارداری با آیکون‌های خطی شیک",
  "طراحی گرافیکی هدر گزارش رسمی با زمینه گرادیانت آبی عمیق و بافت خطی",
];

export default function ImageStudioView({ onMenu }) {
  const [tab, setTab] = useState("create"); // "create" | "edit"
  const [prompt, setPrompt] = useState("");
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [loading, setLoading] = useState(false);

  // Edit Mode States
  const [sourceImage, setSourceImage] = useState(null); // base64 string
  const [sourceImageName, setSourceImageName] = useState("");
  const [sourceMimeType, setSourceMimeType] = useState("image/png");

  // Result States
  const [currentResult, setCurrentResult] = useState(null);
  const [gallery, setGallery] = useState([]);
  const [copiedLink, setCopiedLink] = useState(false);

  const fileInputRef = useRef(null);

  // Load gallery on mount
  const loadGallery = async () => {
    try {
      const { data } = await http.get("/gemini/images");
      if (data.images) {
        setGallery(data.images);
      }
    } catch (err) {
      console.error("Failed to load images gallery:", err);
    }
  };

  useEffect(() => {
    loadGallery();
  }, []);

  // Handle File Upload for Editing
  const handleFileUpload = (file) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("لطفاً یک فایل تصویری (PNG, JPG, WebP) انتخاب فرمایید.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      setSourceImage(e.target.result);
      setSourceImageName(file.name);
      setSourceMimeType(file.type);
      toast.success(`تصویر «${file.name}» برای ویرایش بارگذاری شد.`);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFileUpload(file);
  };

  // Submit action: Create or Edit
  const handleGenerateOrEdit = async () => {
    const trimmedPrompt = prompt.trim();
    if (!trimmedPrompt) {
      toast.error("لطفاً متن توصیفی (پرامپت) را وارد فرمایید.");
      return;
    }

    if (tab === "edit" && !sourceImage) {
      toast.error("برای ویرایش، ابتدا یک تصویر اولیه بارگذاری فرمایید.");
      return;
    }

    setLoading(true);

    try {
      const payload = {
        action: tab,
        prompt: trimmedPrompt,
        aspectRatio,
        image: tab === "edit" ? sourceImage : undefined,
        mimeType: tab === "edit" ? sourceMimeType : undefined,
        model: "gemini-3.1-flash-image-preview",
      };

      const { data } = await http.post("/gemini/image", payload);

      if (data.success && data.imageUrl) {
        setCurrentResult(data);
        if (data.warning) {
          toast.warning(data.warning, { duration: 6000 });
        } else {
          toast.success(
            tab === "create"
              ? "تصویر با مدل gemini-3.1-flash-image-preview تولید شد"
              : "ویرایش تصویر با موفقیت انجام گردید"
          );
        }
        loadGallery();
      } else {
        toast.error("پاسخی معتبر از مدل تصویر دریافت نشد.");
      }
    } catch (err) {
      const msg = err.response?.data?.detail || err.message || "خطا در پردازش تصویر";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  // Switch result image to be edited
  const handleSendToEdit = (imgDataUrl, filename = "generated-image.png") => {
    setSourceImage(imgDataUrl);
    setSourceImageName(filename);
    setSourceMimeType("image/png");
    setTab("edit");
    setPrompt("");
    toast.info("تصویر انتخاب‌شده در حالت ویرایش قرار گرفت.");
  };

  const handleCopyLink = async (url) => {
    const fullUrl = window.location.origin + url;
    await navigator.clipboard.writeText(fullUrl);
    setCopiedLink(true);
    toast.success("لینک تصویر در حافظه کپی شد");
    setTimeout(() => setCopiedLink(false), 1500);
  };

  return (
    <div className="flex h-full flex-col overflow-hidden bg-background">
      <ViewHeader
        title="استودیو تولید و ویرایش تصویر (Gemini Image Studio)"
        subtitle="طراحی، تولید و ویرایش هوشمند تصاویر با مدل اختصاصی gemini-3.1-flash-image-preview"
        onMenu={onMenu}
      >
        <div className="flex items-center gap-1.5 rounded-sm border border-brand/30 bg-brand/10 px-2.5 py-1 text-xs font-mono text-brand">
          <Wand2 className="h-3.5 w-3.5" />
          <span>gemini-3.1-flash-image-preview</span>
        </div>
      </ViewHeader>

      <div className="flex flex-1 min-h-0 flex-col lg:flex-row overflow-hidden">
        {/* Left Side: Controls & Prompts */}
        <div className="flex w-full flex-col border-b border-border bg-surface/40 p-4 sm:p-6 lg:w-[460px] lg:border-b-0 lg:border-s overflow-y-auto">
          {/* Tab switch: Create vs Edit */}
          <div className="mb-4 flex rounded-sm border border-border bg-ink p-1">
            <button
              onClick={() => setTab("create")}
              data-testid="tab-create-image"
              className={`flex flex-1 items-center justify-center gap-2 rounded-sm py-2 text-xs font-semibold transition-all ${
                tab === "create"
                  ? "bg-brand text-white shadow"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" />
              تولید تصویر جدید (Create)
            </button>
            <button
              onClick={() => setTab("edit")}
              data-testid="tab-edit-image"
              className={`flex flex-1 items-center justify-center gap-2 rounded-sm py-2 text-xs font-semibold transition-all ${
                tab === "edit"
                  ? "bg-brand text-white shadow"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Edit3 className="h-3.5 w-3.5" />
              ویرایش تصویر (Edit)
            </button>
          </div>

          {/* Edit Mode: Source Image Upload */}
          {tab === "edit" && (
            <div className="mb-4 space-y-2">
              <label className="text-xs font-semibold text-foreground flex items-center justify-between">
                <span>تصویر مبدا برای ویرایش:</span>
                {sourceImage && (
                  <button
                    onClick={() => {
                      setSourceImage(null);
                      setSourceImageName("");
                    }}
                    className="text-[11px] text-err hover:underline"
                  >
                    حذف تصویر
                  </button>
                )}
              </label>

              {sourceImage ? (
                <div className="relative rounded-sm border border-brand/40 bg-ink p-2 flex items-center gap-3">
                  <img
                    src={sourceImage}
                    alt="Source"
                    className="h-16 w-16 rounded-sm object-cover border border-border"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-medium text-foreground">{sourceImageName}</p>
                    <p className="text-[10px] text-muted-foreground">آماده پردازش و ویرایش متنی</p>
                  </div>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="rounded-sm border border-border bg-surface px-2 py-1 text-xs text-muted-foreground hover:text-foreground"
                  >
                    تغییر
                  </button>
                </div>
              ) : (
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className="cursor-pointer rounded-sm border-2 border-dashed border-border p-5 text-center transition-colors hover:border-brand/60 hover:bg-surfaceHover"
                >
                  <Upload className="mx-auto h-6 w-6 text-muted-foreground mb-2" />
                  <p className="text-xs font-medium text-foreground">
                    کلیک برای انتخاب یا کشیدن و رها کردن تصویر
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    پشتیبانی از PNG، JPG و WebP
                  </p>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleFileUpload(e.target.files?.[0])}
              />
            </div>
          )}

          {/* Aspect Ratio Selector (mostly for Create) */}
          {tab === "create" && (
            <div className="mb-4 space-y-1.5">
              <label className="text-xs font-semibold text-foreground">نسبت ابعاد تصویر (Aspect Ratio):</label>
              <div className="grid grid-cols-5 gap-1">
                {ASPECT_RATIOS.map((ar) => (
                  <button
                    key={ar.id}
                    onClick={() => setAspectRatio(ar.id)}
                    className={`rounded-sm border py-1.5 text-center text-xs transition-all ${
                      aspectRatio === ar.id
                        ? "border-brand bg-brand/15 text-white font-bold"
                        : "border-border bg-ink text-muted-foreground hover:bg-surfaceHover hover:text-foreground"
                    }`}
                  >
                    <div>{ar.label}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Prompt Input */}
          <div className="mb-4 space-y-1.5 flex-1">
            <label className="text-xs font-semibold text-foreground flex items-center justify-between">
              <span>{tab === "create" ? "متن پرامپت تولید تصویر:" : "دستورالعمل ویرایش تصویر:"}</span>
              <span className="text-[11px] text-muted-foreground font-normal">فارسی یا انگلیسی</span>
            </label>
            <Textarea
              data-testid="image-prompt-input"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={
                tab === "create"
                  ? "مثلاً: دیاگرام ارتباطات پایگاه داده ERP با جداول سند حسابداری در تم تیره مدرن..."
                  : "مثلاً: رنگ پس‌زمینه را به سرمه‌ای تیره تغییر بده و لوگوی شرکت را در بالا اضافه کن..."
              }
              rows={4}
              className="resize-none rounded-sm border-border bg-ink text-xs leading-relaxed"
            />
          </div>

          {/* Preset Suggestions */}
          <div className="mb-4 space-y-1.5">
            <span className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
              <Sparkles className="h-3 w-3 text-brand" /> ایده‌ها و پرامپت‌های پیشنهادی:
            </span>
            <div className="flex flex-col gap-1">
              {PRESET_IMAGE_PROMPTS.map((p, i) => (
                <button
                  key={`preset-p-${i}`}
                  onClick={() => setPrompt(p)}
                  className="rounded-sm border border-border/70 bg-ink/70 px-2.5 py-1.5 text-start text-[11px] text-muted-foreground transition-colors hover:border-brand/40 hover:text-foreground hover:bg-surface"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Action Button */}
          <Button
            data-testid="image-submit-btn"
            onClick={handleGenerateOrEdit}
            disabled={loading || !prompt.trim() || (tab === "edit" && !sourceImage)}
            className="w-full gap-2 rounded-sm bg-brand py-2.5 text-sm font-semibold hover:bg-brand/90"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                در حال پردازش با gemini-3.1-flash-image-preview…
              </>
            ) : tab === "create" ? (
              <>
                <Sparkles className="h-4 w-4" />
                تولید تصویر با جِمینای
              </>
            ) : (
              <>
                <Edit3 className="h-4 w-4" />
                اعمال ویرایش بر روی تصویر
              </>
            )}
          </Button>

          <p className="mt-2 text-center text-[10px] text-muted-foreground">
            استفاده از مدل رسمی <span className="font-mono text-brand">gemini-3.1-flash-image-preview</span>
          </p>
        </div>

        {/* Right Side: Preview & History Gallery */}
        <div className="flex flex-1 flex-col overflow-y-auto p-4 sm:p-6 bg-background">
          <div className="mx-auto flex w-full max-w-4xl flex-col gap-6">
            {/* Current Active Preview */}
            <div className="rounded-sm border border-border bg-surface p-4 sm:p-6">
              <div className="mb-3 flex items-center justify-between border-b border-border pb-2.5">
                <div className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4 text-brand" />
                  <h3 className="text-sm font-bold text-foreground">
                    {currentResult ? "پیش‌نمایش نتیجه تولید/ویرایش" : "پیش‌نمایش استودیو"}
                  </h3>
                </div>
                {currentResult && (
                  <div className="flex items-center gap-2">
                    <span className="rounded-sm bg-brand/15 px-2 py-0.5 font-mono text-[10px] text-brand border border-brand/30">
                      {currentResult.model}
                    </span>
                    <span className="text-xs text-muted-foreground font-mono">
                      {currentResult.aspectRatio}
                    </span>
                  </div>
                )}
              </div>

              {currentResult ? (
                <div className="space-y-4">
                  {currentResult.warning && (
                    <div className="flex items-start gap-2 rounded-sm border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200">
                      <AlertCircle className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
                      <div className="leading-relaxed">{currentResult.warning}</div>
                    </div>
                  )}

                  {/* Main Rendered Image */}
                  <div className="relative flex items-center justify-center overflow-hidden rounded-sm border border-border bg-ink p-2">
                    <img
                      src={currentResult.imageUrl}
                      alt={currentResult.prompt}
                      className="max-h-[440px] w-auto max-w-full rounded-sm object-contain shadow-lg"
                    />
                  </div>

                  {/* Details and Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-foreground">
                        پرامپت: <span className="font-normal text-muted-foreground">{currentResult.prompt}</span>
                      </p>
                      {currentResult.description && (
                        <p className="mt-0.5 text-[11px] text-muted-foreground">
                          {currentResult.description}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <a
                        href={currentResult.downloadUrl || currentResult.imageUrl}
                        download={currentResult.filename || "gemini-image.png"}
                        className="flex items-center gap-1.5 rounded-sm bg-brand px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-brand/90"
                      >
                        <Download className="h-3.5 w-3.5" />
                        دانلود تصویر
                      </a>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() =>
                          handleSendToEdit(currentResult.imageUrl, currentResult.filename)
                        }
                        className="gap-1.5 rounded-sm border-border bg-surface text-xs hover:border-brand/50 hover:text-brand"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                        ویرایش این تصویر
                      </Button>

                      {currentResult.downloadUrl && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCopyLink(currentResult.downloadUrl)}
                          className="gap-1.5 rounded-sm border-border bg-surface text-xs"
                        >
                          {copiedLink ? (
                            <Check className="h-3.5 w-3.5 text-ok" />
                          ) : (
                            <Copy className="h-3.5 w-3.5" />
                          )}
                          کپی لینک
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex min-h-[300px] flex-col items-center justify-center rounded-sm border border-dashed border-border bg-ink/40 p-8 text-center">
                  <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-sm bg-surface border border-border text-brand">
                    <ImageIcon className="h-6 w-6" />
                  </div>
                  <h4 className="text-sm font-semibold text-foreground">تصویری هنوز تولید نشده است</h4>
                  <p className="mt-1 max-w-sm text-xs text-muted-foreground">
                    در پنل کناری، یک پرامپت توصیفی وارد کرده یا تصویری برای ویرایش بارگذاری کنید و دکمه
                    پردازش را فشار دهید.
                  </p>
                </div>
              )}
            </div>

            {/* Gallery Section */}
            <div className="rounded-sm border border-border bg-surface p-4 sm:p-6">
              <div className="mb-3 flex items-center justify-between border-b border-border pb-2.5">
                <div className="flex items-center gap-2">
                  <Layers className="h-4 w-4 text-brand" />
                  <h3 className="text-sm font-bold text-foreground">گالری تصاویر ذخیره‌شده اخیر</h3>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={loadGallery}
                  className="gap-1 text-xs text-muted-foreground hover:text-foreground"
                >
                  <RefreshCw className="h-3 w-3" /> تازه‌سازی
                </Button>
              </div>

              {gallery.length > 0 ? (
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
                  {gallery.map((img, i) => (
                    <div
                      key={`gallery-img-${i}`}
                      className="group relative flex flex-col overflow-hidden rounded-sm border border-border bg-ink p-1.5 transition-all hover:border-brand/50"
                    >
                      <div className="relative aspect-square w-full overflow-hidden rounded-sm bg-surface">
                        <img
                          src={img.url}
                          alt={img.filename}
                          className="h-full w-full object-cover transition-transform group-hover:scale-105"
                        />
                      </div>
                      <div className="mt-1.5 flex items-center justify-between gap-1 text-[11px]">
                        <span className="truncate text-muted-foreground font-mono">
                          {img.filename}
                        </span>
                        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                          <button
                            onClick={() => handleSendToEdit(img.url, img.filename)}
                            title="ویرایش این تصویر"
                            className="rounded p-1 text-muted-foreground hover:bg-surfaceHover hover:text-brand"
                          >
                            <Edit3 className="h-3 w-3" />
                          </button>
                          <a
                            href={img.url}
                            download={img.filename}
                            title="دانلود"
                            className="rounded p-1 text-muted-foreground hover:bg-surfaceHover hover:text-ok"
                          >
                            <Download className="h-3 w-3" />
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="py-6 text-center text-xs text-muted-foreground">
                  هنوز تصویری در حافظه سرور ذخیره نشده است.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
