import { useEffect, useState, useCallback } from "react";
import { http } from "@/lib/api";
import { ViewHeader, Sev, CategoryPicker } from "@/views/shared";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  FolderOpen,
  Layers,
  Hash,
  Repeat,
  Plus,
  Loader2,
  Lightbulb,
  Download,
  Search,
  Folder,
  Files,
  MessageSquarePlus,
} from "lucide-react";

const BACKEND = (typeof process !== "undefined" && process.env && process.env.REACT_APP_BACKEND_URL) || "";

export default function CatalogView({ onMenu, onReuse }) {
  const [items, setItems] = useState([]);
  const [stats, setStats] = useState(null);
  const [categories, setCategories] = useState([]);
  const [active, setActive] = useState(null); // null = all
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (q.trim()) params.q = q.trim();
      else if (active !== null) params.category = active;
      const { data } = await http.get("/reports", { params });
      setItems(data.results || []);
      setCategories(data.categories || []);
      if (data.stats) setStats(data.stats);
    } finally {
      setLoading(false);
    }
  }, [q, active]);

  useEffect(() => {
    load();
  }, [load]);

  const totalCount = categories.reduce((s, c) => s + c.count, 0);

  return (
    <>
      <ViewHeader
        title="کاتالوگ گزارش‌ها"
        subtitle="گزارش‌های ساخته‌شده، دسته‌بندی‌شده در فولدرهای ماژول"
        onMenu={onMenu}
      >
        <div className="relative hidden sm:block">
          <Search className="absolute end-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            data-testid="catalog-search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جست‌وجو…"
            className="h-8 w-48 rounded-sm border-border bg-surface pe-7 text-xs"
          />
        </div>
      </ViewHeader>

      <div className="flex min-h-0 flex-1">
        {/* folder sidebar */}
        <div className="hidden w-56 shrink-0 flex-col border-s border-border bg-surface/40 md:flex">
          <div className="border-b border-border px-3 py-2.5 text-xs text-muted-foreground">فولدرها</div>
          <ScrollArea className="flex-1">
            <div className="p-2">
              <FolderRow
                icon={Files}
                label="همه گزارش‌ها"
                count={totalCount}
                active={active === null && !q}
                onClick={() => {
                  setQ("");
                  setActive(null);
                }}
                testid="folder-all"
              />
              {categories.map((c) => (
                <FolderRow
                  key={c.name || "_none"}
                  icon={Folder}
                  label={c.name || "بدون دسته"}
                  count={c.count}
                  active={active === c.name && !q}
                  onClick={() => {
                    setQ("");
                    setActive(c.name);
                  }}
                  testid={`folder-${c.name || "none"}`}
                />
              ))}
            </div>
          </ScrollArea>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-4 sm:p-6">
            {/* mobile folder chips */}
            <div className="mb-3 flex flex-wrap gap-1.5 md:hidden">
              <Chip testid="folder-all" active={active === null && !q} onClick={() => { setQ(""); setActive(null); }} label={`همه (${totalCount})`} />
              {categories.map((c) => (
                <Chip key={c.name || "_n"} testid={`folder-${c.name || "none"}`} active={active === c.name && !q} onClick={() => { setQ(""); setActive(c.name); }} label={`${c.name || "بدون دسته"} (${c.count})`} />
              ))}
            </div>

            {loading ? (
              <div className="flex h-64 items-center justify-center text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin" />
              </div>
            ) : items.length === 0 ? (
              <div className="flex h-64 flex-col items-center justify-center gap-2 text-center text-sm text-muted-foreground">
                <FolderOpen className="h-8 w-8 opacity-40" />
                گزارشی در این فولدر نیست. از بخش گفتگو یا آپلود، گزارشی بسازید و ذخیره کنید.
              </div>
            ) : (
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {items.map((e) => (
                  <ReportCard key={e.slug} e={e} categories={categories} onChanged={load} onReuse={onReuse} />
                ))}
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </>
  );
}

function FolderRow({ icon: Icon, label, count, active, onClick, testid }) {
  return (
    <button
      data-testid={testid}
      onClick={onClick}
      className={`mb-1 flex w-full items-center justify-between gap-2 rounded-sm px-2 py-2 text-xs transition-colors ${
        active ? "bg-brand/15 text-white" : "text-muted-foreground hover:bg-surfaceHover"
      }`}
    >
      <span className="flex items-center gap-1.5 truncate"><Icon className="h-3.5 w-3.5 shrink-0" /> {label}</span>
      <span className="font-mono text-[10px]">{count}</span>
    </button>
  );
}

function Chip({ active, onClick, label, testid }) {
  return (
    <button
      data-testid={testid}
      onClick={onClick}
      className={`rounded-sm border px-2 py-1 text-[11px] transition-colors ${
        active ? "border-brand bg-brand/10 text-brand" : "border-border bg-ink text-muted-foreground"
      }`}
    >
      {label}
    </button>
  );
}

function ReportCard({ e, categories, onChanged, onReuse }) {
  const [lesson, setLesson] = useState("");
  const [saving, setSaving] = useState(false);

  const addLesson = async () => {
    if (!lesson.trim()) return;
    setSaving(true);
    try {
      await http.post("/knowledge", { kind: "lesson", payload: { slug: e.slug, lesson: lesson.trim() } });
      toast.success("درس ثبت شد");
      setLesson("");
      onChanged?.();
    } catch (err) {
      toast.error("خطا: " + (err.response?.data?.detail || err.message));
    } finally {
      setSaving(false);
    }
  };

  const setCategory = async (category) => {
    try {
      await http.post(`/reports/${encodeURIComponent(e.slug)}/category`, { category });
      toast.success(category ? `به فولدر «${category}» منتقل شد` : "از فولدر خارج شد");
      onChanged?.();
    } catch (err) {
      toast.error("خطا: " + (err.response?.data?.detail || err.message));
    }
  };

  return (
    <div
      data-testid={`catalog-${e.slug}`}
      className="flex flex-col rounded-sm border border-border bg-surface p-3 transition-colors hover:border-brand/40"
    >
      <div className="mb-2 flex items-start justify-between gap-2">
        <div className="text-sm font-semibold">{e.title_fa}</div>
        <CategoryPicker
          categories={categories}
          value={e.category || ""}
          onChange={setCategory}
          testid={`cat-${e.slug}`}
        />
      </div>
      <div className="mb-2 flex flex-wrap gap-1">
        {(e.tables || []).slice(0, 4).map((t) => (
          <span key={t} className="rounded-sm border border-border bg-ink px-1.5 py-0.5 font-mono text-[10px] text-slate-300">
            {t}
          </span>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] text-muted-foreground">
        <span className="flex items-center gap-1"><Layers className="h-3 w-3" /> {e.layout_kind}</span>
        <span className="flex items-center gap-1"><Hash className="h-3 w-3" /> {(e.parameters || []).length} پارامتر</span>
        <span className="flex items-center gap-1"><Repeat className="h-3 w-3" /> {e.used_count || 0}</span>
      </div>
      {e.lessons?.length > 0 && (
        <ul className="mt-2 space-y-1 text-[11px] text-slate-400">
          {e.lessons.slice(0, 4).map((l, i) => (
            <li key={i} className="flex items-start gap-1">
              <Lightbulb className="mt-0.5 h-3 w-3 shrink-0 text-warn" /> {l}
            </li>
          ))}
        </ul>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-1.5 border-t border-border pt-3">
        <span className="flex items-center gap-1 text-[10px] text-muted-foreground"><Download className="h-3 w-3" /></span>
        <a data-testid={`dl-sql-${e.slug}`} href={`${BACKEND}/api/reports/${encodeURIComponent(e.slug)}/file/sql`} className="rounded-sm border border-border bg-ink px-1.5 py-0.5 font-mono text-[10px] text-slate-300 transition-colors hover:border-brand/50 hover:text-brand">.sql</a>
        <a data-testid={`dl-txt-${e.slug}`} href={`${BACKEND}/api/reports/${encodeURIComponent(e.slug)}/file/txt`} className="rounded-sm border border-border bg-ink px-1.5 py-0.5 font-mono text-[10px] text-slate-300 transition-colors hover:border-brand/50 hover:text-brand">.txt</a>
        {e.rdl_path && (
          <a data-testid={`dl-rdl-${e.slug}`} href={`${BACKEND}/api/reports/${encodeURIComponent(e.slug)}/file/rdl`} className="rounded-sm border border-brand/40 bg-brand/10 px-1.5 py-0.5 font-mono text-[10px] text-brand transition-colors hover:bg-brand/20">.rdl</a>
        )}
        {onReuse && (e.request_fa || e.title_fa) && (
          <button
            data-testid={`reuse-${e.slug}`}
            onClick={() => onReuse(e.request_fa || e.title_fa)}
            className="ms-auto flex items-center gap-1 rounded-sm border border-border bg-ink px-2 py-0.5 text-[10px] text-muted-foreground transition-colors hover:border-brand/50 hover:text-brand"
          >
            <MessageSquarePlus className="h-3 w-3" /> استفاده مجدد
          </button>
        )}
      </div>

      <div className="mt-2 flex gap-1">
        <Input
          data-testid={`lesson-input-${e.slug}`}
          value={lesson}
          onChange={(ev) => setLesson(ev.target.value)}
          onKeyDown={(ev) => ev.key === "Enter" && addLesson()}
          placeholder="افزودن درس آموخته‌شده…"
          className="h-8 rounded-sm border-border bg-ink text-xs"
        />
        <Button
          data-testid={`lesson-add-${e.slug}`}
          onClick={addLesson}
          disabled={saving || !lesson.trim()}
          size="sm"
          className="h-8 shrink-0 rounded-sm bg-brand px-2 hover:bg-brand/90"
        >
          {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
        </Button>
      </div>
    </div>
  );
}
