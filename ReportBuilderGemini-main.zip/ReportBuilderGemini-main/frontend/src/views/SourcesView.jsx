import { useRef, useState, useEffect } from "react";
import { API, http } from "@/lib/api";
import { ViewHeader, Sev, SqlBlock, CategoryPicker } from "@/views/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import {
  UploadCloud,
  Loader2,
  FileCode2,
  FileText,
  GraduationCap,
  RefreshCw,
  Check,
  Database,
  Save,
} from "lucide-react";

export default function SourcesView({ onMenu }) {
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [titles, setTitles] = useState({}); // full_name -> title_fa
  const [added, setAdded] = useState({}); // full_name -> true
  const [learning, setLearning] = useState(false);
  const [rebuilding, setRebuilding] = useState(false);
  const [category, setCategory] = useState("");
  const [categories, setCategories] = useState([]);
  const [savedLib, setSavedLib] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => {
    http.get("/categories").then(({ data }) => setCategories(data.categories || [])).catch(() => {});
  }, []);

  const onFile = async (file) => {
    if (!file) return;
    const ext = "." + file.name.split(".").pop().toLowerCase();
    if (![".rdl", ".sql", ".txt", ".xml"].includes(ext)) {
      toast.error("فقط .rdl / .sql / .txt پشتیبانی می‌شود.");
      return;
    }
    setUploading(true);
    setResult(null);
    setTitles({});
    setAdded({});
    setSavedLib(false);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch(`${API}/upload`, { method: "POST", body: fd });
      if (!res.ok) throw new Error((await res.text()) || `HTTP ${res.status}`);
      const data = await res.json();
      setResult(data);
      toast.success(`«${data.filename}» تحلیل شد — ${data.tables_found.length} جدول یافت شد`);
    } catch (e) {
      toast.error("خطا در آپلود: " + (e.message || ""));
    } finally {
      setUploading(false);
    }
  };

  const learnProfile = async () => {
    if (!result?.path) return;
    setLearning(true);
    try {
      const { data } = await http.post("/profile/learn", { paths: [result.path] });
      toast.success("قالب سازمانی یاد گرفته شد");
      if (data.summary) toast.message(data.summary.slice(0, 160));
    } catch (e) {
      toast.error("خطا: " + (e.response?.data?.detail || e.message));
    } finally {
      setLearning(false);
    }
  };

  const addTable = async (full_name) => {
    try {
      await http.post("/knowledge", {
        kind: "table",
        payload: { full_name, title_fa: titles[full_name] || null },
      });
      setAdded((a) => ({ ...a, [full_name]: true }));
      toast.success(`${full_name} به دانش افزوده شد`);
    } catch (e) {
      toast.error("خطا: " + (e.response?.data?.detail || e.message));
    }
  };

  const rebuild = async () => {
    setRebuilding(true);
    toast.info("بازسازی ایندکس…");
    try {
      const { data } = await http.post("/index/rebuild");
      if (data.ok) toast.success("ایندکس بازسازی شد و دانش جدید فعال است.");
      else toast.error("ناموفق: " + (data.error || ""));
    } catch (e) {
      toast.error("خطا: " + (e.message || ""));
    } finally {
      setRebuilding(false);
    }
  };

  const saveToLibrary = async () => {
    if (!result) return;
    const title = result.filename.replace(/\.[^.]+$/, "");
    const sqlText =
      result.type === "rdl"
        ? (result.datasets || []).map((d) => `-- ${d.name}\n${d.command || ""}`).join("\n\n")
        : result.sql || "";
    try {
      await http.post("/save-report", {
        sql: sqlText || "-- (بدون کوئری)",
        title_fa: title,
        category,
        tables: (result.tables_found || []).map((t) => t.full_name),
        rdl_source_path: result.type === "rdl" ? result.path : undefined,
      });
      setSavedLib(true);
      const { data } = await http.get("/categories");
      setCategories(data.categories || []);
      toast.success(category ? `در فولدر «${category}» ذخیره شد` : "در کتابخانه ذخیره شد");
    } catch (e) {
      toast.error("خطا در ذخیره: " + (e.response?.data?.detail || e.message));
    }
  };

  return (
    <>
      <ViewHeader
        title="منابع و آپلود"
        subtitle="فایل‌های .rdl / .sql / .txt را آپلود کنید و دانش جدید را دستی به حافظهٔ اپلیکیشن اضافه کنید."
        onMenu={onMenu}
      >
        <Button
          data-testid="sources-rebuild-btn"
          onClick={rebuild}
          disabled={rebuilding}
          variant="outline"
          size="sm"
          className="gap-1.5 rounded-sm border-border bg-surface"
        >
          {rebuilding ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          <span className="hidden sm:inline">بازسازی ایندکس</span>
        </Button>
      </ViewHeader>

      <ScrollArea className="flex-1">
        <div className="mx-auto max-w-4xl space-y-5 p-4 sm:p-6">
          {/* dropzone */}
          <div
            data-testid="upload-dropzone"
            onClick={() => inputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              onFile(e.dataTransfer.files?.[0]);
            }}
            className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-sm border-2 border-dashed border-border bg-surface/50 p-8 text-center transition-colors hover:border-brand/50 hover:bg-surfaceHover"
          >
            {uploading ? (
              <Loader2 className="h-8 w-8 animate-spin text-brand" />
            ) : (
              <UploadCloud className="h-8 w-8 text-brand" />
            )}
            <div className="text-sm font-semibold">فایل را این‌جا رها کنید یا کلیک کنید</div>
            <div className="font-mono text-xs text-muted-foreground">.rdl · .sql · .txt</div>
            <input
              ref={inputRef}
              data-testid="upload-input"
              type="file"
              accept=".rdl,.sql,.txt,.xml"
              className="hidden"
              onChange={(e) => onFile(e.target.files?.[0])}
            />
          </div>

          {result && (
            <div className="space-y-4 rc-fade-up">
              <div className="flex flex-wrap items-center gap-2">
                {result.type === "rdl" ? (
                  <FileCode2 className="h-4 w-4 text-brand" />
                ) : (
                  <FileText className="h-4 w-4 text-brand" />
                )}
                <span className="font-mono text-sm">{result.filename}</span>
                <Sev severity="info">{result.type.toUpperCase()}</Sev>
                <div className="ms-auto flex items-center gap-2">
                  <span className="text-[11px] text-muted-foreground">فولدر:</span>
                  <CategoryPicker categories={categories} value={category} onChange={setCategory} testid="sources-cat" />
                  <Button
                    data-testid="sources-save-btn"
                    size="sm"
                    variant="outline"
                    onClick={saveToLibrary}
                    disabled={savedLib}
                    className="gap-1.5 rounded-sm border-ok/40 bg-ok/10 text-ok hover:bg-ok/20 disabled:opacity-70"
                  >
                    {savedLib ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
                    {savedLib ? "ذخیره شد" : "ذخیره در کتابخانه"}
                  </Button>
                  {result.learnable_profile && (
                    <Button
                      data-testid="learn-profile-btn"
                      size="sm"
                      onClick={learnProfile}
                      disabled={learning}
                      className="gap-1.5 rounded-sm bg-brand hover:bg-brand/90"
                    >
                      {learning ? <Loader2 className="h-4 w-4 animate-spin" /> : <GraduationCap className="h-4 w-4" />}
                      یادگیری قالب سازمانی
                    </Button>
                  )}
                </div>
              </div>

              {result.type === "rdl" && result.datasets?.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-semibold text-muted-foreground">
                    DataSetها ({result.datasets.length}) · پارامتر: {result.parameters?.length || 0} · Subreport: {result.subreports?.length || 0}
                  </div>
                  {result.datasets.map((d, i) => (
                    <div key={i}>
                      <div className="mb-1 font-mono text-xs text-brand">{d.name}</div>
                      {d.command && <SqlBlock sql={d.command} title={`SQL · ${d.name}`} testid={`ds-sql-${i}`} />}
                    </div>
                  ))}
                </div>
              )}

              {result.type === "sql" && result.sql && (
                <SqlBlock sql={result.sql} title="محتوای فایل" testid="uploaded-sql" />
              )}

              {/* extracted tables → manual add to knowledge */}
              <div className="rounded-sm border border-border bg-surface p-3">
                <div className="mb-2 flex items-center gap-1.5 text-sm font-bold">
                  <Database className="h-4 w-4 text-brand" /> جدول‌های شناسایی‌شده
                  <span className="text-xs font-normal text-muted-foreground">
                    ({result.tables_found.length}) — دانش را دستی اضافه کنید
                  </span>
                </div>
                {result.tables_found.length === 0 ? (
                  <p className="py-3 text-center text-xs text-muted-foreground">
                    جدول شناخته‌شده‌ای در این فایل پیدا نشد.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {result.tables_found.map((t) => (
                      <div
                        key={t.full_name}
                        data-testid={`src-table-${t.full_name}`}
                        className="flex flex-wrap items-center gap-2 rounded-sm border border-border bg-ink p-2"
                      >
                        <span className="font-mono text-xs text-brand">{t.full_name}</span>
                        {t.title_fa ? (
                          <Sev severity="success">{t.title_fa}</Sev>
                        ) : (
                          <Sev severity="warning">بدون عنوان فارسی</Sev>
                        )}
                        <Input
                          data-testid={`src-title-${t.full_name}`}
                          value={titles[t.full_name] ?? (t.title_fa || "")}
                          onChange={(e) => setTitles({ ...titles, [t.full_name]: e.target.value })}
                          placeholder="عنوان فارسی…"
                          className="ms-auto h-8 w-40 rounded-sm border-border bg-surface text-xs"
                        />
                        <Button
                          data-testid={`src-add-${t.full_name}`}
                          size="sm"
                          onClick={() => addTable(t.full_name)}
                          disabled={added[t.full_name]}
                          className="h-8 gap-1 rounded-sm bg-brand px-2 text-xs hover:bg-brand/90 disabled:bg-ok/20 disabled:text-ok"
                        >
                          {added[t.full_name] ? <Check className="h-3.5 w-3.5" /> : "افزودن"}
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
                <p className="mt-3 text-[11px] text-muted-foreground">
                  پس از افزودن دانش، حتماً «بازسازی ایندکس» را بزنید تا در جست‌وجو و پاسخ مدل فعال شود.
                </p>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
    </>
  );
}
