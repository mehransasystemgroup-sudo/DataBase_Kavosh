import { useState, useMemo } from "react";
import { http } from "@/lib/api";
import { ViewHeader, Sev } from "@/views/shared";
import D3RelationshipVisualizer from "@/components/D3RelationshipVisualizer";
import SchemaNodeGraph from "@/components/SchemaNodeGraph";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Search,
  Loader2,
  KeyRound,
  Link2,
  AlertTriangle,
  ArrowRight,
  GraduationCap,
  RefreshCw,
  Gauge,
  FolderTree,
  Maximize2,
  ExternalLink,
  Layers,
  Database,
  Copy,
  Check,
  X,
  FileCode2,
  Layers2,
  ShieldCheck,
  TableProperties,
  Network,
  Code,
  Sparkles,
  Route,
  CheckSquare,
  Square,
  FileText,
  Terminal,
  ArrowLeft,
  Compass,
  ChevronDown,
  ChevronUp,
  Filter,
  ArrowUpDown,
  SlidersHorizontal,
  Hash,
  Coins,
  Type,
  Calendar,
  RotateCcw,
  CheckCircle2,
  XCircle,
  HelpCircle,
} from "lucide-react";

const BANNER =
  "https://images.unsplash.com/photo-1683322499436-f4383dd59f5a?crop=entropy&cs=srgb&fm=jpg&q=85&w=1400";

// Quick-select common ERP schemas
const POPULAR_SCHEMAS = [
  { id: "FIN3", label: "مالی (FIN3)", count: "۷۹۰ جدول" },
  { id: "GNR3", label: "عمومی (GNR3)", count: "۳۸۰ جدول" },
  { id: "ACC", label: "حسابداری (ACC)", count: "۵۰ جدول" },
  { id: "RPA3", label: "دریافت/پرداخت (RPA3)", count: "۱۲۰ جدول" },
  { id: "HCM3", label: "پرسنلی (HCM3)", count: "۲۵۰ جدول" },
  { id: "LGS3", label: "لجستیک (LGS3)", count: "۱۱۰ جدول" },
  { id: "MMG3", label: "انبار (MMG3)", count: "۱۶۰ جدول" },
  { id: "SLS3", label: "فروش (SLS3)", count: "۱۴۰ جدول" },
];

const FIELD_TYPE_OPTIONS = [
  { id: "", label: "همه نوع فیلدها", desc: "بدون محدودیت نوع ستون" },
  { id: "int", label: "عددی صحیح (int, bigint...)", desc: "کلیدها و شمارنده‌ها" },
  { id: "decimal", label: "اعشاری و مالی (decimal, money...)", desc: "مبالغ، نرخ‌ها و اوزان" },
  { id: "varchar", label: "متنی و رشته‌ای (varchar, text...)", desc: "عناوین، کدهای متنی و توضیحات" },
  { id: "datetime", label: "تاریخ و زمان (datetime, date...)", desc: "زمان ثبت، تغییرات و تراکنش‌ها" },
  { id: "bit", label: "بولی و پرچم (bit, boolean)", desc: "وضعیت‌های فعال/غیرفعال" },
  { id: "uniqueidentifier", label: "شناسه یکتا (GUID / UUID)", desc: "شناسه‌های سیستمی" },
  { id: "binary", label: "باینری و مدیا (binary, image)", desc: "پیوست‌ها و فایل‌های باینری" },
  { id: "custom", label: "نوع سفارشی دیگر…", desc: "جستجوی دستی نوع فیلد" },
];

const ROW_COUNT_PRESETS = [
  { id: "all", label: "همه ردیف‌ها", min: "", max: "" },
  { id: "1_1k", label: "۱ تا ۱٬۰۰۰", min: 1, max: 1000 },
  { id: "1k_50k", label: "۱٬۰۰۰ تا ۵۰٬۰۰۰", min: 1000, max: 50000 },
  { id: "50k_plus", label: "بیش از ۵۰٬۰۰۰", min: 50000, max: "" },
  { id: "1m_plus", label: "بیش از ۱ میلیون", min: 1000000, max: "" },
  { id: "custom", label: "محدوده دلخواه…", min: "", max: "" },
];

const DATA_STATUS_OPTIONS = [
  { id: "all", label: "همه جدول‌ها" },
  { id: "with_data", label: "فقط دارای داده (>۰)" },
  { id: "no_data", label: "فقط بدون داده (خالی)" },
];

const SORT_OPTIONS = [
  { id: "score", label: "بیشترین تطابق و ارتباط" },
  { id: "row_count_desc", label: "بیشترین ردیف (نزولی)" },
  { id: "row_count_asc", label: "کمترین ردیف (صعودی)" },
  { id: "n_cols", label: "بیشترین تعداد ستون" },
  { id: "name", label: "نام الفبایی جدول (A-Z)" },
];

export default function KnowledgeView({ onMenu, onNavigateToChat }) {
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState([]);
  const [detail, setDetail] = useState(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [rebuilding, setRebuilding] = useState(false);
  const [viewMode, setViewMode] = useState("explorer"); // "explorer" | "schemaGraph"
  const [activeSchemaForGraph, setActiveSchemaForGraph] = useState("ACC");

  // Advanced Filters State
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [dataStatus, setDataStatus] = useState("all"); // "all" | "with_data" | "no_data"
  const [fieldType, setFieldType] = useState(""); // "", "int", "decimal", "varchar", "datetime", "bit", "uniqueidentifier", "binary", "custom"
  const [customFieldType, setCustomFieldType] = useState("");
  const [rowCountPreset, setRowCountPreset] = useState("all");
  const [minRows, setMinRows] = useState("");
  const [maxRows, setMaxRows] = useState("");
  const [schemaFilter, setSchemaFilter] = useState("ALL");
  const [sortBy, setSortBy] = useState("score");

  // Count active filters (excluding default values)
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (dataStatus !== "all") count++;
    if (fieldType) count++;
    if (fieldType === "custom" && customFieldType.trim()) count++;
    if (rowCountPreset !== "all" || minRows !== "" || maxRows !== "") count++;
    if (schemaFilter !== "ALL") count++;
    if (sortBy !== "score") count++;
    return count;
  }, [dataStatus, fieldType, customFieldType, rowCountPreset, minRows, maxRows, schemaFilter, sortBy]);

  const handleRowCountPresetChange = (presetId) => {
    setRowCountPreset(presetId);
    const preset = ROW_COUNT_PRESETS.find((p) => p.id === presetId);
    if (preset && presetId !== "custom") {
      setMinRows(preset.min !== "" ? String(preset.min) : "");
      setMaxRows(preset.max !== "" ? String(preset.max) : "");
    }
  };

  const run = async (overrideQ, overrideFilters = {}) => {
    const query = (overrideQ !== undefined ? overrideQ : q).trim();
    const curDataStatus = overrideFilters.dataStatus ?? dataStatus;
    const curFieldType =
      overrideFilters.fieldType ??
      (fieldType === "custom" ? customFieldType.trim() : fieldType);
    const curMinRows = overrideFilters.minRows !== undefined ? overrideFilters.minRows : minRows;
    const curMaxRows = overrideFilters.maxRows !== undefined ? overrideFilters.maxRows : maxRows;
    const curSchema = overrideFilters.schema ?? (schemaFilter !== "ALL" ? schemaFilter : undefined);
    const curSortBy = overrideFilters.sortBy ?? sortBy;

    const hasAnyFilter =
      Boolean(query) ||
      curDataStatus !== "all" ||
      Boolean(curFieldType) ||
      curMinRows !== "" ||
      curMaxRows !== "" ||
      Boolean(curSchema) ||
      curSortBy !== "score";

    if (!hasAnyFilter && overrideQ === undefined) {
      toast.info("لطفاً عبارتی برای جستجو وارد کنید یا فیلترهای پیشرفته را انتخاب کنید.");
      return;
    }

    setBusy(true);
    try {
      let sortKey = curSortBy;
      let sortOrder = "desc";
      if (curSortBy === "row_count_desc") {
        sortKey = "row_count";
        sortOrder = "desc";
      } else if (curSortBy === "row_count_asc") {
        sortKey = "row_count";
        sortOrder = "asc";
      } else if (curSortBy === "name") {
        sortKey = "name";
        sortOrder = "asc";
      }

      const params = {
        q: query,
        all: curDataStatus === "all",
        dataStatus: curDataStatus,
        fieldType: curFieldType || undefined,
        minRows: curMinRows !== "" ? curMinRows : undefined,
        maxRows: curMaxRows !== "" ? curMaxRows : undefined,
        schema: curSchema || undefined,
        sortBy: sortKey,
        sortOrder,
        limit: 80,
      };

      const { data } = await http.get("/search", { params });
      const found = data.results || [];
      setResults(found);

      if (found.length === 0) {
        toast.info("جدولی با این شرایط و فیلترها یافت نشد.");
      }
    } catch (e) {
      toast.error("خطا در جست‌وجو: " + (e.response?.data?.detail || e.message));
    } finally {
      setBusy(false);
    }
  };

  const open = async (name) => {
    setLoadingDetail(true);
    try {
      const { data } = await http.get(`/table/${encodeURIComponent(name)}`);
      setDetail(data);
    } catch (e) {
      toast.error("خطا در بارگذاری جدول: " + (e.response?.data?.detail || e.message));
    } finally {
      setLoadingDetail(false);
    }
  };

  const rebuild = async () => {
    setRebuilding(true);
    toast.info("بازسازی ایندکس آغاز شد…");
    try {
      const { data } = await http.post("/index/rebuild");
      if (data.ok) toast.success("ایندکس بازسازی شد. دانش جدید در جست‌وجو فعال است.");
      else toast.error("بازسازی ناموفق: " + (data.error || ""));
    } catch (e) {
      toast.error("خطا: " + (e.message || ""));
    } finally {
      setRebuilding(false);
    }
  };

  const handleSchemaClick = (schemaId, openGraph = false) => {
    setActiveSchemaForGraph(schemaId);
    if (openGraph) {
      setViewMode("schemaGraph");
    } else {
      setSchemaFilter(schemaId);
      setQ(schemaId + ".");
      run(schemaId + ".", { schema: schemaId });
    }
  };

  const clearSearch = () => {
    setQ("");
    if (activeFilterCount === 0) {
      setResults([]);
    } else {
      run("", { query: "" });
    }
  };

  const resetAllFilters = () => {
    setDataStatus("all");
    setFieldType("");
    setCustomFieldType("");
    setRowCountPreset("all");
    setMinRows("");
    setMaxRows("");
    setSchemaFilter("ALL");
    setSortBy("score");
    if (q.trim()) {
      run(q, {
        dataStatus: "all",
        fieldType: "",
        minRows: "",
        maxRows: "",
        schema: undefined,
        sortBy: "score",
      });
    } else {
      setResults([]);
    }
    toast.success("تمامی فیلترهای پیشرفته بازنشانی شدند.");
  };

  return (
    <>
      <ViewHeader
        title="کاوش پایگاه دانش"
        subtitle="جست‌وجو در ۳٬۴۲۸ جدول و ۴۰٬۷۸۷ ستون سیستم ERP شما"
        banner={BANNER}
        onMenu={onMenu}
      >
        <div className="flex flex-wrap items-center gap-2">
          {/* Mode Switcher */}
          <div className="flex items-center gap-1 rounded-sm border border-border bg-surface p-0.5">
            <button
              data-testid="mode-explorer-btn"
              type="button"
              onClick={() => setViewMode("explorer")}
              className={`flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-xs font-medium transition-colors ${
                viewMode === "explorer"
                  ? "bg-brand text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Search className="h-3.5 w-3.5" />
              <span>کاوش جدول‌ها</span>
            </button>
            <button
              data-testid="mode-schemagraph-btn"
              type="button"
              onClick={() => setViewMode("schemaGraph")}
              className={`flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-xs font-medium transition-colors ${
                viewMode === "schemaGraph"
                  ? "bg-brand text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Network className="h-3.5 w-3.5" />
              <span>گراف روابط اسکیما</span>
              <span className="rounded-full bg-emerald-500/20 text-emerald-400 px-1 py-0.2 text-[10px] font-mono">
                نو
              </span>
            </button>
          </div>

          <Button
            data-testid="rebuild-index-btn"
            onClick={rebuild}
            disabled={rebuilding}
            variant="outline"
            size="sm"
            className="gap-1.5 rounded-sm border-border bg-surface text-xs font-medium text-foreground hover:bg-surfaceHover"
          >
            {rebuilding ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4 text-brand" />}
            <span className="hidden sm:inline">بازسازی ایندکس</span>
          </Button>
        </div>
      </ViewHeader>

      {viewMode === "schemaGraph" ? (
        <div className="flex-1 min-h-0 p-3 sm:p-4 flex flex-col bg-ink/30">
          <SchemaNodeGraph
            initialSchema={activeSchemaForGraph}
            onSelectTable={(name) => {
              open(name);
              setViewMode("explorer");
            }}
            height="100%"
          />
        </div>
      ) : (
        <div className="flex min-h-0 flex-1">
          {/* Sidebar list */}
          <div
            className={`w-full shrink-0 flex-col border-s border-border bg-surface/40 md:flex md:w-[390px] lg:w-[420px] ${
              detail ? "hidden md:flex" : "flex"
            }`}
          >
            <div className="space-y-2 border-b border-border p-3 bg-surface/60">
              {/* Primary Search Input Row */}
              <div className="relative flex gap-1.5">
                <div className="relative flex-1">
                  <Input
                    data-testid="kb-search-input"
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") run();
                      if (e.key === "Escape") clearSearch();
                    }}
                    placeholder="جستجو در نام، فیلد، اسکیما یا توضیحات…"
                    className="rounded-sm border-border bg-ink pe-8 ps-8 text-xs placeholder:text-muted-foreground focus-visible:ring-brand h-9"
                  />
                  <Search className="absolute start-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground pointer-events-none" />
                  {q && (
                    <button
                      type="button"
                      onClick={clearSearch}
                      className="absolute end-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-0.5 rounded"
                      title="پاک کردن متن جستجو"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>

                <Button
                  data-testid="kb-search-btn"
                  onClick={() => run()}
                  disabled={busy}
                  className="rounded-sm bg-brand text-white hover:bg-brand/90 px-3 shrink-0 h-9"
                  title="جستجو"
                >
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                </Button>

                <Button
                  data-testid="kb-toggle-filters-btn"
                  type="button"
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  variant="outline"
                  className={`rounded-sm px-2.5 shrink-0 h-9 border-border transition-colors flex items-center gap-1 text-xs ${
                    showAdvancedFilters || activeFilterCount > 0
                      ? "border-brand/60 bg-brand/10 text-brand font-semibold shadow-xs"
                      : "bg-ink text-muted-foreground hover:text-foreground hover:bg-surfaceHover"
                  }`}
                  title="فیلترهای پیشرفته (نوع فیلد، تعداد ردیف و وجود داده)"
                >
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                  {activeFilterCount > 0 && (
                    <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 text-[10px] font-mono font-bold text-white leading-none">
                      {activeFilterCount}
                    </span>
                  )}
                  {showAdvancedFilters ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                </Button>
              </div>

              {/* Collapsible Advanced Filters Panel */}
              {showAdvancedFilters && (
                <div className="rounded-md border border-brand/20 bg-ink/90 p-3 space-y-3 shadow-md animate-in fade-in slide-in-from-top-2 duration-150 text-xs">
                  <div className="flex items-center justify-between pb-1.5 border-b border-border/60">
                    <span className="flex items-center gap-1.5 font-bold text-foreground">
                      <Filter className="h-3.5 w-3.5 text-brand" />
                      فیلترهای پیشرفته جدول‌ها
                    </span>
                    {activeFilterCount > 0 && (
                      <button
                        type="button"
                        onClick={resetAllFilters}
                        className="flex items-center gap-1 text-[11px] text-rose-400 hover:text-rose-300 font-medium"
                      >
                        <RotateCcw className="h-3 w-3" />
                        پاک کردن فیلترها
                      </button>
                    )}
                  </div>

                  {/* 1. Data Status Filter (وجود یا عدم وجود داده) */}
                  <div className="space-y-1.5">
                    <label className="flex items-center justify-between text-[11px] font-semibold text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Database className="h-3 w-3 text-brand" />
                        وضعیت وجود داده
                      </span>
                      <span className="text-[10px] font-mono text-muted-foreground">
                        {dataStatus === "with_data"
                          ? "فقط با داده"
                          : dataStatus === "no_data"
                          ? "فقط خالی"
                          : "همه"}
                      </span>
                    </label>
                    <div className="grid grid-cols-3 gap-1 rounded-sm bg-surface p-1 border border-border">
                      {DATA_STATUS_OPTIONS.map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          data-testid={`data-status-${opt.id}`}
                          onClick={() => {
                            setDataStatus(opt.id);
                            run(undefined, { dataStatus: opt.id });
                          }}
                          className={`rounded-xs px-2 py-1 text-[11px] font-medium transition-colors text-center truncate ${
                            dataStatus === opt.id
                              ? "bg-brand text-white shadow-xs font-semibold"
                              : "text-muted-foreground hover:text-foreground"
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 2. Column / Field Type Filter (نوع فیلد ستون‌ها) */}
                  <div className="space-y-1.5">
                    <label className="flex items-center justify-between text-[11px] font-semibold text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Type className="h-3 w-3 text-brand" />
                        نوع فیلد (Data Type)
                      </span>
                      {fieldType && (
                        <button
                          type="button"
                          onClick={() => {
                            setFieldType("");
                            setCustomFieldType("");
                            run(undefined, { fieldType: "" });
                          }}
                          className="text-[10px] text-muted-foreground hover:text-rose-400"
                        >
                          حذف فیلتر نوع
                        </button>
                      )}
                    </label>
                    <select
                      data-testid="kb-field-type-select"
                      value={fieldType}
                      onChange={(e) => {
                        const val = e.target.value;
                        setFieldType(val);
                        if (val !== "custom") {
                          run(undefined, { fieldType: val });
                        }
                      }}
                      className="w-full rounded-sm border border-border bg-surface px-2.5 py-1.5 text-xs text-foreground focus:border-brand focus:outline-none"
                    >
                      {FIELD_TYPE_OPTIONS.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.label} — {f.desc}
                        </option>
                      ))}
                    </select>

                    {fieldType === "custom" && (
                      <div className="flex gap-1.5 pt-1">
                        <Input
                          value={customFieldType}
                          onChange={(e) => setCustomFieldType(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") run(undefined, { fieldType: customFieldType });
                          }}
                          placeholder="مثلاً: nvarchar(max), money, float..."
                          className="h-7 text-xs rounded-sm border-border bg-surface"
                        />
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => run(undefined, { fieldType: customFieldType })}
                          className="h-7 px-2.5 text-xs bg-brand text-white"
                        >
                          اعمال
                        </Button>
                      </div>
                    )}
                  </div>

                  {/* 3. Row Count Filter (تعداد ردیف‌ها) */}
                  <div className="space-y-1.5">
                    <label className="flex items-center justify-between text-[11px] font-semibold text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Hash className="h-3 w-3 text-brand" />
                        تعداد ردیف‌های جدول
                      </span>
                      {(minRows !== "" || maxRows !== "") && (
                        <span className="text-[10px] font-mono text-emerald-400">
                          {minRows ? Number(minRows).toLocaleString("fa") : "۰"} تا{" "}
                          {maxRows ? Number(maxRows).toLocaleString("fa") : "∞"}
                        </span>
                      )}
                    </label>

                    {/* Presets Grid */}
                    <div className="grid grid-cols-3 gap-1">
                      {ROW_COUNT_PRESETS.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          data-testid={`row-preset-${p.id}`}
                          onClick={() => {
                            handleRowCountPresetChange(p.id);
                            if (p.id !== "custom") {
                              run(undefined, {
                                minRows: p.min !== "" ? p.min : undefined,
                                maxRows: p.max !== "" ? p.max : undefined,
                              });
                            }
                          }}
                          className={`rounded-xs border px-1.5 py-1 text-[10px] font-medium transition-colors text-center truncate ${
                            rowCountPreset === p.id
                              ? "border-brand bg-brand/15 text-brand font-semibold"
                              : "border-border/70 bg-surface text-muted-foreground hover:bg-surfaceHover hover:text-foreground"
                          }`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>

                    {/* Custom Range Inputs */}
                    {(rowCountPreset === "custom" || minRows !== "" || maxRows !== "") && (
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div>
                          <span className="text-[10px] text-muted-foreground block mb-0.5">حداقل ردیف:</span>
                          <Input
                            type="number"
                            min="0"
                            value={minRows}
                            onChange={(e) => setMinRows(e.target.value)}
                            placeholder="مثلاً: ۱۰۰۰"
                            className="h-7 text-xs rounded-sm border-border bg-surface font-mono"
                          />
                        </div>
                        <div>
                          <span className="text-[10px] text-muted-foreground block mb-0.5">حداکثر ردیف:</span>
                          <Input
                            type="number"
                            min="0"
                            value={maxRows}
                            onChange={(e) => setMaxRows(e.target.value)}
                            placeholder="مثلاً: ۵۰۰۰۰"
                            className="h-7 text-xs rounded-sm border-border bg-surface font-mono"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* 4. Schema Filter & Sort By Grid */}
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-border/60">
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-muted-foreground block">
                        اسکیما:
                      </label>
                      <select
                        value={schemaFilter}
                        onChange={(e) => {
                          const s = e.target.value;
                          setSchemaFilter(s);
                          run(undefined, { schema: s !== "ALL" ? s : undefined });
                        }}
                        className="w-full rounded-sm border border-border bg-surface px-2 py-1 text-xs text-foreground focus:border-brand focus:outline-none"
                      >
                        <option value="ALL">همه اسکیماها</option>
                        {POPULAR_SCHEMAS.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.id} ({s.label})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-muted-foreground block">
                        ترتیب نتایج:
                      </label>
                      <select
                        value={sortBy}
                        onChange={(e) => {
                          const s = e.target.value;
                          setSortBy(s);
                          run(undefined, { sortBy: s });
                        }}
                        className="w-full rounded-sm border border-border bg-surface px-2 py-1 text-xs text-foreground focus:border-brand focus:outline-none"
                      >
                        {SORT_OPTIONS.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-1">
                    <Button
                      type="button"
                      onClick={() => run()}
                      disabled={busy}
                      className="flex-1 rounded-sm bg-brand text-white hover:bg-brand/90 text-xs h-8 font-medium gap-1.5"
                    >
                      {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
                      اعمال فیلترها و جستجو
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowAdvancedFilters(false)}
                      className="rounded-sm border-border bg-surface text-xs h-8 text-muted-foreground hover:text-foreground"
                    >
                      بستن پنل
                    </Button>
                  </div>
                </div>
              )}

              {/* Active Filter Badges Bar */}
              {activeFilterCount > 0 && (
                <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[11px]">
                  <span className="text-muted-foreground text-[10px] font-medium">فیلترهای فعال:</span>

                  {dataStatus !== "all" && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-brand/15 text-brand border border-brand/30 px-2 py-0.5 font-medium">
                      <Database className="h-2.5 w-2.5" />
                      {dataStatus === "with_data" ? "دارای داده" : "بدون داده"}
                      <button
                        type="button"
                        onClick={() => {
                          setDataStatus("all");
                          run(undefined, { dataStatus: "all" });
                        }}
                        className="hover:text-rose-400 p-0.5"
                      >
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </span>
                  )}

                  {fieldType && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/30 px-2 py-0.5 font-medium">
                      <Type className="h-2.5 w-2.5" />
                      نوع: {fieldType === "custom" ? customFieldType || "سفارشی" : fieldType}
                      <button
                        type="button"
                        onClick={() => {
                          setFieldType("");
                          setCustomFieldType("");
                          run(undefined, { fieldType: "" });
                        }}
                        className="hover:text-rose-400 p-0.5"
                      >
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </span>
                  )}

                  {(minRows !== "" || maxRows !== "") && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 font-medium font-mono">
                      <Hash className="h-2.5 w-2.5" />
                      {minRows ? Number(minRows).toLocaleString("fa") : "۰"}..
                      {maxRows ? Number(maxRows).toLocaleString("fa") : "∞"}
                      <button
                        type="button"
                        onClick={() => {
                          setRowCountPreset("all");
                          setMinRows("");
                          setMaxRows("");
                          run(undefined, { minRows: "", maxRows: "" });
                        }}
                        className="hover:text-rose-400 p-0.5"
                      >
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </span>
                  )}

                  {schemaFilter !== "ALL" && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2 py-0.5 font-medium font-mono">
                      اسکیما: {schemaFilter}
                      <button
                        type="button"
                        onClick={() => {
                          setSchemaFilter("ALL");
                          run(undefined, { schema: undefined });
                        }}
                        className="hover:text-rose-400 p-0.5"
                      >
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </span>
                  )}

                  {sortBy !== "score" && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-blue-500/15 text-blue-300 border border-blue-500/30 px-2 py-0.5 font-medium">
                      مرتب‌سازی: {SORT_OPTIONS.find((s) => s.id === sortBy)?.label.split(" ")[0]}
                      <button
                        type="button"
                        onClick={() => {
                          setSortBy("score");
                          run(undefined, { sortBy: "score" });
                        }}
                        className="hover:text-rose-400 p-0.5"
                      >
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </span>
                  )}

                  <button
                    type="button"
                    onClick={resetAllFilters}
                    className="text-[10px] text-muted-foreground hover:text-rose-400 underline ms-auto"
                  >
                    پاک کردن همه
                  </button>
                </div>
              )}

              {/* Status footer with counter */}
              <div className="flex items-center justify-between gap-2 pt-0.5 text-xs text-muted-foreground">
                <span className="text-[11px]">
                  {activeFilterCount > 0 ? (
                    <span className="text-brand font-medium">{activeFilterCount} فیلتر فعال</span>
                  ) : (
                    "جست‌وجو در جداول پایگاه دانش"
                  )}
                </span>
                {results.length > 0 && (
                  <span className="text-[11px] font-mono text-foreground font-semibold shrink-0 bg-surface px-1.5 py-0.5 rounded border border-border">
                    {results.length.toLocaleString("fa")} جدول یافت شد
                  </span>
                )}
              </div>
            </div>

            <ScrollArea className="flex-1">
              <div className="p-2 space-y-1">
                {/* Quick Schema Badges when no search has been made */}
                {results.length === 0 && !busy && activeFilterCount === 0 && (
                  <div className="px-2 py-3">
                    <div className="mb-2.5 flex items-center justify-between text-xs font-semibold text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <Layers2 className="h-3.5 w-3.5 text-brand" />
                        اسکیماهای پرکاربرد
                      </span>
                      <span className="text-[10px]">کلیک برای کاوش سریع</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {POPULAR_SCHEMAS.map((s) => (
                        <div
                          key={s.id}
                          className="flex items-center justify-between rounded-sm border border-border/80 bg-ink/70 p-2 text-start transition-all hover:border-brand/50 hover:bg-surfaceHover group"
                        >
                          <button
                            type="button"
                            onClick={() => handleSchemaClick(s.id)}
                            className="flex-1 flex flex-col items-start min-w-0"
                          >
                            <span className="font-mono text-xs font-bold text-brand group-hover:underline">
                              {s.id}
                            </span>
                            <span className="text-[11px] text-foreground mt-0.5 truncate">{s.label}</span>
                            <span className="text-[10px] text-muted-foreground mt-0.5 font-mono">{s.count}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSchemaClick(s.id, true)}
                            title={`کاوش اسکیما ${s.id} در گراف بصری`}
                            className="p-1.5 rounded text-muted-foreground hover:text-brand hover:bg-brand/10 transition-colors"
                          >
                            <Network className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 rounded-sm border border-border/60 bg-surface/30 p-2.5 text-center text-xs text-muted-foreground">
                      نام کامل جدول یا کلمه‌ای مانند «سند»، «فاکتور»، «انبار» یا «مشتری» را جستجو کنید یا با فیلترهای بالا جدول‌ها را محدود نمایید.
                    </div>
                  </div>
                )}

                {/* Search Results */}
                {results.map((r) => {
                  const parts = r.full_name.split(".");
                  const schema = parts[0];
                  const tableName = parts.slice(1).join(".");
                  const isSelected = detail?.full_name === r.full_name;

                  return (
                    <button
                      key={r.full_name}
                      data-testid="kb-result"
                      onClick={() => open(r.full_name)}
                      className={`block w-full rounded-sm border p-2.5 text-start transition-all duration-150 ${
                        isSelected
                          ? "border-brand/60 bg-brand/10 shadow-sm"
                          : "border-transparent bg-surface/40 hover:border-border hover:bg-surfaceHover"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="truncate font-mono text-xs">
                          <span className="text-muted-foreground font-normal">{schema}.</span>
                          <span className="text-brand font-semibold">{tableName}</span>
                        </div>
                        {r.has_data ? (
                          <Sev severity="success">{Number(r.row_count).toLocaleString("fa")} ردیف</Sev>
                        ) : (
                          <Sev severity="warning">بدون داده</Sev>
                        )}
                      </div>
                      {r.title_fa && (
                        <div className="mt-1 text-xs text-foreground font-medium truncate">{r.title_fa}</div>
                      )}

                      {/* Display matched column types if any */}
                      {r.matched_columns && r.matched_columns.length > 0 && (
                        <div className="mt-1.5 flex flex-wrap items-center gap-1 text-[10px]">
                          <span className="text-muted-foreground flex items-center gap-0.5">
                            <Type className="h-2.5 w-2.5 text-brand" />
                            ستون مطابق:
                          </span>
                          {r.matched_columns.slice(0, 3).map((c, idx) => (
                            <span
                              key={idx}
                              className="rounded bg-brand/15 text-brand font-mono px-1 py-0.2 border border-brand/20"
                            >
                              {c.name} <span className="text-[9px] text-muted-foreground">({c.type})</span>
                            </span>
                          ))}
                          {r.matched_columns.length > 3 && (
                            <span className="text-muted-foreground font-mono">
                              +{r.matched_columns.length - 3}
                            </span>
                          )}
                        </div>
                      )}

                      {r.why && !r.matched_columns && (
                        <div className="mt-1 text-[10px] text-muted-foreground truncate">
                          {r.why}
                        </div>
                      )}
                    </button>
                  );
                })}

                {busy && (
                  <div className="flex items-center justify-center gap-2 py-8 text-xs text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin text-brand" />
                    در حال جست‌وجوی ساختار متادیتا…
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>

          {/* Detail View */}
          <div className={`min-w-0 flex-1 overflow-y-auto p-4 sm:p-6 ${detail ? "block" : "hidden md:block"}`}>
            {!detail ? (
              <div className="flex h-full flex-col space-y-3">
                <div className="flex items-center justify-between rounded-md border border-border/80 bg-surface/70 px-3.5 py-2.5 shadow-sm">
                  <div className="flex items-center gap-2">
                    <div className="flex h-6 w-6 items-center justify-center rounded bg-brand/15 text-brand">
                      <Network className="h-3.5 w-3.5" />
                    </div>
                    <div>
                      <span className="font-semibold text-foreground text-xs">
                        گراف بصری روابط اسکیما {activeSchemaForGraph}
                      </span>
                      <span className="text-muted-foreground text-[11px] ms-2 hidden sm:inline">
                        برای مشاهده جزئیات هر جدول روی گره آن کلیک نمایید
                      </span>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setViewMode("schemaGraph")}
                    className="h-7 gap-1 rounded-sm border-brand/40 text-brand hover:bg-brand/10 text-xs"
                  >
                    <Maximize2 className="h-3 w-3" />
                    <span>تمام‌صفحه گراف</span>
                  </Button>
                </div>

                <div className="flex-1 min-h-[480px]">
                  <SchemaNodeGraph
                    initialSchema={activeSchemaForGraph}
                    onSelectTable={(name) => open(name)}
                    height="100%"
                    embedded={true}
                  />
                </div>
              </div>
            ) : (
              <>
                <button
                  data-testid="kb-back-btn"
                  onClick={() => setDetail(null)}
                  className="mb-3 flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground md:hidden"
                >
                  <ArrowRight className="h-3.5 w-3.5" /> بازگشت به فهرست
                </button>
                {loadingDetail ? (
                  <div className="flex h-64 items-center justify-center gap-2 text-xs text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin text-brand" />
                    در حال بارگذاری اطلاعات تفصیلی جدول…
                  </div>
                ) : (
                  <TableDetail
                    t={detail}
                    onRefresh={() => open(detail.full_name)}
                    onSelectTable={(name) => open(name)}
                    onOpenSchemaGraph={(schema) => {
                      setActiveSchemaForGraph(schema);
                      setViewMode("schemaGraph");
                    }}
                    onNavigateToChat={onNavigateToChat}
                  />
                )}
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}

// Schema color accents and labels
const SCHEMA_ACCENTS = {
  FIN3: { border: "border-emerald-500/50", bg: "bg-emerald-950/40", text: "text-emerald-400", label: "مالی (FIN3)" },
  GNR3: { border: "border-sky-500/50", bg: "bg-sky-950/40", text: "text-sky-400", label: "عمومی (GNR3)" },
  HCM3: { border: "border-purple-500/50", bg: "bg-purple-950/40", text: "text-purple-400", label: "منابع انسانی (HCM3)" },
  RPA3: { border: "border-amber-500/50", bg: "bg-amber-950/40", text: "text-amber-400", label: "دریافت/پرداخت (RPA3)" },
  LGS3: { border: "border-indigo-500/50", bg: "bg-indigo-950/40", text: "text-indigo-400", label: "لجستیک (LGS3)" },
  BDG3: { border: "border-pink-500/50", bg: "bg-pink-950/40", text: "text-pink-400", label: "بودجه (BDG3)" },
  SLS3: { border: "border-cyan-500/50", bg: "bg-cyan-950/40", text: "text-cyan-400", label: "فروش (SLS3)" },
  FMK: { border: "border-teal-500/50", bg: "bg-teal-950/40", text: "text-teal-400", label: "فریم‌ورک (FMK)" },
  DEFAULT: { border: "border-border", bg: "bg-ink", text: "text-muted-foreground", label: "اسکیما" },
};

function getSchemaAccent(schema) {
  return SCHEMA_ACCENTS[schema] || SCHEMA_ACCENTS.DEFAULT;
}

function TableDetail({ t, onRefresh, onSelectTable, onOpenSchemaGraph, onNavigateToChat }) {
  const [activeTab, setActiveTab] = useState("connections");
  const [showTreeDiagram, setShowTreeDiagram] = useState(false);
  const [isTreeModalOpen, setIsTreeModalOpen] = useState(false);
  
  // Filtering & Selection states
  const [columnFilter, setColumnFilter] = useState("");
  const [columnTypeCategory, setColumnTypeCategory] = useState("all");
  const [columnSortMode, setColumnSortMode] = useState("default"); // "default" | "name" | "type" | "keys"
  const [selectedColumns, setSelectedColumns] = useState(() => new Set());
  const [showCustomSqlPreview, setShowCustomSqlPreview] = useState(false);
  const [connFilter, setConnFilter] = useState("");
  const [schemaNeighborFilter, setSchemaNeighborFilter] = useState("");
  const [enumFilter, setEnumFilter] = useState("");
  const [copiedTableName, setCopiedTableName] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);
  const [selectedSqlTemplate, setSelectedSqlTemplate] = useState("select");

  // Join Path Finder state
  const [targetPathTable, setTargetPathTable] = useState("");
  const [pathLoading, setPathLoading] = useState(false);
  const [pathResult, setPathResult] = useState(null);
  const [pathError, setPathError] = useState("");

  const schema = t.schema || (t.full_name ? t.full_name.split(".")[0] : "");
  const tableName = t.table_name || (t.full_name ? t.full_name.split(".")[1] || t.full_name : "");
  const schemaAccent = getSchemaAccent(schema);

  const indexed = useMemo(() => new Set(t.indexed_columns || []), [t.indexed_columns]);
  const outgoing = t.outgoing || [];
  const incoming = t.incoming || [];
  const totalConns = outgoing.length + incoming.length;
  const hasFiscalYear = useMemo(() => (t.columns || []).some((c) => c.name === "FiscalYearRef"), [t.columns]);
  const hasEnums = Boolean(t.enums && Object.keys(t.enums).length > 0);
  const schemaNeighbors = useMemo(() => t.schema_neighbors || [], [t.schema_neighbors]);

  // Filter schema neighbors locally
  const filteredSchemaNeighbors = useMemo(() => {
    if (!schemaNeighborFilter.trim()) return schemaNeighbors;
    const q = schemaNeighborFilter.trim().toLowerCase();
    return schemaNeighbors.filter(
      (nb) =>
        nb.full_name.toLowerCase().includes(q) ||
        (nb.title_fa || "").toLowerCase().includes(q)
    );
  }, [schemaNeighbors, schemaNeighborFilter]);

  // Map of outgoing FKs by column name for inline badge in columns tab
  const outgoingByCol = useMemo(() => {
    const map = new Map();
    outgoing.forEach((j) => {
      map.set(j.from_col, j);
    });
    return map;
  }, [outgoing]);

  // Primary keys display string
  const primaryKeysDisplay = useMemo(() => {
    if (Array.isArray(t.primary_key)) {
      return t.primary_key.length > 0 ? t.primary_key.join(", ") : "بدون PK";
    }
    return t.primary_key || "بدون PK";
  }, [t.primary_key]);

  // Filter columns locally with category chips
  const filteredColumns = useMemo(() => {
    let list = t.columns || [];
    if (columnTypeCategory !== "all") {
      list = list.filter((c) => {
        const typeLower = (c.type || "").toLowerCase();
        const isPk = t.primary_key?.includes(c.name);
        const isFk = outgoingByCol.has(c.name);
        const isIx = indexed.has(c.name);
        if (columnTypeCategory === "keys") return isPk || isFk;
        if (columnTypeCategory === "pk") return isPk;
        if (columnTypeCategory === "indexed") return isIx;
        if (columnTypeCategory === "notnull") return !c.nullable;
        if (columnTypeCategory === "enum") return Boolean(t.enums?.[c.name]);
        if (columnTypeCategory === "numeric") {
          return typeLower.includes("int") || typeLower.includes("decimal") || typeLower.includes("numeric") || typeLower.includes("float") || typeLower.includes("money");
        }
        if (columnTypeCategory === "text") {
          return typeLower.includes("char") || typeLower.includes("text") || typeLower.includes("string");
        }
        if (columnTypeCategory === "date") {
          return typeLower.includes("date") || typeLower.includes("time");
        }
        return true;
      });
    }

    if (!columnFilter.trim()) return list;
    const q = columnFilter.trim().toLowerCase();
    return list.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        (c.type || "").toLowerCase().includes(q)
    );
  }, [t.columns, t.primary_key, t.enums, indexed, outgoingByCol, columnTypeCategory, columnFilter]);

  // Sort filtered columns based on user selection
  const sortedFilteredColumns = useMemo(() => {
    const list = [...filteredColumns];
    if (columnSortMode === "name") {
      return list.sort((a, b) => a.name.localeCompare(b.name));
    }
    if (columnSortMode === "type") {
      return list.sort((a, b) => (a.type || "").localeCompare(b.type || ""));
    }
    if (columnSortMode === "keys") {
      return list.sort((a, b) => {
        const aPk = t.primary_key?.includes(a.name) ? 1 : 0;
        const bPk = t.primary_key?.includes(b.name) ? 1 : 0;
        if (aPk !== bPk) return bPk - aPk;
        const aFk = outgoingByCol.has(a.name) ? 1 : 0;
        const bFk = outgoingByCol.has(b.name) ? 1 : 0;
        if (aFk !== bFk) return bFk - aFk;
        const aIx = indexed.has(a.name) ? 1 : 0;
        const bIx = indexed.has(b.name) ? 1 : 0;
        return bIx - aIx;
      });
    }
    return list;
  }, [filteredColumns, columnSortMode, t.primary_key, outgoingByCol, indexed]);

  // Filter outgoing connections locally
  const filteredOutgoing = useMemo(() => {
    if (!connFilter.trim()) return outgoing;
    const q = connFilter.trim().toLowerCase();
    return outgoing.filter(
      (j) =>
        j.to_table.toLowerCase().includes(q) ||
        j.from_col.toLowerCase().includes(q) ||
        j.to_col.toLowerCase().includes(q)
    );
  }, [outgoing, connFilter]);

  // Filter incoming connections locally
  const filteredIncoming = useMemo(() => {
    if (!connFilter.trim()) return incoming;
    const q = connFilter.trim().toLowerCase();
    return incoming.filter(
      (j) =>
        j.from_table.toLowerCase().includes(q) ||
        j.from_col.toLowerCase().includes(q) ||
        j.to_col.toLowerCase().includes(q)
    );
  }, [incoming, connFilter]);

  // Filter enums dictionary locally
  const filteredEnums = useMemo(() => {
    if (!t.enums) return {};
    if (!enumFilter.trim()) return t.enums;
    const q = enumFilter.trim().toLowerCase();
    const res = {};
    Object.entries(t.enums).forEach(([col, vals]) => {
      const colMatches = col.toLowerCase().includes(q);
      const matchedVals = vals.filter(
        (v) =>
          String(v.value).toLowerCase().includes(q) ||
          (v.label_fa || "").toLowerCase().includes(q)
      );
      if (colMatches || matchedVals.length > 0) {
        res[col] = colMatches ? vals : matchedVals;
      }
    });
    return res;
  }, [t.enums, enumFilter]);

  // Copy Helpers
  const copyTableName = () => {
    navigator.clipboard.writeText(t.full_name);
    setCopiedTableName(true);
    toast.success(`نام کامل جدول ${t.full_name} کپی شد.`);
    setTimeout(() => setCopiedTableName(false), 2000);
  };

  const copyJoinCondition = (leftTable, leftCol, rightTable, rightCol) => {
    const clause = `ON ${leftTable}.${leftCol} = ${rightTable}.${rightCol}`;
    navigator.clipboard.writeText(clause);
    toast.success(`شرط اتصال کپی شد: ${clause}`);
  };

  const copyFullJoinSql = (leftTable, leftCol, rightTable, rightCol) => {
    const rParts = rightTable.split(".");
    const rSchema = rParts[0];
    const rName = rParts[1] || rightTable;
    const clause = `LEFT JOIN [${rSchema}].[${rName}] AS [${rName}]\n    ON [${leftTable}].[${leftCol}] = [${rName}].[${rightCol}]`;
    navigator.clipboard.writeText(clause);
    toast.success(`دستور کامل JOIN کپی شد:\n${clause}`);
  };

  // Column selection helpers
  const toggleColumnSelection = (colName) => {
    setSelectedColumns((prev) => {
      const next = new Set(prev);
      if (next.has(colName)) next.delete(colName);
      else next.add(colName);
      return next;
    });
  };

  const selectAllColumns = () => {
    const allNames = (t.columns || []).map((c) => c.name);
    setSelectedColumns(new Set(allNames));
    toast.info(`همه ${(t.columns || []).length} ستون انتخاب شدند.`);
  };

  const deselectAllColumns = () => {
    setSelectedColumns(new Set());
  };

  const selectKeyColumns = () => {
    const keys = (t.columns || [])
      .filter((c) => {
        const isPk = t.primary_key?.includes(c.name);
        const isFk = outgoingByCol.has(c.name);
        const isName = c.name.toLowerCase().includes("title") || c.name.toLowerCase().includes("name") || c.name.toLowerCase().includes("code");
        return isPk || isFk || isName;
      })
      .map((c) => c.name);
    setSelectedColumns(new Set(keys));
    toast.info(`${keys.length} ستون کلیدی و شناسه انتخاب شدند.`);
  };

  const copySelectedColumnsList = () => {
    const cols = selectedColumns.size > 0
      ? Array.from(selectedColumns)
      : (t.columns || []).map((c) => c.name);
    const sqlText = cols.join(", ");
    navigator.clipboard.writeText(sqlText);
    toast.success(`${cols.length} ستون کپی شد.`);
  };

  const copySelectedSelectSql = () => {
    const cols = selectedColumns.size > 0
      ? Array.from(selectedColumns)
      : (t.columns || []).map((c) => c.name);
    const colsFormatted = cols.map((c) => `    [${c}]`).join(",\n");
    const sqlText = `SELECT\n${colsFormatted}\nFROM [${schema}].[${tableName}]${
      hasFiscalYear ? "\nWHERE [FiscalYearRef] = @FiscalYearRef" : ""
    };`;
    navigator.clipboard.writeText(sqlText);
    toast.success("کوئری SELECT در کلیپ‌بورد کپی شد.");
  };

  const customSelectSql = useMemo(() => {
    const cols = selectedColumns.size > 0
      ? Array.from(selectedColumns)
      : (t.columns || []).map((c) => c.name);
    const colsFormatted = cols.map((c) => `    t.[${c}]`).join(",\n");
    return `SELECT TOP 100\n${colsFormatted}\nFROM [${schema}].[${tableName}] AS t${
      hasFiscalYear ? "\nWHERE t.[FiscalYearRef] = @FiscalYearRef" : ""
    };`;
  }, [selectedColumns, t.columns, schema, tableName, hasFiscalYear]);

  // Join Path Finder
  const runFindJoinPath = async (target) => {
    const dst = (target || targetPathTable).trim();
    if (!dst) {
      toast.error("لطفاً نام جدول مقصد را وارد کنید.");
      return;
    }
    setPathLoading(true);
    setPathError("");
    setPathResult(null);
    try {
      const { data } = await http.get("/joinpath", {
        params: { source: t.full_name, target: dst },
      });
      const formattedData = {
        ...data,
        found: data.found ?? (Array.isArray(data.path) && data.path.length > 0),
        steps: data.steps || (data.path || []).map((s) => ({
          ...s,
          sql: `LEFT JOIN [${s.to_table}] ON [${s.from_table}].[${s.from_col}] = [${s.to_table}].[${s.to_col}]`,
        })),
      };
      setPathResult(formattedData);
      if (!formattedData.found) {
        setPathError(data.warning || "مسیری در گراف دانش پیدا نشد.");
      }
    } catch (e) {
      setPathError(e.response?.data?.detail || "خطا در برقراری ارتباط با سرور");
    } finally {
      setPathLoading(false);
    }
  };

  // Pre-generated SQL queries
  const generatedSqlQueries = useMemo(() => {
    const cols = (t.columns || []).map((c) => `    t.[${c.name}]`).join(",\n");
    const selectQuery = `-- کوئری بازیابی اطلاعات جدول ${t.title_fa || t.full_name}
SELECT TOP 100
${cols}
FROM [${schema}].[${tableName}] AS t${
      hasFiscalYear ? "\nWHERE t.[FiscalYearRef] = @FiscalYearRef -- الزامی: فیلتر سال مالی جاری" : ""
    };`;

    const verifiedJoins = outgoing.filter((j) => j.verified);
    const joinClauses = verifiedJoins
      .map((j, i) => `LEFT JOIN [${j.to_table}] AS p${i + 1}\n    ON t.[${j.from_col}] = p${i + 1}.[${j.to_col}]`)
      .join("\n");

    const joinSelectCols = verifiedJoins
      .map((j, i) => `    p${i + 1}.* -- از جدول ${j.to_table}`)
      .join(",\n");

    const joinQuery = `-- کوئری پیوند جامع جدول ${t.full_name} با جداول والد
SELECT
    t.*${joinSelectCols ? ",\n" + joinSelectCols : ""}
FROM [${schema}].[${tableName}] AS t
${joinClauses || "-- بدون اتصال تأییدشده"}${
      hasFiscalYear ? "\nWHERE t.[FiscalYearRef] = @FiscalYearRef" : ""
    };`;

    const aggQuery = `-- کوئری تجمیع و شمارش ردیف‌های جدول ${t.full_name}
SELECT
    COUNT(*) AS [TotalRows]${
      hasFiscalYear ? ",\n    t.[FiscalYearRef]" : ""
    }${
      t.primary_key?.length ? `,\n    COUNT(DISTINCT t.[${t.primary_key[0]}]) AS [UniqueKeyCount]` : ""
    }
FROM [${schema}].[${tableName}] AS t
${hasFiscalYear ? "GROUP BY t.[FiscalYearRef]\nORDER BY t.[FiscalYearRef] DESC;" : ";"}`;

    return {
      select: selectQuery,
      join: joinQuery,
      aggregate: aggQuery,
    };
  }, [t, schema, tableName, hasFiscalYear, outgoing]);

  const activeSqlQuery = generatedSqlQueries[selectedSqlTemplate] || generatedSqlQueries.select;

  return (
    <div className="space-y-4 rc-fade-up">
      {/* ── Table Master Header Card ── */}
      <div className="rounded-lg border border-border bg-surface p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0 space-y-1.5 flex-1">
            {/* Schema Tag + Table Name + Quick Copy */}
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`inline-flex items-center gap-1 rounded-sm border px-2 py-0.5 font-mono text-xs font-semibold ${schemaAccent.border} ${schemaAccent.bg} ${schemaAccent.text}`}
                title={`اسکیما: ${schema}`}
              >
                {schema}
              </span>
              <span className="font-mono text-lg sm:text-xl font-bold text-foreground select-all tracking-tight">
                {t.full_name}
              </span>

              <button
                type="button"
                onClick={copyTableName}
                title="کپی نام جدول در کلیپ‌بورد"
                className="inline-flex items-center gap-1 rounded border border-border bg-ink px-2 py-1 text-xs text-muted-foreground hover:border-brand/50 hover:text-foreground transition-colors"
              >
                {copiedTableName ? <Check className="h-3 w-3 text-ok" /> : <Copy className="h-3 w-3" />}
                <span>{copiedTableName ? "کپی شد" : "کپی نام"}</span>
              </button>

              {t.has_data ? (
                <Sev severity="success">{Number(t.row_count || 0).toLocaleString("fa")} ردیف داده</Sev>
              ) : (
                <Sev severity="warning">بدون داده در نصب فعلی</Sev>
              )}

              {hasFiscalYear && (
                <span className="inline-flex items-center gap-1 rounded bg-amber-950/60 border border-amber-600/50 px-2 py-0.5 text-[11px] text-amber-300 font-medium">
                  <AlertTriangle className="h-3 w-3 text-amber-400" />
                  سال مالی‌محور
                </span>
              )}
            </div>

            {/* Title & Description */}
            {t.title_fa ? (
              <h3 className="text-base sm:text-lg font-bold text-foreground">{t.title_fa}</h3>
            ) : (
              <p className="text-xs text-muted-foreground italic">بدون عنوان فارسی ثبت‌شده</p>
            )}

            {t.description_fa && (
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed pt-0.5 max-w-4xl">
                {t.description_fa}
              </p>
            )}
          </div>

          {/* Master Actions Group */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {onNavigateToChat && (
              <Button
                data-testid="table-ask-copilot-btn"
                onClick={() =>
                  onNavigateToChat?.(
                    t.full_name,
                    `لطفاً یک گزارش تحلیلی جامع و استاندارد برای جدول ${t.full_name} (${t.title_fa || "بدون عنوان"}) طراحی کن.`
                  )
                }
                className="gap-1.5 bg-brand text-white hover:bg-brand/90 text-xs font-semibold shadow-sm rounded-sm h-8"
                title="شروع گزارش‌گیری یا ساخت کوئری هوشمند با این جدول"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>گزارش‌گیری با ایجنت</span>
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              onClick={() => onOpenSchemaGraph?.(schema)}
              className="gap-1.5 rounded-sm border-brand/30 bg-surface text-xs text-brand hover:bg-brand/10 h-8"
              title={`مشاهده تمام جداول اسکیما ${schema} در گراف گره‌ای`}
            >
              <Network className="h-3.5 w-3.5" />
              <span>گراف اسکیما {schema}</span>
            </Button>

            <TeachDialog table={t} onDone={onRefresh} />
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 pt-2 border-t border-border/70">
          <div className="flex items-center gap-2.5 rounded-sm border border-border/60 bg-ink/60 px-3 py-2">
            <Database className="h-4 w-4 text-sky-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-[10px] text-muted-foreground">تعداد ستون‌ها</div>
              <div className="font-mono text-xs font-semibold text-foreground">
                {(t.columns?.length || 0).toLocaleString("fa")} ستون
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 rounded-sm border border-border/60 bg-ink/60 px-3 py-2">
            <KeyRound className="h-4 w-4 text-amber-400 shrink-0" />
            <div className="min-w-0 truncate">
              <div className="text-[10px] text-muted-foreground">کلید اصلی (PK)</div>
              <div className="font-mono text-xs font-semibold text-amber-300 truncate" title={primaryKeysDisplay}>
                {primaryKeysDisplay}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 rounded-sm border border-border/60 bg-ink/60 px-3 py-2">
            <Link2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-[10px] text-muted-foreground">اتصالات کلید خارجی</div>
              <div className="font-mono text-xs font-semibold text-foreground">
                {totalConns.toLocaleString("fa")} رابطه ({outgoing.length} خروجی / {incoming.length} ورودی)
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 rounded-sm border border-border/60 bg-ink/60 px-3 py-2">
            <Gauge className="h-4 w-4 text-purple-400 shrink-0" />
            <div className="min-w-0">
              <div className="text-[10px] text-muted-foreground">ایندکس‌های فیزیکی</div>
              <div className="font-mono text-xs font-semibold text-foreground">
                {(t.indexes?.length || 0).toLocaleString("fa")} ایندکس
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Warnings Banner */}
      {t.warnings?.length > 0 && (
        <div className="space-y-1.5">
          {t.warnings.map((w, i) => (
            <div key={i} className="flex items-center gap-2 rounded-sm border border-warn/40 bg-warn/10 p-2.5 text-xs text-warn">
              <AlertTriangle className="h-4 w-4 shrink-0 text-warn" />
              <span>{w}</span>
            </div>
          ))}
        </div>
      )}

      {/* ── Exploration Tabs Panel ── */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="flex flex-wrap h-auto w-full gap-1 rounded-md border border-border bg-surface p-1">
          <TabsTrigger
            value="connections"
            data-testid="tab-connections"
            className="flex items-center gap-1.5 text-xs py-1.5 px-3 data-[state=active]:bg-brand/20 data-[state=active]:text-foreground data-[state=active]:font-semibold"
          >
            <Link2 className="h-3.5 w-3.5 text-brand" />
            <span>اتصال‌ها و مسیریابی</span>
            <span className="rounded-full bg-ink px-1.5 py-0.2 font-mono text-[10px] text-brand">
              {totalConns}
            </span>
          </TabsTrigger>

          <TabsTrigger
            value="columns"
            data-testid="tab-columns"
            className="flex items-center gap-1.5 text-xs py-1.5 px-3 data-[state=active]:bg-brand/20 data-[state=active]:text-foreground data-[state=active]:font-semibold"
          >
            <Database className="h-3.5 w-3.5 text-sky-400" />
            <span>مشخصات ستون‌ها</span>
            <span className="rounded-full bg-ink px-1.5 py-0.2 font-mono text-[10px] text-muted-foreground">
              {t.columns?.length || 0}
            </span>
          </TabsTrigger>

          <TabsTrigger
            value="sql"
            data-testid="tab-sql"
            className="flex items-center gap-1.5 text-xs py-1.5 px-3 data-[state=active]:bg-brand/20 data-[state=active]:text-foreground data-[state=active]:font-semibold"
          >
            <Code className="h-3.5 w-3.5 text-amber-400" />
            <span>کوئری‌های آماده (SQL)</span>
          </TabsTrigger>

          <TabsTrigger
            value="diagram"
            data-testid="tab-diagram"
            className="flex items-center gap-1.5 text-xs py-1.5 px-3 data-[state=active]:bg-brand/20 data-[state=active]:text-foreground data-[state=active]:font-semibold"
          >
            <Layers className="h-3.5 w-3.5 text-emerald-400" />
            <span>گراف روابط</span>
          </TabsTrigger>

          <TabsTrigger
            value="indexes"
            data-testid="tab-indexes"
            className="flex items-center gap-1.5 text-xs py-1.5 px-3 data-[state=active]:bg-brand/20 data-[state=active]:text-foreground data-[state=active]:font-semibold"
          >
            <Gauge className="h-3.5 w-3.5 text-purple-400" />
            <span>ایندکس‌ها</span>
            <span className="rounded-full bg-ink px-1.5 py-0.2 font-mono text-[10px] text-muted-foreground">
              {t.indexes?.length || 0}
            </span>
          </TabsTrigger>

          {hasEnums && (
            <TabsTrigger
              value="enums"
              data-testid="tab-enums"
              className="flex items-center gap-1.5 text-xs py-1.5 px-3 data-[state=active]:bg-brand/20 data-[state=active]:text-foreground data-[state=active]:font-semibold"
            >
              <TableProperties className="h-3.5 w-3.5 text-pink-400" />
              <span>واژه‌نامه و مقادیر</span>
              <span className="rounded-full bg-ink px-1.5 py-0.2 font-mono text-[10px] text-pink-300">
                {Object.keys(t.enums).length}
              </span>
            </TabsTrigger>
          )}
        </TabsList>

        {/* ── TAB 1: CONNECTIONS & JOIN PATH FINDER ── */}
        <TabsContent value="connections" className="mt-4 space-y-4">
          {/* Header Bar with Tree Toggle & Path Finder Opener */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-md border border-border bg-surface p-3 shadow-sm">
            <div>
              <div className="flex items-center gap-2">
                <Link2 className="h-4 w-4 text-brand" />
                <h4 className="text-sm font-semibold text-foreground">اتصالات و کلیدهای خارجی (Foreign Keys)</h4>
              </div>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {outgoing.length} کلید خارجی خروجی (جداول والد) • {incoming.length} رابطه ورودی (جداول وابسته)
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                data-testid="show-tree-diagram-btn"
                variant={showTreeDiagram ? "default" : "outline"}
                size="sm"
                onClick={() => setShowTreeDiagram(!showTreeDiagram)}
                className={`gap-1.5 text-xs font-semibold shadow-sm transition-all h-8 ${
                  showTreeDiagram
                    ? "bg-emerald-600 text-white hover:bg-emerald-700"
                    : "border-emerald-500/50 bg-emerald-950/20 text-emerald-400 hover:bg-emerald-900/40"
                }`}
              >
                <FolderTree className="h-3.5 w-3.5" />
                {showTreeDiagram ? "بستن نمودار درختی" : "نمودار درختی روابط"}
              </Button>

              <Button
                data-testid="modal-tree-diagram-btn"
                variant="outline"
                size="sm"
                onClick={() => setIsTreeModalOpen(true)}
                className="gap-1.5 border-border bg-ink text-xs text-foreground hover:bg-surfaceHover h-8"
                title="مشاهده نمودار درختی در پنجره بزرگ تعاملی"
              >
                <Maximize2 className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">تمام‌صفحه</span>
              </Button>
            </div>
          </div>

          {/* VISUAL TREE DIAGRAM SECTION */}
          {showTreeDiagram && (
            <div
              data-testid="tree-diagram-container"
              className="rounded-lg border border-emerald-500/40 bg-ink p-2.5 sm:p-3 shadow-xl transition-all animate-in fade-in zoom-in-95 duration-200 overflow-hidden"
            >
              <div className="mb-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-border/70 pb-2">
                <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                  <FolderTree className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span className="text-xs font-semibold text-foreground">
                    نمودار درختی تعاملی روابط کلید خارجی جدول{" "}
                    <span className="font-mono text-brand">{t.full_name}</span>
                  </span>
                  <span className="rounded bg-emerald-950/80 px-1.5 py-0.5 text-[10px] text-emerald-300 border border-emerald-700/60 font-mono shrink-0">
                    D3 Tree
                  </span>
                </div>
                <div className="flex items-center justify-end gap-1.5 shrink-0">
                  <span className="text-[11px] text-muted-foreground hidden md:inline">
                    والدین (سمت چپ) • فرزندان (سمت راست)
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsTreeModalOpen(true)}
                    className="h-7 gap-1 px-2 text-[11px] text-foreground hover:bg-surfaceHover"
                  >
                    <Maximize2 className="h-3 w-3" /> <span className="hidden xs:inline">بزرگ‌نمایی</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowTreeDiagram(false)}
                    className="h-7 px-2 text-[11px] text-muted-foreground hover:text-err"
                  >
                    ✕ بستن
                  </Button>
                </div>
              </div>

              <D3RelationshipVisualizer table={t} onSelectTable={onSelectTable} initialLayout="tree" />
            </div>
          )}

          {/* FULLSCREEN TREE MODAL DIALOG */}
          <Dialog open={isTreeModalOpen} onOpenChange={setIsTreeModalOpen}>
            <DialogContent className="w-[96vw] max-w-6xl h-[92vh] sm:h-[88vh] flex flex-col p-2.5 sm:p-4 bg-ink border-border">
              <DialogHeader className="border-b border-border pb-2">
                <div className="flex items-center justify-between gap-2">
                  <DialogTitle className="flex items-center gap-2 text-sm sm:text-base font-bold text-foreground">
                    <FolderTree className="h-4 sm:h-5 w-4 sm:w-5 text-emerald-400 shrink-0" />
                    <span className="truncate">
                      نمودار درختی روابط جدول <span className="font-mono text-brand">{t.full_name}</span>
                    </span>
                  </DialogTitle>
                </div>
                <p className="text-[11px] sm:text-xs text-muted-foreground line-clamp-2 sm:line-clamp-none">
                  نمایش بصری و تعاملی سلسله‌مراتبی اتصالات کلید خارجی بر پایه D3.js با خطوط منحنی Bezier و قابلیت زوم و درگ.
                </p>
              </DialogHeader>
              <div className="flex-1 min-h-0 pt-1.5">
                <D3RelationshipVisualizer
                  table={t}
                  onSelectTable={(tbl) => {
                    setIsTreeModalOpen(false);
                    onSelectTable?.(tbl);
                  }}
                  initialLayout="tree"
                />
              </div>
            </DialogContent>
          </Dialog>

          {/* ── Smart Join Path Finder Card ── */}
          <div className="rounded-lg border border-brand/40 bg-surface/80 p-3.5 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Route className="h-4 w-4 text-brand shrink-0" />
                <span className="text-xs sm:text-sm font-bold text-foreground">
                  یافتن کوتاه‌ترین مسیر اتصال (JOIN Path Finder)
                </span>
              </div>
              <span className="text-[11px] text-muted-foreground">
                پیمایش خودکار گراف پایگاه داده برای اتصال این جدول به هر جدول دیگر
              </span>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <div className="relative flex-1">
                <Input
                  value={targetPathTable}
                  onChange={(e) => setTargetPathTable(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") runFindJoinPath();
                  }}
                  placeholder="نام جدول مقصد (مثلاً GNR3.Party یا FIN3.Account یا SLS3.Invoice)…"
                  className="h-8 text-xs font-mono rounded-sm border-border bg-ink pe-7 placeholder:font-sans placeholder:text-muted-foreground"
                />
                {targetPathTable && (
                  <button
                    onClick={() => {
                      setTargetPathTable("");
                      setPathResult(null);
                      setPathError("");
                    }}
                    className="absolute end-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>

              <Button
                size="sm"
                onClick={() => runFindJoinPath()}
                disabled={pathLoading || !targetPathTable.trim()}
                className="gap-1.5 h-8 text-xs bg-brand text-white hover:bg-brand/90 shrink-0"
              >
                {pathLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Compass className="h-3.5 w-3.5" />}
                <span>یافتن مسیر JOIN</span>
              </Button>
            </div>

            {/* Quick target suggestion chips */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[11px] text-muted-foreground">
              <span>مقاصد متداول:</span>
              {["GNR3.Party", "FIN3.Account", "FIN3.FiscalYear", "SLS3.Invoice"].map((target) => (
                <button
                  key={target}
                  type="button"
                  onClick={() => {
                    setTargetPathTable(target);
                    runFindJoinPath(target);
                  }}
                  className="rounded border border-border/80 bg-ink px-1.5 py-0.5 font-mono text-[10px] text-foreground hover:border-brand/50 hover:bg-surfaceHover transition-colors"
                >
                  {target}
                </button>
              ))}
            </div>

            {/* Path Result Box */}
            {pathError && (
              <div className="rounded border border-err/30 bg-err/10 p-2.5 text-xs text-err flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 shrink-0 text-err" />
                <span>{pathError}</span>
              </div>
            )}

            {pathResult && pathResult.found && (
              <div className="rounded-md border border-emerald-500/40 bg-ink p-3 space-y-2.5 animate-in fade-in duration-200">
                <div className="flex items-center justify-between text-xs font-semibold text-emerald-400">
                  <span className="flex items-center gap-1.5">
                    <Check className="h-3.5 w-3.5" />
                    مسیر اتصال با موفقیت در {pathResult.steps.length} گام استخراج شد:
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const fullJoinSql = pathResult.steps.map((s) => s.sql).join("\n");
                      navigator.clipboard.writeText(fullJoinSql);
                      toast.success("دستورات JOIN کپی شد.");
                    }}
                    className="inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground border border-border/60 rounded px-1.5 py-0.5 bg-surface"
                  >
                    <Copy className="h-3 w-3" />
                    <span>کپی کل مسیر JOIN</span>
                  </button>
                </div>

                {pathResult.warning && (
                  <div className="text-[11px] text-warn bg-warn/10 p-2 rounded border border-warn/30">
                    ⚠️ {pathResult.warning}
                  </div>
                )}

                <div className="space-y-1.5 font-mono text-xs">
                  {pathResult.steps.map((step, sIdx) => (
                    <div
                      key={sIdx}
                      className="flex items-center justify-between gap-2 rounded border border-border/60 bg-surface/80 p-2 text-foreground"
                    >
                      <span className="text-[11px] text-brand font-bold">گام {sIdx + 1}:</span>
                      <span className="dir-ltr text-start flex-1 select-all">{step.sql}</span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(step.sql);
                          toast.success(`گام ${sIdx + 1} کپی شد.`);
                        }}
                        className="text-muted-foreground hover:text-foreground p-1"
                        title="کپی این گام"
                      >
                        <Copy className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Connections Search Filter */}
          {totalConns > 3 && (
            <div className="relative">
              <Input
                value={connFilter}
                onChange={(e) => setConnFilter(e.target.value)}
                placeholder="فیلتر سریع در اتصالات (نام جدول مقصد یا ستون کلید)…"
                className="rounded-sm border-border bg-ink h-8 text-xs placeholder:text-muted-foreground pe-7"
              />
              {connFilter && (
                <button
                  onClick={() => setConnFilter("")}
                  className="absolute end-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>
          )}

          {/* Outgoing Foreign Keys List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-foreground">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-400" />
                کلیدهای خارجی خروجی (ارجاع به جداول والد — Outgoing FKs)
              </span>
              <span className="font-mono text-muted-foreground">({filteredOutgoing.length})</span>
            </div>

            {filteredOutgoing.length === 0 ? (
              <div className="rounded-sm border border-border bg-ink/40 p-3 text-center text-xs text-muted-foreground">
                {outgoing.length === 0
                  ? "این جدول کلید خارجی به جدول دیگری ارجاع مستقیم ندارد."
                  : "رابطه‌ای منطبق بر جستجوی شما یافت نشد."}
              </div>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2">
                {filteredOutgoing.map((j, i) => (
                  <div
                    key={i}
                    className="flex flex-col justify-between gap-2 rounded-sm border border-border bg-ink p-3 transition-colors hover:border-emerald-500/40"
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="rounded bg-emerald-950/60 px-1.5 py-0.5 font-mono text-[10px] text-emerald-300 border border-emerald-800/40">
                        {j.to_table.split(".")[0]}
                      </span>
                      <span className="text-[10px]">
                        {j.verified ? (
                          <span className="text-emerald-400 font-medium">تأییدشده ✓</span>
                        ) : (
                          <span className="text-warn font-medium">استنتاجی ~</span>
                        )}
                      </span>
                    </div>

                    <div className="font-mono text-xs text-foreground dir-ltr text-start">
                      <span className="font-semibold text-foreground">{j.from_col}</span>
                      <span className="mx-1 text-emerald-400 font-bold">→</span>
                      <span className="text-brand font-bold">{j.to_table}.{j.to_col}</span>
                    </div>

                    <div className="flex items-center justify-between pt-1.5 border-t border-border/40 text-[11px]">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => copyJoinCondition(t.full_name, j.from_col, j.to_table, j.to_col)}
                          className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
                          title="کپی شرط ON در کلیپ‌بورد"
                        >
                          <Copy className="h-3 w-3" />
                          <span>شرط ON</span>
                        </button>
                        <span className="text-border">|</span>
                        <button
                          type="button"
                          onClick={() => copyFullJoinSql(t.full_name, j.from_col, j.to_table, j.to_col)}
                          className="inline-flex items-center gap-1 text-muted-foreground hover:text-emerald-400 transition-colors"
                          title="کپی دستور کامل LEFT JOIN ... ON"
                        >
                          <Code className="h-3 w-3" />
                          <span>دستور JOIN</span>
                        </button>
                      </div>

                      <button
                        onClick={() => onSelectTable?.(j.to_table)}
                        className="flex items-center gap-1 text-brand hover:underline font-medium"
                      >
                        <ExternalLink className="h-3 w-3" /> مشاهده جدول مقصد
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Incoming Foreign Keys List */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between text-xs font-semibold text-foreground">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-sky-400" />
                جداول وابسته ارجاع‌دهنده به این جدول (Incoming References)
              </span>
              <span className="font-mono text-muted-foreground">({filteredIncoming.length})</span>
            </div>

            {filteredIncoming.length === 0 ? (
              <div className="rounded-sm border border-border bg-ink/40 p-3 text-center text-xs text-muted-foreground">
                {incoming.length === 0
                  ? "هیچ جدول ثبت‌شده‌ای به این جدول کلید خارجی ندارد."
                  : "رابطه‌ای منطبق بر جستجوی شما یافت نشد."}
              </div>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2">
                {filteredIncoming.map((j, i) => (
                  <div
                    key={i}
                    className="flex flex-col justify-between gap-2 rounded-sm border border-border bg-ink p-3 transition-colors hover:border-sky-500/40"
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="rounded bg-sky-950/60 px-1.5 py-0.5 font-mono text-[10px] text-sky-300 border border-sky-800/40">
                        {j.from_table.split(".")[0]}
                      </span>
                      <span className="text-[10px]">
                        {j.verified ? (
                          <span className="text-emerald-400 font-medium">تأییدشده ✓</span>
                        ) : (
                          <span className="text-warn font-medium">استنتاجی ~</span>
                        )}
                      </span>
                    </div>

                    <div className="font-mono text-xs text-foreground dir-ltr text-start">
                      <span className="text-brand font-bold">{j.from_table}.{j.from_col}</span>
                      <span className="mx-1 text-sky-400 font-bold">→</span>
                      <span className="font-semibold text-foreground">{j.to_col}</span>
                    </div>

                    <div className="flex items-center justify-between pt-1.5 border-t border-border/40 text-[11px]">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => copyJoinCondition(j.from_table, j.from_col, t.full_name, j.to_col)}
                          className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
                          title="کپی شرط ON در کلیپ‌بورد"
                        >
                          <Copy className="h-3 w-3" />
                          <span>شرط ON</span>
                        </button>
                        <span className="text-border">|</span>
                        <button
                          type="button"
                          onClick={() => copyFullJoinSql(t.full_name, j.to_col, j.from_table, j.from_col)}
                          className="inline-flex items-center gap-1 text-muted-foreground hover:text-sky-400 transition-colors"
                          title="کپی دستور کامل LEFT JOIN ... ON"
                        >
                          <Code className="h-3 w-3" />
                          <span>دستور JOIN</span>
                        </button>
                      </div>

                      <button
                        onClick={() => onSelectTable?.(j.from_table)}
                        className="flex items-center gap-1 text-sky-400 hover:underline font-medium"
                      >
                        <ExternalLink className="h-3 w-3" /> مشاهده جدول ارجاع‌دهنده
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sibling Tables in the Same Module / Schema */}
          {schemaNeighbors.length > 0 && (
            <div className="space-y-2 pt-3 border-t border-border/60">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 text-xs font-semibold text-foreground">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-brand" />
                  جداول هم‌گروه در اسکیما {schema} ({schemaNeighbors.length.toLocaleString("fa")} جدول دیگر در همین ماژول)
                </span>
                <span className="text-[11px] text-muted-foreground font-normal">
                  کلیک روی هر جدول برای کاوش مستقیم
                </span>
              </div>

              {schemaNeighbors.length > 6 && (
                <div className="relative">
                  <Input
                    value={schemaNeighborFilter}
                    onChange={(e) => setSchemaNeighborFilter(e.target.value)}
                    placeholder={`جستجو در جدول‌های اسکیما ${schema}...`}
                    className="rounded-sm border-border bg-ink h-7 text-xs placeholder:text-muted-foreground pe-6"
                  />
                  {schemaNeighborFilter && (
                    <button
                      type="button"
                      onClick={() => setSchemaNeighborFilter("")}
                      className="absolute end-1.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
              )}

              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3 max-h-60 overflow-y-auto pr-0.5">
                {filteredSchemaNeighbors.map((nb) => {
                  const nbName = nb.full_name.split(".")[1] || nb.full_name;
                  return (
                    <button
                      key={nb.full_name}
                      type="button"
                      onClick={() => onSelectTable?.(nb.full_name)}
                      className="flex flex-col justify-between gap-1.5 rounded-sm border border-border bg-ink p-2.5 text-start transition-colors hover:border-brand/50 hover:bg-surfaceHover group"
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-mono text-xs font-bold text-foreground group-hover:text-brand transition-colors">
                          {nbName}
                        </span>
                        {nb.has_data ? (
                          <span className="text-[10px] text-emerald-400 font-mono">
                            {Number(nb.row_count).toLocaleString("fa")} ردیف
                          </span>
                        ) : (
                          <span className="text-[10px] text-muted-foreground">بدون داده</span>
                        )}
                      </div>
                      {nb.title_fa ? (
                        <span className="text-[11px] text-muted-foreground truncate">{nb.title_fa}</span>
                      ) : (
                        <span className="text-[10px] font-mono text-muted-foreground/60">{nb.n_cols} ستون</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </TabsContent>

        {/* ── TAB 2: COLUMNS & FIELD SPECIFICATIONS ── */}
        <TabsContent value="columns" className="mt-4 space-y-3">
          {/* Top Search & Filter Bar */}
          <div className="flex flex-col gap-2 rounded-md border border-border bg-surface p-3 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <div className="relative flex-1">
                <Input
                  value={columnFilter}
                  onChange={(e) => setColumnFilter(e.target.value)}
                  placeholder="جستجو در ستون‌ها بر اساس نام یا نوع داده (varchar, int, date)..."
                  className="rounded-sm border-border bg-ink h-8 text-xs pe-7 placeholder:text-muted-foreground"
                />
                {columnFilter && (
                  <button
                    type="button"
                    onClick={() => setColumnFilter("")}
                    className="absolute end-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs font-mono text-muted-foreground">
                  نمایش {filteredColumns.length.toLocaleString("fa")} از {(t.columns?.length || 0).toLocaleString("fa")} ستون
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={copySelectedColumnsList}
                  className="h-8 gap-1 rounded-sm border-border bg-ink text-xs text-foreground hover:bg-surfaceHover"
                  title="کپی ستون‌های انتخابی یا تمام ستون‌ها"
                >
                  <FileCode2 className="h-3.5 w-3.5 text-brand" />
                  <span>کپی لیست ستون‌ها</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={copySelectedSelectSql}
                  className="h-8 gap-1 rounded-sm border-border bg-ink text-xs text-brand hover:bg-surfaceHover"
                  title="کپی دستور SELECT برای ستون‌های انتخاب‌شده"
                >
                  <Code className="h-3.5 w-3.5" />
                  <span>کپی SELECT</span>
                </Button>
              </div>
            </div>

            {/* Filter Category Chips */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-border/60">
              <span className="text-[11px] text-muted-foreground me-1 flex items-center gap-1">
                <Filter className="h-3 w-3" /> فیلتر نوع:
              </span>
              {[
                { id: "all", label: "همه" },
                { id: "keys", label: "کلیدها (PK / FK)" },
                { id: "pk", label: "فقط کلید اصلی" },
                { id: "indexed", label: "ایندکس‌شده" },
                { id: "notnull", label: "الزامی (NOT NULL)" },
                { id: "enum", label: "دارای واژه‌نامه (Enum)" },
                { id: "text", label: "رشته‌ای (Text)" },
                { id: "numeric", label: "عددی (Numeric)" },
                { id: "date", label: "تاریخ/زمان (Date)" },
              ].map((chip) => (
                <button
                  key={chip.id}
                  type="button"
                  onClick={() => setColumnTypeCategory(chip.id)}
                  className={`rounded px-2 py-0.5 text-xs transition-colors ${
                    columnTypeCategory === chip.id
                      ? "bg-brand text-white font-semibold shadow-xs"
                      : "border border-border/80 bg-ink text-muted-foreground hover:border-brand/40 hover:text-foreground"
                  }`}
                >
                  {chip.label}
                </button>
              ))}

              {/* Column Sorting Controls */}
              <div className="flex items-center gap-1 text-[11px] text-muted-foreground me-2">
                <ArrowUpDown className="h-3 w-3" /> مرتب‌سازی:
                <button
                  type="button"
                  onClick={() => setColumnSortMode("default")}
                  className={`rounded px-1.5 py-0.5 transition-colors ${
                    columnSortMode === "default"
                      ? "bg-brand/20 text-brand font-semibold"
                      : "hover:text-foreground"
                  }`}
                >
                  پیش‌فرض
                </button>
                <button
                  type="button"
                  onClick={() => setColumnSortMode("name")}
                  className={`rounded px-1.5 py-0.5 transition-colors ${
                    columnSortMode === "name"
                      ? "bg-brand/20 text-brand font-semibold"
                      : "hover:text-foreground"
                  }`}
                >
                  نام ستون
                </button>
                <button
                  type="button"
                  onClick={() => setColumnSortMode("type")}
                  className={`rounded px-1.5 py-0.5 transition-colors ${
                    columnSortMode === "type"
                      ? "bg-brand/20 text-brand font-semibold"
                      : "hover:text-foreground"
                  }`}
                >
                  نوع داده
                </button>
                <button
                  type="button"
                  onClick={() => setColumnSortMode("keys")}
                  className={`rounded px-1.5 py-0.5 transition-colors ${
                    columnSortMode === "keys"
                      ? "bg-brand/20 text-brand font-semibold"
                      : "hover:text-foreground"
                  }`}
                >
                  کلیدها در ابتدا
                </button>
              </div>

              <div className="ms-auto flex items-center gap-1.5 text-[11px]">
                <button
                  type="button"
                  onClick={selectAllColumns}
                  className="text-muted-foreground hover:text-foreground underline"
                >
                  انتخاب همه
                </button>
                <span className="text-muted-foreground">•</span>
                <button
                  type="button"
                  onClick={selectKeyColumns}
                  className="text-muted-foreground hover:text-foreground underline"
                >
                  انتخاب کلیدها
                </button>
                <span className="text-muted-foreground">•</span>
                <button
                  type="button"
                  onClick={deselectAllColumns}
                  className="text-muted-foreground hover:text-foreground underline"
                >
                  لغو انتخاب
                </button>
                {selectedColumns.size > 0 && (
                  <span className="font-mono text-brand font-semibold ms-1">
                    ({selectedColumns.size} انتخاب‌شده)
                  </span>
                )}
              </div>
            </div>

            {/* Interactive Selected Columns & Live Query Preview */}
            {selectedColumns.size > 0 && (
              <div className="rounded-md border border-brand/40 bg-brand/5 p-3 space-y-2 mt-1">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-brand">
                    <CheckSquare className="h-4 w-4" />
                    <span>{selectedColumns.size.toLocaleString("fa")} ستون انتخاب شده است</span>
                    <span className="text-[11px] text-muted-foreground font-normal">
                      ({Array.from(selectedColumns).slice(0, 4).join("، ")}
                      {selectedColumns.size > 4 ? ` و ${selectedColumns.size - 4} ستون دیگر...` : ""})
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setShowCustomSqlPreview(!showCustomSqlPreview)}
                      className="h-7 text-xs gap-1 border-brand/30 text-brand hover:bg-brand/10"
                    >
                      <Code className="h-3 w-3" />
                      <span>{showCustomSqlPreview ? "بستن پیش‌نمایش" : "پیش‌نمایش کوئری"}</span>
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={copySelectedSelectSql}
                      className="h-7 text-xs gap-1 border-border bg-ink text-foreground hover:bg-surfaceHover"
                    >
                      <Copy className="h-3 w-3" />
                      <span>کپی SELECT</span>
                    </Button>
                    {onNavigateToChat && (
                      <Button
                        size="sm"
                        onClick={() =>
                          onNavigateToChat?.(
                            t.full_name,
                            `لطفاً با استفاده از ستون‌های انتخاب‌شدهٔ جدول ${t.full_name} (${Array.from(selectedColumns).join(", ")}) یک گزارش کامل و بهینه آماده کن.`
                          )
                        }
                        className="h-7 text-xs gap-1 bg-brand text-white hover:bg-brand/90"
                      >
                        <Sparkles className="h-3 w-3" />
                        <span>ارسال به کوپایلوت</span>
                      </Button>
                    )}
                  </div>
                </div>
                {showCustomSqlPreview && (
                  <div className="rounded border border-border/80 bg-ink p-2.5 font-mono text-xs text-sky-200 dir-ltr text-start overflow-x-auto select-all">
                    <pre>{customSelectSql}</pre>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Columns Table */}
          <div className="overflow-x-auto rounded-md border border-border bg-surface shadow-sm">
            <table className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-surfaceHover/80 text-muted-foreground border-b border-border">
                  <th className="px-3 py-2 text-center w-8">
                    <input
                      type="checkbox"
                      checked={selectedColumns.size > 0 && selectedColumns.size === (t.columns || []).length}
                      onChange={(e) => {
                        if (e.target.checked) selectAllColumns();
                        else deselectAllColumns();
                      }}
                      className="rounded border-border"
                      title="انتخاب همه"
                    />
                  </th>
                  <th className="px-2 py-2 text-start font-semibold w-10">ردیف</th>
                  <th className="px-3 py-2 text-start font-semibold">نام ستون</th>
                  <th className="px-3 py-2 text-start font-semibold">نوع داده</th>
                  <th className="px-3 py-2 text-start font-semibold">وضعیت کلید / ایندکس</th>
                  <th className="px-3 py-2 text-start font-semibold">پذیرش Null</th>
                  <th className="px-3 py-2 text-start font-semibold">ارتباط و واژه‌نامه</th>
                  <th className="px-2 py-2 text-end font-semibold">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/60">
                {sortedFilteredColumns.map((c, idx) => {
                  const isPk = t.primary_key?.includes(c.name);
                  const isIx = indexed.has(c.name);
                  const fkJoin = outgoingByCol.get(c.name);
                  const enumVals = t.enums?.[c.name];
                  const isSelected = selectedColumns.has(c.name);

                  return (
                    <tr
                      key={c.name}
                      className={`transition-colors hover:bg-surfaceHover/70 group ${
                        isSelected ? "bg-brand/5" : ""
                      }`}
                    >
                      <td className="px-3 py-2 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleColumnSelection(c.name)}
                          className="rounded border-border"
                        />
                      </td>
                      <td className="px-2 py-2 font-mono text-muted-foreground text-[11px]">
                        {idx + 1}
                      </td>
                      <td className="px-3 py-2 font-mono font-semibold text-foreground">
                        <span className="select-all">{c.name}</span>
                      </td>
                      <td className="px-3 py-2 font-mono text-muted-foreground">
                        <span className="rounded bg-ink/80 px-1.5 py-0.5 border border-border/50 text-[11px]">
                          {c.type}
                        </span>
                      </td>
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {isPk && (
                            <span className="inline-flex items-center gap-1 rounded bg-amber-950/70 border border-amber-600/50 px-1.5 py-0.5 font-mono text-[10px] text-amber-300 font-bold">
                              <KeyRound className="h-3 w-3 text-amber-400" /> PK
                            </span>
                          )}
                          {isIx && !isPk && (
                            <span className="inline-flex items-center gap-1 rounded bg-sky-950/70 border border-sky-600/50 px-1.5 py-0.5 font-mono text-[10px] text-sky-300 font-bold">
                              <Gauge className="h-3 w-3 text-sky-400" /> INDEX
                            </span>
                          )}
                          {!isPk && !isIx && (
                            <span className="text-muted-foreground text-[11px]">—</span>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-2">
                        {c.nullable ? (
                          <span className="text-muted-foreground text-[11px]">NULL</span>
                        ) : (
                          <span className="font-medium text-foreground text-[11px]">NOT NULL</span>
                        )}
                      </td>
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          {fkJoin && (
                            <button
                              type="button"
                              onClick={() => onSelectTable?.(fkJoin.to_table)}
                              className="inline-flex items-center gap-1 rounded bg-emerald-950/60 border border-emerald-700/50 px-1.5 py-0.5 font-mono text-[10px] text-emerald-300 hover:bg-emerald-900/60 transition-colors"
                              title={`ارجاع کلید خارجی به جدول ${fkJoin.to_table}`}
                            >
                              <span>→ {fkJoin.to_table}.{fkJoin.to_col}</span>
                              <ExternalLink className="h-2.5 w-2.5" />
                            </button>
                          )}
                          {enumVals && (
                            <span
                              onClick={() => setActiveTab("enums")}
                              className="cursor-pointer inline-flex items-center gap-1 rounded bg-pink-950/60 border border-pink-700/50 px-1.5 py-0.5 font-mono text-[10px] text-pink-300 hover:bg-pink-900/60 transition-colors"
                              title="مشاهده مقادیر معتبر در تب واژه‌نامه"
                            >
                              <TableProperties className="h-2.5 w-2.5" />
                              <span>واژه‌نامه ({enumVals.length} مقدار)</span>
                            </span>
                          )}
                          {!fkJoin && !enumVals && (
                            <span className="text-muted-foreground text-[11px]">—</span>
                          )}
                        </div>
                      </td>
                      <td className="px-2 py-2 text-end">
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(c.name);
                            toast.success(`ستون ${c.name} کپی شد.`);
                          }}
                          className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-ink text-muted-foreground hover:text-foreground"
                          title="کپی نام ستون"
                        >
                          <Copy className="h-3 w-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
                {filteredColumns.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground text-xs">
                      هیچ ستونی منطبق بر فیلتر «{columnFilter || columnTypeCategory}» یافت نشد.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* ── TAB 3: QUICK SQL TEMPLATES ── */}
        <TabsContent value="sql" className="mt-4 space-y-4">
          <div className="rounded-lg border border-border bg-surface p-4 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Code className="h-4 w-4 text-amber-400 shrink-0" />
                <h4 className="text-sm font-semibold text-foreground">کوئری‌های پیش‌ساخته و آماده (SQL Templates)</h4>
              </div>
              <span className="text-xs text-muted-foreground">
                اسکریپت‌های استاندارد، بهینه‌شده و منطبق با ساختار دیتابیس
              </span>
            </div>

            {/* Template selector pills */}
            <div className="flex flex-wrap items-center gap-2 border-b border-border/60 pb-3">
              {[
                { id: "select", label: "SELECT پایه با ستون‌ها", desc: "نمایش ۱۰۰ ردیف اول با فیلترهای استاندارد" },
                { id: "join", label: "JOIN جامع با جداول والد", desc: "پیوند خودکار با تمامی جداول تأییدشده" },
                { id: "aggregate", label: "شمارش و تجمیع داده‌ها", desc: "خلاصه‌سازی ردیف‌ها و سال مالی" },
              ].map((tmpl) => (
                <button
                  key={tmpl.id}
                  type="button"
                  onClick={() => setSelectedSqlTemplate(tmpl.id)}
                  className={`rounded-md px-3 py-1.5 text-xs text-start transition-colors ${
                    selectedSqlTemplate === tmpl.id
                      ? "bg-brand text-white font-semibold shadow-xs"
                      : "border border-border bg-ink text-muted-foreground hover:border-brand/40 hover:text-foreground"
                  }`}
                >
                  <div className="font-semibold">{tmpl.label}</div>
                  <div className="text-[10px] opacity-80">{tmpl.desc}</div>
                </button>
              ))}
            </div>

            {/* Code Box */}
            <div className="relative rounded-md border border-border bg-ink p-3.5 font-mono text-xs text-foreground overflow-x-auto">
              <div className="flex items-center justify-between pb-2 border-b border-border/50 text-[11px] text-muted-foreground mb-2">
                <span className="flex items-center gap-1.5">
                  <Terminal className="h-3.5 w-3.5 text-brand" />
                  <span>T-SQL Query Snippet</span>
                </span>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      navigator.clipboard.writeText(activeSqlQuery);
                      setCopiedSql(true);
                      toast.success("اسکریپت SQL در کلیپ‌بورد کپی شد.");
                      setTimeout(() => setCopiedSql(false), 2000);
                    }}
                    className="h-7 text-xs gap-1 border-border bg-surface text-foreground hover:bg-surfaceHover"
                  >
                    {copiedSql ? <Check className="h-3 w-3 text-ok" /> : <Copy className="h-3 w-3" />}
                    <span>{copiedSql ? "کپی شد" : "کپی اسکریپت"}</span>
                  </Button>

                  {onNavigateToChat && (
                    <Button
                      size="sm"
                      onClick={() =>
                        onNavigateToChat?.(
                          t.full_name,
                          `لطفاً این کوئری را برای جدول ${t.full_name} بررسی و بر اساس نیاز کاربر سفارشی‌سازی کن:\n\n\`\`\`sql\n${activeSqlQuery}\n\`\`\``
                        )
                      }
                      className="h-7 text-xs gap-1 bg-brand text-white hover:bg-brand/90"
                      title="ارسال این کوئری به محیط گفتگو برای پردازش یا ساخت RDL"
                    >
                      <Sparkles className="h-3 w-3" />
                      <span>ارسال به کوپایلوت</span>
                    </Button>
                  )}
                </div>
              </div>

              <pre className="dir-ltr text-start whitespace-pre select-all text-sky-200 leading-relaxed font-mono">
                {activeSqlQuery}
              </pre>
            </div>
          </div>
        </TabsContent>

        {/* ── TAB 4: INTERACTIVE D3 GRAPH ── */}
        <TabsContent value="diagram" className="mt-4 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border bg-surface p-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5 text-foreground font-medium">
              <Layers className="h-4 w-4 text-emerald-400" />
              کاوش تعاملی گراف روابط جدول {t.full_name}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onOpenSchemaGraph?.(schema)}
              className="gap-1.5 h-8 text-xs border-brand/40 text-brand hover:bg-brand/10"
            >
              <Network className="h-3.5 w-3.5" />
              <span>کاوش کل جدول‌های اسکیما {schema} در گراف گره‌ای</span>
            </Button>
          </div>
          <D3RelationshipVisualizer table={t} onSelectTable={onSelectTable} initialLayout="force" />
        </TabsContent>

        {/* ── TAB 5: DATABASE INDEXES ── */}
        <TabsContent value="indexes" className="mt-4 space-y-4">
          {t.indexes?.length > 0 ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-foreground">
                <span className="flex items-center gap-1.5">
                  <Gauge className="h-4 w-4 text-purple-400" />
                  ایندکس‌های فیزیکی دیتابیس
                </span>
                <span className="font-mono text-muted-foreground">({t.indexes.length} ایندکس)</span>
              </div>

              <div className="grid gap-2">
                {t.indexes.map((ix, i) => (
                  <div
                    key={i}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-sm border border-border bg-ink p-3 text-xs"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      {ix.is_pk ? (
                        <span className="rounded bg-amber-950/80 border border-amber-700/60 px-1.5 py-0.5 font-mono text-[10px] text-amber-300 font-bold">
                          PRIMARY KEY
                        </span>
                      ) : ix.unique ? (
                        <span className="rounded bg-sky-950/80 border border-sky-700/60 px-1.5 py-0.5 font-mono text-[10px] text-sky-300 font-bold">
                          UNIQUE
                        </span>
                      ) : (
                        <span className="rounded bg-emerald-950/80 border border-emerald-700/60 px-1.5 py-0.5 font-mono text-[10px] text-emerald-300 font-bold">
                          {ix.type || "INDEX"}
                        </span>
                      )}

                      {ix.name && (
                        <span className="font-mono text-xs text-muted-foreground">
                          {ix.name}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[11px] text-muted-foreground">ستون‌ها:</span>
                      {(ix.columns || []).map((col, cIdx) => (
                        <span
                          key={cIdx}
                          className="rounded border border-border bg-surface px-1.5 py-0.5 font-mono text-xs text-brand font-medium"
                        >
                          {col}
                        </span>
                      ))}
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText((ix.columns || []).join(", "));
                          toast.success("ستون‌های ایندکس کپی شدند.");
                        }}
                        className="p-1 text-muted-foreground hover:text-foreground rounded"
                        title="کپی نام ستون‌های ایندکس"
                      >
                        <Copy className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="rounded-sm border border-border bg-ink/40 p-4 text-center text-xs text-muted-foreground">
              هیچ ایندکس اختصاصی برای این جدول در متادیتا ثبت نشده است.
            </div>
          )}
        </TabsContent>

        {/* ── TAB 6: LOOKUP ENUMS (ONLY IF TABLE HAS ENUMS) ── */}
        {hasEnums && (
          <TabsContent value="enums" className="mt-4 space-y-3">
            <div className="rounded-md border border-border bg-surface p-3 shadow-sm space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <TableProperties className="h-4 w-4 text-pink-400" />
                  <h4 className="text-sm font-semibold text-foreground">
                    واژه‌نامه و مقادیر کدهای جدول (Lookup Enums)
                  </h4>
                </div>
                <div className="relative sm:w-64">
                  <Input
                    value={enumFilter}
                    onChange={(e) => setEnumFilter(e.target.value)}
                    placeholder="جستجو در مقادیر یا عنوان..."
                    className="h-7 text-xs rounded-sm border-border bg-ink pe-6"
                  />
                  {enumFilter && (
                    <button
                      onClick={() => setEnumFilter("")}
                      className="absolute end-1.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-2.5">
                {Object.entries(filteredEnums).map(([col, vals]) => (
                  <div key={col} className="rounded border border-border/70 bg-ink p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs font-bold text-brand">{col}</span>
                      <span className="text-[11px] text-muted-foreground">
                        {vals.length} مقدار معتبر
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {vals.map((v, i) => (
                        <span
                          key={i}
                          onClick={() => {
                            navigator.clipboard.writeText(String(v.value));
                            toast.success(`کد ${v.value} (${v.label_fa || ""}) کپی شد.`);
                          }}
                          className="cursor-pointer inline-flex items-center gap-1.5 rounded border border-border/80 bg-surface px-2 py-1 font-mono text-xs text-foreground hover:border-brand/50 hover:bg-surfaceHover transition-colors"
                          title="کلیک برای کپی مقدار در کلیپ‌بورد"
                        >
                          <span className="text-brand font-bold">{v.value}</span>
                          <span className="text-muted-foreground">=</span>
                          <span className="text-foreground font-sans font-medium">{v.label_fa || "—"}</span>
                          <Copy className="h-2.5 w-2.5 text-muted-foreground opacity-60" />
                        </span>
                      ))}
                    </div>
                  </div>
                ))}

                {Object.keys(filteredEnums).length === 0 && (
                  <div className="text-center py-4 text-xs text-muted-foreground">
                    موردی منطبق بر عبارت «{enumFilter}» یافت نشد.
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}

function TeachDialog({ table, onDone }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [meta, setMeta] = useState({ title_fa: "", description_fa: "", gotcha: "" });
  const [en, setEn] = useState({ column: "", value: "", label_fa: "" });
  const [jn, setJn] = useState({ from_col: "", to_table: "", to_col: "" });

  const post = (kind, payload) => http.post("/knowledge", { kind, payload });

  const hasInput =
    !!(meta.title_fa || meta.description_fa || meta.gotcha) ||
    !!(en.column && en.value && en.label_fa) ||
    !!(jn.from_col && jn.to_table && jn.to_col);

  const submit = async () => {
    setSaving(true);
    try {
      let did = 0;
      if (meta.title_fa || meta.description_fa || meta.gotcha) {
        await post("table", {
          full_name: table.full_name,
          title_fa: meta.title_fa || null,
          description_fa: meta.description_fa || null,
          gotcha: meta.gotcha || null,
        });
        did++;
      }
      if (en.column && en.value && en.label_fa) {
        await post("enum", { full_name: table.full_name, ...en });
        did++;
      }
      if (jn.from_col && jn.to_table && jn.to_col) {
        await post("join", { from_table: table.full_name, ...jn });
        did++;
      }
      if (did === 0) {
        toast.warning("چیزی برای ثبت وارد نشد.");
        return;
      }
      toast.success("دانش ثبت شد. برای فعال‌سازی، «بازسازی ایندکس» را بزنید.");
      setOpen(false);
      setMeta({ title_fa: "", description_fa: "", gotcha: "" });
      setEn({ column: "", value: "", label_fa: "" });
      setJn({ from_col: "", to_table: "", to_col: "" });
      onDone?.();
    } catch (e) {
      toast.error("خطا در ثبت: " + (e.response?.data?.detail || e.message));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          data-testid="teach-btn"
          size="sm"
          variant="outline"
          className="shrink-0 gap-1.5 rounded-sm border-brand/40 bg-brand/10 text-brand hover:bg-brand/20 text-xs font-semibold"
        >
          <GraduationCap className="h-4 w-4" /> بهبود دانش
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg rounded-sm border-border bg-surface" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-start font-mono text-brand text-base">{table.full_name}</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="meta" dir="rtl">
          <TabsList className="grid w-full grid-cols-3 rounded-sm bg-ink">
            <TabsTrigger value="meta" data-testid="teach-tab-meta">معنی جدول</TabsTrigger>
            <TabsTrigger value="enum" data-testid="teach-tab-enum">مقدار Enum</TabsTrigger>
            <TabsTrigger value="join" data-testid="teach-tab-join">مسیر JOIN</TabsTrigger>
          </TabsList>
          <TabsContent value="meta" className="space-y-3 pt-3">
            <TField label="عنوان فارسی">
              <Input
                data-testid="teach-title"
                value={meta.title_fa}
                onChange={(e) => setMeta({ ...meta, title_fa: e.target.value })}
                className="rounded-sm border-border bg-ink text-sm"
                placeholder="مثلاً سند حسابداری"
              />
            </TField>
            <TField label="توضیح">
              <Textarea
                data-testid="teach-desc"
                value={meta.description_fa}
                onChange={(e) => setMeta({ ...meta, description_fa: e.target.value })}
                className="min-h-[60px] rounded-sm border-border bg-ink text-sm"
                placeholder="کاربرد این جدول…"
              />
            </TField>
            <TField label="نکتهٔ مهم (Gotcha)">
              <Input
                data-testid="teach-gotcha"
                value={meta.gotcha}
                onChange={(e) => setMeta({ ...meta, gotcha: e.target.value })}
                className="rounded-sm border-border bg-ink text-sm"
                placeholder="مثلاً همیشه با سال مالی فیلتر شود"
              />
            </TField>
          </TabsContent>
          <TabsContent value="enum" className="space-y-3 pt-3">
            <TField label="ستون">
              <Input
                data-testid="teach-enum-col"
                value={en.column}
                onChange={(e) => setEn({ ...en, column: e.target.value })}
                className="rounded-sm border-border bg-ink font-mono text-sm"
                placeholder="State"
                dir="ltr"
              />
            </TField>
            <div className="grid grid-cols-2 gap-2">
              <TField label="کد">
                <Input
                  data-testid="teach-enum-val"
                  value={en.value}
                  onChange={(e) => setEn({ ...en, value: e.target.value })}
                  className="rounded-sm border-border bg-ink font-mono text-sm"
                  placeholder="2"
                  dir="ltr"
                />
              </TField>
              <TField label="معنی فارسی">
                <Input
                  data-testid="teach-enum-label"
                  value={en.label_fa}
                  onChange={(e) => setEn({ ...en, label_fa: e.target.value })}
                  className="rounded-sm border-border bg-ink text-sm"
                  placeholder="قطعی"
                />
              </TField>
            </div>
          </TabsContent>
          <TabsContent value="join" className="space-y-3 pt-3">
            <TField label="ستون این جدول">
              <Input
                data-testid="teach-join-from"
                value={jn.from_col}
                onChange={(e) => setJn({ ...jn, from_col: e.target.value })}
                className="rounded-sm border-border bg-ink font-mono text-sm"
                placeholder="AccountRef"
                dir="ltr"
              />
            </TField>
            <div className="grid grid-cols-2 gap-2">
              <TField label="جدول مقصد">
                <Input
                  data-testid="teach-join-table"
                  value={jn.to_table}
                  onChange={(e) => setJn({ ...jn, to_table: e.target.value })}
                  className="rounded-sm border-border bg-ink font-mono text-sm"
                  placeholder="FIN3.Account"
                  dir="ltr"
                />
              </TField>
              <TField label="ستون مقصد">
                <Input
                  data-testid="teach-join-col"
                  value={jn.to_col}
                  onChange={(e) => setJn({ ...jn, to_col: e.target.value })}
                  className="rounded-sm border-border bg-ink font-mono text-sm"
                  placeholder="AccountID"
                  dir="ltr"
                />
              </TField>
            </div>
          </TabsContent>
        </Tabs>
        <DialogFooter>
          <Button
            data-testid="teach-submit"
            onClick={submit}
            disabled={saving || !hasInput}
            className="w-full gap-1.5 rounded-sm bg-brand hover:bg-brand/90 text-white"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <GraduationCap className="h-4 w-4" />}
            ثبت دانش
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function TField({ label, children }) {
  return (
    <div>
      <Label className="mb-1 block text-[11px] text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
