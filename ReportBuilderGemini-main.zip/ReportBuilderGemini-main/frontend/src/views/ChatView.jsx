import { useEffect, useRef, useState } from "react";
import { http, streamPost } from "@/lib/api";
import { SqlBlock, Sev, ViewHeader, CategoryPicker } from "@/views/shared";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import RdlProgressCard from "@/components/RdlProgressCard";
import { PlanEditorModal } from "@/components/PlanEditorModal";
import {
  Send,
  Loader2,
  Table2,
  ListChecks,
  FileDown,
  Sparkles,
  Layers,
  History,
  Plus,
  Trash2,
  FileCode2,
  FileText,
  Save,
  SlidersHorizontal,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
} from "lucide-react";

const SAMPLES = [
  "لیست اسناد حسابداری با شماره، تاریخ و شرح",
  "جمع مبلغ بدهکار و بستانکار هر حساب در سال مالی",
  "گزارش موجودی کالا در انبارها",
  "لیست پرداختی حقوق کارکنان به تفکیک ماه",
];

const STEP_LABEL = {
  header: "سرستون",
  group_header: "عنوان گروه",
  detail: "جزئیات",
  group_total: "جمع گروه",
  grand_total: "جمع کل",
};

function Bubble({ role, children }) {
  const user = role === "user";
  return (
    <div className={`flex ${user ? "justify-start" : "justify-start"} rc-fade-up`}>
      <div
        className={`w-full ${user ? "border-brand/40 bg-brand/10" : "border-border bg-surface"} rounded-sm border p-3`}
      >
        <div className="mb-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          {user ? "درخواست شما" : "دستیار"}
        </div>
        {children}
      </div>
    </div>
  );
}

export default function ChatView({ health, onCost, onMenu, seed, onSeedConsumed }) {
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [msgs, setMsgs] = useState([]); // {role, ...}
  const [showHistory, setShowHistory] = useState(false);
  const scRef = useRef(null);

  useEffect(() => {
    if (seed) {
      setInput(seed);
      onSeedConsumed?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seed]);

  const loadSessions = async () => {
    try {
      const { data } = await http.get("/sessions");
      setSessions(data.sessions || []);
    } catch {}
  };
  useEffect(() => {
    loadSessions();
  }, []);
  useEffect(() => {
    if (scRef.current) scRef.current.scrollTop = scRef.current.scrollHeight;
  }, [msgs]);

  const openSession = async (sid) => {
    setSessionId(sid);
    setShowHistory(false);
    try {
      const { data } = await http.get(`/sessions/${sid}`);
      const restored = [];
      const turns = Array.isArray(data?.turns)
        ? data.turns
        : Array.isArray(data?.messages)
        ? data.messages
        : [];
      for (const t of turns) {
        if (t.role === "user") {
          restored.push({ role: "user", text: t.content || t.text || t.request || "" });
        } else {
          restored.push({
            role: "assistant",
            done: t.done || t.meta || null,
            tables: t.tables || t.meta?.tables || t.done?.tables || [],
            attempts: t.attempts || [],
            validation: t.validation || null,
          });
        }
      }
      setMsgs(restored);
    } catch (err) {
      console.error("Failed to restore session:", err);
    }
  };

  const newChat = () => {
    setSessionId(null);
    setMsgs([]);
    setInput("");
  };

  const delSession = async (sid, e) => {
    e.stopPropagation();
    await http.delete(`/sessions/${sid}`);
    if (sid === sessionId) newChat();
    loadSessions();
  };

  const send = async (text) => {
    const req = (text ?? input).trim();
    if (!req || busy) return;
    setBusy(true);
    setInput("");
    setMsgs((m) => [...m, { role: "user", text: req }]);
    const idx = { current: null };
    setMsgs((m) => {
      idx.current = m.length;
      return [...m, { role: "assistant", tables: [], attempts: [], validation: null, done: null }];
    });

    const patch = (fn) =>
      setMsgs((m) => m.map((x, i) => (i === idx.current ? fn(x) : x)));

    try {
      await streamPost(
        "/chat",
        { request: req, session_id: sessionId },
        (event, data) => {
          if (event === "start") setSessionId(data.session_id);
          else if (event === "tables") patch((x) => ({ ...x, tables: data.tables }));
          else if (event === "attempt")
            patch((x) => ({ ...x, attempts: [...(x.attempts || []), data] }));
          else if (event === "validation") patch((x) => ({ ...x, validation: data.issues }));
          else if (event === "done") patch((x) => ({ ...x, done: data }));
        },
      );
      loadSessions();
      onCost?.();
    } catch (e) {
      toast.error("خطا در تولید گزارش: " + (e.message || ""));
      patch((x) => ({ ...x, error: e.message }));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <ViewHeader
        title="گفتگو با دستیار"
        subtitle="درخواست گزارش را به زبان فارسی بنویسید؛ خروجی SQL دقیق و فایل RDL دریافت کنید."
        onMenu={onMenu}
      >
        <Button
          data-testid="mobile-history-btn"
          variant="outline"
          size="sm"
          onClick={() => setShowHistory(true)}
          className="gap-1.5 rounded-sm border-border bg-surface lg:hidden"
        >
          <History className="h-4 w-4" />
        </Button>
        <Button
          data-testid="new-chat-btn"
          variant="outline"
          size="sm"
          onClick={newChat}
          className="gap-1.5 rounded-sm border-border bg-surface"
        >
          <Plus className="h-4 w-4" /> <span className="hidden sm:inline">گفتگوی جدید</span>
        </Button>
      </ViewHeader>

      <div className="flex min-h-0 flex-1">
        {/* history strip (desktop) */}
        <div className="hidden w-56 shrink-0 flex-col border-s border-border bg-surface/40 lg:flex">
          <div className="flex items-center gap-1.5 border-b border-border px-3 py-2.5 text-xs text-muted-foreground">
            <History className="h-3.5 w-3.5" /> تاریخچه
          </div>
          <ScrollArea className="flex-1">
            <HistoryList
              sessions={sessions}
              sessionId={sessionId}
              openSession={openSession}
              delSession={delSession}
            />
          </ScrollArea>
        </div>

        {/* history overlay (mobile) */}
        {showHistory && (
          <div className="fixed inset-0 z-40 lg:hidden" data-testid="mobile-history-overlay">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowHistory(false)} />
            <div className="absolute inset-y-0 end-0 flex w-72 flex-col border-s border-border bg-surface rc-fade-up">
              <div className="flex items-center justify-between border-b border-border px-3 py-3 text-sm">
                <span className="flex items-center gap-1.5"><History className="h-4 w-4" /> تاریخچه گفتگوها</span>
                <button onClick={() => setShowHistory(false)} className="text-muted-foreground hover:text-white">
                  <Trash2 className="hidden" />بستن
                </button>
              </div>
              <ScrollArea className="flex-1">
                <HistoryList
                  sessions={sessions}
                  sessionId={sessionId}
                  openSession={openSession}
                  delSession={delSession}
                />
              </ScrollArea>
            </div>
          </div>
        )}

        {/* conversation */}
        <div className="flex min-w-0 flex-1 flex-col">
          <div ref={scRef} className="flex-1 space-y-4 overflow-y-auto p-6">
            {msgs.length === 0 && (
              <div className="mx-auto mt-6 max-w-2xl">
                <div className="mb-3 flex items-center gap-2 text-sm text-muted-foreground">
                  <Sparkles className="h-4 w-4 text-brand" /> نمونه درخواست‌ها
                </div>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {SAMPLES.map((s) => (
                    <button
                      key={s}
                      data-testid="sample-prompt"
                      onClick={() => send(s)}
                      className="rounded-sm border border-border bg-surface p-3 text-start text-sm transition-colors hover:border-brand/50 hover:bg-surfaceHover"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {msgs.map((m, i) =>
              m.role === "user" ? (
                <Bubble key={`msg-user-${i}`} role="user">
                  <p className="text-sm leading-relaxed">{m.text}</p>
                </Bubble>
              ) : (
                <Bubble key={`msg-assistant-${i}`} role="assistant">
                  <AssistantBody m={m} />
                </Bubble>
              ),
            )}
          </div>

          {/* composer */}
          <div className="border-t border-border bg-surface/50 p-4">
            <div className="mx-auto flex max-w-3xl items-end gap-2">
              <Textarea
                data-testid="chat-input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    send();
                  }
                }}
                placeholder="مثلاً: گزارش گردش حساب‌ها در سال مالی جاری…"
                className="min-h-[52px] resize-none rounded-sm border-border bg-ink text-sm"
              />
              <Button
                data-testid="chat-submit-button"
                onClick={() => send()}
                disabled={busy || !input.trim()}
                className="h-[52px] shrink-0 gap-2 rounded-sm bg-brand px-5 hover:bg-brand/90"
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                ارسال
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function HistoryList({ sessions, sessionId, openSession, delSession }) {
  return (
    <div className="p-2">
      {sessions.length === 0 && (
        <p className="px-2 py-4 text-xs text-muted-foreground">گفتگویی ثبت نشده.</p>
      )}
      {sessions.map((s) => (
        <div
          key={s.id}
          onClick={() => openSession(s.id)}
          data-testid={`session-${s.id}`}
          className={`group mb-1 flex cursor-pointer items-center justify-between gap-1 rounded-sm px-2 py-2 text-xs transition-colors ${
            s.id === sessionId ? "bg-brand/15 text-white" : "text-muted-foreground hover:bg-surfaceHover"
          }`}
        >
          <span className="truncate">{s.title}</span>
          <Trash2
            data-testid={`del-session-${s.id}`}
            onClick={(e) => delSession(s.id, e)}
            className="h-3.5 w-3.5 shrink-0 opacity-60 hover:text-err lg:opacity-0 lg:group-hover:opacity-100"
          />
        </div>
      ))}
    </div>
  );
}

function AssistantBody({ m }) {
  const running = !m.done && !m.error;
  return (
    <div className="space-y-3">
      {/* timeline */}
      <div className="space-y-2 border-s-2 border-border ps-3">
        {m.tables?.length > 0 && (
          <Step icon={Table2} active={running && !m.attempts?.length} label="جدول‌های مرتبط شناسایی شد">
            <div className="flex flex-wrap gap-1">
              {m.tables.map((t, idx) => (
                <span key={`tbl-${t}-${idx}`} className="rounded-sm border border-border bg-ink px-1.5 py-0.5 font-mono text-[10px] text-slate-300">
                  {t}
                </span>
              ))}
            </div>
          </Step>
        )}
        {m.attempts?.map((a, i) => (
          <Step key={`attempt-${a.attempt ?? a.n ?? i}`} icon={Sparkles} label={`تلاش ${a.attempt ?? a.n ?? (i + 1)} — نقشهٔ کوئری از مدل`} />
        ))}
        {m.validation && (
          <Step icon={ListChecks} label="اعتبارسنجی نقشه">
            {m.validation.length === 0 ? (
              <Sev severity="success">بدون خطا</Sev>
            ) : (
              <div className="flex flex-wrap gap-1">
                {m.validation.map((v, i) => (
                  <Sev key={`val-${v.severity || "sev"}-${i}`} severity={v.severity}>{v.message}</Sev>
                ))}
              </div>
            )}
          </Step>
        )}
      </div>

      {running && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3.5 w-3.5 animate-spin" /> در حال پردازش…
        </div>
      )}
      {m.error && <Sev severity="error">{m.error}</Sev>}

      {m.done && <DoneBlock done={m.done} />}
    </div>
  );
}

function Step({ icon: Icon, label, active, children }) {
  return (
    <div className="relative rc-fade-up">
      <span
        className={`absolute -start-[19px] top-1 flex h-3 w-3 items-center justify-center rounded-full ${active ? "bg-brand rc-pulse" : "bg-border"}`}
      />
      <div className="flex items-center gap-1.5 text-[13px] text-white">
        <Icon className="h-3.5 w-3.5 text-brand" /> {label}
      </div>
      {children && <div className="mt-1.5">{children}</div>}
    </div>
  );
}

function DoneBlock({ done }) {
  const [activeDone, setActiveDone] = useState(done);
  const [isEditingPlan, setIsEditingPlan] = useState(false);
  const [safetyInfo, setSafetyInfo] = useState(done.safety || null);
  const [building, setBuilding] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stageIndex, setStageIndex] = useState(0);
  const [rdl, setRdl] = useState(null);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [category, setCategory] = useState("");
  const [categories, setCategories] = useState([]);
  const progressTimerRef = useRef(null);

  useEffect(() => {
    setActiveDone(done);
  }, [done]);

  useEffect(() => {
    http.get("/categories").then(({ data }) => setCategories(data.categories || [])).catch(() => {});
    return () => {
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
    };
  }, []);

  // Fetch pre-flight safety and slow query analysis
  useEffect(() => {
    if (activeDone.sql) {
      http
        .post("/check-sql-safety", { sql: activeDone.sql, plan: activeDone.plan })
        .then(({ data }) => setSafetyInfo(data))
        .catch(() => {});
    }
  }, [activeDone.sql, activeDone.plan]);

  const title = activeDone.plan?.intent_fa || "گزارش";

  const downloadText = (ext) => {
    const blob = new Blob([`-- ${title}\n\n${activeDone.sql}`], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `report.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`فایل .${ext} دانلود شد`);
  };

  const saveToLibrary = async () => {
    setSaving(true);
    try {
      await http.post("/save-report", {
        sql: activeDone.sql,
        plan: activeDone.plan,
        title_fa: title,
        category,
      });
      setSaved(true);
      toast.success(
        category
          ? `در فولدر «${category}» ثبت شد`
          : "در کتابخانه ثبت شد — در «کاتالوگ گزارش‌ها» ببینید",
      );
    } catch (e) {
      toast.error("خطا در ثبت: " + (e.response?.data?.detail || e.message));
    } finally {
      setSaving(false);
    }
  };

  const buildRdl = async () => {
    if (building) return;
    setBuilding(true);
    setError(null);
    setProgress(15);
    setStageIndex(0);

    if (progressTimerRef.current) clearInterval(progressTimerRef.current);

    const startTime = Date.now();
    progressTimerRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      if (elapsed < 350) {
        setProgress(20);
        setStageIndex(0);
      } else if (elapsed < 750) {
        setProgress(45);
        setStageIndex(1);
      } else if (elapsed < 1150) {
        setProgress(70);
        setStageIndex(2);
      } else if (elapsed < 1550) {
        setProgress(90);
        setStageIndex(3);
      }
    }, 120);

    try {
      const [response] = await Promise.all([
        http.post("/rdl", {
          plan: activeDone.plan,
          layout: activeDone.layout,
          title_fa: title,
          filename: "report.rdl",
        }),
        new Promise((resolve) => setTimeout(resolve, 1400)),
      ]);

      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
      setProgress(100);
      setStageIndex(4);
      setRdl(response.data);

      if (response.data?.ok) {
        toast.success("فایل RDL با موفقیت ساخته و اعتبارسنجی شد");
      } else {
        toast.warning("RDL ساخته شد ولی دارای هشدارهایی است");
      }
    } catch (e) {
      if (progressTimerRef.current) clearInterval(progressTimerRef.current);
      const msg = e.response?.data?.detail || e.message || "خطا در ساخت RDL";
      setError(msg);
      toast.error("خطا در ساخت RDL: " + msg);
    } finally {
      setBuilding(false);
    }
  };

  if (!activeDone.ok) {
    return <Sev severity="error">نقشهٔ معتبری ساخته نشد. درخواست را دقیق‌تر بنویسید.</Sev>;
  }

  return (
    <div className="space-y-3 rc-fade-up">
      {/* Pre-flight Security & Slow Query Inspection Badge */}
      {safetyInfo && (
        <div
          onClick={() => setIsEditingPlan(true)}
          className={`cursor-pointer flex flex-wrap items-center justify-between gap-2 rounded-sm border p-2.5 text-xs transition-colors ${
            !safetyInfo.is_safe
              ? "border-red-500/50 bg-red-950/30 text-red-300 hover:bg-red-950/40"
              : safetyInfo.has_slow_query_risks
              ? "border-amber-500/40 bg-amber-950/20 text-amber-300 hover:bg-amber-950/30"
              : "border-emerald-500/30 bg-emerald-950/20 text-emerald-300 hover:bg-emerald-950/30"
          }`}
          title="جهت بررسی و ویرایش نقشه کلیک کنید"
        >
          <div className="flex items-center gap-2">
            {!safetyInfo.is_safe ? (
              <ShieldAlert className="h-4 w-4 text-red-400 shrink-0" />
            ) : safetyInfo.has_slow_query_risks ? (
              <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0" />
            ) : (
              <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
            )}
            <span className="font-semibold">{safetyInfo.summary_fa}</span>
          </div>

          <span className="text-[11px] underline opacity-90 flex items-center gap-1 font-medium">
            <SlidersHorizontal className="h-3.5 w-3.5" /> ویرایش نقشه و بررسی ایمنی
          </span>
        </div>
      )}

      <SqlBlock sql={activeDone.sql} />

      {activeDone.plan?.notes?.length > 0 && (
        <div className="rounded-sm border border-info/30 bg-info/5 p-2.5">
          <div className="mb-1 flex items-center gap-1.5 text-xs font-semibold text-info">
            <Layers className="h-3.5 w-3.5" /> نکته‌های مدل
          </div>
          <ul className="list-disc space-y-1 pe-4 text-xs text-slate-300">
            {activeDone.plan.notes.map((n, i) => (
              <li key={`note-${i}`}>{n}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
        <span>چیدمان: <b className="text-foreground font-semibold">{activeDone.layout?.kind || "table"}</b></span>
        <span>توکن: <span className="font-mono text-foreground">{(activeDone.usage?.in || 0) + (activeDone.usage?.out || 0)}</span></span>
        <span>هزینه: <span className="font-mono text-foreground">${activeDone.cost_usd || 0}</span></span>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button
          data-testid="edit-plan-btn"
          size="sm"
          variant="outline"
          onClick={() => setIsEditingPlan(true)}
          className="gap-1.5 rounded-sm border-brand/50 bg-brand/10 text-brand hover:bg-brand/20 font-semibold"
        >
          <SlidersHorizontal className="h-4 w-4 text-brand" /> ویرایش نقشه و چیدمان
        </Button>
        <Button data-testid="download-sql-btn" size="sm" variant="outline" onClick={() => downloadText("sql")} className="gap-1.5 rounded-sm border-border bg-surface">
          <FileCode2 className="h-4 w-4" /> دانلود ‎.sql
        </Button>
        <Button data-testid="download-txt-btn" size="sm" variant="outline" onClick={() => downloadText("txt")} className="gap-1.5 rounded-sm border-border bg-surface">
          <FileText className="h-4 w-4" /> دانلود ‎.txt
        </Button>
        <Button data-testid="save-library-btn" size="sm" variant="outline" onClick={saveToLibrary} disabled={saving || saved} className="gap-1.5 rounded-sm border-ok/40 bg-ok/10 text-ok hover:bg-ok/20">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {saved ? "ثبت شد" : "ثبت در کتابخانه"}
        </Button>
        <CategoryPicker categories={categories} value={category} onChange={setCategory} testid="chat-cat" />
      </div>

      {/* Plan Editor Modal */}
      <PlanEditorModal
        isOpen={isEditingPlan}
        onClose={() => setIsEditingPlan(false)}
        initialPlan={activeDone.plan}
        initialLayout={activeDone.layout}
        onApply={(newPlan, newLayout, newSql) => {
          setActiveDone((prev) => ({
            ...prev,
            plan: newPlan,
            layout: newLayout,
            sql: newSql || prev.sql,
          }));
        }}
      />

      {/* Modern Beautiful RDL Progress Bar and Generation Card */}
      <RdlProgressCard
        building={building}
        progress={progress}
        currentStageIndex={stageIndex}
        rdl={rdl}
        error={error}
        onBuild={buildRdl}
        onReset={() => {
          setRdl(null);
          setProgress(0);
          setStageIndex(0);
          setError(null);
        }}
      />
    </div>
  );
}
