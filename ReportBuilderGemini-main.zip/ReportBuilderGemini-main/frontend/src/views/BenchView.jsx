import { useState } from "react";
import { streamPost } from "@/lib/api";
import { ViewHeader, Sev } from "@/views/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Scale, Loader2, Trophy, CheckCircle2, XCircle } from "lucide-react";

const MODELS = [
  { id: "emergent", label: "Emergent · Claude" },
  { id: "emergent-gpt", label: "Emergent · GPT" },
  { id: "emergent-gemini", label: "Emergent · Gemini" },
  { id: "claude", label: "Claude (کلید شخصی)" },
  { id: "gpt", label: "GPT (کلید شخصی)" },
  { id: "deepseek", label: "DeepSeek" },
  { id: "gemini", label: "Gemini" },
  { id: "ollama", label: "Ollama (محلی)" },
];

export default function BenchView({ health, onMenu }) {
  const [selected, setSelected] = useState(["emergent", "emergent-gpt"]);
  const [req, setReq] = useState("لیست اسناد حسابداری با شماره، تاریخ و شرح");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(null);
  const [result, setResult] = useState(null);

  const toggle = (id) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const run = async () => {
    if (selected.length === 0) return toast.error("حداقل یک مدل را انتخاب کنید");
    setBusy(true);
    setResult(null);
    setProgress(null);
    try {
      await streamPost(
        "/bench",
        { models: selected, requests: [req] },
        (event, data) => {
          if (event === "progress") setProgress(data);
          else if (event === "done") setResult(data);
        },
      );
      toast.success("محک کامل شد");
    } catch (e) {
      toast.error("خطا در محک: " + (e.message || ""));
    } finally {
      setBusy(false);
      setProgress(null);
    }
  };

  return (
    <>
      <ViewHeader
        title="محک چندمدلی"
        subtitle="یک درخواست را روی چند مدل اجرا کنید و ببینید همه به یک SQL می‌رسند یا نه."
        onMenu={onMenu}
      />
      <div className="flex-1 overflow-y-auto p-6">
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="space-y-3 lg:col-span-1">
            <div className="rounded-sm border border-border bg-surface p-3">
              <div className="mb-2 text-xs font-semibold text-muted-foreground">مدل‌ها</div>
              <div className="space-y-1.5">
                {MODELS.map((m) => {
                  const on = selected.includes(m.id);
                  return (
                    <button
                      key={m.id}
                      data-testid={`bench-model-${m.id}`}
                      onClick={() => toggle(m.id)}
                      className={`flex w-full items-center justify-between rounded-sm border px-2.5 py-2 text-xs transition-colors ${
                        on ? "border-brand/50 bg-brand/10 text-white" : "border-border text-muted-foreground hover:bg-surfaceHover"
                      }`}
                    >
                      {m.label}
                      <span className={`h-3 w-3 rounded-full border ${on ? "border-brand bg-brand" : "border-border"}`} />
                    </button>
                  );
                })}
              </div>
            </div>

            <Input
              data-testid="bench-request"
              value={req}
              onChange={(e) => setReq(e.target.value)}
              className="rounded-sm border-border bg-ink text-sm"
              placeholder="درخواست گزارش…"
            />
            <Button
              data-testid="bench-run-btn"
              onClick={run}
              disabled={busy}
              className="w-full gap-2 rounded-sm bg-brand hover:bg-brand/90"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Scale className="h-4 w-4" />}
              اجرای محک
            </Button>
            {progress && (
              <div className="rounded-sm border border-border bg-surface p-2 font-mono text-[11px] text-muted-foreground">
                {progress.done}/{progress.total} · {progress.model}
              </div>
            )}
          </div>

          <div className="lg:col-span-2">
            {!result ? (
              <div className="flex h-64 items-center justify-center rounded-sm border border-dashed border-border text-sm text-muted-foreground">
                نتیجهٔ محک این‌جا نمایش داده می‌شود.
              </div>
            ) : (
              <div className="space-y-4 rc-fade-up">
                {result.scoreboard && (
                  <div className="overflow-hidden rounded-sm border border-border">
                    <div className="flex items-center gap-1.5 border-b border-border bg-surface px-3 py-2 text-xs font-semibold">
                      <Trophy className="h-3.5 w-3.5 text-warn" /> جدول امتیاز
                    </div>
                    <table className="w-full border-collapse text-xs">
                      <thead>
                        <tr className="bg-surface/50 text-muted-foreground">
                          <th className="border-b border-border px-2 py-1.5 text-start">مدل</th>
                          <th className="border-b border-border px-2 py-1.5 text-start">موفق</th>
                          <th className="border-b border-border px-2 py-1.5 text-start">میانگین تلاش</th>
                          <th className="border-b border-border px-2 py-1.5 text-start">زمان</th>
                          <th className="border-b border-border px-2 py-1.5 text-start">توکن</th>
                          <th className="border-b border-border px-2 py-1.5 text-start">هم‌نظری</th>
                        </tr>
                      </thead>
                      <tbody>
                        {result.scoreboard.map((r, i) => (
                          <tr key={i} className="hover:bg-surfaceHover">
                            <td className="border-b border-border px-2 py-1 font-mono text-brand">{r.model}</td>
                            <td className="border-b border-border px-2 py-1 font-mono">{r.success}</td>
                            <td className="border-b border-border px-2 py-1 font-mono">{r.avg_attempts}</td>
                            <td className="border-b border-border px-2 py-1 font-mono">{r.avg_seconds}s</td>
                            <td className="border-b border-border px-2 py-1 font-mono">{r.tokens}</td>
                            <td className="border-b border-border px-2 py-1 font-mono">{r.agreement}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {result.cases?.map((c, i) => (
                  <div key={i} className="rounded-sm border border-border bg-surface p-3">
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm font-semibold">{c.case}</span>
                      <Sev severity={c.consensus?.[0] > 0 && c.consensus?.[0] === c.consensus?.[1] ? "success" : "warning"}>
                        {c.consensus?.[0] > 0 && c.consensus?.[0] === c.consensus?.[1]
                          ? "≡ اجماع کامل"
                          : `≠ ${c.consensus?.[0] ?? 0} از ${c.consensus?.[1] ?? 0}`}
                      </Sev>
                    </div>
                    <div className="grid gap-2 sm:grid-cols-2">
                      {c.runs?.map((run, j) => (
                        <div key={j} className={`rounded-sm border p-2 ${run.ok ? "border-ok/30 bg-ok/5" : "border-err/30 bg-err/5"}`}>
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-mono text-brand">{run.model}</span>
                            {run.ok ? <CheckCircle2 className="h-4 w-4 text-ok" /> : <XCircle className="h-4 w-4 text-err" />}
                          </div>
                          <div className="mt-1 font-mono text-[10px] text-muted-foreground">
                            {run.attempts} تلاش · {run.seconds}s · {(run.tokens_in || 0) + (run.tokens_out || 0)} توکن
                          </div>
                          {run.error && <div className="mt-1 text-[10px] text-err">{run.error}</div>}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
