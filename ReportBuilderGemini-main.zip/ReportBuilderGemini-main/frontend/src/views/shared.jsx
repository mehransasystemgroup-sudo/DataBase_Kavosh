import { useState } from "react";
import { Copy, Check, Menu, FolderPlus, Folder } from "lucide-react";
import { toast } from "sonner";
import ThemeToggle from "@/components/ThemeToggle";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function SqlBlock({ sql, title = "SQL تولیدشده", testid = "sql-block" }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    await navigator.clipboard.writeText(sql || "");
    setCopied(true);
    toast.success("SQL کپی شد");
    setTimeout(() => setCopied(false), 1400);
  };
  return (
    <div className="overflow-hidden rounded-sm border border-border bg-ink" data-testid={testid}>
      <div className="flex items-center justify-between border-b border-border bg-surface px-3 py-1.5">
        <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
          {title}
        </span>
        <button
          onClick={copy}
          data-testid={`${testid}-copy`}
          className="flex items-center gap-1.5 rounded-sm px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-surfaceHover hover:text-white"
        >
          {copied ? <Check className="h-3.5 w-3.5 text-ok" /> : <Copy className="h-3.5 w-3.5" />}
          کپی
        </button>
      </div>
      <pre className="sql-block overflow-x-auto p-3 text-[12.5px] leading-6 text-slate-200">
        <code>{sql}</code>
      </pre>
    </div>
  );
}

const SEV = {
  error: "bg-err/10 text-err border-err/40",
  warning: "bg-warn/10 text-warn border-warn/40",
  info: "bg-info/10 text-info border-info/40",
  success: "bg-ok/10 text-ok border-ok/40",
};

export function Sev({ severity = "info", children }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-sm border px-1.5 py-0.5 font-mono text-[10px] ${SEV[severity] || SEV.info}`}
    >
      {children}
    </span>
  );
}

export function CategoryPicker({ categories = [], value = "", onChange, testid = "category-picker", compact = false }) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const names = categories.map((c) => c.name).filter(Boolean);

  const pick = (name) => {
    onChange?.(name);
    setOpen(false);
    setDraft("");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          data-testid={`${testid}-trigger`}
          className={`flex items-center gap-1 rounded-sm border border-border bg-ink px-2 py-1 text-[11px] transition-colors hover:border-brand/50 hover:text-brand ${compact ? "" : ""}`}
        >
          <Folder className="h-3 w-3" />
          {value || "بدون دسته"}
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-sm rounded-sm border-border bg-surface" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-start text-sm">انتخاب یا ساخت فولدر</DialogTitle>
        </DialogHeader>
        <div className="flex gap-2">
          <Input
            data-testid={`${testid}-input`}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && draft.trim() && pick(draft.trim())}
            placeholder="نام فولدر جدید (مثلاً مالی، انبار، حقوق)…"
            className="rounded-sm border-border bg-ink text-sm"
          />
          <Button
            data-testid={`${testid}-create`}
            onClick={() => draft.trim() && pick(draft.trim())}
            disabled={!draft.trim()}
            className="shrink-0 gap-1 rounded-sm bg-brand hover:bg-brand/90"
          >
            <FolderPlus className="h-4 w-4" /> ساخت
          </Button>
        </div>
        <div className="flex flex-wrap gap-1.5 pt-1">
          <button
            data-testid={`${testid}-none`}
            onClick={() => pick("")}
            className="rounded-sm border border-border bg-ink px-2 py-1 text-xs text-muted-foreground hover:border-brand/50"
          >
            بدون دسته
          </button>
          {names.map((n) => (
            <button
              key={n}
              data-testid={`${testid}-opt-${n}`}
              onClick={() => pick(n)}
              className={`rounded-sm border px-2 py-1 text-xs transition-colors ${
                value === n ? "border-brand bg-brand/10 text-brand" : "border-border bg-ink hover:border-brand/50"
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function ViewHeader({ title, subtitle, banner, onMenu, hideThemeToggle = false, children }) {
  return (
    <div
      className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-xl sm:px-6 sm:py-4"
      style={
        banner
          ? {
              backgroundImage: `linear-gradient(90deg, rgba(9,10,12,0.94), rgba(9,10,12,0.72)), url(${banner})`,
              backgroundSize: "cover",
            }
          : undefined
      }
    >
      <div className="flex min-w-0 items-center gap-2">
        {onMenu && (
          <button
            data-testid="open-menu-btn"
            onClick={onMenu}
            className="shrink-0 rounded-sm p-1.5 text-muted-foreground hover:bg-surfaceHover hover:text-foreground lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>
        )}
        <div className="min-w-0">
          <h2 className="truncate text-lg font-black tracking-tight sm:text-xl">{title}</h2>
          {subtitle && (
            <p className="mt-0.5 hidden truncate text-xs text-muted-foreground sm:block">
              {subtitle}
            </p>
          )}
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        {children}
        {!hideThemeToggle && <ThemeToggle />}
      </div>
    </div>
  );
}
