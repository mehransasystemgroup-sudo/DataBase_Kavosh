# PRD — گزارش‌ساز هوشمند (AI SSRS Report Copilot)

## Original Problem Statement
User (Persian) already built, with Claude, a personalized assistant that generates & fixes reports based on their ERP database (financial / admin / warehouse / payroll). They provided the full existing Python tool (`report-copilot-FINAL-v2.zip`) + a `.skill` knowledge pack. Ask: as a full-stack developer, turn it into a complete, professional, flawless web application so they can plug in various AI model APIs and get accurate output.

## Architecture
- **Backend**: FastAPI at `/app/backend/server.py` (thin bootstrap) importing the reused engine package `/app/backend/rc/` (core/, app/server.py, kb/, scripts/, instances/). All routes under `/api`.
  - Knowledge base: read-only SQLite index `/app/backend/rc/index/kb.sqlite` built from `kb/` YAML (3,428 tables · 40,787 columns · 11,626 joins · 1,080 Persian titles · 1,565 enums).
  - App state (sessions/settings/encrypted secrets) in `RC_HOME=/app/backend/rc_data` (engine's own SQLite/JSON stores).
  - Model-agnostic agent loop: search tables → describe → model returns JSON QueryPlan → deterministic validation vs KB → self-correct → assemble T-SQL → derive RDL layout.
- **AI providers**: `rc/core/providers.py` — Anthropic, OpenAI-compatible (GPT/DeepSeek/Ollama/LM Studio/OpenRouter), Google, and **EmergentProvider** (universal key via `emergentintegrations`). Presets: `emergent`(Claude), `emergent-gpt`, `emergent-gemini`, plus personal-key presets.
- **Frontend**: React (CRA) fully Persian RTL, dark "IDE console" theme (Vazirmatn + JetBrains Mono). Views: Chat (SSE streaming), Knowledge Explorer, Multi-model Benchmark, Report Catalog, Settings.

## User Persona
Single technical operator/report author for a Persian ERP. No authentication (internal tool).

## Core Requirements (static)
1. Persian natural-language → validated SQL personalized to the real ERP schema.
2. Generate downloadable SSRS **.rdl** files honoring the org's report profile (system params, number format, page size).
3. Support plugging in multiple AI models + compare them (benchmark).
4. Explore the 40k-column knowledge base.

## Implemented (2026-06)
- Reused the entire 5,200-line engine; built KB index; wired Emergent universal key + personal keys.
- Chat with live SSE timeline (tables → attempts → validation → SQL + layout), RDL build & download.
- Knowledge Base explorer (search all/with-data, table detail: columns, PK, enums, FK join paths, warnings).
- Multi-model benchmark with consensus/scoreboard (SSE progress).
- Report catalog + Settings (model preset, personal API keys, base URL, override model, daily budget, self-correct attempts, test-connection).
- Fix: `SecretStore.get` now maps `emergent→EMERGENT_LLM_KEY` (bench for Emergent presets).

## Iteration 2 (2026-06) — Responsive + Knowledge Improvement
- **Fully responsive**: mobile drawer nav (hamburger per view), collapsible sidebar; mobile chat-history overlay; KB list/detail stacking with back button; all views adapt 390px→desktop.
- **Knowledge improvement flow** (user-emphasized): `TeachDialog` in KB detail records table meaning / enum labels / JOIN paths (`POST /api/knowledge`), plus header **rebuild-index** button. Added `KnowledgeBase.reload()` so rebuilt index applies LIVE without server restart; rebuild falls back to `dev-fixture`.
- **Catalog lessons**: add lessons to saved reports inline.
- **Chat history**: restore/delete verified.
- Verified by testing agent: backend 20/20 pytest, frontend 100% at mobile 390px AND desktop 1440px. KB test artifacts cleaned; base restored to pristine.

## Backlog / Remaining
- **P1**: Live SQL Server connection (real `table-stats.yaml` + query execution) — deferred by user.
- **P1**: Subreport (زیرگزارش) generation with Persian paths & parameter passing.
- **P2**: Learn org RDL profile from uploaded .rdl files via UI (`/api/profile/learn` exists; needs upload UI).
- **P2**: Persist sessions/settings in MongoDB instead of engine SQLite (platform alignment).
- **P2**: SQL result preview once a live DB is connected.

## Iteration 3–4 (2026-06) — Save formats + Upload & curate knowledge
- **Save reports in 2 formats**: chat result block → download `.sql` / `.txt` (client Blob) + «ثبت در کتابخانه» (`POST /api/save-report` → catalog + `.sql` file) + build/download `.rdl`. Catalog cards expose per-report download links `.sql`/`.txt`/`.rdl` (`GET /api/reports/{slug}/file/{fmt}`).
- **Upload & curate** (new «منابع و آپلود» view): `POST /api/upload` accepts `.rdl`/`.sql`/`.txt` (8MB cap, filename-collision safe), extracts referenced `SCHEMA.Table` matched to KB, plus RDL datasets/params/subreports. User manually adds each table's Persian title to knowledge (`/api/knowledge`), learns org RDL profile (`/api/profile/learn`), then rebuilds index (live-applied).
- Bug fixed & verified by testing agent: `/api/reports/{slug}/file/rdl` now 404 (not 500) when no RDL exists.
- Verified: backend 36/36 pytest; frontend 100% (desktop + mobile 390px). All TEST artifacts cleaned; KB/catalog/uploads restored pristine; index rebuilt.

## Iteration 5 (2026-06) — Report folders/categories + polish
- **Folders/categories** across Catalog + Sources: `CatalogEntry.category`; `catalog.save(category=)`, `save_raw()` (plan-less, for uploaded SQL/RDL), `set_category()`, `categories()`. Endpoints: `GET /api/categories`, `POST /api/reports/{slug}/category`, `GET /api/reports?category=`.
- Catalog view: folder sidebar (+ mobile chips) with counts, filter, per-card folder picker (create/select/clear), search box.
- Sources & Chat: destination-folder picker + «ذخیره در کتابخانه» (uploaded resources saved via `save_raw` land in catalog folders; chat results save with folder). Uploaded `.rdl` copied into OUT_DIR and attached for download.
- **Reuse-in-chat**: catalog card «استفاده مجدد» seeds the chat input (App-level `chatSeed`).
- Chat history retained (desktop strip + mobile overlay, restore/delete).
- Verified: backend 45/45 pytest; frontend 100% (desktop + mobile 390px); zero issues. All TEST artifacts cleaned; KB/catalog pristine; index rebuilt (3,428 tables).

## Next Tasks
- Awaiting user's `table-stats.yaml` → drop into `rc/instances/` (or set settings.instance) + rebuild to light up live `has_data` flags.
- Live SQL Server connector (query execution + row preview) when connection string provided.
- Subreport generation with Persian paths; batch multi-RDL profile learning.
